"use client";

import { useCallback, useEffect, useState } from "react";
import { usePlaidLink } from "react-plaid-link";
import { FiCheckCircle, FiLoader, FiShield } from "react-icons/fi";

type PlaidAccount = {
  id: string;
  name: string;
  official_name?: string | null;
  type: string;
  subtype?: string | null;
  mask?: string | null;
};

type PlaidBankConnectProps = {
  clientUserId: string;
  onConnected?: (data: {
    item_id: string;
    accounts: PlaidAccount[];
  }) => void;
};

export default function PlaidBankConnect({
  clientUserId,
  onConnected,
}: PlaidBankConnectProps) {
  const [linkToken, setLinkToken] = useState<string | null>(null);

  const [loadingToken, setLoadingToken] = useState(true);

  const [connecting, setConnecting] = useState(false);

  const [error, setError] = useState("");

  const [connected, setConnected] = useState(false);

  const createLinkToken = useCallback(
    async () => {
      try {
        setLoadingToken(true);
        setError("");

        const response = await fetch(
          "/api/plaid/create-link-token",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              client_user_id: clientUserId,
            }),
          },
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            data?.error ||
              "Unable to create Plaid connection.",
          );
        }

        if (!data?.link_token) {
          throw new Error(
            "Plaid did not return a link token.",
          );
        }

        setLinkToken(data.link_token);
      } catch (err) {
        console.error(err);

        setError(
          err instanceof Error
            ? err.message
            : "Unable to connect to Plaid.",
        );
      } finally {
        setLoadingToken(false);
      }
    },
    [clientUserId],
  );

  useEffect(() => {
    createLinkToken();
  }, [createLinkToken]);

  const handleSuccess = useCallback(
    async (publicToken: string | null) => {
      if (!publicToken) {
        setError(
          "Plaid did not return a valid bank connection token.",
        );
        setConnecting(false);
        return;
      }

      try {
        setConnecting(true);
        setError("");

        const response = await fetch(
          "/api/plaid/exchange-public-token",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              public_token: publicToken,
            }),
          },
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(
            data?.error ||
              "Unable to verify your bank account.",
          );
        }

        if (!data?.success) {
          throw new Error(
            "Bank account verification was not completed.",
          );
        }

        setConnected(true);

        onConnected?.({
          item_id: data.item_id,
          accounts: data.accounts || [],
        });
      } catch (err) {
        console.error(err);

        setError(
          err instanceof Error
            ? err.message
            : "Unable to verify the connected bank account.",
        );
      } finally {
        setConnecting(false);
      }
    },
    [onConnected],
  );

  const {
    open,
    ready,
  } = usePlaidLink({
    token: linkToken,
    onSuccess: handleSuccess,
    onExit: (exitError) => {
      if (exitError) {
        console.error(
          "Plaid Link exited:",
          exitError,
        );
      }

      setConnecting(false);
    },
  });

  function handleOpen() {
    setError("");

    if (!linkToken) {
      setError(
        "Plaid is still preparing the bank connection.",
      );
      return;
    }

    open();
  }

  if (connected) {
    return (
      <div className="rounded-2xl border border-emerald-400/20 bg-emerald-400/5 p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-400">
            <FiCheckCircle size={19} />
          </div>

          <div>
            <p className="text-sm font-black text-emerald-300">
              Bank connected
            </p>

            <p className="mt-1 text-xs text-gray-500">
              Your bank connection was successfully verified.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-yellow-400/20 bg-yellow-400/5 p-5">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-yellow-400/10 text-yellow-400">
          <FiShield size={19} />
        </div>

        <div className="flex-1">
          <p className="text-sm font-black">
            Connect your bank
          </p>

          <p className="mt-1 text-xs leading-5 text-gray-500">
            Securely search for your bank and connect your
            account through Plaid.
          </p>

          <button
            type="button"
            onClick={handleOpen}
            disabled={
              loadingToken ||
              connecting ||
              !ready ||
              !linkToken
            }
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-yellow-400 px-4 py-3 text-sm font-black text-black transition hover:bg-yellow-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loadingToken ? (
              <>
                <FiLoader
                  size={17}
                  className="animate-spin"
                />
                Preparing bank connection...
              </>
            ) : connecting ? (
              <>
                <FiLoader
                  size={17}
                  className="animate-spin"
                />
                Verifying bank...
              </>
            ) : (
              "Connect bank with Plaid"
            )}
          </button>

          {error && (
            <p className="mt-3 text-xs leading-5 text-red-300">
              {error}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}