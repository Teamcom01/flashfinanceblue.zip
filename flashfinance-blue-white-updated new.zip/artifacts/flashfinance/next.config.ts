import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  allowedDevOrigins: [
    process.env.REPLIT_DEV_DOMAIN ?? "*.replit.dev",
    "127.0.0.1",
  ],
};

export default nextConfig;
