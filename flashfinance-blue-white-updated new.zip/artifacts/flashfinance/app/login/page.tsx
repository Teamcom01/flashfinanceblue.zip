"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();

  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  function cleanPassword(value: string) {
    return value.replace(/\s/g, "");
  }

  function handlePasswordChange(value: string) {
    setPassword(cleanPassword(value));
  }

  function handlePasswordKeyDown(
    e: React.KeyboardEvent<HTMLInputElement>,
  ) {
    if (e.key === " ") {
      e.preventDefault();
    }
  }

  function handlePasswordPaste(
    e: React.ClipboardEvent<HTMLInputElement>,
  ) {
    e.preventDefault();

    const pastedText = e.clipboardData.getData("text");
    const cleanedText = cleanPassword(pastedText);

    setPassword((currentPassword) => currentPassword + cleanedText);
  }

  async function handleLogin(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setMessage("");

    const normalizedEmail = email.trim().toLowerCase();
    const cleanPassword = password.replace(/\s/g, "");

    if (!normalizedEmail || !cleanPassword) {
      setMessage("Please enter your email and password.");
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: cleanPassword,
      });

      if (error) {
        console.error("FlashFinance login error:", error);

        setMessage(
          error.message ||
            "Unable to log in. Please check your email and password.",
        );

        return;
      }

      if (!data.session) {
        setMessage(
          "Login was not completed. Please verify your email address and try again.",
        );

        return;
      }

      if (remember) {
        localStorage.setItem(
          "flashfinance_remember_email",
          normalizedEmail,
        );
      } else {
        localStorage.removeItem("flashfinance_remember_email");
      }

      router.push("/dashboard");
      router.refresh();
    } catch (error) {
      console.error("Unexpected FlashFinance login error:", error);

      setMessage(
        error instanceof Error
          ? error.message
          : "Something went wrong while logging in. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="ff-auth-page flex min-h-screen items-center justify-center !bg-[#F1F3F6] px-6 py-12 !text-[#111318]">
      <div className="w-full max-w-md">
        <div className="mb-10 text-center">
          <a href="/" className="text-3xl font-bold tracking-wide">
            <span className="!text-[#111318]">FLASH</span>
            <span className="!text-[#B51F35]">FINANCE</span>
          </a>

          <h1 className="mt-8 text-3xl font-bold !text-[#111318]">
            Welcome back
          </h1>

          <p className="mt-3 !text-[#69707D]">
            Login to your FlashFinance account
          </p>
        </div>

        <div className="rounded-[28px] !border !border-[#E2E5E9] !bg-white p-7 shadow-[0_10px_35px_rgba(0,0,0,0.07)]">
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label
                htmlFor="email"
                className="mb-2 block text-sm font-medium !text-[#252932]"
              >
                Email Address
              </label>

              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                disabled={loading}
                className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] disabled:cursor-not-allowed disabled:opacity-60"
              />
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between">
                <label
                  htmlFor="password"
                  className="block text-sm font-medium !text-[#252932]"
                >
                  Password
                </label>

                <a
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="text-xs font-semibold !text-[#B51F35] hover:!text-[#C9213A]"
                >
                  Forgot password?
                </a>
              </div>

              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) =>
                    handlePasswordChange(e.target.value)
                  }
                  onKeyDown={handlePasswordKeyDown}
                  onPaste={handlePasswordPaste}
                  placeholder="Enter your password"
                  disabled={loading}
                  spellCheck={false}
                  className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 pr-20 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] disabled:cursor-not-allowed disabled:opacity-60"
                />

                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={loading}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold !text-[#B51F35] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {showPassword ? "HIDE" : "SHOW"}
                </button>
              </div>

              <p className="mt-2 text-xs !text-[#9298A3]">
                Spaces are not allowed in passwords.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <input
                id="remember"
                name="remember"
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                disabled={loading}
                className="h-4 w-4 accent-[#B51F35]"
              />

              <label
                htmlFor="remember"
                className="text-sm !text-[#69707D]"
              >
                Remember me
              </label>
            </div>

            {message && (
              <div className="rounded-2xl border border-red-200 bg-red-50 p-3 text-sm leading-5 text-red-700">
                {message}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-[#B51F35] py-3.5 font-bold text-white shadow-sm transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>

          <p className="mt-7 text-center text-sm !text-[#69707D]">
            Don't have an account?{" "}
            <a
              href="/signup"
              className="font-semibold !text-[#B51F35] hover:!text-[#C9213A]"
            >
              Create an account
            </a>
          </p>
        </div>

        <div className="mt-6 text-center">
          <a
            href="/"
            className="text-sm !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            ← Back to FlashFinance
          </a>
        </div>
      </div>
    </main>
  );
}