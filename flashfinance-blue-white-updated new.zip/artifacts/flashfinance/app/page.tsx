"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  FiArrowDownLeft,
  FiArrowRight,
  FiArrowUpRight,
  FiBarChart2,
  FiCheckCircle,
  FiChevronDown,
  FiChevronRight,
  FiClock,
  FiCreditCard,
  FiDollarSign,
  FiHeart,
  FiHelpCircle,
  FiLock,
  FiMenu,
  FiPlus,
  FiSend,
  FiShield,
  FiSmartphone,
  FiTrendingUp,
  FiUserPlus,
  FiWifi,
  FiX,
  FiZap,
} from "react-icons/fi";

type InvestmentPlan = {
  name: string;
  roi: number;
  days: number;
  min: number;
  max: number;
  featured?: boolean;
};

const investmentPlans: InvestmentPlan[] = [
  {
    name: "Starter",
    roi: 2.5,
    days: 30,
    min: 500,
    max: 9999,
  },
  {
    name: "Pro",
    roi: 3.0,
    days: 30,
    min: 10000,
    max: 19999,
  },
  {
    name: "Elite",
    roi: 3.25,
    days: 60,
    min: 20000,
    max: 49999,
    featured: true,
  },
  {
    name: "Advanced",
    roi: 3.5,
    days: 60,
    min: 50000,
    max: 99999,
  },
  {
    name: "Premium",
    roi: 3.75,
    days: 60,
    min: 100000,
    max: 99999999,
  },
];

const faqs = [
  {
    question: "How do I create a FlashFinance account?",
    answer:
      "Create an account using the Sign Up button. After registration, you can log in and access your personal FlashFinance dashboard.",
  },
  {
    question: "How do I fund my account?",
    answer:
      "After signing in, open Add Money and choose an available funding method. Your deposit will appear in your account activity while it is being processed.",
  },
  {
    question: "How do investment plans work?",
    answer:
      "Investment plans have different minimum amounts, maximum amounts, terms and displayed sample rates. You can compare them before continuing to the investment flow.",
  },
  {
    question: "Can I track my investment?",
    answer:
      "The FlashFinance dashboard is designed to show portfolio value, active plans and investment activity once the investment backend is enabled.",
  },
  {
    question: "When can I withdraw?",
    answer:
      "Withdrawal availability depends on the applicable product terms. The platform will show the relevant information when the investment withdrawal feature is implemented.",
  },
  {
    question: "What happens after I submit a deposit?",
    answer:
      "Your deposit can appear as pending in your account activity. Once it is reviewed, its status will change accordingly.",
  },
];

const sampleTransactions = [
  {
    name: "Mary",
    daysAgo: 0,
    amount: "$23,000.00",
    detail: "Investment return",
    type: "credit",
  },
  {
    name: "David",
    daysAgo: 1,
    amount: "$20,000.00",
    detail: "Investment",
    type: "credit",
  },
  {
    name: "Sarah",
    daysAgo: 2,
    amount: "$5,250.00",
    detail: "Savings transfer",
    type: "credit",
  },
  {
    name: "Michael",
    daysAgo: 4,
    amount: "$650.00",
    detail: "Investment earnings",
    type: "credit",
  },
  {
    name: "Emma",
    daysAgo: 6,
    amount: "$1,200.00",
    detail: "Withdrawal",
    type: "debit",
  },
];

const blogPosts = [
  {
    title: "Building a better savings habit",
    category: "Savings",
    description:
      "Simple ways to organize your money and make saving part of your routine.",
  },
  {
    title: "Understanding investment plans",
    category: "Investing",
    description:
      "A practical guide to comparing investment amount, term and potential returns.",
  },
  {
    title: "Managing money from one dashboard",
    category: "Money",
    description:
      "How keeping your financial activity together can make everyday money management easier.",
  },
];

function getRecentDate(daysAgo: number) {
  const date = new Date();

  date.setDate(date.getDate() - daysAgo);

  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export default function HomePage() {
  const router = useRouter();

  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [activityRefresh, setActivityRefresh] = useState(0);

  useEffect(() => {
    const refreshInterval = window.setInterval(() => {
      setActivityRefresh((value) => value + 1);
    }, 60 * 60 * 1000);

    return () => {
      window.clearInterval(refreshInterval);
    };
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });

    setMenuOpen(false);
  };

  return (
    <main className="ff-public-home relative min-h-screen overflow-x-hidden !bg-[#F4F5F7] !text-[#30343B]">
      {/* GLOBAL BACKGROUND */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute -left-56 -top-48 h-[620px] w-[620px] rounded-full bg-[#C9364D]/[0.075] blur-[110px]" />
        <div className="absolute -right-56 top-[420px] h-[650px] w-[650px] rounded-full bg-[#28303B]/[0.045] blur-[120px]" />
        <div className="absolute left-[35%] top-[1150px] h-[500px] w-[500px] rounded-full bg-white/70 blur-[100px]" />
        <div className="absolute right-[8%] top-[2500px] h-[430px] w-[430px] rounded-full bg-[#C9364D]/[0.035] blur-[100px]" />
      </div>

      {/* =====================================================
          NAVIGATION
      ====================================================== */}
      <header className="fixed left-0 right-0 top-0 z-50 border-b border-white/10 bg-[#10141D]/[0.97] shadow-[0_8px_30px_rgba(16,20,29,0.14)] backdrop-blur-xl">
        <div className="mx-auto flex h-[74px] max-w-[1280px] items-center justify-between px-5 sm:px-7 lg:px-10">
          <button
            onClick={() =>
              window.scrollTo({
                top: 0,
                behavior: "smooth",
              })
            }
            className="text-xl font-black tracking-tight"
          >
            <span className="text-white">FLASH</span>
            <span className="text-[#BFDBFE]">FINANCE</span>
          </button>

          <nav className="hidden items-center gap-7 lg:flex">
            <button
              onClick={() => scrollTo("home")}
              className="text-sm text-white transition hover:text-[#D9586B]"
            >
              Home
            </button>

            <button
              onClick={() => scrollTo("plans")}
              className="text-sm text-white/60 transition hover:text-white"
            >
              Plans
            </button>

            <button
              onClick={() => scrollTo("how-it-works")}
              className="text-sm text-white/60 transition hover:text-white"
            >
              How It Works
            </button>

            <button
              onClick={() => scrollTo("about")}
              className="text-sm text-white/60 transition hover:text-white"
            >
              About
            </button>

            <button
              onClick={() => scrollTo("faq")}
              className="text-sm text-white/60 transition hover:text-white"
            >
              FAQ
            </button>
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <button
              onClick={() => router.push("/login")}
              className="rounded-xl px-4 py-2.5 text-sm font-semibold text-white/70 transition hover:bg-white/5 hover:text-white"
            >
              Log In
            </button>

            <button
              onClick={() => router.push("/signup")}
              className="rounded-xl bg-[#C9364D] px-5 py-2.5 text-sm font-bold text-white shadow-[0_8px_22px_rgba(201,54,77,0.20)] transition hover:bg-[#B52F45]"
            >
              Create Account
            </button>
          </div>

          <button
            onClick={() => setMenuOpen((value) => !value)}
            className="rounded-xl bg-white/5 p-2.5 text-[#D9586B] transition hover:bg-white/10 lg:hidden"
          >
            {menuOpen ? <FiX size={21} /> : <FiMenu size={21} />}
          </button>
        </div>

        {menuOpen && (
          <div className="border-t border-white/10 bg-[#10141D] px-5 py-4 shadow-xl lg:hidden">
            <div className="space-y-1">
              <button
                onClick={() => scrollTo("home")}
                className="block w-full rounded-xl px-4 py-3 text-left text-sm text-white/70 transition hover:bg-white/5 hover:text-white"
              >
                Home
              </button>

              <button
                onClick={() => scrollTo("plans")}
                className="block w-full rounded-xl px-4 py-3 text-left text-sm text-white/70 transition hover:bg-white/5 hover:text-white"
              >
                Investment Plans
              </button>

              <button
                onClick={() => scrollTo("how-it-works")}
                className="block w-full rounded-xl px-4 py-3 text-left text-sm text-white/70 transition hover:bg-white/5 hover:text-white"
              >
                How It Works
              </button>

              <button
                onClick={() => scrollTo("services")}
                className="block w-full rounded-xl px-4 py-3 text-left text-sm text-white/70 transition hover:bg-white/5 hover:text-white"
              >
                Services
              </button>

              <button
                onClick={() => scrollTo("about")}
                className="block w-full rounded-xl px-4 py-3 text-left text-sm text-white/70 transition hover:bg-white/5 hover:text-white"
              >
                About
              </button>

              <button
                onClick={() => scrollTo("faq")}
                className="block w-full rounded-xl px-4 py-3 text-left text-sm text-white/70 transition hover:bg-white/5 hover:text-white"
              >
                FAQ
              </button>

              <div className="mt-3 grid grid-cols-2 gap-2 border-t border-white/10 pt-3">
                <button
                  onClick={() => router.push("/login")}
                  className="rounded-xl border border-white/10 px-4 py-3 text-sm font-semibold text-white"
                >
                  Log In
                </button>

                <button
                  onClick={() => router.push("/signup")}
                  className="rounded-xl bg-[#C9364D] px-4 py-3 text-sm font-bold text-white"
                >
                  Sign Up
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* =====================================================
          HERO
      ====================================================== */}
      <section
        id="home"
        className="relative z-10 overflow-hidden scroll-mt-20 pt-[74px]"
      >
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -left-40 -top-40 h-[520px] w-[520px] rounded-full bg-[#C9364D]/[0.065] blur-[110px]" />
          <div className="absolute -right-44 top-10 h-[600px] w-[600px] rounded-full bg-[#252C36]/[0.055] blur-[120px]" />
          <div className="absolute bottom-[-240px] left-[28%] h-[520px] w-[520px] rounded-full bg-white/80 blur-[110px]" />
        </div>

        <div className="relative mx-auto grid min-h-[720px] max-w-[1280px] items-center gap-12 px-5 py-20 sm:px-7 lg:grid-cols-[1fr_0.9fr] lg:px-10">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-[#C9364D]/20 bg-[#C9364D]/[0.075] px-4 py-2 text-[10px] font-bold uppercase tracking-[0.22em] text-[#B52F45]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#C9364D]" />
              Money • Savings • Investments
            </div>

            <h1 className="mt-6 max-w-[760px] text-5xl font-black leading-[1.02] tracking-tight text-[#30343B] sm:text-6xl lg:text-7xl">
              Manage everyday money.
              <span className="block text-[#C9364D]">
                Explore grants and loans.
              </span>
              Plan what comes next.
            </h1>

            <p className="mt-7 max-w-[650px] text-base leading-8 text-[#69707D] sm:text-lg">
              FlashFinance brings everyday banking, transfers, deposits,
              withdrawals, investments, grants, loans, payments and support
              into one simple financial platform.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <button
                onClick={() => router.push("/signup")}
                className="flex items-center justify-center gap-2 rounded-2xl bg-[#C9364D] px-7 py-4 text-sm font-black text-white shadow-[0_12px_30px_rgba(201,54,77,0.18)] transition hover:bg-[#B52F45]"
              >
                Get Started
                <FiArrowRight size={17} />
              </button>

              <button
                onClick={() => scrollTo("plans")}
                className="rounded-2xl border border-[#DDE1E6] bg-white px-7 py-4 text-sm font-semibold text-[#424750] shadow-sm transition hover:border-[#C9364D]/30 hover:bg-[#FAFAFB]"
              >
                Explore Plans
              </button>
            </div>

            <div className="mt-10 grid max-w-[650px] grid-cols-3 gap-5 border-t border-[#DDE1E6] pt-7">
              <div>
                <p className="text-2xl font-black text-[#3B4048]">Everyday</p>

                <p className="mt-1 text-[10px] uppercase tracking-wider text-[#858C97]">
                  Money tools
                </p>
              </div>

              <div>
                <p className="text-2xl font-black text-[#3B4048]">Grants + loans</p>

                <p className="mt-1 text-[10px] uppercase tracking-wider text-[#858C97]">
                  Financial support
                </p>
              </div>

              <div>
                <p className="text-2xl font-black text-[#3B4048]">One place</p>

                <p className="mt-1 text-[10px] uppercase tracking-wider text-[#858C97]">
                  Connected account
                </p>
              </div>
            </div>
          </div>

          {/* HERO DASHBOARD PREVIEW */}
          <div className="relative mx-auto w-full max-w-[480px]">
            <div className="absolute inset-0 rounded-[45px] bg-[#C9364D]/[0.07] blur-[70px]" />

            <div className="relative rounded-[34px] border border-[#DDE1E6] bg-white p-4 shadow-[0_25px_70px_rgba(35,40,48,0.13)] sm:p-5">
              <div className="rounded-[28px] bg-gradient-to-br from-[#C9364D] via-[#BA344A] to-[#A72D42] p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[9px] uppercase tracking-[0.2em] text-white/65">
                      FlashFinance
                    </p>

                    <p className="mt-1 text-sm font-bold">
                      Personal Account
                    </p>
                  </div>

                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-xs font-black text-[#C9364D]">
                    FF
                  </div>
                </div>

                <p className="mt-8 text-[10px] uppercase tracking-[0.18em] text-white/65">
                  Your available balance
                </p>

                <div
                  className="mt-3 h-11 w-44 rounded-xl bg-white/20"
                  aria-label="Available balance appears after signing in"
                />

                <div className="mt-6 grid grid-cols-4 gap-2">
                  {[
                    {
                      icon: <FiArrowDownLeft />,
                      label: "Deposit",
                    },
                    {
                      icon: <FiSend />,
                      label: "Send",
                    },
                    {
                      icon: <FiArrowUpRight />,
                      label: "Withdraw",
                    },
                    {
                      icon: <FiTrendingUp />,
                      label: "Invest",
                    },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="flex flex-col items-center rounded-2xl bg-white/[0.12] py-3"
                    >
                      <span className="text-white">{item.icon}</span>

                      <span className="mt-2 text-[9px] text-white/65">
                        {item.label}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-5 rounded-2xl border border-white/[0.13] bg-black/[0.09] p-4">
                  <div className="flex items-center justify-between">
                    <div>
                       <p className="text-[9px] uppercase tracking-wider text-white/60">
                         Financial overview
                      </p>

                      <div className="mt-2 h-7 w-32 rounded-lg bg-white/25" />
                    </div>

                    <FiTrendingUp size={22} className="text-white" />
                  </div>

                  <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/[0.13]">
                    <div className="h-full w-1/2 rounded-full bg-white/80" />
                  </div>

                  <div className="mt-3 flex justify-between text-[9px] text-white/55">
                     <span>Everyday money</span>
                     <span>Plan activity</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-[#DDE1E6] bg-[#F8F9FA] p-4">
                  <p className="text-[9px] uppercase tracking-wider text-[#858C97]">
                    Assistance
                  </p>

                    <div className="mt-2 h-6 w-20 rounded-lg bg-[#DDE1E6]" />
                </div>

                <div className="rounded-2xl border border-[#DDE1E6] bg-[#F8F9FA] p-4">
                  <p className="text-[9px] uppercase tracking-wider text-[#858C97]">
                    Loans
                  </p>

                    <div className="mt-2 h-6 w-10 rounded-lg bg-[#DDE1E6]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          QUICK BENEFITS
      ====================================================== */}
      <section className="relative z-10 border-y border-[#E1E4E8] bg-white/95 py-20">
        <div className="mx-auto max-w-[1280px] px-5 sm:px-7 lg:px-10">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: <FiShield size={22} />,
                title: "Account Management",
                text: "Keep your money, activity and financial tools organized.",
              },
              {
                icon: <FiTrendingUp size={22} />,
                title: "Investment Planning",
                text: "Compare plans and estimate sample investment outcomes.",
              },
              {
                icon: <FiDollarSign size={22} />,
                title: "Savings Goals",
                text: "Set money aside and work toward specific financial goals.",
              },
              {
                icon: <FiCreditCard size={22} />,
                title: "Everyday Payments",
                text: "Bring everyday services and spending into one platform.",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="rounded-[26px] border border-[#E1E4E8] bg-[#F8F9FA] p-6 shadow-[0_8px_25px_rgba(35,40,48,0.035)]"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#C9364D]/[0.09] text-[#C9364D]">
                  {item.icon}
                </div>

                <h3 className="mt-5 text-base font-bold text-[#3B4048]">
                  {item.title}
                </h3>

                <p className="mt-2 text-sm leading-6 text-[#69707D]">
                  {item.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          INVESTMENT PLANS
      ====================================================== */}
      <section
        id="plans"
        className="relative z-10 scroll-mt-20 py-24"
      >
        <div className="mx-auto max-w-[1280px] px-5 sm:px-7 lg:px-10">
          <div className="mx-auto max-w-[800px] text-center">
            <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#C9364D]">
              FlashFinance Plans
            </p>

            <h2 className="mt-3 text-3xl font-black text-[#3B4048] sm:text-5xl">
              Choose an investment plan
            </h2>

            <p className="mt-4 text-sm leading-7 text-[#69707D]">
              Compare sample plans based on investment amount,
              term and displayed sample ROI.
            </p>
          </div>

          <div className="mt-12 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {investmentPlans.map((plan) => (
              <div
                key={plan.name}
                className={`relative rounded-[28px] border p-6 text-left shadow-[0_8px_28px_rgba(35,40,48,0.04)] ${
                  plan.featured
                    ? "border-[#C9364D]/35 bg-[#C9364D]/[0.035]"
                    : "border-[#E1E4E8] bg-white"
                }`}
              >
                {plan.featured && (
                  <span className="absolute right-5 top-5 rounded-full bg-[#C9364D] px-3 py-1 text-[8px] font-black uppercase tracking-wider text-white">
                    Popular
                  </span>
                )}

                <div className="flex items-start justify-between pr-20">
                  <div>
                    <p className="text-xl font-black text-[#3B4048]">
                      {plan.name}
                    </p>

                    <p className="mt-1 text-xs text-[#858C97]">
                      {plan.days} day term
                    </p>
                  </div>
                </div>

                <div className="mt-7 flex items-end gap-2">
                  <span className="text-4xl font-black text-[#C9364D]">
                    {plan.roi.toFixed(2)}%
                  </span>

                  <span className="pb-1 text-[10px] text-[#858C97]">
                    sample ROI
                  </span>
                </div>

                <div className="mt-7 grid grid-cols-2 gap-4 border-t border-[#E1E4E8] pt-5">
                  <div>
                    <p className="text-[9px] uppercase tracking-wider text-[#858C97]">
                      Minimum
                    </p>

                    <p className="mt-2 text-sm font-bold text-[#3B4048]">
                      ${plan.min.toLocaleString()}
                    </p>
                  </div>

                  <div>
                    <p className="text-[9px] uppercase tracking-wider text-[#858C97]">
                      Maximum
                    </p>

                    <p className="mt-2 text-sm font-bold text-[#3B4048]">
                      ${plan.max.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="mt-5 flex items-center gap-2 text-xs text-[#69707D]">
                  <FiClock size={15} />
                  {plan.days} day term
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 rounded-2xl border border-[#C9364D]/15 bg-[#C9364D]/[0.025] p-4">
            <p className="text-[10px] leading-5 text-[#69707D]">
              The rates displayed above are sample development
              figures used for the FlashFinance investment
              experience. They are not guaranteed returns.
            </p>
          </div>
        </div>
      </section>

      {/* =====================================================
          HOW IT WORKS
      ====================================================== */}
      <section
        id="how-it-works"
        className="relative z-10 scroll-mt-20 border-y border-[#E1E4E8] bg-white/95 py-24"
      >
        <div className="mx-auto max-w-[1280px] px-5 sm:px-7 lg:px-10">
          <div className="mx-auto max-w-[760px] text-center">
            <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#C9364D]">
              Work Process
            </p>

            <h2 className="mt-3 text-3xl font-black text-[#3B4048] sm:text-5xl">
              5 simple steps to start investing
            </h2>

            <p className="mt-4 text-sm leading-7 text-[#69707D]">
              The journey is designed to be simple to understand
              from registration through investment management.
            </p>
          </div>

          <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {[
              {
                number: "01",
                title: "Registration",
                description:
                  "Create your FlashFinance account.",
                icon: <FiUserPlus size={21} />,
              },
              {
                number: "02",
                title: "Deposit",
                description:
                  "Fund your account using an available method.",
                icon: <FiPlus size={21} />,
              },
              {
                number: "03",
                title: "Investing",
                description:
                  "Choose an available investment plan.",
                icon: <FiBarChart2 size={21} />,
              },
              {
                number: "04",
                title: "Track",
                description:
                  "Monitor your investment and displayed earnings.",
                icon: <FiTrendingUp size={21} />,
              },
              {
                number: "05",
                title: "Withdraw",
                description:
                  "Withdraw eligible funds according to applicable terms.",
                icon: <FiArrowUpRight size={21} />,
              },
            ].map((step) => (
              <div
                key={step.number}
                className="rounded-[26px] border border-[#E1E4E8] bg-[#F8F9FA] p-5 shadow-[0_8px_25px_rgba(35,40,48,0.035)]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#C9364D] text-white">
                    {step.icon}
                  </div>

                  <span className="text-[10px] font-black tracking-[0.18em] text-[#C9364D]">
                    {step.number}
                  </span>
                </div>

                <h3 className="mt-6 text-lg font-bold text-[#3B4048]">
                  {step.title}
                </h3>

                <p className="mt-2 text-sm leading-6 text-[#69707D]">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          ABOUT
      ====================================================== */}
      <section
        id="about"
        className="relative z-10 scroll-mt-20 overflow-hidden bg-[#202631] py-24 text-white"
      >
        <div className="pointer-events-none absolute -right-40 -top-40 h-[480px] w-[480px] rounded-full bg-[#C9364D]/[0.12] blur-[110px]" />
        <div className="pointer-events-none absolute -left-40 bottom-[-300px] h-[500px] w-[500px] rounded-full bg-white/[0.025] blur-[110px]" />

        <div className="relative mx-auto grid max-w-[1150px] gap-12 px-5 sm:px-7 lg:grid-cols-2 lg:items-center lg:px-10">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#D9586B]">
              About FlashFinance
            </p>

            <h2 className="mt-3 text-3xl font-black text-white sm:text-5xl">
              A financial platform built around your goals
            </h2>

            <p className="mt-5 text-sm leading-7 text-white/65">
              FlashFinance is being developed to bring everyday
              money management, savings, payments and investment
              planning into one organized experience.
            </p>

            <p className="mt-4 text-sm leading-7 text-white/65">
              Instead of making users jump between different
              tools, the goal is to give them one clear place to
              manage their account and understand their financial
              activity.
            </p>

            <div className="mt-7 space-y-3">
              {[
                "Clear financial information",
                "Simple account management",
                "Investment planning tools",
                "Savings and money management",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-3"
                >
                  <FiCheckCircle
                    size={17}
                    className="text-[#D9586B]"
                  />

                  <span className="text-sm text-white/75">
                    {item}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[32px] border border-white/[0.10] bg-white/[0.055] p-6 shadow-[0_20px_60px_rgba(0,0,0,0.16)] sm:p-8">
            <div className="space-y-4">
              <div className="rounded-2xl border border-white/[0.09] bg-white/[0.045] p-5">
                <FiLock size={21} className="text-[#D9586B]" />

                <h3 className="mt-4 text-base font-bold text-white">
                  Account-first experience
                </h3>

                <p className="mt-2 text-sm leading-6 text-white/55">
                  Your account dashboard is designed to bring
                  balances, deposits and activity together.
                </p>
              </div>

              <div className="rounded-2xl border border-white/[0.09] bg-white/[0.045] p-5">
                <FiBarChart2
                  size={21}
                  className="text-[#D9586B]"
                />

                <h3 className="mt-4 text-base font-bold text-white">
                  Clear investment planning
                </h3>

                <p className="mt-2 text-sm leading-6 text-white/55">
                  Compare plans and use the investment tools
                  inside your dashboard.
                </p>
              </div>

              <div className="rounded-2xl border border-white/[0.09] bg-white/[0.045] p-5">
                <FiTrendingUp
                  size={21}
                  className="text-[#D9586B]"
                />

                <h3 className="mt-4 text-base font-bold text-white">
                  Built to expand
                </h3>

                <p className="mt-2 text-sm leading-6 text-white/55">
                  Savings, loans, payments, cards and other
                  financial tools can be connected as the
                  platform grows.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          FINANCIAL SERVICES
      ====================================================== */}
      <section
        id="services"
        className="relative z-10 scroll-mt-20 py-24"
      >
        <div className="mx-auto max-w-[1280px] px-5 sm:px-7 lg:px-10">
          <div className="max-w-[750px]">
            <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#C9364D]">
              Complete financial platform
            </p>

            <h2 className="mt-3 text-3xl font-black text-[#424750] sm:text-5xl">
              Everyday money, assistance, and plans
            </h2>

            <p className="mt-4 text-sm leading-7 text-[#69707D]">
              Bring your everyday money, financial assistance,
              loans, payments, transfers, and longer-term plans
              together in one account.
            </p>
          </div>

          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: <FiCreditCard size={22} />,
                title: "Everyday banking",
                text: "Keep account information and everyday money tools together.",
                href: "/dashboard",
              },
              {
                icon: <FiSend size={22} />,
                title: "Transfers",
                text: "Send money using the existing transfer flow.",
                href: "/transfer",
              },
              {
                icon: <FiPlus size={22} />,
                title: "Deposits",
                text: "Add money through the funding methods available to your account.",
                href: "/deposit",
              },
              {
                icon: <FiArrowUpRight size={22} />,
                title: "Withdrawals",
                text: "Review the withdrawal flow and available destinations.",
                href: "/withdraw",
              },
              {
                icon: <FiTrendingUp size={22} />,
                title: "Investments",
                text: "Compare the investment plans and terms already available.",
                href: "/investments",
              },
              {
                icon: <FiHeart size={22} />,
                title: "Financial assistance",
                text: "Explore grant eligibility and the application process.",
                href: "/grants",
              },
              {
                icon: <FiShield size={22} />,
                title: "Loans",
                text: "Review the existing loan application and account experience.",
                href: "/loans",
              },
              {
                icon: <FiZap size={22} />,
                title: "Bills & payments",
                text: "Use the supported bill and payment flows.",
                href: "/payments",
              },
              {
                icon: <FiHelpCircle size={22} />,
                title: "Support",
                text: "Get help and follow existing support conversations.",
                href: "/support",
              },
            ].map((service) => (
              <Link
                key={service.title}
                href={service.href}
                className="rounded-[26px] border border-[#E1E4E8] bg-white p-6 shadow-[0_8px_28px_rgba(35,40,48,0.045)] transition hover:-translate-y-0.5 hover:shadow-[0_12px_35px_rgba(35,40,48,0.08)]"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#C9364D]/[0.085] text-[#C9364D]">
                  {service.icon}
                </div>

                <h3 className="mt-6 text-lg font-bold text-[#424750]">
                  {service.title}
                </h3>

                <p className="mt-2 text-sm leading-6 text-[#69707D]">
                  {service.text}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          AFFILIATE / REWARDS
      ====================================================== */}
      <section className="relative z-10 bg-[#F8F9FA] py-24">
        <div className="mx-auto max-w-[1100px] px-5 sm:px-7">
          <div className="overflow-hidden rounded-[32px] border border-[#E1E4E8] bg-white shadow-[0_15px_45px_rgba(35,40,48,0.055)]">
            <div className="grid gap-8 p-6 sm:p-8 lg:grid-cols-[1fr_0.8fr] lg:items-center lg:p-10">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#C9364D]">
                  Affiliate Program
                </p>

                <h2 className="mt-3 text-3xl font-black text-[#424750] sm:text-4xl">
                  Grow together with FlashFinance
                </h2>

                <p className="mt-4 text-sm leading-7 text-[#69707D]">
                  A future referral and affiliate area can allow
                  users to share FlashFinance and track eligible
                  referral activity from their account.
                </p>

                <button
                  onClick={() =>
                    alert(
                      "Affiliate features will be connected later."
                    )
                  }
                  className="mt-6 flex items-center gap-2 rounded-xl bg-[#C9364D] px-5 py-3 text-sm font-bold text-white shadow-[0_8px_20px_rgba(201,54,77,0.16)] transition hover:bg-[#B52F45]"
                >
                  Learn More
                  <FiArrowRight size={16} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-[#E1E4E8] bg-[#F8F9FA] p-5">
                  <FiUserPlus
                    size={21}
                    className="text-[#C9364D]"
                  />

                  <p className="mt-4 text-sm font-bold text-[#424750]">
                    Referral Network
                  </p>

                  <p className="mt-1 text-xs leading-5 text-[#858C97]">
                    Share your referral link.
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E1E4E8] bg-[#F8F9FA] p-5">
                  <FiBarChart2
                    size={21}
                    className="text-[#C9364D]"
                  />

                  <p className="mt-4 text-sm font-bold text-[#424750]">
                    Track Activity
                  </p>

                  <p className="mt-1 text-xs leading-5 text-[#858C97]">
                    Follow referral performance.
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E1E4E8] bg-[#F8F9FA] p-5">
                  <FiDollarSign
                    size={21}
                    className="text-[#C9364D]"
                  />

                  <p className="mt-4 text-sm font-bold text-[#424750]">
                    Rewards
                  </p>

                  <p className="mt-1 text-xs leading-5 text-[#858C97]">
                    Future eligible rewards.
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E1E4E8] bg-[#F8F9FA] p-5">
                  <FiTrendingUp
                    size={21}
                    className="text-[#C9364D]"
                  />

                  <p className="mt-4 text-sm font-bold text-[#424750]">
                    Grow
                  </p>

                  <p className="mt-1 text-xs leading-5 text-[#858C97]">
                    Build your network.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          TRANSACTIONS SHOWCASE
      ====================================================== */}
      <section className="relative z-10 py-24">
        <div className="mx-auto max-w-[1100px] px-5 sm:px-7">
          <div className="mb-10 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#C9364D]">
                Activity
              </p>

              <h2 className="mt-3 text-3xl font-black text-[#424750] sm:text-5xl">
                Latest transactions
              </h2>

              <p className="mt-4 text-sm leading-7 text-[#69707D]">
                A preview of the kind of financial activity that
                can appear inside the FlashFinance platform.
              </p>
            </div>

            <button
              onClick={() => router.push("/signup")}
              className="flex items-center gap-2 text-xs font-semibold text-[#C9364D] transition hover:text-[#B52F45]"
            >
              Create Account
              <FiChevronRight size={15} />
            </button>
          </div>

          <div
            key={activityRefresh}
            className="overflow-hidden rounded-[28px] border border-[#E1E4E8] bg-white shadow-[0_10px_35px_rgba(35,40,48,0.045)]"
          >
            <div className="hidden grid-cols-[1.2fr_1fr_1fr_1.5fr] gap-4 border-b border-[#E1E4E8] px-6 py-4 text-[9px] font-bold uppercase tracking-[0.18em] text-[#858C97] sm:grid">
              <span>Name</span>
              <span>Date</span>
              <span>Amount</span>
              <span>Details</span>
            </div>

            {sampleTransactions.map((transaction) => (
              <div
                key={`${transaction.name}-${transaction.daysAgo}-${activityRefresh}`}
                className="grid gap-3 border-b border-[#E1E4E8] px-5 py-5 last:border-b-0 sm:grid-cols-[1.2fr_1fr_1fr_1.5fr] sm:items-center sm:gap-4 sm:px-6"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#C9364D]/[0.085] text-[#C9364D]">
                    {transaction.type === "credit" ? (
                      <FiArrowDownLeft size={17} />
                    ) : (
                      <FiArrowUpRight size={17} />
                    )}
                  </div>

                  <span className="text-sm font-semibold text-[#424750]">
                    {transaction.name}
                  </span>
                </div>

                <span className="text-xs text-[#69707D]">
                  {getRecentDate(transaction.daysAgo)}
                </span>

                <span
                  className={`text-sm font-bold ${
                    transaction.type === "credit"
                      ? "text-green-600"
                      : "text-[#424750]"
                  }`}
                >
                  {transaction.type === "credit" ? "+" : "-"}
                  {transaction.amount}
                </span>

                <span className="text-xs text-[#69707D]">
                  {transaction.detail}
                </span>
              </div>
            ))}
          </div>

          <p className="mt-4 text-[10px] text-[#858C97]">
            The transaction examples above are illustrative
            website content, not live customer records.
          </p>
        </div>
      </section>

      {/* =====================================================
          BLOG / NEWS
      ====================================================== */}
      <section className="relative z-10 border-y border-[#E1E4E8] bg-white/95 py-24">
        <div className="mx-auto max-w-[1280px] px-5 sm:px-7 lg:px-10">
          <div className="flex items-end justify-between gap-5">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#C9364D]">
                Insights
              </p>

              <h2 className="mt-3 text-3xl font-black text-[#424750] sm:text-5xl">
                Latest from FlashFinance
              </h2>
            </div>

            <button
              onClick={() =>
                alert(
                  "The full blog section will be added later."
                )
              }
              className="hidden items-center gap-1 text-xs font-semibold text-[#C9364D] transition hover:text-[#B52F45] sm:flex"
            >
              View all
              <FiChevronRight size={15} />
            </button>
          </div>

          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {blogPosts.map((post) => (
              <article
                key={post.title}
                className="rounded-[26px] border border-[#E1E4E8] bg-[#F8F9FA] p-6 shadow-[0_8px_25px_rgba(35,40,48,0.035)]"
              >
                <div className="flex h-40 items-end rounded-2xl bg-gradient-to-br from-[#C9364D]/[0.075] via-white to-[#F0F2F4] p-5">
                  <span className="rounded-full bg-[#C9364D] px-3 py-1 text-[8px] font-black uppercase tracking-wider text-white">
                    {post.category}
                  </span>
                </div>

                <h3 className="mt-5 text-lg font-bold text-[#424750]">
                  {post.title}
                </h3>

                <p className="mt-2 text-sm leading-6 text-[#69707D]">
                  {post.description}
                </p>

                <button
                  onClick={() =>
                    alert(
                      "Full article pages will be added later."
                    )
                  }
                  className="mt-5 flex items-center gap-2 text-xs font-semibold text-[#C9364D] transition hover:text-[#B52F45]"
                >
                  Continue Reading
                  <FiArrowRight size={14} />
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          FAQ
      ====================================================== */}
      <section
        id="faq"
        className="relative z-10 scroll-mt-20 py-24"
      >
        <div className="mx-auto max-w-[900px] px-5 sm:px-7">
          <div className="text-center">
            <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#C9364D]">
              FAQ
            </p>

            <h2 className="mt-3 text-3xl font-black text-[#424750] sm:text-5xl">
              Frequently asked questions
            </h2>
          </div>

          <div className="mt-12 space-y-3">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;

              return (
                <div
                  key={faq.question}
                  className="overflow-hidden rounded-2xl border border-[#E1E4E8] bg-white shadow-[0_6px_20px_rgba(35,40,48,0.03)]"
                >
                  <button
                    onClick={() =>
                      setOpenFaq(isOpen ? null : index)
                    }
                    className="flex w-full items-center justify-between gap-5 px-5 py-5 text-left"
                  >
                    <span className="text-sm font-semibold text-[#424750]">
                      {faq.question}
                    </span>

                    <FiChevronDown
                      size={18}
                      className={`shrink-0 text-[#858C97] transition-transform ${
                        isOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>

                  {isOpen && (
                    <div className="border-t border-[#E1E4E8] px-5 pb-5 pt-4">
                      <p className="text-sm leading-7 text-[#69707D]">
                        {faq.answer}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* =====================================================
          FINAL CTA
      ====================================================== */}
      <section className="relative z-10 py-24">
        <div className="mx-auto max-w-[1100px] px-5 sm:px-7">
          <div className="relative overflow-hidden rounded-[36px] bg-gradient-to-br from-[#C9364D] via-[#B93449] to-[#A52E42] p-8 text-white shadow-[0_20px_60px_rgba(201,54,77,0.15)] sm:p-10">
            <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/[0.09] blur-[90px]" />

            <div className="relative flex flex-col justify-between gap-8 lg:flex-row lg:items-center">
              <div className="max-w-[650px]">
                <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-white/70">
                  Get Started
                </p>

                <h2 className="mt-3 text-3xl font-black text-white sm:text-4xl">
                  Take the next step with FlashFinance
                </h2>

                <p className="mt-4 text-sm leading-7 text-white/70">
                  Create your account and explore money
                  management, savings and investment tools in one
                  place.
                </p>
              </div>

              <button
                onClick={() => router.push("/signup")}
                className="flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-white px-7 py-4 text-sm font-black text-[#B52F45] shadow-lg transition hover:bg-[#F8F9FA]"
              >
                Create Account
                <FiArrowRight size={17} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          FOOTER
      ====================================================== */}
      <footer className="relative z-10 border-t border-white/[0.08] bg-[#202631] py-14 text-white">
        <div className="mx-auto max-w-[1280px] px-5 sm:px-7 lg:px-10">
          <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <h3 className="text-xl font-black">
                <span className="text-white">FLASH</span>
                <span className="text-[#D9586B]">FINANCE</span>
              </h3>

              <p className="mt-4 max-w-[320px] text-sm leading-6 text-white/50">
                A modern financial platform for managing money,
                saving and exploring investment tools.
              </p>
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white/65">
                Platform
              </p>

              <div className="mt-4 space-y-3">
                <button
                  onClick={() => scrollTo("plans")}
                  className="block text-sm text-white/50 transition hover:text-white"
                >
                  Investment Plans
                </button>

                <button
                  onClick={() => scrollTo("how-it-works")}
                  className="block text-sm text-white/50 transition hover:text-white"
                >
                  How It Works
                </button>
              </div>
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white/65">
                Account
              </p>

              <div className="mt-4 space-y-3">
                <button
                  onClick={() => router.push("/login")}
                  className="block text-sm text-white/50 transition hover:text-white"
                >
                  Log In
                </button>

                <button
                  onClick={() => router.push("/signup")}
                  className="block text-sm text-white/50 transition hover:text-white"
                >
                  Create Account
                </button>

                <button
                  onClick={() =>
                    alert(
                      "Profile and account settings are available inside the user dashboard."
                    )
                  }
                  className="block text-sm text-white/50 transition hover:text-white"
                >
                  Account
                </button>
              </div>
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white/65">
                Important
              </p>

              <p className="mt-4 text-sm leading-6 text-white/50">
                FlashFinance is currently a development
                environment. Investment rates shown on this
                website are sample figures and are not guaranteed
                returns.
              </p>
            </div>
          </div>

          <div className="mt-12 border-t border-white/[0.09] pt-6">
            <p className="text-xs text-white/35">
              © 2026 FlashFinance. Development environment.
            </p>
          </div>
        </div>
      </footer>
    </main>
  );
}