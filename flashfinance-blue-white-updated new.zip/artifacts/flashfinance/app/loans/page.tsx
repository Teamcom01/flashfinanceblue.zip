"use client";

import {
  Suspense,
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ChangeEvent,
} from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  FiArrowLeft,
  FiArrowRight,
  FiBookOpen,
  FiBriefcase,
  FiCheckCircle,
  FiChevronDown,
  FiClock,
  FiDollarSign,
  FiEdit3,
  FiFileText,
  FiHome,
  FiInfo,
  FiLoader,
  FiRefreshCw,
  FiShield,
  FiTruck,
  FiUser,
  FiXCircle,
} from "react-icons/fi";
import { createClient } from "../../lib/supabase";

const loanOptions = [
  {
    name: "Starter Loan",
    min: 500,
    max: 5000,
    terms: [3, 6, 12],
  },
  {
    name: "Personal Loan",
    min: 5000,
    max: 25000,
    terms: [6, 12, 18, 24],
  },
  {
    name: "Premium Loan",
    min: 25000,
    max: 100000,
    terms: [12, 18, 24, 36],
  },
];

const purposes = [
  "Personal expenses",
  "Home improvement",
  "Education",
  "Medical expenses",
  "Debt consolidation",
  "Vehicle",
  "Business",
  "Other",
  "Car",
  "Rent",
];

const loanUses = [
  {
    title: "Personal expenses",
    description:
      "Handle important personal expenses, unexpected costs, and everyday financial needs.",
    icon: FiUser,
  },
  {
    title: "Home improvement",
    description:
      "Fund repairs, renovations, upgrades, furniture, and other home projects.",
    icon: FiHome,
  },
  {
    title: "Education",
    description:
      "Cover tuition, educational materials, courses, and other learning expenses.",
    icon: FiBookOpen,
  },
  {
    title: "Medical expenses",
    description:
      "Help manage eligible medical, dental, treatment, and healthcare related expenses.",
    icon: FiShield,
  },
  {
    title: "Debt consolidation",
    description:
      "Combine qualifying debts into one manageable repayment plan.",
    icon: FiFileText,
  },
  {
    title: "Vehicle",
    description:
      "Use financing toward a vehicle purchase, repairs, maintenance, or related costs.",
    icon: FiTruck,
  },
  {
    title: "Business",
    description:
      "Support eligible business expenses, equipment, supplies, and working capital needs.",
    icon: FiBriefcase,
  },
  {
    title: "Other needs",
    description:
      "Apply for another qualifying financial need that is not listed above.",
    icon: FiDollarSign,
  },
];

const howItWorks = [
  {
    number: "01",
    title: "Choose your loan",
    description:
      "Select the amount, purpose, and repayment term that best fits your needs.",
    icon: FiEdit3,
  },
  {
    number: "02",
    title: "Complete verification",
    description:
      "Provide the required information so your application can be reviewed.",
    icon: FiShield,
  },
  {
    number: "03",
    title: "Application review",
    description:
      "Your application is reviewed and you will be notified of the decision.",
    icon: FiClock,
  },
  {
    number: "04",
    title: "Receive your funds",
    description:
      "Once approved, your loan can move forward according to the applicable terms.",
    icon: FiCheckCircle,
  },
];

type LoanRequest = {
  id: string;
  user_id: string;
  amount: number;
  purpose: string;
  term_months: number;
  note: string | null;
  status: string | null;
  created_at: string;
};

function formatMoney(amount: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  }).format(amount);
}

function formatDate(date: string) {
  try {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return date;
  }
}

function getStatusInfo(status: string | null) {
  const normalized = (status || "pending").toLowerCase().trim();

  if (
    normalized === "pending" ||
    normalized === "under_review" ||
    normalized === "submitted" ||
    normalized === "waiting"
  ) {
    return {
      label: "Under Review",
      className:
        "border-[#B51F35]/20 bg-[#B51F35]/10 !text-[#B51F35]",
      icon: FiClock,
    };
  }

  if (normalized === "approved" || normalized === "active") {
    return {
      label: "Approved",
      className:
        "border-emerald-200 bg-emerald-50 !text-emerald-700",
      icon: FiCheckCircle,
    };
  }

  if (normalized === "rejected" || normalized === "declined") {
    return {
      label: normalized === "declined" ? "Declined" : "Rejected",
      className: "border-red-200 bg-red-50 !text-red-600",
      icon: FiXCircle,
    };
  }

  return {
    label: status || "Pending",
    className:
      "border-[#E2E5E9] bg-[#F1F3F6] !text-[#69707D]",
    icon: FiInfo,
  };
}

function LoansPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();

  const [amount, setAmount] = useState("");
  const [purpose, setPurpose] = useState("");
  const [term, setTerm] = useState("");
  const [note, setNote] = useState("");

  const [loan, setLoan] = useState<LoanRequest | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingLoan, setLoadingLoan] = useState(false);
  const [error, setError] = useState("");

  const submitted = searchParams.get("submitted") === "true";

  const loadLoanHistory = useCallback(
    async (userId: string) => {
      setLoadingLoan(true);
      setError("");

      const { data, error: loanError } = await supabase
        .from("loan_requests")
        .select(
          "id, user_id, amount, purpose, term_months, note, status, created_at"
        )
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (loanError) {
        console.error("Loan history error:", loanError);
        setLoan(null);
        setError(
          "We could not load your loan history right now. Please try again."
        );
      } else {
        setLoan(data as LoanRequest | null);
      }

      setLoadingLoan(false);
    },
    [supabase]
  );

  const initializePage = useCallback(async () => {
    setLoading(true);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.push("/login");
      return;
    }

    try {
      const savedLoan = sessionStorage.getItem(
        "flashfinance_pending_loan"
      );

      if (savedLoan) {
        const parsed = JSON.parse(savedLoan);

        if (parsed?.amount) {
          setAmount(String(parsed.amount));
        }

        if (parsed?.purpose) {
          setPurpose(String(parsed.purpose));
        }

        if (parsed?.term) {
          setTerm(String(parsed.term));
        }

        if (parsed?.note) {
          setNote(String(parsed.note));
        }
      }
    } catch (storageError) {
      console.error("Unable to restore pending loan:", storageError);
    }

    await loadLoanHistory(user.id);
    setLoading(false);
  }, [loadLoanHistory, router, supabase]);

  useEffect(() => {
    initializePage();
  }, [initializePage]);

  const refreshLoanHistory = async () => {
    setError("");

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.push("/login");
      return;
    }

    await loadLoanHistory(user.id);
  };

  const numericAmount = Number(amount);

  /*
   * IMPORTANT:
   * This does NOT select a loan plan automatically.
   *
   * The amount is only used to determine which repayment terms
   * are available. Starter, Personal, and Premium remain
   * informational cards until the user manually chooses the
   * amount and repayment term.
   */
  const matchingLoanOption = useMemo(() => {
    if (!numericAmount || numericAmount <= 0) {
      return null;
    }

    return (
      loanOptions.find(
        (option) =>
          numericAmount >= option.min &&
          numericAmount <= option.max
      ) || null
    );
  }, [numericAmount]);

  const availableTerms = matchingLoanOption?.terms || [];

  const handleAmountChange = (
    event: ChangeEvent<HTMLInputElement>
  ) => {
    const value = event.target.value;

    if (value === "") {
      setAmount("");
      setTerm("");
      return;
    }

    const parsed = Number(value);

    if (Number.isNaN(parsed)) {
      return;
    }

    setAmount(value);

    const matchingOption = loanOptions.find(
      (option) =>
        parsed >= option.min &&
        parsed <= option.max
    );

    /*
     * Only clear an already-selected term if the new amount
     * makes that term invalid.
     *
     * We never automatically choose a term.
     */
    if (
      matchingOption &&
      term &&
      !matchingOption.terms.includes(Number(term))
    ) {
      setTerm("");
    }

    if (!matchingOption) {
      setTerm("");
    }
  };

  const handleContinue = () => {
    setError("");

    if (!amount || numericAmount <= 0) {
      setError("Please enter the amount you would like to borrow.");
      return;
    }

    if (!matchingLoanOption) {
      setError(
        "Please enter an amount within one of the available loan ranges."
      );
      return;
    }

    if (!purpose) {
      setError("Please select a loan purpose.");
      return;
    }

    if (!term) {
      setError("Please select a repayment term.");
      return;
    }

    if (!matchingLoanOption.terms.includes(Number(term))) {
      setError("Please select a valid repayment term.");
      return;
    }

    try {
      sessionStorage.setItem(
        "flashfinance_pending_loan",
        JSON.stringify({
          amount: numericAmount,
          purpose,
          term: Number(term),
          note,
        })
      );
    } catch (storageError) {
      console.error("Unable to save pending loan:", storageError);
    }

    router.push("/verification?from=loan");
  };

  if (loading) {
    return (
      <main
        className="ff-product-page ff-loans-page !min-h-screen !bg-[#F8F9FB]"
        style={{ backgroundColor: "#F8F9FB" }}
      >
        <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
          <div className="h-8 w-44 animate-pulse rounded-xl bg-white/80" />
          <div className="mt-8 h-56 animate-pulse rounded-[1.75rem] bg-[#1c3b5b]/15" />
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="h-36 animate-pulse rounded-2xl bg-white/80" />
            <div className="h-36 animate-pulse rounded-2xl bg-white/80" />
            <div className="h-36 animate-pulse rounded-2xl bg-white/80" />
          </div>
        </div>
      </main>
    );
  }

  return (
    <main
      className="ff-product-page ff-loans-page !min-h-screen !bg-[#F8F9FB] !text-[#111318]"
      style={{
        backgroundColor: "#F8F9FB",
        color: "#111318",
      }}
    >
      {/* NAVY HERO */}
      <section
        className="w-full !bg-[#0B0E17]"
        style={{
          background:
            "linear-gradient(135deg, #0B0E17 0%, #111827 100%)",
        }}
      >
        <div className="mx-auto w-full max-w-6xl px-4 pb-12 pt-6 sm:px-6 lg:px-8 lg:pb-14 lg:pt-8">
          <button
            type="button"
            onClick={() => router.push("/dashboard")}
            className="mb-10 inline-flex items-center gap-2 !bg-transparent !text-sm !font-semibold !text-white/70 transition hover:!text-white"
          >
            <FiArrowLeft size={17} />
            Back to Dashboard
          </button>

          <div className="max-w-4xl">
            <div className="mb-6 flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl !bg-[#B51F35] !text-white shadow-lg">
                <FiDollarSign size={24} />
              </div>

              <div>
                <p className="!m-0 !p-0 !text-sm !font-bold uppercase !tracking-[0.18em] !text-white">
                  FlashFinance
                </p>

                <p className="!m-0 !mt-1 !p-0 !text-sm !font-medium !text-white/60">
                  Financial Services
                </p>
              </div>
            </div>

            <h1 className="!m-0 !p-0 !text-4xl !font-bold !leading-tight !tracking-tight !text-white sm:!text-5xl">
              Loan Application
            </h1>

            <p className="!m-0 !mt-5 !max-w-3xl !p-0 !text-base !leading-7 !text-white/70 sm:!text-lg sm:!leading-8">
              Your financial story is more than a credit score. Whether your
              credit history is strong, limited, or less than perfect,
              FlashFinance gives you the opportunity to apply for financing
              built around your needs. Choose what you need, tell us what it is
              for, and take the next step toward the financial support you are
              looking for.
            </p>
          </div>
        </div>
      </section>

      {/* MAIN CONTENT */}
      <div
        className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6 lg:px-8 lg:py-10"
        style={{ color: "#111318" }}
      >
        {/* SUBMITTED */}
        {submitted && (
          <section className="mb-8 overflow-hidden rounded-2xl border border-emerald-200 !bg-white shadow-sm">
            <div className="border-b border-emerald-100 !bg-emerald-50 px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full !bg-white !text-emerald-600 shadow-sm">
                  <FiCheckCircle size={23} />
                </div>

                <div>
                  <h2 className="!m-0 !p-0 !text-xl !font-bold !text-[#111318]">
                    Application submitted
                  </h2>

                  <p className="!m-0 !mt-1 !p-0 !text-sm !leading-6 !text-[#69707D]">
                    Your loan application has been successfully submitted and
                    is now being reviewed.
                  </p>
                </div>
              </div>
            </div>

            <div className="!bg-white p-6">
              <div className="rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-5">
                <h3 className="!m-0 !p-0 !font-bold !text-[#111318]">
                  What happens next?
                </h3>

                <p className="!m-0 !mt-2 !p-0 !text-sm !leading-6 !text-[#69707D]">
                  Our team will review the information you provided. You can
                  return to this page at any time to check the status of your
                  application.
                </p>
              </div>

              <button
                type="button"
                onClick={() => router.push("/dashboard")}
                className="mt-5 inline-flex items-center justify-center gap-2 rounded-xl !bg-[#B51F35] px-5 py-3 !text-sm !font-bold !text-white transition hover:!bg-[#9F1B30]"
              >
                Return to Dashboard
                <FiArrowRight size={17} />
              </button>
            </div>
          </section>
        )}

        {/* LOAN HISTORY */}
        <section className="mb-10">
          <div className="mb-5 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="!m-0 !p-0 !text-sm !font-bold uppercase !tracking-[0.14em] !text-[#B51F35]">
                Your application
              </p>

              <h2 className="!m-0 !mt-1 !p-0 !text-2xl !font-bold !text-[#111318]">
                Loan History
              </h2>

              <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
                View your most recent loan application
              </p>
            </div>

            <button
              type="button"
              onClick={refreshLoanHistory}
              disabled={loadingLoan}
              className="inline-flex w-fit items-center gap-2 rounded-xl border border-[#E2E5E9] !bg-white px-4 py-2.5 !text-sm !font-semibold !text-[#252932] shadow-sm transition hover:border-[#B51F35] hover:!text-[#B51F35] disabled:cursor-not-allowed disabled:opacity-60"
            >
              <FiRefreshCw
                size={16}
                className={loadingLoan ? "animate-spin" : ""}
              />
              Refresh
            </button>
          </div>

          {loadingLoan ? (
            <div className="rounded-2xl border border-[#E2E5E9] !bg-white p-8 text-center shadow-sm">
              <FiLoader
                className="mx-auto animate-spin !text-[#B51F35]"
                size={26}
              />

              <p className="!m-0 !mt-3 !p-0 !text-sm !text-[#69707D]">
                Loading loan history...
              </p>
            </div>
          ) : error ? (
            <div className="rounded-2xl border border-red-200 !bg-red-50 p-6">
              <div className="flex items-start gap-3">
                <FiInfo
                  className="mt-0.5 shrink-0 !text-red-600"
                  size={20}
                />

                <div>
                  <h3 className="!m-0 !p-0 !font-bold !text-red-700">
                    Unable to load loan history
                  </h3>

                  <p className="!m-0 !mt-1 !p-0 !text-sm !leading-6 !text-red-600">
                    {error}
                  </p>

                  <button
                    type="button"
                    onClick={refreshLoanHistory}
                    className="mt-4 inline-flex items-center gap-2 rounded-lg !bg-white px-4 py-2 !text-sm !font-semibold !text-red-600 shadow-sm ring-1 ring-red-200 transition hover:!bg-red-50"
                  >
                    <FiRefreshCw size={15} />
                    Try again
                  </button>
                </div>
              </div>
            </div>
          ) : !loan ? (
            <div className="rounded-2xl border border-[#E2E5E9] !bg-white p-8 text-center shadow-sm">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl !bg-[#B51F35]/10 !text-[#B51F35]">
                <FiFileText size={25} />
              </div>

              <h3 className="!m-0 !mt-4 !p-0 !text-lg !font-bold !text-[#111318]">
                No loan applications yet
              </h3>

              <p className="!mx-auto !mt-2 !max-w-md !p-0 !text-sm !leading-6 !text-[#69707D]">
                You have not submitted a loan application yet. Complete the
                form below to get started.
              </p>
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-[#E2E5E9] !bg-white shadow-sm">
              <div className="border-b border-[#E2E5E9] !bg-white p-6">
                <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl !bg-[#B51F35] !text-white">
                      <FiFileText size={22} />
                    </div>

                    <div>
                      <p className="!m-0 !p-0 !text-xs !font-bold uppercase !tracking-[0.12em] !text-[#9298A3]">
                        Loan Application
                      </p>

                      <h3 className="!m-0 !mt-1 break-all !p-0 !text-sm !font-semibold !text-[#252932]">
                        ID: {loan.id}
                      </h3>

                      <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
                        Submitted {formatDate(loan.created_at)}
                      </p>
                    </div>
                  </div>

                  {(() => {
                    const statusInfo = getStatusInfo(loan.status);
                    const StatusIcon = statusInfo.icon;

                    return (
                      <div
                        className={`inline-flex w-fit items-center gap-2 rounded-full border px-3 py-1.5 !text-sm !font-bold ${statusInfo.className}`}
                      >
                        <StatusIcon size={15} />
                        {statusInfo.label}
                      </div>
                    );
                  })()}
                </div>
              </div>

              <div className="!bg-white p-6">
                <div className="mb-6">
                  <p className="!m-0 !p-0 !text-sm !font-medium !text-[#69707D]">
                    Requested Amount
                  </p>

                  <p className="!m-0 !mt-1 !p-0 !text-3xl !font-bold !text-[#111318]">
                    {formatMoney(Number(loan.amount))}
                  </p>
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                    <p className="!m-0 !p-0 !text-xs !font-bold uppercase !tracking-wide !text-[#9298A3]">
                      Purpose
                    </p>

                    <p className="!m-0 !mt-2 !p-0 !text-sm !font-semibold !text-[#252932]">
                      {loan.purpose}
                    </p>
                  </div>

                  <div className="rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                    <p className="!m-0 !p-0 !text-xs !font-bold uppercase !tracking-wide !text-[#9298A3]">
                      Repayment Term
                    </p>

                    <p className="!m-0 !mt-2 !p-0 !text-sm !font-semibold !text-[#252932]">
                      {loan.term_months} months
                    </p>
                  </div>

                  <div className="rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                    <p className="!m-0 !p-0 !text-xs !font-bold uppercase !tracking-wide !text-[#9298A3]">
                      Status
                    </p>

                    <p className="!m-0 !mt-2 !p-0 !text-sm !font-semibold !text-[#252932]">
                      {getStatusInfo(loan.status).label}
                    </p>
                  </div>
                </div>

                {loan.note && (
                  <div className="mt-4 rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                    <p className="!m-0 !p-0 !text-xs !font-bold uppercase !tracking-wide !text-[#9298A3]">
                      Additional Note
                    </p>

                    <p className="!m-0 !mt-2 !p-0 !text-sm !leading-6 !text-[#69707D]">
                      {loan.note}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </section>

        {/* APPLY FOR A LOAN */}
        <section className="mb-10">
          <div className="mb-5">
            <p className="!m-0 !p-0 !text-sm !font-bold uppercase !tracking-[0.14em] !text-[#B51F35]">
              New application
            </p>

            <h2 className="!m-0 !mt-1 !p-0 !text-2xl !font-bold !text-[#111318]">
              Apply for a loan
            </h2>

            <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
              Choose the amount, purpose, and repayment term that fits your
              needs
            </p>
          </div>

          <div className="space-y-6">
            {/* AMOUNT */}
            <div className="rounded-2xl border border-[#E2E5E9] !bg-white p-6 shadow-sm">
              <div className="mb-5 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
                  <FiDollarSign size={20} />
                </div>

                <div>
                  <h3 className="!m-0 !p-0 !font-bold !text-[#111318]">
                    How much do you need?
                  </h3>

                  <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
                    Enter the amount you would like to borrow
                  </p>
                </div>
              </div>

              <label
                htmlFor="loan-amount"
                className="mb-2 block !text-sm !font-bold !text-[#252932]"
              >
                Loan amount
              </label>

              <div className="relative">
                <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 !text-lg !font-bold !text-[#69707D]">
                  $
                </span>

                <input
                  id="loan-amount"
                  type="number"
                  min="0"
                  step="100"
                  value={amount}
                  onChange={handleAmountChange}
                  placeholder="Enter amount"
                  className="w-full rounded-xl border border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-9 pr-4 !text-base !font-semibold !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:border-[#B51F35] focus:!bg-white focus:ring-2 focus:ring-[#B51F35]/10"
                />
              </div>

              {/* LOAN PLANS ARE INFORMATIONAL ONLY */}
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                {loanOptions.map((option) => {
                  return (
                    <div
                      key={option.name}
                      className="rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-4 transition hover:border-[#B51F35]/30 hover:shadow-sm"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="!m-0 !p-0 !text-sm !font-bold !text-[#111318]">
                          {option.name}
                        </p>
                      </div>

                      <p className="!m-0 !mt-2 !p-0 !text-sm !font-semibold !text-[#252932]">
                        {formatMoney(option.min)} to{" "}
                        {formatMoney(option.max)}
                      </p>

                      <p className="!m-0 !mt-1 !p-0 !text-xs !text-[#69707D]">
                        {option.terms.join(", ")} month terms
                      </p>
                    </div>
                  );
                })}
              </div>

              <div className="mt-4 rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                <p className="!m-0 !p-0 !text-sm !leading-6 !text-[#69707D]">
                  Enter the amount you need above. Available repayment terms
                  will be shown based on the amount you enter. No loan plan or
                  repayment term is selected automatically.
                </p>
              </div>
            </div>

            {/* PURPOSE */}
            <div className="rounded-2xl border border-[#E2E5E9] !bg-white p-6 shadow-sm">
              <div className="mb-5 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
                  <FiBriefcase size={20} />
                </div>

                <div>
                  <h3 className="!m-0 !p-0 !font-bold !text-[#111318]">
                    What is the loan for?
                  </h3>

                  <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
                    Select the purpose that best describes your need
                  </p>
                </div>
              </div>

              <label
                htmlFor="loan-purpose"
                className="mb-2 block !text-sm !font-bold !text-[#252932]"
              >
                Loan purpose
              </label>

              <div className="relative">
                <select
                  id="loan-purpose"
                  value={purpose}
                  onChange={(event) => setPurpose(event.target.value)}
                  className="w-full appearance-none rounded-xl border border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 pr-11 !text-sm !font-medium !text-[#111318] outline-none transition focus:border-[#B51F35] focus:!bg-white focus:ring-2 focus:ring-[#B51F35]/10"
                >
                  <option value="" className="!bg-white !text-[#111318]">
                    Select a purpose
                  </option>

                  {purposes.map((item) => (
                    <option
                      key={item}
                      value={item}
                      className="!bg-white !text-[#111318]"
                    >
                      {item}
                    </option>
                  ))}
                </select>

                <FiChevronDown
                  className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 !text-[#69707D]"
                  size={18}
                />
              </div>
            </div>

            {/* TERM */}
            <div className="rounded-2xl border border-[#E2E5E9] !bg-white p-6 shadow-sm">
              <div className="mb-5 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
                  <FiClock size={20} />
                </div>

                <div>
                  <h3 className="!m-0 !p-0 !font-bold !text-[#111318]">
                    Repayment term
                  </h3>

                  <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
                    Choose how long you would like to repay the loan
                  </p>
                </div>
              </div>

              <label
                htmlFor="loan-term"
                className="mb-2 block !text-sm !font-bold !text-[#252932]"
              >
                Repayment period
              </label>

              <div className="relative">
                <select
                  id="loan-term"
                  value={term}
                  onChange={(event) => setTerm(event.target.value)}
                  disabled={!matchingLoanOption}
                  className="w-full appearance-none rounded-xl border border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 pr-11 !text-sm !font-medium !text-[#111318] outline-none transition focus:border-[#B51F35] focus:!bg-white focus:ring-2 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <option
                    value=""
                    className="!bg-white !text-[#111318]"
                  >
                    {matchingLoanOption
                      ? "Select repayment term"
                      : "Enter a valid loan amount first"}
                  </option>

                  {availableTerms.map((months) => (
                    <option
                      key={months}
                      value={months}
                      className="!bg-white !text-[#111318]"
                    >
                      {months} months
                    </option>
                  ))}
                </select>

                <FiChevronDown
                  className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 !text-[#69707D]"
                  size={18}
                />
              </div>

              {matchingLoanOption && (
                <div className="mt-4 rounded-xl border border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                  <p className="!m-0 !p-0 !text-sm !leading-6 !text-[#69707D]">
                    Based on the amount entered, the available repayment terms
                    are{" "}
                    <span className="!font-bold !text-[#B51F35]">
                      {availableTerms.join(", ")} months
                    </span>
                    . Please select the term you prefer.
                  </p>
                </div>
              )}
            </div>

            {/* NOTE */}
            <div className="rounded-2xl border border-[#E2E5E9] !bg-white p-6 shadow-sm">
              <div className="mb-5 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
                  <FiFileText size={20} />
                </div>

                <div>
                  <h3 className="!m-0 !p-0 !font-bold !text-[#111318]">
                    Additional information
                  </h3>

                  <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
                    Add anything else you would like us to know
                  </p>
                </div>
              </div>

              <label
                htmlFor="loan-note"
                className="mb-2 block !text-sm !font-bold !text-[#252932]"
              >
                Note{" "}
                <span className="!font-normal !text-[#9298A3]">
                  (optional)
                </span>
              </label>

              <textarea
                id="loan-note"
                value={note}
                onChange={(event) => setNote(event.target.value)}
                rows={4}
                placeholder="Tell us anything that may help with your application..."
                className="w-full resize-none rounded-xl border border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-sm !font-medium !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:border-[#B51F35] focus:!bg-white focus:ring-2 focus:ring-[#B51F35]/10"
              />
            </div>

            {/* ERROR */}
            {error && (
              <div className="rounded-xl border border-red-200 !bg-red-50 p-4">
                <div className="flex items-start gap-3">
                  <FiInfo
                    className="mt-0.5 shrink-0 !text-red-600"
                    size={19}
                  />

                  <p className="!m-0 !p-0 !text-sm !font-medium !leading-6 !text-red-600">
                    {error}
                  </p>
                </div>
              </div>
            )}

            {/* CONTINUE */}
            <div className="rounded-2xl border border-[#E2E5E9] !bg-white p-6 shadow-sm">
              <button
                type="button"
                onClick={handleContinue}
                className="flex w-full items-center justify-center gap-2 rounded-xl !bg-[#B51F35] px-5 py-3.5 !text-sm !font-bold !text-white shadow-sm transition hover:!bg-[#9F1B30] focus:outline-none focus:ring-2 focus:ring-[#B51F35]/30 focus:ring-offset-2"
              >
                Continue Application
                <FiArrowRight size={18} />
              </button>

              <p className="!m-0 !mt-4 !p-0 !text-center !text-xs !leading-5 !text-[#9298A3]">
                By continuing, you will proceed to the verification step for
                your loan application.
              </p>
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="mb-10">
          <div className="mb-5">
            <p className="!m-0 !p-0 !text-sm !font-bold uppercase !tracking-[0.14em] !text-[#B51F35]">
              Simple process
            </p>

            <h2 className="!m-0 !mt-1 !p-0 !text-2xl !font-bold !text-[#111318]">
              How it works
            </h2>

            <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
              A straightforward application process from start to finish
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {howItWorks.map((item) => {
              const Icon = item.icon;

              return (
                <div
                  key={item.number}
                  className="rounded-2xl border border-[#E2E5E9] !bg-white p-6 shadow-sm transition hover:border-[#B51F35]/30"
                >
                  <div className="flex items-start gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
                      <Icon size={21} />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="!text-xs !font-bold !text-[#9298A3]">
                          {item.number}
                        </span>

                        <h3 className="!m-0 !p-0 !font-bold !text-[#111318]">
                          {item.title}
                        </h3>
                      </div>

                      <p className="!m-0 !mt-2 !p-0 !text-sm !leading-6 !text-[#69707D]">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* WHAT YOU CAN USE YOUR LOAN FOR */}
        <section className="mb-10">
          <div className="mb-5">
            <p className="!m-0 !p-0 !text-sm !font-bold uppercase !tracking-[0.14em] !text-[#B51F35]">
              Flexible financing
            </p>

            <h2 className="!m-0 !mt-1 !p-0 !text-2xl !font-bold !text-[#111318]">
              What you can use your loan for
            </h2>

            <p className="!m-0 !mt-1 !p-0 !text-sm !text-[#69707D]">
              Financing can be used for a variety of qualifying financial needs
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {loanUses.map((item) => {
              const Icon = item.icon;

              return (
                <div
                  key={item.title}
                  className="rounded-2xl border border-[#E2E5E9] !bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-[#B51F35]/30 hover:shadow-md"
                >
                  <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
                    <Icon size={21} />
                  </div>

                  <h3 className="!m-0 !p-0 !font-bold !text-[#111318]">
                    {item.title}
                  </h3>

                  <p className="!m-0 !mt-2 !p-0 !text-sm !leading-6 !text-[#69707D]">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </section>

        {/* IMPORTANT INFORMATION */}
        <section className="rounded-2xl border border-[#E2E5E9] !bg-white p-6 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
              <FiInfo size={21} />
            </div>

            <div>
              <h2 className="!m-0 !p-0 !font-bold !text-[#111318]">
                Important information
              </h2>

              <p className="!m-0 !mt-2 !p-0 !text-sm !leading-6 !text-[#69707D]">
                Loan applications are subject to review and approval.
                Available amounts and repayment terms may vary based on your
                application and eligibility. Having less than perfect credit
                does not automatically prevent you from applying, but
                completing an application does not guarantee approval.
              </p>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

export default function LoansPage() {
  return (
    <Suspense
      fallback={
        <main
          className="ff-product-page ff-loans-page !min-h-screen !bg-[#F8F9FB]"
          style={{ backgroundColor: "#F8F9FB" }}
        >
          <div className="flex min-h-screen items-center justify-center">
            <div className="flex flex-col items-center">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-[#E2E5E9] border-t-[#B51F35]" />

              <p className="!m-0 !mt-4 !p-0 !text-sm !font-medium !text-[#69707D]">
                Loading...
              </p>
            </div>
          </div>
        </main>
      }
    >
      <LoansPageContent />
    </Suspense>
  );
}