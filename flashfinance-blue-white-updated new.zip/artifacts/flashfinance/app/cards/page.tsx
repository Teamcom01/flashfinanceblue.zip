"use client";

import { useEffect, useState } from "react";
import { createClient } from "../../lib/supabase";

type Card = {
  id: string;
  card_number: string;
  last4: string | null;
  card_type: string;
  status: string;
  balance: number;
  created_at: string;
};

export default function CardsPage() {
  const supabase = createClient();

  const [cards, setCards] = useState<Card[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    loadCards();
  }, []);

  async function loadCards() {
    setLoading(true);
    setError("");

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setError("You must be logged in to view your cards.");
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from("cards")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      setError(error.message);
    } else {
      setCards(data || []);
    }

    setLoading(false);
  }

  function openCreateConfirmation() {
    setMessage("");
    setError("");
    setShowConfirmation(true);
  }

  function closeCreateConfirmation() {
    if (!creating) {
      setShowConfirmation(false);
    }
  }

  async function confirmCreateCard() {
    setCreating(true);
    setMessage("");
    setError("");

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setError("You must be logged in to create a card.");
      setCreating(false);
      return;
    }

    const { error } = await supabase.rpc("create_virtual_card");

    if (error) {
      setError(error.message);
      setCreating(false);
      return;
    }

    setShowConfirmation(false);

    setMessage(
      "Your virtual card has been created successfully. A $1,000 creation fee was charged to your account."
    );

    await loadCards();

    setCreating(false);
  }

  function formatCardNumber(cardNumber: string, last4: string | null) {
    if (last4) {
      return `•••• •••• •••• ${last4}`;
    }

    const numbers = cardNumber.replace(/\s/g, "");

    if (numbers.length <= 4) {
      return numbers;
    }

    return `•••• •••• •••• ${numbers.slice(-4)}`;
  }

  function formatDate(date: string) {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  }

  return (
    <main className="min-h-screen !bg-[#F1F3F6] px-4 py-8 !text-[#111318] sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">

        {/* HEADER */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] !text-[#B51F35]">
              FlashFinance
            </p>

            <h1 className="mt-1 text-3xl font-bold tracking-tight !text-[#111318]">
              My Cards
            </h1>

            <p className="mt-1 text-sm !text-[#69707D]">
              Manage your FlashFinance virtual cards
            </p>
          </div>

          <button
            onClick={openCreateConfirmation}
            disabled={creating}
            className="rounded-2xl bg-[#B51F35] px-5 py-3 font-semibold text-white shadow-sm transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
          >
            + Create Virtual Card
          </button>
        </div>

        {/* SUCCESS MESSAGE */}
        {message && (
          <div className="mb-6 rounded-2xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
            {message}
          </div>
        )}

        {/* ERROR MESSAGE */}
        {error && (
          <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        {/* CARDS */}
        {loading ? (
          <div className="rounded-[28px] !border !border-[#E2E5E9] !bg-white p-10 text-center shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
            <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-[#E2E5E9] border-t-[#B51F35]" />

            <p className="mt-4 text-sm !text-[#69707D]">
              Loading your cards...
            </p>
          </div>
        ) : cards.length === 0 ? (
          <div className="rounded-[28px] !border !border-[#E2E5E9] !bg-white p-10 text-center shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#B51F35] text-3xl text-white">
              💳
            </div>

            <h2 className="text-xl font-bold !text-[#111318]">
              You don't have a card yet
            </h2>

            <p className="mx-auto mt-2 max-w-md text-sm leading-6 !text-[#69707D]">
              Create a virtual FlashFinance card to start making online
              payments.
            </p>

            <button
              onClick={openCreateConfirmation}
              disabled={creating}
              className="mt-6 rounded-2xl bg-[#B51F35] px-6 py-3 font-semibold text-white transition hover:bg-[#C9213A] disabled:opacity-50"
            >
              Create Virtual Card
            </button>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {cards.map((card) => (
              <div
                key={card.id}
                className="relative overflow-hidden rounded-[30px] bg-gradient-to-br from-[#B51F35] via-[#C9213A] to-[#991B30] p-6 text-white shadow-[0_16px_40px_rgba(181,31,53,0.20)]"
              >
                <div className="absolute -right-20 -top-20 h-48 w-48 rounded-full bg-white/10 blur-3xl" />

                <div className="absolute -bottom-20 -left-16 h-44 w-44 rounded-full bg-white/[0.05] blur-3xl" />

                <div className="relative">

                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs uppercase tracking-[0.2em] text-white/60">
                        FlashFinance
                      </p>

                      <p className="mt-1 text-sm capitalize text-white/90">
                        {card.card_type} Card
                      </p>
                    </div>

                    <div className="flex h-10 w-14 items-center justify-center rounded-xl border border-white/20 bg-white/10">
                      <span className="text-lg text-white">
                        ▰
                      </span>
                    </div>
                  </div>

                  <div className="mt-12">
                    <p className="text-xs text-white/60">
                      Card Number
                    </p>

                    <p className="mt-2 font-mono text-xl tracking-widest text-white">
                      {formatCardNumber(
                        card.card_number,
                        card.last4
                      )}
                    </p>
                  </div>

                  <div className="mt-10 grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-xs text-white/60">
                        Status
                      </p>

                      <p className="mt-1 text-sm font-semibold capitalize text-white">
                        {card.status}
                      </p>
                    </div>

                    <div>
                      <p className="text-xs text-white/60">
                        Created
                      </p>

                      <p className="mt-1 text-sm text-white/85">
                        {formatDate(card.created_at)}
                      </p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs text-white/60">
                        Balance
                      </p>

                      <p className="mt-1 text-lg font-bold text-white">
                        ${Number(card.balance || 0).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* INFORMATION */}
        <div className="mt-8 rounded-[28px] !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35] text-lg text-white">
              💳
            </div>

            <h3 className="font-bold !text-[#111318]">
              Virtual Cards
            </h3>
          </div>

          <p className="mt-3 text-sm leading-6 !text-[#69707D]">
            Your FlashFinance virtual card can be used for online payments.
            Keep your card details secure and never share sensitive card
            information with anyone.
          </p>
        </div>

        {/* BACK */}
        <div className="mt-6">
          <a
            href="/payments"
            className="text-sm font-semibold !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            ← Back to Payments
          </a>
        </div>
      </div>

      {/* CONFIRMATION MODAL */}
      {showConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B0E17]/60 px-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-[30px] !border !border-[#E2E5E9] !bg-white p-7 !text-[#111318] shadow-2xl">

            <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#B51F35] text-2xl text-white">
              💳
            </div>

            <h2 className="text-2xl font-bold !text-[#111318]">
              Create Virtual Card
            </h2>

            <p className="mt-3 text-sm leading-6 !text-[#69707D]">
              A virtual card creation fee of{" "}
              <span className="font-semibold !text-[#111318]">
                $1,000
              </span>{" "}
              will be charged to your FlashFinance account.
            </p>

            <div className="mt-5 rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm !text-[#69707D]">
                  Card creation fee
                </span>

                <span className="font-bold !text-[#111318]">
                  $1,000
                </span>
              </div>
            </div>

            <p className="mt-4 text-xs leading-5 !text-[#9298A3]">
              The charge will be deducted immediately after you confirm.
              Please make sure you have sufficient funds before continuing.
            </p>

            <div className="mt-7 grid grid-cols-2 gap-3">
              <button
                onClick={closeCreateConfirmation}
                disabled={creating}
                className="rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3 font-semibold !text-[#111318] transition hover:!bg-[#E2E5E9] disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                onClick={confirmCreateCard}
                disabled={creating}
                className="rounded-2xl bg-[#B51F35] px-4 py-3 font-semibold text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {creating
                  ? "Processing..."
                  : "Confirm & Pay $1,000"}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}