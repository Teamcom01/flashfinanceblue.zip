"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase";

const US_STATES = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming",
  "Washington, D.C.",
];

type KycStatus =
  | "not_started"
  | "under_review"
  | "approved"
  | "rejected"
  | "changes_requested";

type ExistingKyc = {
  id: string;
  status: Exclude<KycStatus, "not_started">;
  admin_note: string | null;
  created_at: string;
};

const MAX_ID_SIZE = 10 * 1024 * 1024;
const MAX_SELFIE_SIZE = 5 * 1024 * 1024;

export default function KycPage() {
  const router = useRouter();
  const supabase = createClient();

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [kycStatus, setKycStatus] = useState<KycStatus>("not_started");
  const [existingKyc, setExistingKyc] = useState<ExistingKyc | null>(null);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [zipCode, setZipCode] = useState("");

  const [idType, setIdType] = useState("");
  const [idDocument, setIdDocument] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);

  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    async function loadKyc() {
      try {
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) {
          router.replace("/login");
          return;
        }

        const { data: kycRecord, error: kycError } = await supabase
          .from("kyc_submissions")
          .select("id,status,admin_note,created_at")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        if (kycError) {
          console.error("KYC record loading error:", kycError);
          setMessage(
            "We could not load your verification status. Please refresh the page and try again."
          );
        }

        if (kycRecord) {
          const status = kycRecord.status as KycStatus;

          setExistingKyc({
            id: kycRecord.id,
            status: status as Exclude<KycStatus, "not_started">,
            admin_note: kycRecord.admin_note,
            created_at: kycRecord.created_at,
          });

          setKycStatus(status);
        }

        const metadata = user.user_metadata || {};

        if (metadata.first_name) {
          setFirstName(String(metadata.first_name));
        }

        if (metadata.last_name) {
          setLastName(String(metadata.last_name));
        }

        if (
          metadata.full_name &&
          !metadata.first_name &&
          !metadata.last_name
        ) {
          const fullName = String(metadata.full_name).trim();
          const parts = fullName.split(/\s+/);

          if (parts.length > 0) {
            setFirstName(parts[0]);
          }

          if (parts.length > 1) {
            setLastName(parts.slice(1).join(" "));
          }
        }
      } catch (error) {
        console.error("KYC loading error:", error);
        router.replace("/login");
      } finally {
        setLoading(false);
      }
    }

    loadKyc();
  }, [router, supabase]);

  function getFileExtension(file: File) {
    const parts = file.name.split(".");
    const extension = parts.length > 1 ? parts.pop() : "";

    return (
      String(extension || "file")
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "")
        .slice(0, 10) || "file"
    );
  }

  function validateFiles() {
    if (!idDocument || !selfie) {
      setMessage(
        "Please upload both your identification document and your selfie."
      );
      return false;
    }

    if (idDocument.size > MAX_ID_SIZE) {
      setMessage(
        "Your identification document is too large. Please upload a file smaller than 10 MB."
      );
      return false;
    }

    if (selfie.size > MAX_SELFIE_SIZE) {
      setMessage(
        "Your selfie is too large. Please upload an image smaller than 5 MB."
      );
      return false;
    }

    const allowedIdTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/webp",
      "image/heic",
      "image/heif",
    ];

    if (
      idDocument.type &&
      !allowedIdTypes.includes(idDocument.type.toLowerCase())
    ) {
      setMessage(
        "Please upload a PDF, JPG, PNG, WEBP, HEIC, or HEIF identification document."
      );
      return false;
    }

    if (!selfie.type.toLowerCase().startsWith("image/")) {
      setMessage("Please upload a valid image for your selfie.");
      return false;
    }

    return true;
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setMessage("");
    setSuccess(false);

    if (
      !firstName.trim() ||
      !lastName.trim() ||
      !dateOfBirth ||
      !address.trim() ||
      !city.trim() ||
      !state ||
      !idType ||
      !idDocument ||
      !selfie
    ) {
      setMessage(
        "Please complete all required fields and upload both your identification document and selfie."
      );
      return;
    }

    if (!validateFiles()) {
      return;
    }

    setSubmitting(true);

    let idDocumentPath = "";
    let selfiePath = "";

    try {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError || !user) {
        throw new Error("Your session has expired. Please log in again.");
      }

      const { data: latestKyc, error: latestKycError } = await supabase
        .from("kyc_submissions")
        .select("id,status")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (latestKycError) {
        throw latestKycError;
      }

      if (
        latestKyc &&
        (latestKyc.status === "under_review" ||
          latestKyc.status === "approved")
      ) {
        setKycStatus(latestKyc.status as KycStatus);
        throw new Error(
          "A KYC submission already exists for this account."
        );
      }

      const timestamp = Date.now();

      const idExtension = getFileExtension(idDocument);
      const selfieExtension = getFileExtension(selfie);

      idDocumentPath = `${user.id}/identification-document-${timestamp}.${idExtension}`;
      selfiePath = `${user.id}/selfie-${timestamp}.${selfieExtension}`;

      setMessage("Uploading your identification document...");

      const { error: idUploadError } = await supabase.storage
        .from("kyc-documents")
        .upload(idDocumentPath, idDocument, {
          cacheControl: "3600",
          contentType: idDocument.type || "application/octet-stream",
          upsert: false,
        });

      if (idUploadError) {
        throw new Error(
          `Identification document upload failed: ${idUploadError.message}`
        );
      }

      setMessage("Uploading your selfie...");

      const { error: selfieUploadError } = await supabase.storage
        .from("kyc-documents")
        .upload(selfiePath, selfie, {
          cacheControl: "3600",
          contentType: selfie.type || "image/jpeg",
          upsert: false,
        });

      if (selfieUploadError) {
        await supabase.storage
          .from("kyc-documents")
          .remove([idDocumentPath]);

        throw new Error(
          `Selfie upload failed: ${selfieUploadError.message}`
        );
      }

      setMessage("Saving your verification information...");

      const { data: submittedKycId, error: submitError } =
        await supabase.rpc("submit_kyc_submission", {
          p_first_name: firstName.trim(),
          p_last_name: lastName.trim(),
          p_date_of_birth: dateOfBirth,
          p_address: address.trim(),
          p_city: city.trim(),
          p_state: state,
          p_zip_code: zipCode.trim(),
          p_id_type: idType,
          p_id_document_path: idDocumentPath,
          p_selfie_path: selfiePath,
        });

      if (submitError) {
        await supabase.storage
          .from("kyc-documents")
          .remove([idDocumentPath, selfiePath]);

        throw new Error(submitError.message);
      }

      const newKyc: ExistingKyc = {
        id: String(submittedKycId),
        status: "under_review",
        admin_note: null,
        created_at: new Date().toISOString(),
      };

      setExistingKyc(newKyc);
      setKycStatus("under_review");
      setSuccess(true);

      setMessage(
        "Your verification request has been received successfully. Our team will review your information and update your account once the review is complete."
      );

      setTimeout(() => {
        router.push("/dashboard");
        router.refresh();
      }, 2500);
    } catch (error) {
      console.error("KYC submission error:", error);

      const errorMessage =
        error instanceof Error
          ? error.message
          : "Something went wrong while submitting your verification.";

      setMessage(errorMessage);
      setSuccess(false);
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center !bg-[#F1F3F6] !text-[#111318]">
        <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-10 text-center shadow-[0_8px_30px_rgba(0,0,0,0.06)]">
          <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-2 border-[#E2E5E9] border-t-[#B51F35]" />

          <p className="text-sm !text-[#69707D]">
            Preparing your verification page...
          </p>
        </div>
      </main>
    );
  }

  if (kycStatus === "under_review") {
    return (
      <StatusScreen
        router={router}
        title="Your KYC is under review"
        badge="Verification Under Review"
        badgeClass="!text-[#B51F35]"
        iconType="clock"
        description="Thank you for completing your identity verification. Your information has been received and is currently being reviewed by our verification team."
        secondaryText="You do not need to submit your verification again. We will update your account once the review has been completed."
        steps={[
          {
            number: "1",
            title: "Verification submitted",
            description:
              "Your identity information and verification documents have been submitted for review.",
            active: true,
          },
          {
            number: "2",
            title: "Verification review",
            description:
              "Our team is reviewing the information you provided.",
            active: true,
          },
          {
            number: "3",
            title: "Account update",
            description:
              "Your account will be updated after the review is completed.",
            active: false,
          },
        ]}
      />
    );
  }

  if (kycStatus === "approved") {
    return (
      <StatusScreen
        router={router}
        title="Your identity has been verified"
        badge="Verification Approved"
        badgeClass="text-green-600"
        iconType="check"
        description="Your KYC verification has been successfully completed. Your identity information has been reviewed and approved."
        secondaryText="Your FlashFinance account has been updated and your verification is complete."
        steps={[
          {
            number: "1",
            title: "Verification submitted",
            description:
              "Your identity information was successfully submitted.",
            active: true,
          },
          {
            number: "2",
            title: "Verification approved",
            description:
              "Our verification team reviewed and approved your information.",
            active: true,
          },
          {
            number: "3",
            title: "Account verified",
            description:
              "Your account is now marked as identity verified.",
            active: true,
          },
        ]}
      />
    );
  }

  if (kycStatus === "rejected") {
    return (
      <StatusScreen
        router={router}
        title="Your verification was not approved"
        badge="Verification Rejected"
        badgeClass="text-red-600"
        iconType="x"
        description="Your KYC submission was reviewed but could not be approved at this time."
        secondaryText={
          existingKyc?.admin_note
            ? `Review note from our verification team: ${existingKyc.admin_note}`
            : "Please contact FlashFinance support for more information about your verification."
        }
        steps={[
          {
            number: "1",
            title: "Verification submitted",
            description:
              "Your documents and identity information were received.",
            active: true,
          },
          {
            number: "2",
            title: "Verification reviewed",
            description:
              "Our verification team reviewed your submission.",
            active: true,
          },
          {
            number: "3",
            title: "Verification rejected",
            description:
              "The submitted information could not be approved.",
            active: false,
          },
        ]}
      />
    );
  }

  return (
    <main className="min-h-screen !bg-[#F1F3F6] px-5 py-10 !text-[#111318] sm:px-6 lg:px-8">
      <div className="mx-auto w-full max-w-4xl">

        {/* Top Navigation */}
        <div className="mb-8 flex items-center justify-between">
          <button
            type="button"
            onClick={() => router.push("/dashboard")}
            className="text-sm font-medium !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            ← Back to Dashboard
          </button>

          <a
            href="/"
            className="text-xl font-bold tracking-wide sm:text-2xl"
          >
            <span className="!text-[#111318]">FLASH</span>
            <span className="!text-[#B51F35]">FINANCE</span>
          </a>
        </div>

        {/* Hero */}
        <div className="mb-8 overflow-hidden rounded-[30px] !bg-[#0B0E17] shadow-[0_12px_35px_rgba(0,0,0,0.12)]">
          <div className="p-7 sm:p-10">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#B51F35]/30 bg-[#B51F35]/15 px-4 py-2 text-xs font-semibold uppercase tracking-wider !text-[#E65A6E]">
              <span className="h-2 w-2 rounded-full bg-[#C9213A]" />
              Secure Identity Verification
            </div>

            <h1 className="max-w-3xl text-3xl font-bold leading-tight text-white sm:text-4xl lg:text-5xl">
              {kycStatus === "changes_requested"
                ? "Update your verification"
                : "Let's verify your identity"}
            </h1>

            <p className="mt-5 max-w-2xl text-base leading-7 !text-[#B8BDC6] sm:text-lg">
              {kycStatus === "changes_requested"
                ? "Our verification team has requested changes to your submission. Please review the note below and submit your updated information."
                : "Complete the verification below to help us confirm your identity and keep your FlashFinance account secure."}
            </p>

            <p className="mt-4 max-w-2xl text-sm leading-6 !text-[#9298A3]">
              Please provide accurate information and upload a clear
              identification document together with a recent selfie. Make
              sure the information you provide matches your identification
              document.
            </p>
          </div>
        </div>

        {kycStatus === "changes_requested" && existingKyc?.admin_note && (
          <div className="mb-8 rounded-2xl border border-orange-200 bg-orange-50 p-5">
            <div className="flex gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-orange-100 font-bold text-orange-600">
                !
              </div>

              <div>
                <h2 className="font-semibold text-orange-700">
                  Changes requested
                </h2>

                <p className="mt-2 text-sm leading-6 text-orange-800/80">
                  {existingKyc.admin_note}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Progress */}
        <div className="mb-8 grid grid-cols-3 gap-3">
          <div className="rounded-2xl !border !border-[#B51F35]/30 !bg-white p-4 shadow-sm">
            <div className="mb-2 text-xs font-semibold !text-[#B51F35]">
              STEP 1
            </div>

            <div className="text-sm font-semibold !text-[#111318]">
              Personal details
            </div>
          </div>

          <div className="rounded-2xl !border !border-[#E2E5E9] !bg-white p-4 shadow-sm">
            <div className="mb-2 text-xs font-semibold !text-[#B51F35]">
              STEP 2
            </div>

            <div className="text-sm font-semibold !text-[#111318]">
              Address
            </div>
          </div>

          <div className="rounded-2xl !border !border-[#E2E5E9] !bg-white p-4 shadow-sm">
            <div className="mb-2 text-xs font-semibold !text-[#B51F35]">
              STEP 3
            </div>

            <div className="text-sm font-semibold !text-[#111318]">
              Identity
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="rounded-[30px] !border !border-[#E2E5E9] !bg-white shadow-[0_8px_30px_rgba(0,0,0,0.06)]">
          <form onSubmit={handleSubmit}>
            {/* Personal Information */}
            <section className="p-6 sm:p-8">
              <div className="mb-7">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wider !text-[#B51F35]">
                  Step 1
                </div>

                <h2 className="text-2xl font-bold !text-[#111318]">
                  Personal Information
                </h2>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  Enter your legal information exactly as it appears on your
                  identification document.
                </p>
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="firstName"
                    className="mb-2 block text-sm font-medium !text-[#252932]"
                  >
                    First Name *
                  </label>

                  <input
                    id="firstName"
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="Enter your first name"
                    autoComplete="given-name"
                    required
                    disabled={submitting}
                    className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>

                <div>
                  <label
                    htmlFor="lastName"
                    className="mb-2 block text-sm font-medium !text-[#252932]"
                  >
                    Last Name *
                  </label>

                  <input
                    id="lastName"
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="Enter your last name"
                    autoComplete="family-name"
                    required
                    disabled={submitting}
                    className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>

                <div>
                  <label
                    htmlFor="dateOfBirth"
                    className="mb-2 block text-sm font-medium !text-[#252932]"
                  >
                    Date of Birth *
                  </label>

                  <input
                    id="dateOfBirth"
                    type="date"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    autoComplete="bday"
                    required
                    disabled={submitting}
                    className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>
              </div>
            </section>

            {/* Address */}
            <section className="border-t border-[#E2E5E9] p-6 sm:p-8">
              <div className="mb-7">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wider !text-[#B51F35]">
                  Step 2
                </div>

                <h2 className="text-2xl font-bold !text-[#111318]">
                  Residential Address
                </h2>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  Provide the address where you currently reside.
                </p>
              </div>

              <div className="space-y-5">
                <div>
                  <label
                    htmlFor="address"
                    className="mb-2 block text-sm font-medium !text-[#252932]"
                  >
                    Street Address *
                  </label>

                  <input
                    id="address"
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Enter your street address"
                    autoComplete="street-address"
                    required
                    disabled={submitting}
                    className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  />
                </div>

                <div className="grid gap-5 sm:grid-cols-3">
                  <div>
                    <label
                      htmlFor="city"
                      className="mb-2 block text-sm font-medium !text-[#252932]"
                    >
                      City *
                    </label>

                    <input
                      id="city"
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="City"
                      autoComplete="address-level2"
                      required
                      disabled={submitting}
                      className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="state"
                      className="mb-2 block text-sm font-medium !text-[#252932]"
                    >
                      State *
                    </label>

                    <select
                      id="state"
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      autoComplete="address-level1"
                      required
                      disabled={submitting}
                      className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      <option value="">Select your state</option>

                      {US_STATES.map((stateName) => (
                        <option key={stateName} value={stateName}>
                          {stateName}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="zipCode"
                      className="mb-2 block text-sm font-medium !text-[#252932]"
                    >
                      Zip Code
                    </label>

                    <input
                      id="zipCode"
                      type="text"
                      value={zipCode}
                      onChange={(e) => setZipCode(e.target.value)}
                      placeholder="Zip code"
                      autoComplete="postal-code"
                      inputMode="numeric"
                      disabled={submitting}
                      className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* Identity */}
            <section className="border-t border-[#E2E5E9] p-6 sm:p-8">
              <div className="mb-7">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wider !text-[#B51F35]">
                  Step 3
                </div>

                <h2 className="text-2xl font-bold !text-[#111318]">
                  Identity Verification
                </h2>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  Select your identification type and upload both your
                  identification document and a clear selfie.
                </p>
              </div>

              <div className="space-y-6">
                <div>
                  <label
                    htmlFor="idType"
                    className="mb-2 block text-sm font-medium !text-[#252932]"
                  >
                    Identification Type *
                  </label>

                  <select
                    id="idType"
                    value={idType}
                    onChange={(e) => setIdType(e.target.value)}
                    required
                    disabled={submitting}
                    className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 !text-[#111318] outline-none transition focus:!border-[#B51F35] focus:ring-1 focus:ring-[#B51F35]/10 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <option value="">Select identification type</option>

                    <option value="passport">Passport</option>

                    <option value="drivers_license">
                      Driver&apos;s License
                    </option>

                    <option value="national_id">National ID</option>

                    <option value="state_id">State ID</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="idDocument"
                    className="mb-2 block text-sm font-medium !text-[#252932]"
                  >
                    Identification Document *
                  </label>

                  <div className="rounded-2xl border border-dashed border-[#D4D8DE] bg-[#F8F9FB] p-5 transition hover:border-[#B51F35]/40">
                    <input
                      id="idDocument"
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) =>
                        setIdDocument(e.target.files?.[0] || null)
                      }
                      required
                      disabled={submitting}
                      className="w-full text-sm !text-[#69707D] file:mr-4 file:rounded-xl file:border-0 file:bg-[#B51F35] file:px-4 file:py-2.5 file:font-semibold file:text-white hover:file:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-60"
                    />

                    <p className="mt-3 text-xs leading-5 !text-[#9298A3]">
                      Upload a clear image or PDF of your selected
                      identification document. Maximum size: 10 MB.
                    </p>

                    {idDocument && (
                      <div className="mt-3 rounded-xl border border-green-200 bg-green-50 px-3 py-2 text-xs text-green-700">
                        Document selected: {idDocument.name}
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="selfie"
                    className="mb-2 block text-sm font-medium !text-[#252932]"
                  >
                    Selfie *
                  </label>

                  <div className="rounded-2xl border border-dashed border-[#D4D8DE] bg-[#F8F9FB] p-5 transition hover:border-[#B51F35]/40">
                    <input
                      id="selfie"
                      type="file"
                      accept="image/*"
                      capture="user"
                      onChange={(e) =>
                        setSelfie(e.target.files?.[0] || null)
                      }
                      required
                      disabled={submitting}
                      className="w-full text-sm !text-[#69707D] file:mr-4 file:rounded-xl file:border-0 file:bg-[#B51F35] file:px-4 file:py-2.5 file:font-semibold file:text-white hover:file:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-60"
                    />

                    <p className="mt-3 text-xs leading-5 !text-[#9298A3]">
                      Upload a clear recent selfie with your face fully
                      visible. Maximum size: 5 MB.
                    </p>

                    {selfie && (
                      <div className="mt-3 rounded-xl border border-green-200 bg-green-50 px-3 py-2 text-xs text-green-700">
                        Selfie selected: {selfie.name}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </section>

            {/* Notice */}
            <section className="border-t border-[#E2E5E9] p-6 sm:p-8">
              <div className="rounded-2xl border border-[#B51F35]/20 bg-[#B51F35]/5 p-5">
                <div className="flex gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#B51F35]/10 text-lg font-bold !text-[#B51F35]">
                    ✓
                  </div>

                  <div>
                    <h3 className="font-semibold !text-[#B51F35]">
                      Before you submit
                    </h3>

                    <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                      Make sure your personal details are accurate, your
                      identification document is clear and readable, and
                      your selfie clearly shows your face.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Message */}
            {message && (
              <div className="px-6 pb-2 sm:px-8">
                <div
                  className={`rounded-2xl border p-4 text-sm leading-6 ${
                    success
                      ? "border-green-200 bg-green-50 text-green-700"
                      : "border-red-200 bg-red-50 text-red-700"
                  }`}
                >
                  {message}

                  {success && (
                    <p className="mt-2 text-xs text-green-600">
                      Redirecting you to your dashboard...
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Submit */}
            <div className="border-t border-[#E2E5E9] p-6 sm:p-8">
              <button
                type="submit"
                disabled={submitting || success}
                className="w-full rounded-2xl bg-[#B51F35] py-4 font-bold text-white shadow-sm transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {submitting
                  ? "Submitting Verification..."
                  : success
                    ? "Verification Submitted"
                    : kycStatus === "changes_requested"
                      ? "Submit Updated Verification"
                      : "Submit Verification"}
              </button>

              <p className="mt-4 text-center text-xs leading-5 !text-[#9298A3]">
                Please review your information carefully before submitting.
              </p>
            </div>
          </form>
        </div>

        <div className="mt-8 pb-4 text-center">
          <p className="text-xs !text-[#9298A3]">
            FlashFinance Identity Verification
          </p>
        </div>
      </div>
    </main>
  );
}

type StatusScreenProps = {
  router: ReturnType<typeof useRouter>;
  title: string;
  badge: string;
  badgeClass: string;
  iconType: "clock" | "check" | "x";
  description: string;
  secondaryText: string;
  steps: {
    number: string;
    title: string;
    description: string;
    active: boolean;
  }[];
};

function StatusScreen({
  router,
  title,
  badge,
  badgeClass,
  iconType,
  description,
  secondaryText,
  steps,
}: StatusScreenProps) {
  return (
    <main className="flex min-h-screen items-center justify-center !bg-[#F1F3F6] px-5 py-10 !text-[#111318]">
      <div className="w-full max-w-xl">
        <div className="mb-8 flex items-center justify-between">
          <button
            type="button"
            onClick={() => router.push("/dashboard")}
            className="text-sm font-medium !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            ← Back to Dashboard
          </button>

          <a
            href="/"
            className="text-xl font-bold tracking-wide sm:text-2xl"
          >
            <span className="!text-[#111318]">FLASH</span>
            <span className="!text-[#B51F35]">FINANCE</span>
          </a>
        </div>

        <div className="rounded-[30px] !border !border-[#E2E5E9] !bg-white p-8 text-center shadow-[0_12px_35px_rgba(0,0,0,0.07)] sm:p-12">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-[#B51F35]/10">
            {iconType === "clock" && (
              <svg
                width="38"
                height="38"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="!text-[#B51F35]"
              >
                <path
                  d="M12 7V12L15 14"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                <circle
                  cx="12"
                  cy="12"
                  r="9"
                  stroke="currentColor"
                  strokeWidth="2"
                />
              </svg>
            )}

            {iconType === "check" && (
              <svg
                width="38"
                height="38"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="text-green-600"
              >
                <path
                  d="M5 12.5L9.5 17L19 7.5"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            )}

            {iconType === "x" && (
              <svg
                width="38"
                height="38"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="text-red-600"
              >
                <path
                  d="M7 7L17 17"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />

                <path
                  d="M17 7L7 17"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />
              </svg>
            )}
          </div>

          <div
            className={`mb-4 inline-flex items-center rounded-full border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-2 text-xs font-semibold uppercase tracking-wider ${badgeClass}`}
          >
            {badge}
          </div>

          <h1 className="text-3xl font-bold !text-[#111318] sm:text-4xl">
            {title}
          </h1>

          <p className="mx-auto mt-5 max-w-lg text-base leading-7 !text-[#69707D]">
            {description}
          </p>

          <p className="mx-auto mt-4 max-w-lg text-sm leading-6 !text-[#9298A3]">
            {secondaryText}
          </p>

          <div className="mt-8 rounded-2xl !border !border-[#E2E5E9] !bg-[#F8F9FB] p-5 text-left">
            {steps.map((step, index) => (
              <div key={step.number}>
                <div className="flex items-start gap-4">
                  <div
                    className={`mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold ${
                      step.active
                        ? "border border-[#B51F35]/20 bg-[#B51F35]/10 !text-[#B51F35]"
                        : "border border-[#E2E5E9] bg-white !text-[#9298A3]"
                    }`}
                  >
                    {step.number}
                  </div>

                  <div>
                    <p
                      className={`font-semibold ${
                        step.active
                          ? "!text-[#111318]"
                          : "!text-[#69707D]"
                      }`}
                    >
                      {step.title}
                    </p>

                    <p
                      className={`mt-1 text-sm leading-6 ${
                        step.active
                          ? "!text-[#69707D]"
                          : "!text-[#9298A3]"
                      }`}
                    >
                      {step.description}
                    </p>
                  </div>
                </div>

                {index < steps.length - 1 && (
                  <div className="my-5 ml-4 h-8 border-l border-dashed border-[#D9DDE2]" />
                )}
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => router.push("/dashboard")}
            className="mt-8 w-full rounded-2xl bg-[#B51F35] py-4 font-bold text-white shadow-sm transition hover:bg-[#C9213A]"
          >
            Return to Dashboard
          </button>
        </div>

        <div className="mt-8 text-center">
          <p className="text-xs !text-[#9298A3]">
            FlashFinance Identity Verification
          </p>
        </div>
      </div>
    </main>
  );
}