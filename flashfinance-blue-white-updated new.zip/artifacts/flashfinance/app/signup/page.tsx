"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase";

export default function SignupPage() {
  const supabase = createClient();

  const [showPassword, setShowPassword] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [terms, setTerms] = useState(false);
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState(false);
  const [message, setMessage] = useState("");

  function normalizeEmail(value: string) {
    return value.trim().toLowerCase();
  }

  function getPhoneDigits(value: string) {
    return value.replace(/\D/g, "").slice(0, 10);
  }

  function formatUSPhone(value: string) {
    const digits = getPhoneDigits(value);

    if (digits.length === 0) {
      return "";
    }

    if (digits.length <= 3) {
      return `(${digits}`;
    }

    if (digits.length <= 6) {
      return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
    }

    return `(${digits.slice(0, 3)}) ${digits.slice(
      3,
      6,
    )}-${digits.slice(6, 10)}`;
  }

  function normalizePhone(value: string) {
    return getPhoneDigits(value);
  }

  function isValidPhone(value: string) {
    return normalizePhone(value).length === 10;
  }

  function isStrongPassword(value: string) {
    return (
      value.length >= 8 &&
      /[A-Z]/.test(value) &&
      /[a-z]/.test(value) &&
      /[0-9]/.test(value)
    );
  }

  async function handleSignup(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setMessage("");

    const cleanFirstName = firstName.trim();
    const cleanLastName = lastName.trim();
    const cleanEmail = normalizeEmail(email);
    const cleanPhone = normalizePhone(phone);
    const cleanFullName = `${cleanFirstName} ${cleanLastName}`.trim();

    if (!terms) {
      setMessage(
        "Please agree to the Terms of Service and Privacy Policy.",
      );
      return;
    }

    if (
      !cleanFirstName ||
      !cleanLastName ||
      !cleanEmail ||
      !cleanPhone ||
      !password
    ) {
      setMessage("Please complete all required fields.");
      return;
    }

    if (cleanFirstName.length < 2) {
      setMessage("Please enter your first name.");
      return;
    }

    if (cleanLastName.length < 2) {
      setMessage("Please enter your last name.");
      return;
    }

    if (!cleanEmail.includes("@") || !cleanEmail.includes(".")) {
      setMessage("Please enter a valid email address.");
      return;
    }

    if (!isValidPhone(cleanPhone)) {
      setMessage(
        "Please enter a valid 10-digit US phone number.",
      );
      return;
    }

    if (!isStrongPassword(password)) {
      setMessage(
        "Password must be at least 8 characters and include an uppercase letter, lowercase letter, and number.",
      );
      return;
    }

    setLoading(true);

    const { data, error } = await supabase.auth.signUp({
      email: cleanEmail,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/confirmed`,
        data: {
          first_name: cleanFirstName,
          last_name: cleanLastName,
          full_name: cleanFullName,
          phone: cleanPhone,
          phone_country_code: "+1",
          phone_formatted: formatUSPhone(cleanPhone),
        },
      },
    });

    setLoading(false);

    if (error) {
      const errorMessage = error.message.toLowerCase();

      if (
        errorMessage.includes("already registered") ||
        errorMessage.includes("already exists") ||
        errorMessage.includes("user already")
      ) {
        setMessage(
          "An account with this email address already exists. Please log in instead.",
        );
      } else {
        setMessage(error.message);
      }

      return;
    }

    if (data.user) {
      setEmail(cleanEmail);
      setCreated(true);
    }
  }

  if (created) {
    return (
      <main className="ff-auth-page flex min-h-screen items-center justify-center !bg-[#F8F9FB] px-6 py-12 !text-[#111318]">
        <div className="w-full max-w-md">
          <div className="mb-10 text-center">
            <a
              href="/"
              className="text-3xl font-black tracking-wide text-[#111318]"
            >
              FLASH<span className="text-[#B51F35]">FINANCE</span>
            </a>

            <p className="mt-3 text-sm text-[#69707D]">
              Financial Assistance
            </p>
          </div>

          <div className="rounded-3xl border border-[#E2E5E9] bg-white p-8 text-center shadow-sm">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#B51F35]/10">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                className="h-8 w-8 text-[#B51F35]"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M21.75 7.5v9a2.25 2.25 0 01-2.25 2.25H4.5A2.25 2.25 0 012.25 16.5v-9A2.25 2.25 0 014.5 5.25h15A2.25 2.25 0 0121.75 7.5z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M3 6.75l8.05 6.037a1.5 1.5 0 001.8 0L21 6.75"
                />
              </svg>
            </div>

            <h1 className="mt-6 text-3xl font-black text-[#111318]">
              Account created
            </h1>

            <p className="mt-4 text-base leading-7 text-[#69707D]">
              Your FlashFinance account has been created successfully.
            </p>

            <div className="mt-6 rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-5 text-left">
              <p className="font-bold text-[#111318]">
                Confirm your email
              </p>

              <p className="mt-2 text-sm leading-6 text-[#69707D]">
                We've sent a confirmation link to:
              </p>

              <p className="mt-2 break-all font-semibold text-[#B51F35]">
                {email}
              </p>

              <p className="mt-3 text-sm leading-6 text-[#69707D]">
                Open the email and click the confirmation button to verify
                your account. After your email is confirmed, you'll be able
                to log in.
              </p>

              <p className="mt-3 text-xs leading-5 text-[#9298A3]">
                If you don't see the email in your inbox, please check your
                spam or junk folder.
              </p>
            </div>

            <a
              href="/login"
              className="mt-7 block w-full rounded-2xl bg-[#B51F35] py-3.5 font-bold text-white transition hover:bg-[#C9213A]"
            >
              Continue to Login
            </a>

            <a
              href="/"
              className="mt-5 block text-sm text-[#69707D] transition hover:text-[#B51F35]"
            >
              ← Back to FlashFinance
            </a>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="ff-auth-page flex min-h-screen items-center justify-center !bg-[#F8F9FB] px-6 py-12 !text-[#111318]">
      <div className="w-full max-w-md">
        <div className="mb-10 text-center">
          <a
            href="/"
            className="text-3xl font-black tracking-wide text-[#111318]"
          >
            FLASH<span className="text-[#B51F35]">FINANCE</span>
          </a>

          <h1 className="mt-8 text-3xl font-black text-[#111318]">
            Create your account
          </h1>

          <p className="mt-3 text-[#69707D]">
            Secure access to your FlashFinance account
          </p>
        </div>

        <div className="rounded-3xl border border-[#E2E5E9] bg-white p-7 shadow-sm">
          <form onSubmit={handleSignup} className="space-y-5">
            {/* FIRST NAME AND LAST NAME */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="firstName"
                  className="mb-2 block text-sm font-semibold text-[#252932]"
                >
                  First Name
                </label>

                <input
                  id="firstName"
                  name="firstName"
                  type="text"
                  autoComplete="given-name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="First name"
                  className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3 text-[#111318] outline-none transition placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
                />
              </div>

              <div>
                <label
                  htmlFor="lastName"
                  className="mb-2 block text-sm font-semibold text-[#252932]"
                >
                  Last Name
                </label>

                <input
                  id="lastName"
                  name="lastName"
                  type="text"
                  autoComplete="family-name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Last name"
                  className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3 text-[#111318] outline-none transition placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
                />
              </div>
            </div>

            {/* EMAIL */}
            <div>
              <label
                htmlFor="email"
                className="mb-2 block text-sm font-semibold text-[#252932]"
              >
                Email Address
              </label>

              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3 text-[#111318] outline-none transition placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
              />

              <p className="mt-2 text-xs text-[#9298A3]">
                You'll use this email to access your account.
              </p>
            </div>

            {/* USA PHONE NUMBER */}
            <div>
              <label
                htmlFor="phone"
                className="mb-2 block text-sm font-semibold text-[#252932]"
              >
                Phone Number
              </label>

              <div className="flex h-[50px] w-full overflow-hidden rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] transition focus-within:border-[#B51F35] focus-within:bg-white">
                <div className="flex shrink-0 items-center gap-2 border-r border-[#E2E5E9] bg-[#E8EBEF] px-4 text-[#252932]">
                  <span className="text-xl leading-none">🇺🇸</span>

                  <span className="text-sm font-bold">
                    +1
                  </span>
                </div>

                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  inputMode="numeric"
                  autoComplete="tel-national"
                  value={phone}
                  onChange={(e) =>
                    setPhone(formatUSPhone(e.target.value))
                  }
                  placeholder="(555) 123-4567"
                  maxLength={14}
                  className="min-w-0 flex-1 bg-transparent px-4 text-[15px] text-[#111318] outline-none placeholder:text-[#9298A3]"
                />
              </div>

              <p className="mt-2 text-xs text-[#9298A3]">
                US phone number only. Example: (555) 123-4567
              </p>
            </div>

            {/* PASSWORD */}
            <div>
              <label
                htmlFor="password"
                className="mb-2 block text-sm font-semibold text-[#252932]"
              >
                Password
              </label>

              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create a strong password"
                  className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3 pr-20 text-[#111318] outline-none transition placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
                />

                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-[#B51F35]"
                >
                  {showPassword ? "HIDE" : "SHOW"}
                </button>
              </div>

              <p className="mt-2 text-xs leading-5 text-[#9298A3]">
                At least 8 characters with uppercase, lowercase, and a number.
              </p>
            </div>

            {/* TERMS */}
            <div className="flex items-start gap-3">
              <input
                id="terms"
                name="terms"
                type="checkbox"
                checked={terms}
                onChange={(e) => setTerms(e.target.checked)}
                className="mt-1 h-4 w-4 accent-[#B51F35]"
              />

              <label
                htmlFor="terms"
                className="text-sm leading-6 text-[#69707D]"
              >
                I agree to the FlashFinance Terms of Service and Privacy
                Policy.
              </label>
            </div>

            {/* ERROR MESSAGE */}
            {message && (
              <div className="rounded-2xl border border-red-200 bg-red-50 p-3 text-sm leading-6 text-red-700">
                {message}
              </div>
            )}

            {/* CREATE ACCOUNT */}
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-[#B51F35] py-3.5 font-bold text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Creating Account..." : "Create Account"}
            </button>
          </form>

          <p className="mt-7 text-center text-sm text-[#69707D]">
            Already have an account?{" "}
            <a
              href="/login"
              className="font-bold text-[#B51F35] hover:text-[#C9213A]"
            >
              Login
            </a>
          </p>
        </div>

        <div className="mt-6 text-center">
          <a
            href="/"
            className="text-sm text-[#69707D] transition hover:text-[#B51F35]"
          >
            ← Back to FlashFinance
          </a>
        </div>
      </div>
    </main>
  );
}