"use client";

import {
  ChangeEvent,
  FormEvent,
  Suspense,
  useEffect,
  useState,
} from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  FiArrowLeft,
  FiCamera,
  FiCheckCircle,
  FiClock,
  FiFileText,
  FiHome,
  FiLoader,
  FiShield,
  FiUser,
  FiXCircle,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type Verification = {
  id: string;
  full_name: string | null;
  date_of_birth: string | null;
  phone: string | null;
  email: string | null;
  address_line: string | null;
  city: string | null;
  state: string | null;
  postal_code: string | null;
  id_type: string | null;
  id_number: string | null;
  ssn: string | null;
  id_document_path: string | null;
  selfie_path: string | null;
  status: string;
  rejection_note: string | null;
};

const US_STATES = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming",
];

export default function VerificationPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center !bg-[#F8F9FB] !text-[#111318]">
          <FiLoader
            size={24}
            className="animate-spin !text-[#B51F35]"
          />
        </main>
      }
    >
      <VerificationPageContent />
    </Suspense>
  );
}

function VerificationPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();

  const fromLoan = searchParams.get("from") === "loan";

  const [verification, setVerification] =
    useState<Verification | null>(null);

  const [fullName, setFullName] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");

  const [addressLine, setAddressLine] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [zipCode, setZipCode] = useState("");

  const [idType, setIdType] = useState("");
  const [ssn, setSsn] = useState("");

  const [idDocument, setIdDocument] =
    useState<File | null>(null);

  const [selfie, setSelfie] =
    useState<File | null>(null);

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    if (!fromLoan) {
      router.replace("/loans");
      return;
    }

    loadVerification();
  }, [fromLoan]);

  async function loadVerification() {
    setLoading(true);
    setError("");

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.push("/login");
      return;
    }

    const { data, error: verificationError } =
      await supabase
        .from("user_verifications")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

    if (verificationError) {
      setError(verificationError.message);
      setLoading(false);
      return;
    }

    if (data) {
      setVerification(data);

      setFullName(data.full_name || "");
      setDateOfBirth(data.date_of_birth || "");
      setPhone(data.phone || "");
      setEmail(data.email || "");

      setAddressLine(data.address_line || "");
      setCity(data.city || "");
      setState(data.state || "");
      setZipCode(data.postal_code || "");

      setIdType(data.id_type || "");
      setSsn(data.ssn || "");
    }

    setLoading(false);
  }

  function handleFileChange(
    event: ChangeEvent<HTMLInputElement>,
    setter: (file: File | null) => void,
  ) {
    const file = event.target.files?.[0] || null;

    if (!file) {
      setter(null);
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError("Each file must be 10MB or smaller.");
      setter(null);
      return;
    }

    setter(file);
    setError("");
  }

  async function uploadFile(
    userId: string,
    file: File,
    folder: string,
  ) {
    const extension =
      file.name.split(".").pop() || "file";

    const filePath =
      userId +
      "/" +
      folder +
      "/" +
      crypto.randomUUID() +
      "." +
      extension;

    const { error: uploadError } =
      await supabase.storage
        .from("verification-documents")
        .upload(filePath, file, {
          upsert: false,
        });

    if (uploadError) {
      throw new Error(uploadError.message);
    }

    return filePath;
  }

  async function handleSubmit(
    event: FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    setError("");
    setSuccess("");

    if (!fullName.trim()) {
      setError("Please enter your full name.");
      return;
    }

    if (!dateOfBirth) {
      setError("Please enter your date of birth.");
      return;
    }

    if (!phone.trim()) {
      setError("Please enter your phone number.");
      return;
    }

    if (!email.trim()) {
      setError("Please enter your email address.");
      return;
    }

    if (!addressLine.trim()) {
      setError("Please enter your street address.");
      return;
    }

    if (!city.trim()) {
      setError("Please enter your city.");
      return;
    }

    if (!state) {
      setError("Please select your state.");
      return;
    }

    if (!zipCode.trim()) {
      setError("Please enter your ZIP code.");
      return;
    }

    if (!idType) {
      setError("Please select your ID type.");
      return;
    }

    if (!ssn.trim()) {
      setError("Please enter your SSN.");
      return;
    }

    if (
      !idDocument &&
      !verification?.id_document_path
    ) {
      setError("Please upload your government ID.");
      return;
    }

    if (
      !selfie &&
      !verification?.selfie_path
    ) {
      setError("Please upload a selfie.");
      return;
    }

    setSubmitting(true);

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const savedLoan =
        sessionStorage.getItem(
          "flashfinance_pending_loan",
        );

      if (!savedLoan) {
        throw new Error(
          "Your loan application information could not be found. Please start the loan application again.",
        );
      }

      let loanData;

      try {
        loanData = JSON.parse(savedLoan);
      } catch {
        throw new Error(
          "Your loan application information could not be read. Please start the loan application again.",
        );
      }

      if (
        !loanData.amount ||
        !loanData.purpose ||
        !loanData.term
      ) {
        throw new Error(
          "Your loan application is incomplete. Please start the loan application again.",
        );
      }

      let idDocumentPath =
        verification?.id_document_path || null;

      let selfiePath =
        verification?.selfie_path || null;

      if (idDocument) {
        idDocumentPath = await uploadFile(
          user.id,
          idDocument,
          "id",
        );
      }

      if (selfie) {
        selfiePath = await uploadFile(
          user.id,
          selfie,
          "selfie",
        );
      }

      const verificationData = {
        user_id: user.id,
        full_name: fullName.trim(),
        date_of_birth: dateOfBirth,
        phone: phone.trim(),
        email: email.trim(),
        address_line: addressLine.trim(),
        city: city.trim(),
        state: state,
        postal_code: zipCode.trim(),
        id_type: idType,
        ssn: ssn.trim(),
        id_document_path: idDocumentPath,
        selfie_path: selfiePath,
        status: "pending",
        rejection_note: null,
        reviewed_by: null,
        reviewed_at: null,
      };

      let savedVerification: Verification;

      if (verification) {
        const {
          data,
          error: updateError,
        } = await supabase
          .from("user_verifications")
          .update(verificationData)
          .eq("id", verification.id)
          .select("*")
          .single();

        if (updateError) {
          throw new Error(updateError.message);
        }

        savedVerification = data;
      } else {
        const {
          data,
          error: insertError,
        } = await supabase
          .from("user_verifications")
          .insert(verificationData)
          .select("*")
          .single();

        if (insertError) {
          throw new Error(insertError.message);
        }

        savedVerification = data;
      }

      setVerification(savedVerification);

      const { error: loanError } =
        await supabase.rpc("request_loan", {
          p_amount: Number(loanData.amount),
          p_purpose: loanData.purpose,
          p_term_months: Number(loanData.term),
          p_note: loanData.note || null,
        });

      if (loanError) {
        throw new Error(loanError.message);
      }

      sessionStorage.removeItem(
        "flashfinance_pending_loan",
      );

      setIdDocument(null);
      setSelfie(null);

      setSuccess(
        "Your verification and loan application have been submitted and are waiting for review.",
      );
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Unable to submit your application.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center !bg-[#F8F9FB] !text-[#111318]">
        <FiLoader
          size={24}
          className="animate-spin !text-[#B51F35]"
        />
      </main>
    );
  }

  const status =
    verification?.status?.toLowerCase();

  return (
    <main className="min-h-screen !bg-[#F8F9FB] !text-[#111318]">
      <div className="border-b !border-[#E2E5E9] !bg-white">
        <div className="mx-auto max-w-4xl px-4 py-4 sm:px-6 lg:px-8">
          <button
            type="button"
            onClick={() => router.push("/loans")}
            className="flex items-center gap-2 text-sm font-medium !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            <FiArrowLeft size={17} />
            Back to loan application
          </button>
        </div>
      </div>

      <section className="!bg-[#0B0E17] px-4 py-10 text-white sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-white/70">
            <FiShield className="!text-[#E04A5D]" />
            Secure identity verification
          </div>

          <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">
            Verify your identity
          </h1>

          <p className="mt-3 max-w-2xl text-sm leading-6 text-white/60 sm:text-base">
            Complete your information so your identity
            and loan application can be reviewed securely.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        {status === "verified" && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-emerald-200 !bg-emerald-50 p-4">
            <FiCheckCircle
              className="mt-0.5 shrink-0 !text-emerald-600"
              size={20}
            />

            <div>
              <p className="text-sm font-semibold !text-emerald-700">
                Verification completed
              </p>

              <p className="mt-1 text-xs leading-5 !text-emerald-600">
                Your identity information has been reviewed.
              </p>
            </div>
          </div>
        )}

        {status === "pending" && !success && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-[#B51F35]/20 !bg-[#B51F35]/5 p-4">
            <FiClock
              className="mt-0.5 shrink-0 !text-[#B51F35]"
              size={20}
            />

            <div>
              <p className="text-sm font-semibold !text-[#B51F35]">
                Verification pending
              </p>

              <p className="mt-1 text-xs leading-5 !text-[#69707D]">
                Your information is currently waiting
                for review.
              </p>
            </div>
          </div>
        )}

        {status === "rejected" && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-red-200 !bg-red-50 p-4">
            <FiXCircle
              className="mt-0.5 shrink-0 !text-red-600"
              size={20}
            />

            <div>
              <p className="text-sm font-semibold !text-red-700">
                Verification needs attention
              </p>

              {verification?.rejection_note && (
                <p className="mt-1 text-xs leading-5 !text-red-600">
                  {verification.rejection_note}
                </p>
              )}
            </div>
          </div>
        )}

        {success ? (
          <div className="overflow-hidden rounded-2xl border !border-[#E2E5E9] !bg-white shadow-sm">
            <div className="!bg-[#0B0E17] px-6 py-7 text-white">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#B51F35]/15">
                <FiCheckCircle
                  className="!text-[#E04A5D]"
                  size={25}
                />
              </div>

              <h2 className="mt-5 text-xl font-semibold">
                Application submitted
              </h2>

              <p className="mt-2 max-w-xl text-sm leading-6 text-white/60">
                Your verification and loan application
                have been submitted and are waiting for
                review.
              </p>
            </div>

            <div className="p-6">
              <p className="text-sm leading-6 !text-[#69707D]">
                Your application will be reviewed along
                with the information and documents you
                provided. You will be notified when there
                is an update.
              </p>

              <button
                type="button"
                onClick={() => router.push("/dashboard")}
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl !bg-[#B51F35] px-4 py-3.5 text-sm font-semibold !text-white transition hover:!bg-[#991B30]"
              >
                <FiArrowLeft size={17} />
                Back to dashboard
              </button>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="space-y-6"
          >
            <section className="rounded-2xl border !border-[#E2E5E9] !bg-white p-5 shadow-sm sm:p-6">
              <SectionHeader
                icon={<FiUser size={19} />}
                title="Personal information"
                description="Enter your information exactly as it appears on your ID."
              />

              <div className="grid gap-4 sm:grid-cols-2">
                <Input
                  label="Full name"
                  value={fullName}
                  onChange={setFullName}
                  placeholder="Full legal name"
                />

                <Input
                  label="Date of birth"
                  type="date"
                  value={dateOfBirth}
                  onChange={setDateOfBirth}
                />

                <Input
                  label="Phone number"
                  value={phone}
                  onChange={setPhone}
                  placeholder="Phone number"
                />

                <Input
                  label="Email address"
                  type="email"
                  value={email}
                  onChange={setEmail}
                  placeholder="Email address"
                />

                <div className="sm:col-span-2">
                  <Input
                    label="Social Security number"
                    value={ssn}
                    onChange={setSsn}
                    placeholder="XXX-XX-XXXX"
                    type="password"
                  />
                </div>
              </div>
            </section>

            <section className="rounded-2xl border !border-[#E2E5E9] !bg-white p-5 shadow-sm sm:p-6">
              <SectionHeader
                icon={<FiHome size={19} />}
                title="Address"
                description="Provide your current residential address."
              />

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Input
                    label="Street address"
                    value={addressLine}
                    onChange={setAddressLine}
                    placeholder="Street address"
                  />
                </div>

                <Input
                  label="City"
                  value={city}
                  onChange={setCity}
                  placeholder="City"
                />

                <div>
                  <label className="mb-2 block text-sm font-medium !text-[#252932]">
                    State
                  </label>

                  <select
                    value={state}
                    onChange={(event) =>
                      setState(event.target.value)
                    }
                    className="w-full rounded-xl border !border-[#E2E5E9] !bg-[#F8F9FB] px-4 py-3 text-sm !text-[#111318] outline-none transition focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                  >
                    <option
                      value=""
                      className="bg-white !text-[#111318]"
                    >
                      Select state
                    </option>

                    {US_STATES.map((stateName) => (
                      <option
                        key={stateName}
                        value={stateName}
                        className="bg-white !text-[#111318]"
                      >
                        {stateName}
                      </option>
                    ))}
                  </select>
                </div>

                <Input
                  label="ZIP code"
                  value={zipCode}
                  onChange={setZipCode}
                  placeholder="ZIP code"
                />
              </div>
            </section>

            <section className="rounded-2xl border !border-[#E2E5E9] !bg-white p-5 shadow-sm sm:p-6">
              <SectionHeader
                icon={<FiFileText size={19} />}
                title="Identity document"
                description="Upload a clear photo or scan of your government ID."
              />

              <div className="grid gap-4">
                <div>
                  <label className="mb-2 block text-sm font-medium !text-[#252932]">
                    ID type
                  </label>

                  <select
                    value={idType}
                    onChange={(event) =>
                      setIdType(event.target.value)
                    }
                    className="w-full rounded-xl border !border-[#E2E5E9] !bg-[#F8F9FB] px-4 py-3 text-sm !text-[#111318] outline-none transition focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                  >
                    <option
                      value=""
                      className="bg-white !text-[#111318]"
                    >
                      Select ID type
                    </option>

                    <option
                      value="Passport"
                      className="bg-white !text-[#111318]"
                    >
                      Passport
                    </option>

                    <option
                      value="Driver's License"
                      className="bg-white !text-[#111318]"
                    >
                      Driver&apos;s License
                    </option>

                    <option
                      value="National ID"
                      className="bg-white !text-[#111318]"
                    >
                      National ID
                    </option>

                    <option
                      value="Other"
                      className="bg-white !text-[#111318]"
                    >
                      Other government ID
                    </option>
                  </select>
                </div>

                <FileUpload
                  label="Government ID"
                  icon={<FiFileText size={18} />}
                  file={idDocument}
                  existing={Boolean(
                    verification?.id_document_path,
                  )}
                  onChange={(event) =>
                    handleFileChange(
                      event,
                      setIdDocument,
                    )
                  }
                  accept="image/*,.pdf"
                />
              </div>
            </section>

            <section className="rounded-2xl border !border-[#E2E5E9] !bg-white p-5 shadow-sm sm:p-6">
              <SectionHeader
                icon={<FiCamera size={19} />}
                title="Selfie verification"
                description="Upload a clear selfie showing your face."
              />

              <FileUpload
                label="Selfie"
                icon={<FiCamera size={18} />}
                file={selfie}
                existing={Boolean(
                  verification?.selfie_path,
                )}
                onChange={(event) =>
                  handleFileChange(
                    event,
                    setSelfie,
                  )
                }
                accept="image/*"
                capture
              />
            </section>

            {error && (
              <div className="flex items-start gap-3 rounded-xl border border-red-200 !bg-red-50 p-4 text-sm !text-red-700">
                <FiXCircle className="mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-xl !bg-[#B51F35] px-4 py-3.5 text-sm font-semibold !text-white shadow-sm transition hover:!bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <FiLoader className="animate-spin" />
                  Submitting application...
                </>
              ) : (
                <>
                  <FiCheckCircle />
                  Submit application
                </>
              )}
            </button>

            <div className="flex items-start gap-3 rounded-2xl border !border-[#E2E5E9] !bg-white p-4">
              <FiShield className="mt-0.5 shrink-0 !text-[#B51F35]" />

              <p className="text-xs leading-5 !text-[#69707D]">
                Your verification information and
                documents are stored in private storage
                for review.
              </p>
            </div>
          </form>
        )}
      </div>
    </main>
  );
}

function SectionHeader({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="mb-6 flex items-center gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
        {icon}
      </div>

      <div>
        <h2 className="text-base font-semibold !text-[#111318]">
          {title}
        </h2>

        <p className="mt-1 text-xs leading-5 !text-[#69707D]">
          {description}
        </p>
      </div>
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium !text-[#252932]">
        {label}
      </label>

      <input
        type={type}
        value={value}
        onChange={(event) =>
          onChange(event.target.value)
        }
        placeholder={placeholder}
        className="w-full rounded-xl border !border-[#E2E5E9] !bg-[#F8F9FB] px-4 py-3 text-sm !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
      />
    </div>
  );
}

function FileUpload({
  label,
  icon,
  file,
  existing,
  onChange,
  accept,
  capture = false,
}: {
  label: string;
  icon: React.ReactElement;
  file: File | null;
  existing: boolean;
  onChange: (
    event: ChangeEvent<HTMLInputElement>,
  ) => void;
  accept: string;
  capture?: boolean;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium !text-[#252932]">
        {label}
      </label>

      <label className="flex cursor-pointer items-center gap-4 rounded-xl border border-dashed !border-[#D6D9DE] !bg-[#F8F9FB] p-4 transition hover:!border-[#B51F35]/50 hover:!bg-[#B51F35]/[0.02]">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
          {icon}
        </div>

        <div className="min-w-0 flex-1">
          {file ? (
            <>
              <p className="truncate text-sm font-medium !text-[#252932]">
                {file.name}
              </p>

              <p className="mt-1 text-xs !text-emerald-600">
                New file selected
              </p>
            </>
          ) : existing ? (
            <>
              <p className="text-sm font-medium !text-[#252932]">
                Document already uploaded
              </p>

              <p className="mt-1 text-xs !text-[#9298A3]">
                Choose a new file if you want to replace it.
              </p>
            </>
          ) : (
            <>
              <p className="text-sm font-medium !text-[#252932]">
                Choose a file
              </p>

              <p className="mt-1 text-xs !text-[#9298A3]">
                Maximum file size: 10MB
              </p>
            </>
          )}
        </div>

        <span className="shrink-0 rounded-lg border !border-[#E2E5E9] !bg-white px-3 py-2 text-xs font-medium !text-[#69707D]">
          Browse
        </span>

        <input
          type="file"
          className="hidden"
          accept={accept}
          capture={capture ? "user" : undefined}
          onChange={onChange}
        />
      </label>
    </div>
  );
}