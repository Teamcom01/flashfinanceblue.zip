"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FiActivity,
  FiAlertCircle,
  FiArrowLeft,
  FiBarChart2,
  FiCheck,
  FiCheckCircle,
  FiChevronRight,
  FiClock,
  FiDollarSign,
  FiInfo,
  FiLoader,
  FiShield,
  FiTrendingUp,
  FiUser,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type InvestmentPlan = {
  id: string;
  name: string;
  description: string | null;
  roi: number;
  duration: string;
  durationValue: number;
  durationUnit: string;
  min: number;
  max: number;
  featured: boolean;
  displayOrder: number;
};

type InvestmentPlanRow = {
  id: string;
  name: string | null;
  description: string | null;
  roi_percent: number | string | null;
  duration_value: number | string | null;
  duration_unit: string | null;
  min_amount: number | string | null;
  max_amount: number | string | null;
  active: boolean | null;
  featured: boolean | null;
  display_order: number | string | null;
};

type Account = {
  balance: number | null;
  currency: string | null;
};

type Investment = {
  id: string;
  plan_name: string;
  roi: number;
  duration_hours: number;
  principal: number;
  profit: number;
  total_return: number;
  status: string;
  started_at: string;
  maturity_at: string;
  created_at: string;
};

type GrowthPoint = {
  label: string;
  value: number;
  profit: number;
};

function formatMoney(amount: number, currency = "USD") {
  const safeCurrency =
    typeof currency === "string" && /^[A-Z]{3}$/.test(currency)
      ? currency
      : "USD";

  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: safeCurrency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(amount) ? amount : 0);
}

function formatDateTime(dateString: string) {
  const date = new Date(dateString);

  if (Number.isNaN(date.getTime())) {
    return "Unavailable";
  }

  return date.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatStatus(status: string) {
  return status
    .replace(/_/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function formatDuration(value: number, unit: string) {
  const safeValue =
    Number.isFinite(value) && value > 0 ? value : 0;

  const normalizedUnit =
    String(unit || "days").trim().toLowerCase();

  const singularUnit = normalizedUnit.endsWith("s")
    ? normalizedUnit.slice(0, -1)
    : normalizedUnit;

  const finalUnit =
    safeValue === 1 ? singularUnit : normalizedUnit;

  return `${safeValue} ${finalUnit}`;
}

function getProgress(investment: Investment, now: number) {
  const start = new Date(investment.started_at).getTime();
  const maturity = new Date(investment.maturity_at).getTime();

  const totalDuration = maturity - start;

  if (
    !Number.isFinite(start) ||
    !Number.isFinite(maturity) ||
    totalDuration <= 0
  ) {
    return 1;
  }

  return Math.min(
    1,
    Math.max(0, (now - start) / totalDuration),
  );
}

function getCurrentInvestmentValue(
  investment: Investment,
  now: number,
) {
  const progress = getProgress(investment, now);

  const principal = Number(investment.principal || 0);
  const profit = Number(investment.profit || 0);

  return {
    progress,
    profitEarned: profit * progress,
    currentValue: principal + profit * progress,
    remainingProfit: profit * (1 - progress),
  };
}

function formatRemaining(milliseconds: number) {
  if (
    !Number.isFinite(milliseconds) ||
    milliseconds <= 0
  ) {
    return "Matured";
  }

  const totalSeconds = Math.floor(milliseconds / 1000);

  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor(
    (totalSeconds % 86400) / 3600,
  );
  const minutes = Math.floor(
    (totalSeconds % 3600) / 60,
  );
  const seconds = totalSeconds % 60;

  if (days > 0) {
    return `${days}d ${hours}h ${minutes}m`;
  }

  if (hours > 0) {
    return `${hours}h ${minutes}m ${seconds}s`;
  }

  if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  }

  return `${seconds}s`;
}

function buildGrowthPoints(
  investment: Investment,
  now: number,
): GrowthPoint[] {
  const startedAt = new Date(
    investment.started_at,
  ).getTime();

  const maturityAt = new Date(
    investment.maturity_at,
  ).getTime();

  const duration = maturityAt - startedAt;

  const principal = Number(
    investment.principal || 0,
  );

  const totalProfit = Number(
    investment.profit || 0,
  );

  if (
    !Number.isFinite(startedAt) ||
    !Number.isFinite(maturityAt) ||
    duration <= 0
  ) {
    return [
      {
        label: "Start",
        value: principal,
        profit: 0,
      },
      {
        label: "End",
        value: principal + totalProfit,
        profit: totalProfit,
      },
    ];
  }

  const elapsed = Math.min(
    duration,
    Math.max(0, now - startedAt),
  );

  const pointCount =
    duration <= 60 * 60 * 1000
      ? 6
      : duration <= 7 * 24 * 60 * 60 * 1000
        ? 7
        : duration <= 30 * 24 * 60 * 60 * 1000
          ? 8
          : 10;

  const points: GrowthPoint[] = [];

  for (
    let index = 0;
    index < pointCount;
    index++
  ) {
    const fraction =
      index / (pointCount - 1);

    const pointTime =
      startedAt + duration * fraction;

    const actualFraction =
      Math.min(
        1,
        Math.max(
          0,
          (pointTime - startedAt) / duration,
        ),
      );

    const pointProfit =
      totalProfit * actualFraction;

    const pointValue =
      principal + pointProfit;

    const passed =
      pointTime <= startedAt + elapsed;

    const valueToShow = passed
      ? pointValue
      : principal +
        totalProfit *
          Math.min(
            elapsed / duration,
            actualFraction,
          );

    const profitToShow =
      valueToShow - principal;

    let label = "";

    if (index === 0) {
      label = "Start";
    } else if (index === pointCount - 1) {
      label = "Maturity";
    } else {
      const pointDate = new Date(pointTime);

      if (
        duration <= 60 * 60 * 1000
      ) {
        label =
          pointDate.toLocaleTimeString(
            "en-US",
            {
              hour: "numeric",
              minute: "2-digit",
            },
          );
      } else {
        label =
          pointDate.toLocaleDateString(
            "en-US",
            {
              month: "short",
              day: "numeric",
            },
          );
      }
    }

    points.push({
      label,
      value: valueToShow,
      profit: Math.max(
        0,
        profitToShow,
      ),
    });
  }

  return points;
}

function GrowthChart({
  points,
  currency,
}: {
  points: GrowthPoint[];
  currency: string;
}) {
  const width = 900;
  const height = 300;

  const paddingLeft = 58;
  const paddingRight = 24;
  const paddingTop = 24;
  const paddingBottom = 48;

  const safePoints =
    points.length > 0
      ? points
      : [
          {
            label: "Start",
            value: 0,
            profit: 0,
          },
          {
            label: "Maturity",
            value: 0,
            profit: 0,
          },
        ];

  const values = safePoints.map((point) =>
    Number.isFinite(point.value)
      ? point.value
      : 0,
  );

  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  const range = maxValue - minValue;

  const chartMin =
    range === 0
      ? minValue - 1
      : minValue - range * 0.08;

  const chartMax =
    range === 0
      ? maxValue + 1
      : maxValue + range * 0.12;

  const chartWidth =
    width -
    paddingLeft -
    paddingRight;

  const chartHeight =
    height -
    paddingTop -
    paddingBottom;

  const getX = (index: number) => {
    if (safePoints.length === 1) {
      return paddingLeft;
    }

    return (
      paddingLeft +
      (index /
        (safePoints.length - 1)) *
        chartWidth
    );
  };

  const getY = (value: number) => {
    const denominator =
      chartMax - chartMin;

    const percentage =
      denominator === 0
        ? 0.5
        : (value - chartMin) /
          denominator;

    return (
      paddingTop +
      chartHeight *
        (1 - percentage)
    );
  };

  const linePoints = safePoints
    .map(
      (point, index) =>
        `${getX(index)},${getY(
          point.value,
        )}`,
    )
    .join(" ");

  const areaPoints = [
    `${getX(0)},${
      paddingTop + chartHeight
    }`,
    ...safePoints.map(
      (point, index) =>
        `${getX(index)},${getY(
          point.value,
        )}`,
    ),
    `${getX(
      safePoints.length - 1,
    )},${
      paddingTop + chartHeight
    }`,
  ].join(" ");

  const gridLines = [
    0,
    0.25,
    0.5,
    0.75,
    1,
  ].map((fraction) => {
    const y =
      paddingTop +
      chartHeight * fraction;

    const value =
      chartMax -
      (chartMax - chartMin) *
        fraction;

    return {
      y,
      value,
    };
  });

  return (
    <div className="mt-5 overflow-hidden rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-3 sm:p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold text-[#252932]">
            Investment growth
          </p>

          <p className="mt-1 text-[11px] text-[#9298A3]">
            Value increases toward the maturity amount
          </p>
        </div>

        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#B51F35]/10">
          <FiActivity
            size={18}
            className="text-[#B51F35]"
          />
        </div>
      </div>

      <div className="w-full overflow-x-auto">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="min-w-[680px] w-full"
          role="img"
          aria-label="Investment growth chart"
        >
          {gridLines.map(
            (line, index) => (
              <g key={index}>
                <line
                  x1={paddingLeft}
                  x2={
                    width -
                    paddingRight
                  }
                  y1={line.y}
                  y2={line.y}
                  stroke="#E2E5E9"
                  strokeWidth="1"
                />

                <text
                  x="8"
                  y={line.y + 4}
                  fill="#9298A3"
                  fontSize="10"
                >
                  {formatMoney(
                    line.value,
                    currency,
                  )}
                </text>
              </g>
            ),
          )}

          <polygon
            points={areaPoints}
            fill="rgba(181,31,53,0.08)"
          />

          <polyline
            points={linePoints}
            fill="none"
            stroke="#B51F35"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {safePoints.map(
            (point, index) => (
              <g
                key={`${point.label}-${index}`}
              >
                <circle
                  cx={getX(index)}
                  cy={getY(
                    point.value,
                  )}
                  r="5"
                  fill="#B51F35"
                  stroke="#FFFFFF"
                  strokeWidth="3"
                />

                <text
                  x={getX(index)}
                  y={height - 18}
                  fill="#69707D"
                  fontSize="10"
                  textAnchor="middle"
                >
                  {point.label}
                </text>
              </g>
            ),
          )}
        </svg>
      </div>
    </div>
  );
}

export default function InvestmentsPage() {
  const router = useRouter();

  const supabase = useMemo(
    () => createClient(),
    [],
  );

  const [
    investmentPlans,
    setInvestmentPlans,
  ] = useState<InvestmentPlan[]>([]);

  const [
    selectedPlan,
    setSelectedPlan,
  ] = useState<InvestmentPlan | null>(
    null,
  );

  const [
    amount,
    setAmount,
  ] = useState("");

  const [
    account,
    setAccount,
  ] = useState<Account | null>(null);

  const [
    investments,
    setInvestments,
  ] = useState<Investment[]>([]);

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    plansLoading,
    setPlansLoading,
  ] = useState(true);

  const [
    investing,
    setInvesting,
  ] = useState(false);

  const [
    maturingId,
    setMaturingId,
  ] = useState<string | null>(null);

  const [
    error,
    setError,
  ] = useState("");

  const [
    success,
    setSuccess,
  ] = useState("");

  const [
    currentTime,
    setCurrentTime,
  ] = useState(Date.now());

  const numericAmount = Number(
    amount || 0,
  );

  const currency =
    account?.currency || "USD";

  const balance = Number(
    account?.balance || 0,
  );

  const estimatedProfit =
    selectedPlan &&
    numericAmount > 0
      ? numericAmount *
        (selectedPlan.roi / 100)
      : 0;

  const estimatedTotal =
    numericAmount +
    estimatedProfit;

  const amountWithinPlan =
    selectedPlan
      ? numericAmount >=
          selectedPlan.min &&
        numericAmount <=
          selectedPlan.max
      : false;

  const enoughBalance =
    numericAmount <= balance;

  const amountValid = Boolean(
    selectedPlan &&
      numericAmount > 0 &&
      amountWithinPlan &&
      enoughBalance,
  );

  useEffect(() => {
    const timer = window.setInterval(
      () => {
        setCurrentTime(Date.now());
      },
      1000,
    );

    return () =>
      window.clearInterval(timer);
  }, []);

  const loadInvestmentPlans =
    useCallback(
      async (silent = false) => {
        if (!silent) {
          setPlansLoading(true);
        }

        const {
          data,
          error: plansError,
        } = await supabase
          .from("investment_plans")
          .select(
            "id,name,description,roi_percent,duration_value,duration_unit,min_amount,max_amount,active,featured,display_order",
          )
          .eq("active", true)
          .order("display_order", {
            ascending: true,
          })
          .order("name", {
            ascending: true,
          });

        if (plansError) {
          console.error(
            "Investment plans error:",
            plansError,
          );

          setError(
            `Investment plans could not be loaded: ${plansError.message}`,
          );

          setInvestmentPlans([]);
          setSelectedPlan(null);
          setPlansLoading(false);

          return;
        }

        const convertedPlans =
          (
            (data || []) as InvestmentPlanRow[]
          )
            .filter(
              (row) =>
                row.active !== false,
            )
            .map((row) => {
              const durationValue =
                Number(
                  row.duration_value ?? 0,
                );

              const durationUnit =
                String(
                  row.duration_unit ||
                    "days",
                ).trim();

              const minAmount =
                Number(
                  row.min_amount ?? 0,
                );

              const maxAmount =
                Number(
                  row.max_amount ?? 0,
                );

              const roi = Number(
                row.roi_percent ?? 0,
              );

              return {
                id: String(row.id),
                name: String(
                  row.name || "",
                ).trim(),
                description:
                  row.description ||
                  null,
                roi: Number.isFinite(
                  roi,
                )
                  ? roi
                  : 0,
                duration:
                  formatDuration(
                    durationValue,
                    durationUnit,
                  ),
                durationValue,
                durationUnit,
                min:
                  Number.isFinite(
                    minAmount,
                  )
                    ? minAmount
                    : 0,
                max:
                  Number.isFinite(
                    maxAmount,
                  )
                    ? maxAmount
                    : 0,
                featured: Boolean(
                  row.featured,
                ),
                displayOrder: Number(
                  row.display_order ?? 0,
                ),
              };
            })
            .filter(
              (plan) =>
                plan.name.length > 0 &&
                plan.durationValue > 0 &&
                plan.min >= 0 &&
                plan.max >= plan.min,
            );

        setInvestmentPlans(
          convertedPlans,
        );

        setSelectedPlan(
          (currentPlan) => {
            if (!currentPlan) {
              return (
                convertedPlans[0] ||
                null
              );
            }

            const updatedPlan =
              convertedPlans.find(
                (plan) =>
                  plan.id ===
                  currentPlan.id,
              );

            return (
              updatedPlan ||
              convertedPlans[0] ||
              null
            );
          },
        );

        if (
          convertedPlans.length ===
          0
        ) {
          setSelectedPlan(null);
          setAmount("");
        }

        setPlansLoading(false);
      },
      [supabase],
    );

  const loadUserData =
    useCallback(
      async (silent = false) => {
        if (!silent) {
          setLoading(true);
        }

        const {
          data: { user },
          error: authError,
        } =
          await supabase.auth.getUser();

        if (authError) {
          setError(
            authError.message,
          );
          setLoading(false);
          return false;
        }

        if (!user) {
          setLoading(false);
          router.replace("/login");
          return false;
        }

        const [
          accountResult,
          investmentResult,
        ] = await Promise.all([
          supabase
            .from("accounts")
            .select(
              "balance,currency",
            )
            .eq(
              "user_id",
              user.id,
            )
            .maybeSingle(),

          supabase
            .from("investments")
            .select(
              "id,plan_name,roi,duration_hours,principal,profit,total_return,status,started_at,maturity_at,created_at",
            )
            .eq(
              "user_id",
              user.id,
            )
            .order(
              "created_at",
              {
                ascending: false,
              },
            ),
        ]);

        if (accountResult.error) {
          setError(
            accountResult.error.message,
          );
        }

        if (investmentResult.error) {
          setError(
            investmentResult.error.message,
          );
        }

        setAccount(
          accountResult.data || null,
        );

        setInvestments(
          (investmentResult.data ||
            []) as Investment[],
        );

        setLoading(false);

        return true;
      },
      [router, supabase],
    );

  useEffect(() => {
    let mounted = true;

    async function initializePage() {
      setLoading(true);
      setPlansLoading(true);
      setError("");
      setSuccess("");

      const {
        data: { user },
        error: authError,
      } =
        await supabase.auth.getUser();

      if (!mounted) {
        return;
      }

      if (authError) {
        setError(
          authError.message,
        );
        setLoading(false);
        setPlansLoading(false);
        return;
      }

      if (!user) {
        setLoading(false);
        setPlansLoading(false);
        router.replace("/login");
        return;
      }

      await Promise.all([
        loadInvestmentPlans(),
        loadUserData(),
      ]);
    }

    void initializePage();

    return () => {
      mounted = false;
    };
  }, [
    router,
    supabase,
    loadInvestmentPlans,
    loadUserData,
  ]);

  useEffect(() => {
    let active = true;

    const channel =
      supabase
        .channel(
          `customer-investment-plans-${Date.now()}`,
        )
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "investment_plans",
          },
          () => {
            if (active) {
              void loadInvestmentPlans(
                true,
              );
            }
          },
        )
        .subscribe();

    const fallbackTimer =
      window.setInterval(() => {
        if (active) {
          void loadInvestmentPlans(
            true,
          );
        }
      }, 10000);

    return () => {
      active = false;

      window.clearInterval(
        fallbackTimer,
      );

      void supabase.removeChannel(
        channel,
      );
    };
  }, [
    supabase,
    loadInvestmentPlans,
  ]);

  async function refreshData() {
    await Promise.all([
      loadUserData(true),
      loadInvestmentPlans(true),
    ]);
  }

  async function handleInvest() {
    setError("");
    setSuccess("");

    if (!selectedPlan) {
      setError(
        "There are no active investment plans available right now.",
      );
      return;
    }

    if (!amount) {
      setError(
        "Enter an investment amount.",
      );
      return;
    }

    if (
      !Number.isFinite(
        numericAmount,
      ) ||
      numericAmount <= 0
    ) {
      setError(
        "Investment amount must be greater than zero.",
      );
      return;
    }

    if (!amountWithinPlan) {
      setError(
        `Enter an amount between ${formatMoney(
          selectedPlan.min,
          currency,
        )} and ${formatMoney(
          selectedPlan.max,
          currency,
        )}.`,
      );
      return;
    }

    if (!enoughBalance) {
      setError(
        "You do not have enough available balance for this investment.",
      );
      return;
    }

    setInvesting(true);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setInvesting(false);
      router.replace("/login");
      return;
    }

    const {
      data,
      error: rpcError,
    } = await supabase.rpc(
      "create_investment",
      {
        p_plan_name:
          selectedPlan.name,
        p_amount:
          numericAmount,
      },
    );

    if (rpcError) {
      setError(
        rpcError.message,
      );
      setInvesting(false);
      return;
    }

    if (!data?.success) {
      setError(
        data?.message ||
          "The investment could not be completed.",
      );
      setInvesting(false);
      return;
    }

    await refreshData();

    setAmount("");

    setSuccess(
      `${selectedPlan.name} investment created successfully.`,
    );

    setInvesting(false);
  }

  async function handleMature(
    investmentId: string,
  ) {
    setError("");
    setSuccess("");
    setMaturingId(investmentId);

    const {
      data,
      error: rpcError,
    } =
      await supabase.rpc(
        "mature_investment",
        {
          p_investment_id:
            investmentId,
        },
      );

    if (rpcError) {
      setError(
        rpcError.message,
      );
      setMaturingId(null);
      return;
    }

    if (!data?.success) {
      setError(
        data?.message ||
          "This investment could not be matured.",
      );
      setMaturingId(null);
      return;
    }

    await refreshData();

    setSuccess(
      `Investment matured and ${formatMoney(
        Number(
          data.total_return || 0,
        ),
        currency,
      )} was returned to your account.`,
    );

    setMaturingId(null);
  }

  if (loading) {
    return (
      <main className="ff-product-page ff-investments-page flex min-h-screen items-center justify-center bg-[#F8F9FB] font-sans text-[#111318]">
        <div className="w-full max-w-5xl px-4 py-10 sm:px-6">
          <div className="h-9 w-44 animate-pulse rounded-xl bg-white/80" />
          <div className="mt-8 h-52 animate-pulse rounded-[1.75rem] bg-[#1c3b5b]/15" />
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div className="h-40 animate-pulse rounded-2xl bg-white/80" />
            <div className="h-40 animate-pulse rounded-2xl bg-white/80" />
          </div>
        </div>
      </main>
    );
  }

  const activeInvestments =
    investments.filter(
      (investment) =>
        investment.status
          .toLowerCase() ===
        "active",
    );

  const completedInvestments =
    investments.filter(
      (investment) =>
        investment.status
          .toLowerCase() !==
        "active",
    );

  return (
    <main className="ff-product-page ff-investments-page min-h-screen bg-[#F8F9FB] font-sans text-[#111318]">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0B0E17]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
          <button
            type="button"
            onClick={() =>
              router.push(
                "/dashboard",
              )
            }
            className="flex items-center gap-2 text-sm font-semibold text-white/70 transition hover:text-white"
          >
            <FiArrowLeft size={18} />
            Dashboard
          </button>

          <div className="text-lg font-black tracking-tight text-white">
            FLASH
            <span className="text-[#C9213A]">
              FINANCE
            </span>
          </div>

          <button
            type="button"
            onClick={() =>
              router.push(
                "/profile",
              )
            }
            className="flex h-9 w-9 items-center justify-center rounded-full bg-[#B51F35] text-white transition hover:bg-[#C9213A]"
          >
            <FiUser size={17} />
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-10">
        <section className="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-[#0B0E17] via-[#111827] to-[#171C29] p-6 text-white shadow-lg sm:p-8">
          <div className="absolute -right-32 -top-32 h-80 w-80 rounded-full bg-[#C9213A]/15 blur-3xl" />

          <div className="relative">
            <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#B51F35] text-white shadow-lg shadow-[#B51F35]/20">
              <FiBarChart2 size={24} />
            </div>

            <p className="text-xs font-bold uppercase tracking-[0.22em] text-white/60">
              Investment Center
            </p>

            <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">
              Investment Plans
            </h1>

            <p className="mt-4 max-w-2xl text-sm leading-6 text-white/60">
              Choose a plan, enter your amount, and track your investment as it progresses toward maturity.
            </p>

            <div className="mt-6 grid max-w-2xl gap-3 sm:grid-cols-2">
              <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-[#B51F35] to-[#C9213A] p-4 shadow-lg shadow-[#B51F35]/10">
                <p className="text-[10px] uppercase tracking-wider text-white/70">
                  Available balance
                </p>

                <p className="mt-1 text-lg font-black">
                  {formatMoney(
                    balance,
                    currency,
                  )}
                </p>
              </div>

              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-[10px] uppercase tracking-wider text-white/50">
                  Active investments
                </p>

                <p className="mt-1 text-lg font-black text-white">
                  {activeInvestments.length}
                </p>
              </div>
            </div>
          </div>
        </section>

        {error && (
          <section className="mt-5 rounded-2xl border border-red-200 bg-red-50 p-4">
            <div className="flex items-start gap-3">
              <FiAlertCircle
                size={19}
                className="mt-0.5 shrink-0 text-red-600"
              />

              <p className="text-sm leading-6 text-red-700">
                {error}
              </p>
            </div>
          </section>
        )}

        {success && (
          <section className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
            <div className="flex items-start gap-3">
              <FiCheckCircle
                size={19}
                className="mt-0.5 shrink-0 text-emerald-600"
              />

              <p className="text-sm leading-6 text-emerald-700">
                {success}
              </p>
            </div>
          </section>
        )}

        <section className="mt-8">
          <div className="mb-5">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
              Available plans
            </p>

            <h2 className="mt-1 text-xl font-black text-[#111318] sm:text-2xl">
              Choose your plan
            </h2>

            <p className="mt-2 text-sm text-[#69707D]">
              These plans are loaded directly from the current investment settings.
            </p>
          </div>

          {plansLoading ? (
            <div className="rounded-3xl border border-[#E2E5E9] bg-white p-10 text-center shadow-sm">
              <FiLoader
                size={25}
                className="mx-auto animate-spin text-[#B51F35]"
              />

              <p className="mt-4 text-sm font-bold text-[#111318]">
                Loading available plans...
              </p>

              <p className="mt-2 text-xs text-[#69707D]">
                Getting the latest investment settings.
              </p>
            </div>
          ) : investmentPlans.length === 0 ? (
            <div className="rounded-3xl border border-[#E2E5E9] bg-white p-10 text-center shadow-sm">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#B51F35]/10">
                <FiInfo
                  size={25}
                  className="text-[#B51F35]"
                />
              </div>

              <p className="mt-4 text-sm font-bold text-[#111318]">
                No investment plans are currently available
              </p>

              <p className="mx-auto mt-2 max-w-md text-xs leading-5 text-[#69707D]">
                Investment plans will appear here when an active plan is configured.
              </p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {investmentPlans.map(
                (plan) => {
                  const selected =
                    selectedPlan?.id ===
                    plan.id;

                  return (
                    <button
                      key={plan.id}
                      type="button"
                      onClick={() => {
                        setSelectedPlan(
                          plan,
                        );
                        setAmount("");
                        setError("");
                        setSuccess("");
                      }}
                      className={`group relative overflow-hidden rounded-3xl border bg-white p-6 text-left shadow-sm transition ${
                        selected
                          ? "border-[#B51F35] shadow-lg shadow-[#B51F35]/10"
                          : "border-[#E2E5E9] hover:-translate-y-1 hover:border-[#B51F35]/30 hover:shadow-md"
                      }`}
                    >
                      {plan.featured && (
                        <div className="absolute right-4 top-4 rounded-full bg-[#B51F35] px-3 py-1 text-[9px] font-black tracking-wider text-white">
                          FEATURED
                        </div>
                      )}

                      <div className="flex items-center gap-3">
                        <div
                          className={`flex h-12 w-12 items-center justify-center rounded-2xl ${
                            selected
                              ? "bg-[#B51F35] text-white"
                              : "bg-[#B51F35]/10 text-[#B51F35]"
                          }`}
                        >
                          <FiTrendingUp size={21} />
                        </div>

                        <div>
                          <h3 className="text-lg font-black text-[#111318]">
                            {plan.name}
                          </h3>

                          <p className="mt-1 flex items-center gap-1 text-xs text-[#9298A3]">
                            <FiClock size={12} />
                            {plan.duration}
                          </p>
                        </div>
                      </div>

                      {plan.description && (
                        <p className="mt-4 text-xs leading-5 text-[#69707D]">
                          {plan.description}
                        </p>
                      )}

                      <div className="mt-7">
                        <p className="text-3xl font-black text-[#B51F35]">
                          {plan.roi}%
                        </p>

                        <p className="mt-1 text-xs text-[#9298A3]">
                          ROI
                        </p>
                      </div>

                      <div className="mt-6 grid grid-cols-2 gap-3">
                        <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-3">
                          <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                            Minimum
                          </p>

                          <p className="mt-1 text-sm font-bold text-[#252932]">
                            {formatMoney(
                              plan.min,
                              currency,
                            )}
                          </p>
                        </div>

                        <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-3">
                          <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                            Maximum
                          </p>

                          <p className="mt-1 text-sm font-bold text-[#252932]">
                            {formatMoney(
                              plan.max,
                              currency,
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="mt-5 flex items-center justify-between text-xs font-bold">
                        <span
                          className={
                            selected
                              ? "text-[#B51F35]"
                              : "text-[#69707D]"
                          }
                        >
                          {selected
                            ? "Selected"
                            : "Select plan"}
                        </span>

                        <FiChevronRight
                          size={16}
                          className={
                            selected
                              ? "text-[#B51F35]"
                              : "text-[#9298A3]"
                          }
                        />
                      </div>
                    </button>
                  );
                },
              )}
            </div>
          )}
        </section>

        {selectedPlan && (
          <section className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
            <div className="rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm sm:p-8">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                  <FiDollarSign size={20} />
                </div>

                <div>
                  <p className="text-xs text-[#9298A3]">
                    Selected plan
                  </p>

                  <h2 className="text-xl font-black text-[#111318]">
                    {selectedPlan.name}
                  </h2>
                </div>
              </div>

              <div className="mt-6 overflow-hidden rounded-2xl bg-gradient-to-br from-[#B51F35] to-[#C9213A] p-5 text-white shadow-lg shadow-[#B51F35]/10">
                <div className="flex items-center justify-between gap-4">
                  <span className="text-xs font-bold text-white/70">
                    Available balance
                  </span>

                  <span className="text-lg font-black">
                    {formatMoney(
                      balance,
                      currency,
                    )}
                  </span>
                </div>
              </div>

              <div className="mt-6">
                <label
                  htmlFor="investmentAmount"
                  className="mb-2 block text-sm font-bold text-[#252932]"
                >
                  Investment amount
                </label>

                <div
                  className={`flex items-center rounded-2xl border bg-[#F1F3F6] px-4 transition focus-within:bg-white ${
                    amount &&
                    (!amountWithinPlan ||
                      !enoughBalance)
                      ? "border-red-300"
                      : "border-[#E2E5E9] focus-within:border-[#B51F35]"
                  }`}
                >
                  <span className="mr-2 text-sm font-bold text-[#9298A3]">
                    {currency}
                  </span>

                  <input
                    id="investmentAmount"
                    type="number"
                    min={selectedPlan.min}
                    max={selectedPlan.max}
                    step="0.01"
                    value={amount}
                    onChange={(event) => {
                      setAmount(
                        event.target.value,
                      );
                      setError("");
                      setSuccess("");
                    }}
                    placeholder={`${selectedPlan.min}`}
                    className="w-full bg-transparent py-4 text-lg font-black text-[#111318] outline-none placeholder:text-[#9298A3]"
                  />
                </div>

                <p className="mt-2 text-xs text-[#9298A3]">
                  Range:{" "}
                  {formatMoney(
                    selectedPlan.min,
                    currency,
                  )}{" "}
                  –{" "}
                  {formatMoney(
                    selectedPlan.max,
                    currency,
                  )}
                </p>

                {amount &&
                  !amountWithinPlan && (
                    <p className="mt-2 text-xs text-red-600">
                      The amount is outside this plan&apos;s range.
                    </p>
                  )}

                {amount &&
                  amountWithinPlan &&
                  !enoughBalance && (
                    <p className="mt-2 text-xs text-red-600">
                      Your available balance is not enough for this investment.
                    </p>
                  )}
              </div>

              <div className="mt-7 grid gap-3 sm:grid-cols-3">
                <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-4">
                  <p className="text-xs text-[#69707D]">
                    Investment
                  </p>

                  <p className="mt-2 text-lg font-black text-[#111318]">
                    {formatMoney(
                      numericAmount,
                      currency,
                    )}
                  </p>
                </div>

                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                  <p className="text-xs text-[#69707D]">
                    Estimated profit
                  </p>

                  <p className="mt-2 text-lg font-black text-emerald-600">
                    {formatMoney(
                      estimatedProfit,
                      currency,
                    )}
                  </p>
                </div>

                <div className="rounded-2xl border border-[#B51F35]/20 bg-[#B51F35]/5 p-4">
                  <p className="text-xs text-[#69707D]">
                    Estimated total
                  </p>

                  <p className="mt-2 text-lg font-black text-[#B51F35]">
                    {formatMoney(
                      estimatedTotal,
                      currency,
                    )}
                  </p>
                </div>
              </div>

              <button
                type="button"
                disabled={
                  investing ||
                  !amountValid
                }
                onClick={
                  handleInvest
                }
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#B51F35] px-5 py-4 text-sm font-black text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-40"
              >
                {investing ? (
                  <>
                    <FiLoader
                      size={18}
                      className="animate-spin"
                    />
                    Processing...
                  </>
                ) : (
                  <>
                    Continue
                    <FiChevronRight
                      size={18}
                    />
                  </>
                )}
              </button>
            </div>

            <aside>
              <div className="rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35]/10">
                    <FiShield
                      size={20}
                      className="text-[#B51F35]"
                    />
                  </div>

                  <h3 className="font-black text-[#111318]">
                    Selected plan
                  </h3>
                </div>

                <div className="mt-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#69707D]">
                      Plan
                    </span>

                    <span className="text-sm font-bold text-[#111318]">
                      {selectedPlan.name}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#69707D]">
                      Duration
                    </span>

                    <span className="text-sm font-bold text-[#111318]">
                      {selectedPlan.duration}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#69707D]">
                      ROI
                    </span>

                    <span className="text-sm font-bold text-[#B51F35]">
                      {selectedPlan.roi}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#69707D]">
                      Minimum
                    </span>

                    <span className="text-sm font-bold text-[#111318]">
                      {formatMoney(
                        selectedPlan.min,
                        currency,
                      )}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#69707D]">
                      Maximum
                    </span>

                    <span className="text-sm font-bold text-[#111318]">
                      {formatMoney(
                        selectedPlan.max,
                        currency,
                      )}
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  router.push(
                    "/dashboard",
                  )
                }
                className="mt-4 flex w-full items-center justify-between rounded-3xl border border-[#E2E5E9] bg-white p-5 shadow-sm transition hover:border-[#B51F35]/30"
              >
                <span className="text-sm font-bold text-[#111318]">
                  Return to dashboard
                </span>

                <FiChevronRight
                  size={17}
                  className="text-[#9298A3]"
                />
              </button>
            </aside>
          </section>
        )}

        <section className="mt-10">
          <div className="mb-5">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
              Your investment activity
            </p>

            <h2 className="mt-1 text-xl font-black text-[#111318] sm:text-2xl">
              Watch your investments grow
            </h2>

            <p className="mt-2 max-w-2xl text-sm text-[#69707D]">
              Each active investment moves gradually from its starting amount toward its calculated maturity value based on the investment period.
            </p>
          </div>

          {investments.length === 0 ? (
            <div className="rounded-3xl border border-[#E2E5E9] bg-white p-10 text-center shadow-sm">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#B51F35]/10">
                <FiBarChart2
                  size={25}
                  className="text-[#B51F35]"
                />
              </div>

              <p className="mt-4 text-sm font-bold text-[#111318]">
                No investments yet
              </p>

              <p className="mt-2 text-xs text-[#69707D]">
                Your investments will appear here after you create one.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              {activeInvestments.map(
                (investment) => {
                  const {
                    progress,
                    profitEarned,
                    currentValue,
                    remainingProfit,
                  } =
                    getCurrentInvestmentValue(
                      investment,
                      currentTime,
                    );

                  const maturityTime =
                    new Date(
                      investment.maturity_at,
                    ).getTime();

                  const remaining =
                    Math.max(
                      0,
                      maturityTime -
                        currentTime,
                    );

                  const growthPoints =
                    buildGrowthPoints(
                      investment,
                      currentTime,
                    );

                  const readyToMature =
                    remaining <= 0;

                  return (
                    <div
                      key={
                        investment.id
                      }
                      className="overflow-hidden rounded-[28px] border border-[#E2E5E9] bg-white shadow-sm"
                    >
                      <div className="p-6 sm:p-7">
                        <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
                          <div className="flex items-start gap-3">
                            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#B51F35]/10 text-[#B51F35]">
                              <FiTrendingUp
                                size={21}
                              />
                            </div>

                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <h3 className="text-lg font-black text-[#111318]">
                                  {
                                    investment.plan_name
                                  }
                                </h3>

                                <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600">
                                  Active
                                </span>
                              </div>

                              <p className="mt-1 text-xs text-[#9298A3]">
                                Started{" "}
                                {formatDateTime(
                                  investment.started_at,
                                )}
                              </p>
                            </div>
                          </div>

                          <div className="text-left lg:text-right">
                            <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                              Current value
                            </p>

                            <p className="mt-1 text-3xl font-black text-[#111318]">
                              {formatMoney(
                                currentValue,
                                currency,
                              )}
                            </p>
                          </div>
                        </div>

                        <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                          <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                              Invested
                            </p>

                            <p className="mt-2 text-lg font-black text-[#111318]">
                              {formatMoney(
                                Number(
                                  investment.principal,
                                ),
                                currency,
                              )}
                            </p>
                          </div>

                          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                            <p className="text-[10px] uppercase tracking-wider text-[#69707D]">
                              Earned so far
                            </p>

                            <p className="mt-2 text-lg font-black text-emerald-600">
                              +
                              {formatMoney(
                                profitEarned,
                                currency,
                              )}
                            </p>
                          </div>

                          <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                              Remaining profit
                            </p>

                            <p className="mt-2 text-lg font-black text-[#B51F35]">
                              {formatMoney(
                                remainingProfit,
                                currency,
                              )}
                            </p>
                          </div>

                          <div className="rounded-2xl bg-gradient-to-br from-[#B51F35] to-[#C9213A] p-4 text-white">
                            <p className="text-[10px] uppercase tracking-wider text-white/70">
                              At maturity
                            </p>

                            <p className="mt-2 text-lg font-black">
                              {formatMoney(
                                Number(
                                  investment.total_return,
                                ),
                                currency,
                              )}
                            </p>
                          </div>
                        </div>

                        <div className="mt-6 rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-5">
                          <div className="flex items-center justify-between gap-4">
                            <div>
                              <div className="flex items-center gap-2">
                                <FiClock
                                  size={15}
                                  className="text-[#B51F35]"
                                />

                                <p className="text-xs font-bold text-[#252932]">
                                  Investment progress
                                </p>
                              </div>

                              <p className="mt-1 text-[11px] text-[#9298A3]">
                                From start date to maturity
                              </p>
                            </div>

                            <p className="text-lg font-black text-[#B51F35]">
                              {(
                                progress *
                                100
                              ).toFixed(
                                1,
                              )}
                              %
                            </p>
                          </div>

                          <div className="mt-4 h-3 overflow-hidden rounded-full bg-[#E2E5E9]">
                            <div
                              className="h-full rounded-full bg-[#B51F35] transition-all duration-700"
                              style={{
                                width: `${
                                  progress *
                                  100
                                }%`,
                              }}
                            />
                          </div>

                          <div className="mt-3 flex items-center justify-between text-[11px]">
                            <span className="text-[#9298A3]">
                              {formatDateTime(
                                investment.started_at,
                              )}
                            </span>

                            <span className="font-bold text-[#252932]">
                              {readyToMature
                                ? "Ready to mature"
                                : formatRemaining(
                                    remaining,
                                  )}
                            </span>

                            <span className="text-[#9298A3]">
                              {formatDateTime(
                                investment.maturity_at,
                              )}
                            </span>
                          </div>
                        </div>

                        <GrowthChart
                          points={
                            growthPoints
                          }
                          currency={
                            currency
                          }
                        />

                        <div className="mt-5 grid gap-3 sm:grid-cols-3">
                          <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-4">
                            <div className="flex items-center gap-2 text-[#69707D]">
                              <FiActivity
                                size={15}
                              />

                              <span className="text-xs">
                                Current position
                              </span>
                            </div>

                            <p className="mt-2 text-lg font-black text-[#111318]">
                              {formatMoney(
                                currentValue,
                                currency,
                              )}
                            </p>
                          </div>

                          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                            <div className="flex items-center gap-2 text-[#69707D]">
                              <FiTrendingUp
                                size={15}
                              />

                              <span className="text-xs">
                                Growth so far
                              </span>
                            </div>

                            <p className="mt-2 text-lg font-black text-emerald-600">
                              +
                              {formatMoney(
                                profitEarned,
                                currency,
                              )}
                            </p>
                          </div>

                          <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-4">
                            <div className="flex items-center gap-2 text-[#69707D]">
                              <FiClock
                                size={15}
                              />

                              <span className="text-xs">
                                Time remaining
                              </span>
                            </div>

                            <p className="mt-2 text-lg font-black text-[#111318]">
                              {formatRemaining(
                                remaining,
                              )}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-[#E2E5E9] px-6 py-4 sm:px-7">
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                          <div className="flex items-start gap-2 text-xs text-[#69707D]">
                            <FiInfo
                              size={14}
                              className="mt-0.5 shrink-0"
                            />

                            <span>
                              The displayed growth reflects the return scheduled for this investment period.
                            </span>
                          </div>

                          {readyToMature && (
                            <button
                              type="button"
                              onClick={() =>
                                handleMature(
                                  investment.id,
                                )
                              }
                              disabled={
                                maturingId ===
                                investment.id
                              }
                              className="flex shrink-0 items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-4 py-3 text-xs font-black text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
                            >
                              {maturingId ===
                              investment.id ? (
                                <>
                                  <FiLoader
                                    size={15}
                                    className="animate-spin"
                                  />
                                  Processing...
                                </>
                              ) : (
                                <>
                                  Mature investment
                                  <FiChevronRight
                                    size={15}
                                  />
                                </>
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                },
              )}
            </div>
          )}
        </section>

        {completedInvestments.length >
          0 && (
          <section className="mt-10">
            <div className="mb-5">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
                Completed
              </p>

              <h2 className="mt-1 text-xl font-black text-[#111318] sm:text-2xl">
                Investment history
              </h2>
            </div>

            <div className="space-y-3">
              {completedInvestments.map(
                (investment) => (
                  <div
                    key={
                      investment.id
                    }
                    className="rounded-3xl border border-[#E2E5E9] bg-white p-5 shadow-sm sm:p-6"
                  >
                    <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex items-start gap-3">
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                          <FiCheckCircle
                            size={20}
                          />
                        </div>

                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-black text-[#111318]">
                              {
                                investment.plan_name
                              }
                            </h3>

                            <span className="text-xs font-bold text-emerald-600">
                              {formatStatus(
                                investment.status,
                              )}
                            </span>
                          </div>

                          <p className="mt-1 text-xs text-[#9298A3]">
                            Matured{" "}
                            {formatDateTime(
                              investment.maturity_at,
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                            Invested
                          </p>

                          <p className="mt-1 text-sm font-black text-[#111318]">
                            {formatMoney(
                              Number(
                                investment.principal,
                              ),
                              currency,
                            )}
                          </p>
                        </div>

                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                            Profit
                          </p>

                          <p className="mt-1 text-sm font-black text-emerald-600">
                            +
                            {formatMoney(
                              Number(
                                investment.profit,
                              ),
                              currency,
                            )}
                          </p>
                        </div>

                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-[#9298A3]">
                            Total
                          </p>

                          <p className="mt-1 text-sm font-black text-[#B51F35]">
                            {formatMoney(
                              Number(
                                investment.total_return,
                              ),
                              currency,
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ),
              )}
            </div>
          </section>
        )}

        <section className="mt-10 grid gap-4 md:grid-cols-3">
          <div className="rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
              <FiBarChart2 size={20} />
            </div>

            <h3 className="mt-5 font-black text-[#111318]">
              Choose a plan
            </h3>

            <p className="mt-2 text-sm leading-6 text-[#69707D]">
              Select the plan and investment amount you want to use.
            </p>
          </div>

          <div className="rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
              <FiDollarSign size={20} />
            </div>

            <h3 className="mt-5 font-black text-[#111318]">
              Track the growth
            </h3>

            <p className="mt-2 text-sm leading-6 text-[#69707D]">
              Your investment activity shows how the current value moves toward the maturity value.
            </p>
          </div>

          <div className="rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
              <FiCheck size={20} />
            </div>

            <h3 className="mt-5 font-black text-[#111318]">
              Mature the investment
            </h3>

            <p className="mt-2 text-sm leading-6 text-[#69707D]">
              Once the maturity time is reached, the backend can return the investment value to the account.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}