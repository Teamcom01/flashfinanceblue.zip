"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useParams, useRouter } from "next/navigation";
import {
  FiArrowLeft,
  FiCheckCircle,
  FiClock,
  FiCreditCard,
  FiFileText,
  FiRefreshCw,
  FiShield,
  FiUpload,
} from "react-icons/fi";
import { FaUniversity } from "react-icons/fa";
import {
  SiBitcoin,
  SiCashapp,
  SiEthereum,
  SiPaypal,
  SiTether,
  SiVenmo,
  SiZelle,
} from "react-icons/si";
import { createClient } from "@/lib/supabase";

type Withdrawal = {
  id: string;
  user_id: string;
  amount: number;
  withdrawal_method: string;
  destination: string;
  status: string;
  note: string | null;
  created_at: string;
  verification_fee: number | null;
  processing_type: string | null;
  processing_text: string | null;
  account_holder_name: string | null;
};

type PaymentMethod = {
  id: string;
  name: string;
  type: string;
  details: unknown;
  is_active: boolean;
  sort_order: number | null;
};

type VerificationPayment = {
  id: string;
  withdrawal_id: string;
  user_id: string;
  amount: number;
  payment_method: string;
  payment_reference: string | null;
  note: string | null;
  status: "pending" | "approved" | "rejected";
  created_at: string;
  reviewed_at: string | null;
  admin_note: string | null;
};

type PaymentMethodKey =
  | "paypal"
  | "cashapp"
  | "bitcoin"
  | "bank"
  | "zelle"
  | "venmo"
  | "chime"
  | "ethereum"
  | "usdt";

type PaymentInformationField = {
  label: string;
  value: string;
};

type PaymentInformation = {
  fields: PaymentInformationField[];
  instructions: string;
};

function money(value: number | null | undefined) {
  return Number(value || 0).toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  });
}

function processingLabel(
  processingType: string | null,
  processingText: string | null,
) {
  if (processingText?.trim()) return processingText.trim();

  switch (processingType) {
    case "instant":
      return "Instant";
    case "3_business_days":
      return "3 Business Days";
    case "after_verification_fee":
      return "After Verification Fee Is Paid";
    case "custom":
      return "Custom";
    default:
      return "Processing details available on withdrawal receipt";
  }
}

function normalizeKey(value: string) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function stringValue(value: unknown) {
  if (
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean"
  ) {
    return String(value).trim();
  }

  return "";
}

function parseDetails(details: unknown): Record<string, unknown> {
  if (
    details &&
    typeof details === "object" &&
    !Array.isArray(details)
  ) {
    return details as Record<string, unknown>;
  }

  if (typeof details === "string") {
    try {
      const parsed = JSON.parse(details);

      if (
        parsed &&
        typeof parsed === "object" &&
        !Array.isArray(parsed)
      ) {
        return parsed as Record<string, unknown>;
      }
    } catch {
      return { instructions: details };
    }
  }

  return {};
}

function getPaymentMethodKey(
  method: PaymentMethod,
): PaymentMethodKey {
  const normalized = normalizeKey(
    `${method.name} ${method.type}`,
  );

  if (normalized.includes("paypal")) return "paypal";

  if (
    normalized.includes("cashapp") ||
    normalized.includes("cashapptransfer")
  ) {
    return "cashapp";
  }

  if (
    normalized.includes("bitcoin") ||
    normalized === "btc"
  ) {
    return "bitcoin";
  }

  if (
    normalized.includes("banktransfer") ||
    normalized.includes("wiretransfer") ||
    normalized.includes("bankwire") ||
    normalized === "bank"
  ) {
    return "bank";
  }

  if (normalized.includes("zelle")) return "zelle";
  if (normalized.includes("venmo")) return "venmo";
  if (normalized.includes("chime")) return "chime";

  if (
    normalized.includes("ethereum") ||
    normalized === "eth"
  ) {
    return "ethereum";
  }

  if (
    normalized.includes("usdt") ||
    normalized.includes("tether")
  ) {
    return "usdt";
  }

  return normalizeKey(method.name) as PaymentMethodKey;
}

function getPaymentMethodVisual(method: PaymentMethod) {
  const key = getPaymentMethodKey(method);

  switch (key) {
    case "paypal":
      return {
        icon: SiPaypal,
        color: "#003087",
        background: "bg-[#F7DDE2]",
        border: "border-[#E8AAB6]",
        description: "Pay through your PayPal account.",
      };

    case "cashapp":
      return {
        icon: SiCashapp,
        color: "#00A63C",
        background: "bg-[#E2F4E9]",
        border: "border-[#A9DDBB]",
        description: "Send your payment through Cash App.",
      };

    case "bitcoin":
      return {
        icon: SiBitcoin,
        color: "#F7931A",
        background: "bg-[#FFF0D9]",
        border: "border-[#F2D09F]",
        description: "Submit a Bitcoin payment for review.",
      };

    case "bank":
      return {
        icon: FaUniversity,
        color: "#315A8A",
        background: "bg-[#E5EEF7]",
        border: "border-[#B9D0E3]",
        description: "Pay your fee by bank transfer.",
      };

    case "zelle":
      return {
        icon: SiZelle,
        color: "#6D1ED4",
        background: "bg-[#EEE5FA]",
        border: "border-[#D2BFEF]",
        description: "Submit your Zelle payment details.",
      };

    case "venmo":
      return {
        icon: SiVenmo,
        color: "#008CFF",
        background: "bg-[#E2F1FC]",
        border: "border-[#B7D9F2]",
        description: "Pay your fee using Venmo.",
      };

    case "chime":
      return {
        icon: FiCreditCard,
        color: "#00C98D",
        background: "bg-[#E0F5EF]",
        border: "border-[#B1DED2]",
        description: "Pay your outstanding fee using Chime.",
      };

    case "ethereum":
      return {
        icon: SiEthereum,
        color: "#627EEA",
        background: "bg-[#E6E9FA]",
        border: "border-[#C5CAF0]",
        description: "Submit an Ethereum payment for review.",
      };

    case "usdt":
      return {
        icon: SiTether,
        color: "#50AF95",
        background: "bg-[#E1F2ED]",
        border: "border-[#B6D9D0]",
        description: "Submit a USDT payment for review.",
      };

    default:
      return {
        icon: FiCreditCard,
        color: "#B51F35",
        background: "bg-[#F7DDE2]",
        border: "border-[#E8AAB6]",
        description: "Use this available payment method.",
      };
  }
}

function getPaymentFieldDefinitions(
  method: PaymentMethodKey,
): { key: string; label: string }[] {
  switch (method) {
    case "paypal":
      return [
        { key: "account_name", label: "Account Name" },
        { key: "email", label: "PayPal Email" },
      ];

    case "cashapp":
      return [
        { key: "account_name", label: "Account Name" },
        { key: "cashtag", label: "Cash App" },
      ];

    case "bitcoin":
      return [
        { key: "network", label: "Payment Network" },
        { key: "wallet_address", label: "Bitcoin Wallet" },
      ];

    case "bank":
      return [
        { key: "bank_name", label: "Bank Name" },
        { key: "account_name", label: "Account Name" },
        { key: "account_number", label: "Account Number" },
        { key: "routing_number", label: "Routing Number" },
        { key: "account_type", label: "Account Type" },
        { key: "swift_code", label: "SWIFT / BIC" },
      ];

    case "zelle":
      return [
        { key: "account_name", label: "Recipient Name" },
        { key: "email_or_phone", label: "Zelle Email or Phone" },
      ];

    case "venmo":
      return [
        { key: "account_name", label: "Account Name" },
        { key: "username", label: "Venmo Username" },
      ];

    case "chime":
      return [
        { key: "account_name", label: "Account Name" },
        { key: "email", label: "Chime Email" },
      ];

    case "ethereum":
      return [
        { key: "network", label: "Payment Network" },
        { key: "wallet_address", label: "Ethereum Wallet" },
      ];

    case "usdt":
      return [
        { key: "network", label: "Payment Network" },
        { key: "wallet_address", label: "USDT Wallet" },
      ];

    default:
      return [];
  }
}

function getFieldAliases(field: string) {
  const aliases: Record<string, string[]> = {
    account_name: [
      "account_name",
      "accountname",
      "account",
      "name",
    ],
    email: [
      "email",
      "email_address",
      "emailaddress",
    ],
    cashtag: [
      "cashtag",
      "cash_app",
      "cashapptag",
      "cashtagname",
      "cashtagid",
      "cashtagvalue",
      "cashtagaccount",
      "cashtagusername",
    ],
    network: [
      "network",
      "network_name",
      "networkname",
      "chain",
      "blockchain",
    ],
    wallet_address: [
      "wallet_address",
      "walletaddress",
      "wallet",
      "wallet_id",
      "address",
    ],
    bank_name: [
      "bank_name",
      "bankname",
      "bank",
      "financial_institution",
      "financialinstitution",
    ],
    account_number: [
      "account_number",
      "accountnumber",
      "acctnumber",
      "account_no",
      "accountno",
    ],
    routing_number: [
      "routing_number",
      "routingnumber",
      "routing",
      "routing_no",
      "routingno",
    ],
    swift_code: [
      "swift_code",
      "swiftcode",
      "swift",
      "bic",
    ],
    email_or_phone: [
      "email_or_phone",
      "emailorphone",
      "email_phone",
      "emailphone",
      "phone",
      "phone_number",
      "phonenumber",
      "zelle_email_phone",
      "zelleemailphone",
    ],
    username: [
      "username",
      "user",
      "venmo_username",
      "venmousername",
    ],
  };

  return aliases[field] || [];
}

function getMethodAliases(method: PaymentMethodKey) {
  switch (method) {
    case "paypal":
      return ["paypal", "paypals"];

    case "cashapp":
      return [
        "cashapp",
        "cash",
        "cash_app",
        "cashapptransfer",
      ];

    case "bitcoin":
      return ["bitcoin", "btc"];

    case "bank":
      return [
        "bank",
        "banktransfer",
        "bank_transfer",
        "wiretransfer",
        "wire_transfer",
        "bankwire",
        "bank_wire",
      ];

    case "zelle":
      return ["zelle"];

    case "venmo":
      return ["venmo"];

    case "chime":
      return ["chime"];

    case "ethereum":
      return ["ethereum", "eth"];

    case "usdt":
      return ["usdt", "tether"];

    default:
      return [];
  }
}

function getFeeSpecificKeys(
  method: PaymentMethodKey,
  fieldKey: string,
) {
  const methodAliases = getMethodAliases(method);
  const fieldAliases = getFieldAliases(fieldKey);
  const candidates = new Set<string>();

  for (const methodAlias of methodAliases) {
    for (const fieldAlias of fieldAliases) {
      const methodName = normalizeKey(methodAlias);
      const fieldName = normalizeKey(fieldAlias);

      candidates.add(
        normalizeKey(
          `fee_${methodAlias}_${fieldAlias}`,
        ),
      );

      candidates.add(
        normalizeKey(
          `fee_${methodAlias}${fieldAlias}`,
        ),
      );

      candidates.add(
        normalizeKey(
          `${methodAlias}_${fieldAlias}`,
        ),
      );

      candidates.add(
        normalizeKey(
          `${methodAlias}${fieldAlias}`,
        ),
      );

      candidates.add(
        normalizeKey(
          `fee${methodName}${fieldName}`,
        ),
      );

      candidates.add(
        normalizeKey(
          `fee_${methodName}_${fieldName}`,
        ),
      );
    }
  }

  for (const fieldAlias of fieldAliases) {
    candidates.add(
      normalizeKey(`fee_${fieldAlias}`),
    );

    candidates.add(
      normalizeKey(fieldAlias),
    );
  }

  return candidates;
}

function getPaymentFieldValue(
  feeDetails: Record<string, unknown>,
  fullDetails: Record<string, unknown>,
  method: PaymentMethodKey,
  fieldKey: string,
) {
  const candidates = getFeeSpecificKeys(
    method,
    fieldKey,
  );

  for (const [key, value] of Object.entries(feeDetails)) {
    const normalized = normalizeKey(key);

    if (
      normalized === "fee" ||
      normalized.includes("destination")
    ) {
      continue;
    }

    if (
      candidates.has(normalized) ||
      getFieldAliases(fieldKey)
        .map(normalizeKey)
        .includes(normalized)
    ) {
      const text = stringValue(value);

      if (text) return text;
    }
  }

  for (const [key, value] of Object.entries(fullDetails)) {
    const normalized = normalizeKey(key);

    if (
      normalized.includes("destination") ||
      normalized.includes("deposit")
    ) {
      continue;
    }

    if (candidates.has(normalized)) {
      const text = stringValue(value);

      if (text) return text;
    }
  }

  return "";
}

function getInstructionValue(
  feeDetails: Record<string, unknown>,
  fullDetails: Record<string, unknown>,
  method: PaymentMethodKey,
) {
  const instructionKeys = [
    "instructions",
    "instruction",
    "payment_instructions",
    "paymentinstructions",
    "note",
    "payment_note",
    "paymentnote",
    "message",
    "description",
  ];

  for (const key of instructionKeys) {
    const text = stringValue(
      feeDetails[key],
    );

    if (text) return text;
  }

  for (const alias of getMethodAliases(method)) {
    const normalizedAlias = normalizeKey(alias);

    const possibleKeys = [
      `fee_${alias}_instructions`,
      `fee_${alias}_instruction`,
      `fee_${alias}_note`,
      `fee_${alias}_payment_instructions`,
      `fee_${alias}_payment_note`,
    ];

    for (const key of possibleKeys) {
      const text = stringValue(
        fullDetails[key],
      );

      if (text) return text;
    }

    for (const [key, value] of Object.entries(fullDetails)) {
      const normalized = normalizeKey(key);

      if (
        normalized.includes(
          `fee${normalizedAlias}`,
        ) &&
        (
          normalized.includes("instruction") ||
          normalized.includes("note")
        )
      ) {
        const text = stringValue(value);

        if (text) return text;
      }
    }
  }

  return "";
}

function getDestinationFallback(
  fullDetails: Record<string, unknown>,
  method: PaymentMethodKey,
) {
  for (const alias of getMethodAliases(method)) {
    const possibleKeys = [
      `fee_${alias}_destination`,
      `fee_${alias}`,
      `fee_destination`,
    ];

    for (const key of possibleKeys) {
      const text = stringValue(
        fullDetails[key],
      );

      if (text) return text;
    }
  }

  return stringValue(
    fullDetails.fee_destination,
  );
}

function parseDestination(destination: string) {
  const fields: PaymentInformationField[] = [];

  const lines = destination
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  for (const line of lines) {
    const separator = line.indexOf(":");

    if (separator <= 0) continue;

    const label = line
      .slice(0, separator)
      .trim();

    const value = line
      .slice(separator + 1)
      .trim();

    if (label && value) {
      fields.push({
        label,
        value,
      });
    }
  }

  return fields;
}

function getAdminFeePaymentInformation(
  method: PaymentMethodKey,
  detailsInput: unknown,
): PaymentInformation {
  const fullDetails = parseDetails(
    detailsInput,
  );

  const feeDetails =
    fullDetails.fee &&
    typeof fullDetails.fee === "object" &&
    !Array.isArray(fullDetails.fee)
      ? (fullDetails.fee as Record<string, unknown>)
      : {};

  const fields: PaymentInformationField[] = [];

  for (const definition of getPaymentFieldDefinitions(method)) {
    const value = getPaymentFieldValue(
      feeDetails,
      fullDetails,
      method,
      definition.key,
    );

    if (value) {
      fields.push({
        label: definition.label,
        value,
      });
    }
  }

  const destination =
    getDestinationFallback(
      fullDetails,
      method,
    );

  if (fields.length === 0 && destination) {
    fields.push(
      ...parseDestination(destination),
    );
  }

  if (destination && fields.length < 2) {
    for (const item of parseDestination(destination)) {
      const exists = fields.some(
        (field) =>
          normalizeKey(field.label) ===
          normalizeKey(item.label),
      );

      if (!exists) fields.push(item);
    }
  }

  return {
    fields,
    instructions: getInstructionValue(
      feeDetails,
      fullDetails,
      method,
    ),
  };
}

export default function WithdrawalVerificationFeePage() {
  const params = useParams();
  const router = useRouter();

  const withdrawalId = useMemo(() => {
    const value = params?.["withdrawal-id"];

    if (Array.isArray(value)) {
      return value[0] || "";
    }

    return typeof value === "string"
      ? value
      : "";
  }, [params]);

  const supabase = useMemo(
    () => createClient(),
    [],
  );

  const [withdrawal, setWithdrawal] =
    useState<Withdrawal | null>(null);

  const [paymentMethods, setPaymentMethods] =
    useState<PaymentMethod[]>([]);

  const [latestPayment, setLatestPayment] =
    useState<VerificationPayment | null>(
      null,
    );

  const [pendingPayment, setPendingPayment] =
    useState<VerificationPayment | null>(
      null,
    );

  const [approvedPaymentTotal, setApprovedPaymentTotal] =
    useState(0);

  const [selectedMethod, setSelectedMethod] =
    useState<PaymentMethod | null>(null);

  const [receiptFile, setReceiptFile] =
    useState<File | null>(null);

  const [paymentAmount, setPaymentAmount] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [submitting, setSubmitting] =
    useState(false);

  const [error, setError] =
    useState("");

  const [success, setSuccess] =
    useState("");

  const loadPage = useCallback(
    async () => {
      if (!withdrawalId) {
        setError(
          "Withdrawal reference is missing.",
        );
        setLoading(false);
        return;
      }

      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          router.push("/login");
          return;
        }

        const {
          data: withdrawalData,
          error: withdrawalError,
        } = await supabase
          .from("withdrawal_requests")
          .select(
            `
              id,
              user_id,
              amount,
              withdrawal_method,
              destination,
              status,
              note,
              created_at,
              verification_fee,
              processing_type,
              processing_text,
              account_holder_name
            `,
          )
          .eq("id", withdrawalId)
          .eq("user_id", user.id)
          .maybeSingle();

        if (withdrawalError) {
          throw withdrawalError;
        }

        if (!withdrawalData) {
          setError(
            "This withdrawal could not be found or is not available to your account.",
          );
          setWithdrawal(null);
          setLoading(false);
          return;
        }

        setWithdrawal(
          withdrawalData as unknown as Withdrawal,
        );

        const {
          data: methodsData,
          error: methodsError,
        } = await supabase
          .from("payment_methods")
          .select(
            "id,name,type,details,is_active,sort_order",
          )
          .eq("is_active", true)
          .order("sort_order", {
            ascending: true,
            nullsFirst: false,
          });

        if (methodsError) {
          throw methodsError;
        }

        const methods =
          (methodsData as PaymentMethod[]) ||
          [];

        setPaymentMethods(methods);

        setSelectedMethod((current) => {
          if (current) {
            return (
              methods.find(
                (method) =>
                  method.id === current.id,
              ) ||
              methods[0] ||
              null
            );
          }

          return methods[0] || null;
        });

        const {
          data: paymentData,
          error: paymentError,
        } = await supabase
          .from(
            "withdrawal_verification_payments",
          )
          .select(
            `
              id,
              withdrawal_id,
              user_id,
              amount,
              payment_method,
              payment_reference,
              note,
              status,
              created_at,
              reviewed_at,
              admin_note
            `,
          )
          .eq(
            "withdrawal_id",
            withdrawalId,
          )
          .eq("user_id", user.id)
          .order("created_at", {
            ascending: false,
          });

        if (paymentError) {
          throw paymentError;
        }

        const payments =
          (paymentData as VerificationPayment[]) ||
          [];

        const latest =
          payments[0] || null;

        const pending =
          payments.find(
            (payment) =>
              payment.status === "pending",
          ) || null;

        const approvedTotal =
          payments
            .filter(
              (payment) =>
                payment.status === "approved",
            )
            .reduce(
              (total, payment) =>
                total +
                Number(payment.amount || 0),
              0,
            );

        setLatestPayment(latest);
        setPendingPayment(pending);
        setApprovedPaymentTotal(
          approvedTotal,
        );
      } catch (loadError) {
        console.error(
          "Withdrawal verification fee load error:",
          loadError,
        );

        setError(
          "Unable to load the withdrawal verification fee information.",
        );
      } finally {
        setLoading(false);
      }
    },
    [
      router,
      supabase,
      withdrawalId,
    ],
  );

  useEffect(() => {
    void loadPage();
  }, [loadPage]);

  useEffect(() => {
    if (!withdrawalId) return;

    const channel = supabase
      .channel(
        `withdrawal-verification-fee-${withdrawalId}`,
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "payment_methods",
        },
        () => {
          void loadPage();
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table:
            "withdrawal_verification_payments",
          filter: `withdrawal_id=eq.${withdrawalId}`,
        },
        () => {
          void loadPage();
        },
      )
      .subscribe();

    const interval =
      window.setInterval(
        () => {
          void loadPage();
        },
        15000,
      );

    return () => {
      window.clearInterval(interval);
      void supabase.removeChannel(channel);
    };
  }, [
    loadPage,
    supabase,
    withdrawalId,
  ]);

  if (loading) {
    return (
      <main className="min-h-screen bg-white px-4 py-10 text-black">
        <div className="mx-auto max-w-3xl">
          <div className="rounded-3xl border border-[#E5E7EB] bg-white p-8 shadow-[0_18px_50px_rgba(15,23,42,0.08)]">
            <div className="animate-pulse space-y-5">
              <div className="h-8 w-64 rounded bg-[#E5E7EB]" />
              <div className="h-20 rounded-2xl bg-[#F1F3F6]" />
              <div className="h-32 rounded-2xl bg-[#F1F3F6]" />
            </div>
          </div>
        </div>
      </main>
    );
  }

  if (error && !withdrawal) {
    return (
      <main className="min-h-screen bg-white px-4 py-10 text-black">
        <div className="mx-auto max-w-3xl">
          <div className="rounded-3xl border border-[#E5E7EB] bg-white p-8 shadow-[0_18px_50px_rgba(15,23,42,0.08)]">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#F7DDE2] text-[#B51F35]">
              <FiShield size={22} />
            </div>

            <h1 className="mt-5 text-2xl font-extrabold tracking-tight !text-black">
              Withdrawal Verification Fee
            </h1>

            <p className="mt-3 text-sm leading-6 text-black">
              {error}
            </p>

            <button
              type="button"
              onClick={() =>
                router.push("/withdraw")
              }
              className="mt-7 inline-flex items-center gap-2 rounded-xl bg-[#B51F35] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#C9213A]"
            >
              <FiArrowLeft size={17} />
              Return to Withdraw
            </button>
          </div>
        </div>
      </main>
    );
  }

  if (!withdrawal) return null;

  const fee = Number(
    withdrawal.verification_fee || 0,
  );

  const remainingFee = Math.max(
    0,
    fee - approvedPaymentTotal,
  );

  const paymentBlocked =
    Boolean(pendingPayment) ||
    remainingFee <= 0;

  const processing = processingLabel(
    withdrawal.processing_type,
    withdrawal.processing_text,
  );

  const selectedPaymentInformation =
    selectedMethod
      ? getAdminFeePaymentInformation(
          getPaymentMethodKey(
            selectedMethod,
          ),
          selectedMethod.details,
        )
      : {
          fields: [],
          instructions: "",
        };

  function handlePaymentAmountChange(
    event: React.ChangeEvent<HTMLInputElement>,
  ) {
    const value = event.target.value;

    if (value === "") {
      setPaymentAmount("");
      return;
    }

    const numericValue = Number(value);

    if (
      !Number.isFinite(numericValue)
    ) {
      return;
    }

    if (numericValue > remainingFee) {
      setPaymentAmount(
        remainingFee > 0
          ? remainingFee.toFixed(2)
          : "",
      );
      return;
    }

    setPaymentAmount(value);
    setError("");
    setSuccess("");
  }

  function handlePayFullFee() {
    if (remainingFee > 0) {
      setPaymentAmount(
        remainingFee.toFixed(2),
      );
      setError("");
      setSuccess("");
    }
  }

  function handleReceiptChange(
    event: React.ChangeEvent<HTMLInputElement>,
  ) {
    const file =
      event.target.files?.[0] || null;

    if (!file) {
      setReceiptFile(null);
      return;
    }

    const fileName =
      file.name.toLowerCase();

    const validExtension =
      fileName.endsWith(".png") ||
      fileName.endsWith(".jpg") ||
      fileName.endsWith(".jpeg") ||
      fileName.endsWith(".pdf");

    if (!validExtension) {
      setReceiptFile(null);
      setError(
        "Please upload a PNG, JPG, JPEG, or PDF payment receipt.",
      );
      event.target.value = "";
      return;
    }

    setError("");
    setSuccess("");
    setReceiptFile(file);
  }

  async function handleSubmitPayment() {
    if (!withdrawal) return;

    if (!selectedMethod) {
      setError(
        "Please select a payment method.",
      );
      return;
    }

    if (pendingPayment) {
      setError(
        "A verification fee payment is already pending review.",
      );
      return;
    }

    if (remainingFee <= 0) {
      setError(
        "The verification fee has already been fully paid.",
      );
      return;
    }

    const amountToPay =
      Number(paymentAmount);

    if (
      !Number.isFinite(amountToPay) ||
      amountToPay <= 0
    ) {
      setError(
        "Please enter the amount you want to pay.",
      );
      return;
    }

    if (amountToPay > remainingFee) {
      setError(
        `You can pay any amount up to ${money(
          remainingFee,
        )}.`,
      );
      return;
    }

    if (!receiptFile) {
      setError(
        "Please upload your payment receipt before submitting the payment.",
      );
      return;
    }

    setSubmitting(true);
    setError("");
    setSuccess("");

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const {
        data,
        error: insertError,
      } = await supabase
        .from(
          "withdrawal_verification_payments",
        )
        .insert({
          withdrawal_id:
            withdrawal.id,
          user_id: user.id,
          amount: amountToPay,
          payment_method:
            selectedMethod.name,
          payment_reference: null,
          note: `Payment receipt: ${receiptFile.name}`,
          status: "pending",
        })
        .select(
          `
            id,
            withdrawal_id,
            user_id,
            amount,
            payment_method,
            payment_reference,
            note,
            status,
            created_at,
            reviewed_at,
            admin_note
          `,
        )
        .single();

      if (insertError) {
        throw insertError;
      }

      const submitted =
        data as VerificationPayment;

      setLatestPayment(submitted);
      setPendingPayment(submitted);
      setReceiptFile(null);
      setPaymentAmount("");

      router.push(
        `/withdraw/verification-fee/confirmation?payment-id=${encodeURIComponent(
          submitted.id,
        )}&withdrawal-id=${encodeURIComponent(
          withdrawal.id,
        )}`,
      );
    } catch (submitError) {
      console.error(
        "Withdrawal verification fee payment error:",
        submitError,
      );

      setError(
        "Unable to submit the verification fee payment. Please try again.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  const enteredAmount =
    Number(paymentAmount || 0);

  const validEnteredAmount =
    Number.isFinite(enteredAmount) &&
    enteredAmount > 0 &&
    enteredAmount <= remainingFee;

  return (
    <main className="min-h-screen bg-white px-4 py-8 text-black sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6">
          <button
            type="button"
            onClick={() =>
              router.push(
                `/withdraw/success?id=${encodeURIComponent(
                  withdrawal.id,
                )}`,
              )
            }
            className="inline-flex items-center gap-2 text-sm font-bold text-black transition hover:text-[#B51F35]"
          >
            <FiArrowLeft size={17} />
            Back to Withdrawal Receipt
          </button>
        </div>

        <section className="overflow-hidden rounded-[28px] border border-[#E5E7EB] bg-white shadow-[0_24px_70px_rgba(15,23,42,0.08)]">
          <div className="border-b border-[#E5E7EB] bg-white px-6 py-7 sm:px-8 sm:py-8">
            <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
              <div className="flex min-w-0 items-start gap-4">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-[#E8AAB6] bg-[#F7DDE2] text-[#B51F35] shadow-sm">
                  <FiShield size={25} />
                </div>

                <div className="min-w-0">
                  <div className="inline-flex items-center rounded-full border border-[#E8AAB6] bg-[#F7DDE2] px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B51F35]">
                    Withdrawal Verification
                  </div>

                  <h1 className="mt-3 text-2xl font-extrabold leading-tight tracking-[-0.025em] !text-black sm:text-3xl">
                    Verification Fee Payment
                  </h1>

                  <p className="mt-3 max-w-2xl text-sm font-medium leading-6 text-black sm:text-[15px]">
                    Complete the verification payment required for this withdrawal using one of the available payment methods below.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  void loadPage()
                }
                className="inline-flex shrink-0 items-center justify-center gap-2 self-start rounded-xl border border-[#D1D5DB] bg-white px-4 py-2.5 text-sm font-bold text-black shadow-sm transition hover:border-[#B51F35] hover:bg-[#F8F9FB]"
              >
                <FiRefreshCw size={16} />
                Refresh
              </button>
            </div>
          </div>

          <div className="grid gap-5 border-b border-[#E5E7EB] bg-[#F8F9FB] px-6 py-6 sm:grid-cols-3 sm:px-8">
            <div>
              <p className="text-xs font-extrabold uppercase tracking-[0.12em] text-black">
                Withdrawal Amount
              </p>
              <p className="mt-1 text-xl font-extrabold !text-black">
                {money(withdrawal.amount)}
              </p>
            </div>

            <div>
              <p className="text-xs font-extrabold uppercase tracking-[0.12em] text-black">
                Payment Method
              </p>
              <p className="mt-1 text-base font-extrabold !text-black">
                {withdrawal.withdrawal_method}
              </p>
            </div>

            <div>
              <p className="text-xs font-extrabold uppercase tracking-[0.12em] text-black">
                Arrival / Processing
              </p>
              <p className="mt-1 text-base font-extrabold !text-black">
                {processing}
              </p>
            </div>
          </div>

          <div className="px-6 py-8 sm:px-8">
            <div className="rounded-2xl border border-[#E5E7EB] bg-[#F8F9FB] p-5 shadow-sm sm:p-6">
              <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-sm font-extrabold !text-black">
                    Verification Fee
                  </p>

                  <p className="mt-1 text-4xl font-extrabold tracking-tight !text-black">
                    {money(fee)}
                  </p>

                  {approvedPaymentTotal > 0 &&
                    remainingFee > 0 && (
                      <div className="mt-3 space-y-1">
                        <p className="text-sm font-semibold text-black">
                          Approved payments:{" "}
                          <span className="font-extrabold text-emerald-700">
                            {money(
                              approvedPaymentTotal,
                            )}
                          </span>
                        </p>

                        <p className="text-sm font-semibold text-black">
                          Remaining fee:{" "}
                          <span className="font-extrabold text-black">
                            {money(
                              remainingFee,
                            )}
                          </span>
                        </p>
                      </div>
                    )}

                  {approvedPaymentTotal === 0 &&
                    remainingFee > 0 && (
                      <p className="mt-2 text-sm font-medium leading-6 text-black">
                        Total verification fee required:{" "}
                        {money(fee)}
                      </p>
                    )}

                  {remainingFee <= 0 &&
                    fee > 0 && (
                      <p className="mt-3 inline-flex items-center gap-2 rounded-full border border-emerald-300 bg-emerald-100 px-3 py-2 text-xs font-extrabold text-emerald-900">
                        <FiCheckCircle size={14} />
                        Verification fee fully paid
                      </p>
                    )}
                </div>

                <div className="inline-flex items-center gap-2 self-start rounded-full border border-[#E8AAB6] bg-[#F7DDE2] px-3 py-2 text-xs font-bold text-[#B51F35] sm:self-auto">
                  <FiCreditCard size={15} />
                  Verification payment
                </div>
              </div>
            </div>

            {pendingPayment && (
              <div className="mt-5 flex gap-3 rounded-2xl border border-amber-300 bg-amber-100 p-5">
                <FiClock
                  className="mt-0.5 shrink-0 text-amber-700"
                  size={20}
                />

                <div>
                  <p className="font-semibold text-black">
                    Payment submitted
                  </p>

                  <p className="mt-1 text-sm leading-6 text-black">
                    Your{" "}
                    {money(
                      pendingPayment.amount,
                    )}{" "}
                    verification fee payment using{" "}
                    {pendingPayment.payment_method}{" "}
                    is pending review.
                  </p>

                  <p className="mt-2 text-xs font-semibold leading-5 text-black">
                    You can submit another payment after this payment is reviewed and approved or rejected.
                  </p>
                </div>
              </div>
            )}

            {latestPayment?.status ===
              "approved" &&
              !pendingPayment &&
              remainingFee > 0 && (
                <div className="mt-5 flex gap-3 rounded-2xl border border-emerald-300 bg-emerald-100 p-5">
                  <FiCheckCircle
                    className="mt-0.5 shrink-0 text-emerald-700"
                    size={20}
                  />

                  <div>
                    <p className="font-semibold text-black">
                      Payment approved
                    </p>

                    <p className="mt-1 text-sm leading-6 text-black">
                      Your latest payment was approved. You still have{" "}
                      <strong>
                        {money(
                          remainingFee,
                        )}
                      </strong>{" "}
                      remaining on the verification fee.
                    </p>

                    {latestPayment.admin_note && (
                      <p className="mt-2 text-sm text-black">
                        {latestPayment.admin_note}
                      </p>
                    )}
                  </div>
                </div>
              )}

            {latestPayment?.status ===
              "approved" &&
              !pendingPayment &&
              remainingFee <= 0 && (
                <div className="mt-5 flex gap-3 rounded-2xl border border-emerald-300 bg-emerald-100 p-5">
                  <FiCheckCircle
                    className="mt-0.5 shrink-0 text-emerald-700"
                    size={20}
                  />

                  <div>
                    <p className="font-semibold text-black">
                      Verification payment approved
                    </p>

                    <p className="mt-1 text-sm leading-6 text-black">
                      Your verification fee has been fully paid and approved.
                    </p>

                    {latestPayment.admin_note && (
                      <p className="mt-2 text-sm text-black">
                        {latestPayment.admin_note}
                      </p>
                    )}
                  </div>
                </div>
              )}

            {latestPayment?.status ===
              "rejected" && (
              <div className="mt-5 rounded-2xl border border-red-300 bg-red-50 p-5">
                <p className="font-semibold text-black">
                  Previous payment was rejected
                </p>

                <p className="mt-1 text-sm leading-6 text-black">
                  You can submit a new payment below using the current payment instructions.
                </p>

                {latestPayment.admin_note && (
                  <p className="mt-2 text-sm text-black">
                    Admin note:{" "}
                    {latestPayment.admin_note}
                  </p>
                )}
              </div>
            )}

            {success && (
              <div className="mt-5 rounded-2xl border border-emerald-300 bg-emerald-50 p-5 text-sm font-medium text-black">
                {success}
              </div>
            )}

            {error && (
              <div className="mt-5 rounded-2xl border border-red-300 bg-red-50 p-5 text-sm font-medium text-black">
                {error}
              </div>
            )}

            <div className="mt-9">
              <div className="mb-5 rounded-2xl border border-[#E5E7EB] bg-white px-5 py-5 shadow-sm">
                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#F7DDE2] text-[#B51F35]">
                    <FiCreditCard size={20} />
                  </div>

                  <div>
                    <h2 className="text-2xl font-extrabold tracking-tight !text-black">
                      Choose a payment method
                    </h2>

                    <p className="mt-1 text-sm font-medium leading-6 text-black">
                      Select your preferred way to pay the verification fee.
                    </p>
                  </div>
                </div>
              </div>

              {paymentMethods.length ===
              0 ? (
                <div className="rounded-2xl border border-[#E5E7EB] bg-[#F8F9FB] p-6 text-sm font-medium text-black">
                  No withdrawal verification payment methods are currently available. Please try again later.
                </div>
              ) : (
                <div className="grid gap-4 sm:grid-cols-2">
                  {paymentMethods.map(
                    (method) => {
                      const selected =
                        selectedMethod?.id ===
                        method.id;

                      const visual =
                        getPaymentMethodVisual(
                          method,
                        );

                      const Icon =
                        visual.icon;

                      return (
                        <button
                          key={method.id}
                          type="button"
                          disabled={
                            paymentBlocked
                          }
                          onClick={() => {
                            setSelectedMethod(
                              method,
                            );
                            setError("");
                            setSuccess("");
                          }}
                          className={`group relative overflow-hidden rounded-2xl border p-4 text-left transition duration-200 ${
                            selected
                              ? "border-[#B51F35] bg-[#FDF0F2] shadow-[0_8px_24px_rgba(181,31,53,0.12)] ring-1 ring-[#B51F35]"
                              : "border-[#E5E7EB] bg-white hover:-translate-y-0.5 hover:border-[#B51F35] hover:bg-[#FDFBFC] hover:shadow-[0_10px_28px_rgba(15,23,42,0.08)]"
                          } ${
                            paymentBlocked
                              ? "cursor-not-allowed opacity-60"
                              : ""
                          }`}
                        >
                          <div className="flex items-center gap-4">
                            <div
                              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border ${visual.border} ${visual.background} shadow-sm`}
                            >
                              <Icon
                                size={30}
                                color={
                                  visual.color
                                }
                                aria-hidden="true"
                              />
                            </div>

                            <div className="min-w-0 flex-1">
                              <p className="text-base font-extrabold !text-black">
                                {method.name}
                              </p>

                              <p className="mt-1 text-xs font-medium leading-5 text-black">
                                {
                                  visual.description
                                }
                              </p>
                            </div>

                            <span
                              aria-hidden="true"
                              className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 ${
                                selected
                                  ? "border-[#B51F35] bg-[#B51F35]"
                                  : "border-[#D1D5DB] bg-white"
                              }`}
                            >
                              {selected && (
                                <span className="h-2 w-2 rounded-full bg-white" />
                              )}
                            </span>
                          </div>

                          {selected && (
                            <div className="mt-4 flex items-center gap-2 border-t border-[#E8AAB6] pt-3 text-xs font-extrabold uppercase tracking-[0.1em] text-[#B51F35]">
                              <FiCheckCircle size={14} />
                              Selected payment method
                            </div>
                          )}
                        </button>
                      );
                    },
                  )}
                </div>
              )}
            </div>

            {selectedMethod && (
              <div className="mt-7 rounded-2xl border border-[#E5E7EB] bg-white p-5 shadow-sm sm:p-6">
                <div className="flex items-center gap-3">
                  {(() => {
                    const visual =
                      getPaymentMethodVisual(
                        selectedMethod,
                      );

                    const Icon =
                      visual.icon;

                    return (
                      <div
                        className={`flex h-12 w-12 items-center justify-center rounded-xl border ${visual.border} ${visual.background} shadow-sm`}
                      >
                        <Icon
                          size={24}
                          color={
                            visual.color
                          }
                          aria-hidden="true"
                        />
                      </div>
                    );
                  })()}

                  <div>
                    <h3 className="text-lg font-extrabold !text-black">
                      {selectedMethod.name}{" "}
                      Payment
                    </h3>

                    <p className="text-xs font-bold uppercase tracking-[0.1em] text-[#6B7280]">
                      Payment Information
                    </p>
                  </div>
                </div>

                <div className="mt-5 rounded-xl border border-[#E5E7EB] bg-[#F8F9FB] p-4">
                  <p className="mb-4 text-xs font-extrabold uppercase tracking-[0.12em] text-black">
                    Payment Information
                  </p>

                  {selectedPaymentInformation
                    .fields.length > 0 ? (
                    <div className="space-y-3">
                      {selectedPaymentInformation.fields.map(
                        (
                          field,
                          index,
                        ) => (
                          <div
                            key={`${field.label}-${field.value}-${index}`}
                            className="rounded-xl border border-[#E5E7EB] bg-white px-4 py-3"
                          >
                            <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-[#6B7280]">
                              {field.label}
                            </p>

                            <p className="mt-1 break-words text-sm font-bold leading-6 !text-black">
                              {field.value}
                            </p>
                          </div>
                        ),
                      )}
                    </div>
                  ) : (
                    <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-4">
                      <p className="text-sm leading-6 text-black">
                        No payment information has been configured for{" "}
                        {selectedMethod.name}{" "}
                        yet.
                      </p>
                    </div>
                  )}

                  {selectedPaymentInformation
                    .instructions && (
                    <div className="mt-4 rounded-xl border border-[#E5E7EB] bg-white px-4 py-3">
                      <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-[#6B7280]">
                        Payment Instructions
                      </p>

                      <p className="mt-1 whitespace-pre-wrap break-words text-sm font-medium leading-6 !text-black">
                        {
                          selectedPaymentInformation.instructions
                        }
                      </p>
                    </div>
                  )}

                  <div className="mt-5 rounded-2xl border border-[#E5E7EB] bg-white p-5 shadow-sm sm:p-6">
                    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                      <div className="min-w-0 flex-1">
                        <label
                          htmlFor="verification-payment-amount"
                          className="block text-sm font-extrabold !text-black"
                        >
                          Fee Amount
                        </label>

                        <p className="mt-1 text-xs font-medium leading-5 text-[#6B7280]">
                          Enter how much you want to pay now.
                        </p>

                        <div className="relative mt-3">
                          <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-lg font-extrabold text-black">
                            $
                          </span>

                          <input
                            id="verification-payment-amount"
                            type="number"
                            min="0.01"
                            max={remainingFee}
                            step="0.01"
                            value={
                              paymentAmount
                            }
                            onChange={
                              handlePaymentAmountChange
                            }
                            disabled={
                              paymentBlocked ||
                              submitting ||
                              remainingFee <= 0
                            }
                            placeholder="0.00"
                            className="w-full rounded-xl border border-[#D1D5DB] bg-white py-3.5 pl-9 pr-4 text-lg font-extrabold !text-black caret-black outline-none transition placeholder:text-[#9CA3AF] focus:border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/20 disabled:cursor-not-allowed disabled:bg-[#F3F4F6]"
                          />
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={
                          handlePayFullFee
                        }
                        disabled={
                          paymentBlocked ||
                          submitting ||
                          remainingFee <= 0
                        }
                        className="rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-extrabold text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        Pay Full Fee
                      </button>
                    </div>

                    <div className="mt-4 flex items-center justify-between gap-4 rounded-xl border border-[#E5E7EB] bg-[#F8F9FB] px-4 py-3">
                      <span className="text-sm font-medium text-black">
                        {approvedPaymentTotal > 0
                          ? "Remaining fee"
                          : "Total fee"}
                      </span>

                      <span className="text-sm font-extrabold !text-black">
                        {money(
                          remainingFee,
                        )}
                      </span>
                    </div>

                    {approvedPaymentTotal > 0 &&
                      remainingFee > 0 && (
                        <p className="mt-3 text-xs font-medium leading-5 text-[#6B7280]">
                          You have already paid{" "}
                          {money(
                            approvedPaymentTotal,
                          )}{" "}
                          in approved payments. You can pay any amount up to the remaining{" "}
                          {money(
                            remainingFee,
                          )}.
                        </p>
                      )}
                  </div>

                  <div className="mt-5">
                    <label
                      htmlFor="withdrawal-verification-receipt"
                      className="mb-2 block text-sm font-bold !text-black"
                    >
                      Payment Receipt{" "}
                      <span className="text-[#B51F35]">
                        *
                      </span>
                    </label>

                    <input
                      id="withdrawal-verification-receipt"
                      type="file"
                      accept=".png,.jpg,.jpeg,.pdf,image/png,image/jpeg,application/pdf"
                      onChange={
                        handleReceiptChange
                      }
                      disabled={
                        paymentBlocked ||
                        submitting
                      }
                      className="sr-only"
                    />

                    <label
                      htmlFor="withdrawal-verification-receipt"
                      className={`flex min-h-[132px] flex-col items-center justify-center rounded-2xl border-2 border-dashed px-5 py-6 text-center transition ${
                        paymentBlocked
                          ? "cursor-not-allowed border-[#D1D5DB] bg-[#F3F4F6] opacity-60"
                          : "cursor-pointer border-[#D1D5DB] bg-[#F8F9FB] hover:border-[#B51F35] hover:bg-[#FDF0F2]"
                      }`}
                    >
                      {receiptFile ? (
                        <>
                          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#F7DDE2] text-[#B51F35]">
                            <FiFileText
                              size={23}
                            />
                          </div>

                          <p className="mt-3 max-w-full break-all text-sm font-extrabold !text-black">
                            {receiptFile.name}
                          </p>

                          <p className="mt-1 text-xs font-medium text-[#6B7280]">
                            Receipt selected successfully
                          </p>
                        </>
                      ) : (
                        <>
                          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#F7DDE2] text-[#B51F35]">
                            <FiUpload
                              size={23}
                            />
                          </div>

                          <p className="mt-3 text-sm font-extrabold !text-black">
                            Upload your payment receipt
                          </p>

                          <p className="mt-1 text-xs font-medium text-[#6B7280]">
                            PNG, JPG or PDF
                          </p>
                        </>
                      )}
                    </label>

                    <p className="mt-3 text-xs leading-5 text-[#6B7280]">
                      The selected file name is included with the payment submission. This page does not upload the file itself to storage.
                    </p>
                  </div>

                  <div className="mt-6 rounded-2xl border border-[#E5E7EB] bg-[#F8F9FB] p-5 sm:p-6">
                    <div className="flex items-start gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#F7DDE2] text-[#B51F35]">
                        <FiFileText size={19} />
                      </div>

                      <div>
                        <h3 className="text-lg font-extrabold !text-black">
                          Payment Summary
                        </h3>

                        <p className="mt-1 text-sm font-medium text-[#6B7280]">
                          Review your payment before submitting.
                        </p>
                      </div>
                    </div>

                    <div className="mt-5 divide-y divide-[#E5E7EB] rounded-xl border border-[#E5E7EB] bg-white">
                      <div className="flex items-center justify-between gap-4 px-4 py-3">
                        <span className="text-sm font-medium text-[#4B5563]">
                          Payment Method
                        </span>

                        <span className="text-sm font-extrabold !text-black">
                          {selectedMethod.name}
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-4 px-4 py-3">
                        <span className="text-sm font-medium text-[#4B5563]">
                          Payment Amount
                        </span>

                        <span className="text-sm font-extrabold !text-black">
                          {money(
                            enteredAmount,
                          )}
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-4 px-4 py-3">
                        <span className="text-sm font-medium text-[#4B5563]">
                          Verification Fee
                        </span>

                        <span className="text-sm font-extrabold !text-black">
                          {money(fee)}
                        </span>
                      </div>

                      {approvedPaymentTotal >
                        0 && (
                        <div className="flex items-center justify-between gap-4 px-4 py-3">
                          <span className="text-sm font-medium text-[#4B5563]">
                            Already Approved
                          </span>

                          <span className="text-sm font-extrabold text-emerald-700">
                            {money(
                              approvedPaymentTotal,
                            )}
                          </span>
                        </div>
                      )}

                      <div className="flex items-center justify-between gap-4 px-4 py-3">
                        <span className="text-sm font-medium text-[#4B5563]">
                          Remaining Fee
                        </span>

                        <span className="text-sm font-extrabold !text-black">
                          {money(
                            Math.max(
                              0,
                              remainingFee -
                                (validEnteredAmount
                                  ? enteredAmount
                                  : 0),
                            ),
                          )}
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-4 px-4 py-3">
                        <span className="text-sm font-medium text-[#4B5563]">
                          Receipt
                        </span>

                        <span
                          className={`text-sm font-extrabold ${
                            receiptFile
                              ? "text-emerald-700"
                              : "text-black"
                          }`}
                        >
                          {receiptFile
                            ? "Attached"
                            : "Required"}
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-4 px-4 py-3">
                        <span className="text-sm font-medium text-[#4B5563]">
                          Status
                        </span>

                        <span className="text-sm font-extrabold !text-black">
                          {pendingPayment
                            ? "Pending Review"
                            : remainingFee <=
                                0
                              ? "Paid in Full"
                              : validEnteredAmount
                                ? "Ready to Submit"
                                : "Amount Required"}
                        </span>
                      </div>
                    </div>

                    <div className="mt-5 rounded-xl border border-[#E5E7EB] bg-white px-4 py-4">
                      <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-[#6B7280]">
                        Payment Instructions
                      </p>

                      <p className="mt-2 text-sm font-medium leading-6 !text-black">
                        Enter the amount you want to pay, complete your payment using the payment information shown above, upload your payment receipt, and submit the payment for review.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={
                        handleSubmitPayment
                      }
                      disabled={
                        submitting ||
                        paymentBlocked ||
                        fee <= 0 ||
                        !validEnteredAmount
                      }
                      className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-extrabold text-white shadow-[0_8px_20px_rgba(181,31,53,0.18)] transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {submitting ? (
                        <>
                          <FiRefreshCw
                            className="animate-spin"
                            size={17}
                          />
                          Submitting Payment...
                        </>
                      ) : latestPayment?.status ===
                          "rejected" ? (
                        <>
                          <FiCheckCircle
                            size={17}
                          />
                          Submit New Payment
                        </>
                      ) : (
                        <>
                          <FiCheckCircle
                            size={17}
                          />
                          Submit Payment for Review
                        </>
                      )}
                    </button>

                    <p className="mt-4 text-center text-xs font-medium leading-5 text-[#6B7280]">
                      Your payment will be recorded as Pending and will be available immediately once your payment is confirmed. If you make a partial payment, you may pay the remaining balance after the current payment is confirmed.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={() =>
                  router.push(
                    `/withdraw/success?id=${encodeURIComponent(
                      withdrawal.id,
                    )}`,
                  )
                }
                className="flex-1 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#C9213A]"
              >
                Return to Withdrawal Receipt
              </button>

              <button
                type="button"
                onClick={() =>
                  router.push("/dashboard")
                }
                className="flex-1 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#C9213A]"
              >
                Dashboard
              </button>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}