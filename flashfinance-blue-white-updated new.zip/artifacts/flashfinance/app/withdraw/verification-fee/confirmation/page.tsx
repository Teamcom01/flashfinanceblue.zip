"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import {
  FiArrowLeft,
  FiCheckCircle,
  FiClock,
  FiCreditCard,
  FiFileText,
  FiRefreshCw,
  FiShield,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type Payment = {
  id: string;
  withdrawal_id: string;
  user_id: string;
  amount: number;
  payment_method: string;
  payment_reference: string | null;
  note: string | null;
  status: string;
  created_at: string;
};

type Withdrawal = {
  id: string;
  amount: number;
  verification_fee: number | null;
  withdrawal_method: string;
  destination: string;
};

function money(value: number | null | undefined) {
  return Number(value || 0).toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  });
}

function VerificationFeeConfirmationContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const paymentId = useMemo(
    () => searchParams.get("payment-id") || "",
    [searchParams],
  );

  const withdrawalId = useMemo(
    () => searchParams.get("withdrawal-id") || "",
    [searchParams],
  );

  const supabase = useMemo(() => createClient(), []);

  const [payment, setPayment] = useState<Payment | null>(null);
  const [withdrawal, setWithdrawal] =
    useState<Withdrawal | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function loadConfirmation() {
      if (!paymentId || !withdrawalId) {
        if (!cancelled) {
          setError(
            "The payment confirmation reference is missing.",
          );
          setLoading(false);
        }
        return;
      }

      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          router.push("/login");
          return;
        }

        const {
          data: paymentData,
          error: paymentError,
        } = await supabase
          .from("withdrawal_verification_payments")
          .select(
            `
              id,
              withdrawal_id,
              user_id,
              amount,
              payment_method,
              payment_reference,
              note,
              status,
              created_at
            `,
          )
          .eq("id", paymentId)
          .eq("withdrawal_id", withdrawalId)
          .eq("user_id", user.id)
          .maybeSingle();

        if (paymentError) {
          throw paymentError;
        }

        if (!paymentData) {
          throw new Error(
            "This payment confirmation could not be found.",
          );
        }

        const {
          data: withdrawalData,
          error: withdrawalError,
        } = await supabase
          .from("withdrawal_requests")
          .select(
            `
              id,
              amount,
              verification_fee,
              withdrawal_method,
              destination
            `,
          )
          .eq("id", withdrawalId)
          .eq("user_id", user.id)
          .maybeSingle();

        if (withdrawalError) {
          throw withdrawalError;
        }

        if (cancelled) return;

        setPayment(paymentData as Payment);
        setWithdrawal(
          withdrawalData as Withdrawal | null,
        );
      } catch (loadError) {
        console.error(
          "Verification fee confirmation load error:",
          loadError,
        );

        if (!cancelled) {
          setError(
            "Unable to load this payment confirmation.",
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadConfirmation();

    return () => {
      cancelled = true;
    };
  }, [
    paymentId,
    router,
    supabase,
    withdrawalId,
  ]);

  if (loading) {
    return (
      <main className="min-h-screen bg-white px-4 py-10 text-black sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <div className="rounded-[28px] border border-[#E5E7EB] bg-white p-8 shadow-[0_24px_70px_rgba(15,23,42,0.08)]">
            <div className="animate-pulse space-y-5">
              <div className="h-8 w-64 rounded bg-[#E5E7EB]" />
              <div className="h-20 rounded-2xl bg-[#F1F3F6]" />
              <div className="h-36 rounded-2xl bg-[#F1F3F6]" />
            </div>
          </div>
        </div>
      </main>
    );
  }

  if (error || !payment) {
    return (
      <main className="min-h-screen bg-white px-4 py-10 text-black sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <div className="rounded-[28px] border border-[#E5E7EB] bg-white p-8 shadow-[0_24px_70px_rgba(15,23,42,0.08)]">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-[#E8AAB6] bg-[#F7DDE2] text-[#B51F35]">
              <FiShield size={25} />
            </div>

            <h1 className="mt-5 text-2xl font-extrabold tracking-tight !text-black">
              Payment Confirmation
            </h1>

            <p className="mt-3 text-sm leading-6 !text-black">
              {error ||
                "This payment confirmation could not be found."}
            </p>

            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={() =>
                  router.push("/dashboard")
                }
                className="flex-1 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-extrabold text-white shadow-sm transition hover:bg-[#C9213A]"
              >
                Dashboard
              </button>

              {withdrawalId && (
                <button
                  type="button"
                  onClick={() =>
                    router.push(
                      `/withdraw/verification-fee/${encodeURIComponent(
                        withdrawalId,
                      )}`,
                    )
                  }
                  className="flex-1 rounded-xl border border-[#D1D5DB] bg-white px-5 py-3.5 text-sm font-extrabold !text-black shadow-sm transition hover:border-[#B51F35] hover:bg-[#F8F9FB]"
                >
                  Back to Payment
                </button>
              )}
            </div>
          </div>
        </div>
      </main>
    );
  }

  const submittedAmount = Number(
    payment.amount || 0,
  );

  const outstandingFee = withdrawal
    ? Number(withdrawal.verification_fee || 0)
    : submittedAmount;

  return (
    <main className="min-h-screen bg-white px-4 py-8 text-black sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6">
          <button
            type="button"
            onClick={() =>
              router.push(
                `/withdraw/verification-fee/${encodeURIComponent(
                  withdrawalId,
                )}`,
              )
            }
            className="inline-flex items-center gap-2 text-sm font-bold !text-black transition hover:text-[#B51F35]"
          >
            <FiArrowLeft size={17} />
            Back to Payment
          </button>
        </div>

        <section className="overflow-hidden rounded-[28px] border border-[#E5E7EB] bg-white shadow-[0_24px_70px_rgba(15,23,42,0.08)]">
          <div className="border-b border-[#E5E7EB] bg-white px-6 py-7 sm:px-8 sm:py-8">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
              <div className="flex min-w-0 items-start gap-4">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-[#E8AAB6] bg-[#F7DDE2] text-[#B51F35] shadow-sm">
                  <FiCheckCircle size={26} />
                </div>

                <div className="min-w-0">
                  <div className="inline-flex items-center rounded-full border border-[#E8AAB6] bg-[#F7DDE2] px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B51F35]">
                    Payment Confirmation
                  </div>

                  <h1 className="mt-3 text-3xl font-extrabold leading-tight tracking-[-0.025em] !text-black">
                    Payment Ready
                  </h1>

                  <p className="mt-3 max-w-2xl text-sm font-medium leading-6 !text-black sm:text-[15px]">
                    Your {payment.payment_method} payment of{" "}
                    {money(submittedAmount)} is ready to be
                    submitted for review. Your payment receipt and
                    reference will be reviewed before the fee is
                    marked as paid.
                  </p>
                </div>
              </div>

              <div className="inline-flex shrink-0 items-center gap-2 self-start rounded-full border border-amber-300 bg-amber-100 px-3 py-2 text-xs font-extrabold text-amber-900">
                <FiClock size={15} />
                Pending Review
              </div>
            </div>
          </div>

          <div className="px-6 py-7 sm:px-8 sm:py-8">
            <div className="rounded-2xl border border-[#E8AAB6] bg-[#FDF0F2] p-6">
              <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs font-extrabold uppercase tracking-[0.14em] text-[#B51F35]">
                    Outstanding Fee
                  </p>

                  <p className="mt-2 text-4xl font-extrabold tracking-tight !text-black">
                    {money(
                      Math.max(
                        0,
                        outstandingFee -
                          submittedAmount,
                      ),
                    )}
                  </p>
                </div>

                <div className="flex items-center gap-3 rounded-xl border border-white/80 bg-white px-4 py-3 shadow-sm">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F7DDE2] text-[#B51F35]">
                    <FiCreditCard size={19} />
                  </div>

                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.08em] text-[#6B7280]">
                      Payment method
                    </p>

                    <p className="mt-1 text-sm font-extrabold !text-black">
                      {payment.payment_method}
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <div className="rounded-xl border border-[#E5E7EB] bg-white px-4 py-3">
                  <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-[#6B7280]">
                    Payment Submitted
                  </p>

                  <p className="mt-1 text-lg font-extrabold !text-black">
                    {money(submittedAmount)}
                  </p>
                </div>

                <div className="rounded-xl border border-[#E5E7EB] bg-white px-4 py-3">
                  <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-[#6B7280]">
                    Payment Status
                  </p>

                  <p className="mt-1 text-lg font-extrabold text-amber-700">
                    Pending Review
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 rounded-2xl border border-[#E5E7EB] bg-[#F8F9FB] p-6">
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#F7DDE2] text-[#B51F35]">
                  <FiFileText size={20} />
                </div>

                <div>
                  <h2 className="text-2xl font-extrabold tracking-tight !text-black">
                    Payment Review
                  </h2>

                  <p className="mt-2 text-sm font-medium leading-6 !text-black">
                    Your payment details are ready for review. Please
                    make sure the payment has been completed using the
                    selected payment method and that your receipt and
                    reference are available when requested.
                  </p>
                </div>
              </div>

              <div className="mt-6 divide-y divide-[#E5E7EB] overflow-hidden rounded-2xl border border-[#E5E7EB] bg-white">
                <div className="flex items-center justify-between gap-4 px-5 py-4">
                  <span className="text-sm font-medium text-[#4B5563]">
                    Payment Method
                  </span>

                  <span className="text-sm font-extrabold !text-black">
                    {payment.payment_method}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-4 px-5 py-4">
                  <span className="text-sm font-medium text-[#4B5563]">
                    Amount Submitted
                  </span>

                  <span className="text-sm font-extrabold !text-black">
                    {money(submittedAmount)}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-4 px-5 py-4">
                  <span className="text-sm font-medium text-[#4B5563]">
                    Verification Fee
                  </span>

                  <span className="text-sm font-extrabold !text-black">
                    {money(outstandingFee)}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-4 px-5 py-4">
                  <span className="text-sm font-medium text-[#4B5563]">
                    Receipt
                  </span>

                  <span className="inline-flex items-center gap-2 text-sm font-extrabold text-emerald-700">
                    <FiCheckCircle size={16} />
                    Submitted
                  </span>
                </div>

                <div className="flex items-center justify-between gap-4 px-5 py-4">
                  <span className="text-sm font-medium text-[#4B5563]">
                    Status
                  </span>

                  <span className="inline-flex items-center gap-2 text-sm font-extrabold text-amber-700">
                    <FiClock size={16} />
                    Pending Review
                  </span>
                </div>
              </div>

              {payment.note && (
                <div className="mt-5 rounded-xl border border-[#E5E7EB] bg-white px-4 py-4">
                  <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-[#6B7280]">
                    Receipt
                  </p>

                  <p className="mt-2 break-words text-sm font-medium leading-6 !text-black">
                    {payment.note.replace(
                      /^Payment receipt:\s*/i,
                      "",
                    )}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-6 rounded-2xl border border-[#E5E7EB] bg-white p-5 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#F7DDE2] text-[#B51F35]">
                  <FiClock size={19} />
                </div>

                <div>
                  <p className="text-sm font-extrabold !text-black">
                    Your submitted payment will remain pending until it has been confirmed.
                  </p>

                  <p className="mt-1 text-sm leading-6 text-[#4B5563]">
                    The verification fee will only be treated as paid after the submitted payment has been confirmed and approved.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={() =>
                  router.push("/dashboard")
                }
                className="flex-1 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-extrabold text-white shadow-sm transition hover:bg-[#C9213A]"
              >
                Dashboard
              </button>

              <button
                type="button"
                onClick={() =>
                  router.push(
                    `/withdraw/verification-fee/${encodeURIComponent(
                      withdrawalId,
                    )}`,
                  )
                }
                className="flex-1 rounded-xl border border-[#D1D5DB] bg-white px-5 py-3.5 text-sm font-extrabold !text-black shadow-sm transition hover:border-[#B51F35] hover:bg-[#F8F9FB]"
              >
                Back to Payment
              </button>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

export default function VerificationFeeConfirmationPage() {
  return (
    <Suspense
      fallback={
        <main className="min-h-screen bg-[#F8F9FB] px-4 py-10">
          <div className="mx-auto max-w-3xl">
            <div className="rounded-2xl border border-[#E5E7EB] bg-white p-8 text-center shadow-sm">
              <p className="text-sm font-semibold text-[#4B5563]">
                Loading payment confirmation...
              </p>
            </div>
          </div>
        </main>
      }
    >
      <VerificationFeeConfirmationContent />
    </Suspense>
  );
}