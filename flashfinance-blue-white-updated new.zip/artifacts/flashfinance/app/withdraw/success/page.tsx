"use client";

export const dynamic = "force-dynamic";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import {
  FiArrowLeft,
  FiCheck,
  FiCheckCircle,
  FiClock,
  FiCopy,
  FiDollarSign,
  FiInfo,
  FiShield,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type Withdrawal = {
  id: string;
  user_id: string;
  amount: number;
  withdrawal_method: string;
  destination: string;
  note: string | null;
  status: string;
  verification_fee: number;
  processing_type: string | null;
  processing_text: string | null;
  account_holder_name: string | null;
  receipt_created_at: string | null;
  created_at: string | null;
};

type Profile = {
  first_name: string | null;
  last_name: string | null;
};

function formatMoney(value: number | string | null | undefined) {
  const amount = Number(value ?? 0);

  return amount.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function formatDate(value: string | null | undefined) {
  if (!value) return "Not available";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "Not available";
  }

  return date.toLocaleString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

/*
 * Masks the ACTUAL destination entered by the user.
 *
 * Zelle:
 * Jojoblack@gmail.com
 * -> Joj**••••**ck@gmail.com
 *
 * Cash App:
 * $Jojojopk
 * -> $Jojo****••••pk
 *
 * Other destinations are masked using the actual
 * beginning and ending of the value entered.
 */
function maskDestination(
  destination: string | null | undefined,
  withdrawalMethod: string | null | undefined
) {
  if (!destination) {
    return "Not provided";
  }

  const value = String(destination).trim();

  if (!value) {
    return "Not provided";
  }

  const method = String(withdrawalMethod ?? "")
    .toLowerCase()
    .replace(/[\s_-]+/g, "");

  /*
   * EMAIL DESTINATIONS
   *
   * This also handles Zelle input such as:
   *
   * Jojoblack      Jojoblack@gmail.com
   *
   * The actual email address is extracted and displayed
   * in masked form.
   */
  const emailMatch = value.match(
    /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i
  );

  if (emailMatch) {
    const email = emailMatch[0];
    const atIndex = email.lastIndexOf("@");

    if (atIndex > 0) {
      const username = email.slice(0, atIndex);
      const domain = email.slice(atIndex);

      if (username.length <= 4) {
        return `${username.slice(
          0,
          Math.min(2, username.length)
        )}••••${domain}`;
      }

      const firstPart = username.slice(0, 3);
      const lastPart = username.slice(-2);

      return `${firstPart}**••••**${lastPart}${domain}`;
    }
  }

  /*
   * CASH APP
   */
  if (
    method.includes("cashapp") ||
    value.startsWith("$")
  ) {
    const prefix = value.startsWith("$") ? "$" : "";
    const username = prefix
      ? value.slice(1)
      : value;

    if (username.length <= 5) {
      return `${prefix}${username}`;
    }

    if (username.length <= 7) {
      return `${prefix}${username.slice(
        0,
        3
      )}••••${username.slice(-2)}`;
    }

    return `${prefix}${username.slice(
      0,
      4
    )}****••••${username.slice(-2)}`;
  }

  /*
   * PHONE NUMBERS
   */
  const digitsOnly = value.replace(/\D/g, "");

  if (
    digitsOnly.length >= 10 &&
    digitsOnly.length ===
      value.replace(/[\s()+.-]/g, "").length
  ) {
    const prefixLength = Math.min(
      4,
      Math.max(
        2,
        Math.floor(digitsOnly.length / 3)
      )
    );

    const suffixLength = 2;

    return `${value.slice(
      0,
      prefixLength
    )}••••${value.slice(-suffixLength)}`;
  }

  /*
   * GENERAL DESTINATION
   */
  if (value.length <= 8) {
    return value;
  }

  if (value.length <= 12) {
    return `${value.slice(
      0,
      3
    )}••••${value.slice(-2)}`;
  }

  return `${value.slice(
    0,
    4
  )}••••••••${value.slice(-4)}`;
}

function statusLabel(status: string | null | undefined) {
  const normalized = String(status ?? "").toLowerCase();

  if (
    normalized === "approved" ||
    normalized === "completed" ||
    normalized === "success" ||
    normalized === "successful"
  ) {
    return "Completed";
  }

  if (
    normalized === "rejected" ||
    normalized === "failed" ||
    normalized === "cancelled"
  ) {
    return "Rejected";
  }

  return "Processing";
}

function statusIsRejected(
  status: string | null | undefined
) {
  const normalized = String(status ?? "").toLowerCase();

  return (
    normalized === "rejected" ||
    normalized === "failed" ||
    normalized === "cancelled"
  );
}

function cleanName(value: unknown) {
  return String(value ?? "")
    .replace(/\s+/g, " ")
    .trim();
}

function getNameFromMetadata(
  metadata: Record<string, unknown> | null
) {
  if (!metadata) {
    return {
      firstName: "",
      lastName: "",
      fullName: "",
    };
  }

  const firstName = cleanName(
    metadata.first_name ??
      metadata.firstName ??
      ""
  );

  const lastName = cleanName(
    metadata.last_name ??
      metadata.lastName ??
      ""
  );

  const fullName = cleanName(
    metadata.full_name ??
      metadata.fullName ??
      metadata.name ??
      ""
  );

  return {
    firstName,
    lastName,
    fullName,
  };
}

function buildAccountHolderName(
  profile: Profile | null,
  metadata: Record<string, unknown> | null,
  storedName: string | null | undefined
) {
  const profileFirstName = cleanName(
    profile?.first_name
  );

  const profileLastName = cleanName(
    profile?.last_name
  );

  const metadataName =
    getNameFromMetadata(metadata);

  if (profileFirstName && profileLastName) {
    return `${profileFirstName} ${profileLastName}`.trim();
  }

  const firstName =
    profileFirstName ||
    metadataName.firstName;

  const lastName =
    profileLastName ||
    metadataName.lastName;

  if (firstName && lastName) {
    return `${firstName} ${lastName}`.trim();
  }

  if (metadataName.fullName) {
    return metadataName.fullName;
  }

  const savedName = cleanName(storedName);

  if (
    savedName &&
    savedName.includes(" ")
  ) {
    return savedName;
  }

  return (
    firstName ||
    savedName ||
    "Account Holder"
  );
}

function WithdrawalSuccessContent() {
  const router = useRouter();
  const params = useParams();
  const searchParams = useSearchParams();

  const supabase = useMemo(
    () => createClient(),
    []
  );

  const withdrawalId = useMemo(() => {
    const queryId = searchParams.get("id");

    if (queryId) {
      return queryId;
    }

    const paramId =
      params?.["withdrawal-id"];

    if (Array.isArray(paramId)) {
      return paramId[0] ?? "";
    }

    return typeof paramId === "string"
      ? paramId
      : "";
  }, [params, searchParams]);

  const [withdrawal, setWithdrawal] =
    useState<Withdrawal | null>(null);

  const [profile, setProfile] =
    useState<Profile | null>(null);

  const [userMetadata, setUserMetadata] =
    useState<Record<string, unknown> | null>(
      null
    );

  const [loading, setLoading] =
    useState(true);

  const [error, setError] = useState("");

  const loadWithdrawal = async () => {
    if (!withdrawalId) {
      setError(
        "Withdrawal reference is missing."
      );
      setLoading(false);
      return;
    }

    try {
      setError("");

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) {
        throw userError;
      }

      if (!user) {
        router.replace("/login");
        return;
      }

      const metadata =
        (user.user_metadata ?? {}) as Record<
          string,
          unknown
        >;

      setUserMetadata(metadata);

      const {
        data,
        error: withdrawalError,
      } = await supabase
        .from("withdrawal_requests")
        .select(
          [
            "id",
            "user_id",
            "amount",
            "withdrawal_method",
            "destination",
            "note",
            "status",
            "verification_fee",
            "processing_type",
            "processing_text",
            "account_holder_name",
            "receipt_created_at",
            "created_at",
          ].join(",")
        )
        .eq("id", withdrawalId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (withdrawalError) {
        throw withdrawalError;
      }

      if (!data) {
        setWithdrawal(null);
        setError(
          "This withdrawal receipt could not be found."
        );
        return;
      }

      setWithdrawal(
        data as unknown as Withdrawal
      );

      const {
        data: profileData,
        error: profileError,
      } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("id", user.id)
        .maybeSingle();

      if (profileError) {
        console.error(
          "Profile name load error:",
          profileError
        );
      }

      const metadataName =
        getNameFromMetadata(metadata);

      const profileFirstName = cleanName(
        profileData?.full_name
      );

      const profileLastName = cleanName(
        ""
      );

      setProfile({
        first_name:
          profileFirstName ||
          metadataName.firstName ||
          null,

        last_name:
          profileLastName ||
          metadataName.lastName ||
          null,
      });
    } catch (err) {
      console.error(
        "Withdrawal receipt load error:",
        err
      );

      setError(
        err instanceof Error
          ? err.message
          : "Unable to load the withdrawal receipt."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadWithdrawal();
  }, [withdrawalId]);

  useEffect(() => {
    if (!withdrawalId) return;

    const channel = supabase
      .channel(
        `withdrawal-receipt-${withdrawalId}`
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "withdrawal_requests",
          filter: `id=eq.${withdrawalId}`,
        },
        () => {
          void loadWithdrawal();
        }
      )
      .subscribe();

    const interval =
      window.setInterval(() => {
        void loadWithdrawal();
      }, 15000);

    return () => {
      window.clearInterval(interval);
      void supabase.removeChannel(
        channel
      );
    };
  }, [withdrawalId]);

  const handleCopyReference = async () => {
    if (!withdrawal?.id) return;

    try {
      await navigator.clipboard.writeText(
        withdrawal.id
      );
    } catch {
      // Clipboard access can be unavailable.
    }
  };

  if (loading) {
    return (
      <main className="ff-product-page ff-withdraw-receipt min-h-screen bg-[#E7ECF2] px-4 py-10 text-[#20252D]">
        <div className="mx-auto max-w-4xl">
          <div className="overflow-hidden rounded-[30px] border border-[#DDE3EA] bg-white shadow-[0_20px_60px_rgba(31,41,55,0.08)]">

            <div className="border-b border-[#E8ECF0] px-6 py-10 text-center sm:px-10">

              <div className="mx-auto h-20 w-20 animate-pulse rounded-full bg-[#E2E7EC]" />

              <div className="mx-auto mt-6 h-4 w-28 animate-pulse rounded-full bg-[#E7EBEF]" />

              <div className="mx-auto mt-4 h-10 w-64 animate-pulse rounded bg-[#E7EBEF]" />

              <div className="mx-auto mt-3 h-4 w-80 max-w-full animate-pulse rounded bg-[#EEF1F4]" />

            </div>

            <div className="p-6 sm:p-10">

              <div className="h-36 animate-pulse rounded-[24px] bg-[#F1F3F5]" />

              <div className="mt-6 h-72 animate-pulse rounded-[24px] bg-[#F1F3F5]" />

            </div>

          </div>
        </div>
      </main>
    );
  }

  if (!withdrawal) {
    return (
      <main className="ff-product-page ff-withdraw-receipt min-h-screen bg-[#E7ECF2] px-4 py-10 text-[#20252D]">
        <div className="mx-auto max-w-2xl">

          <div className="rounded-[30px] border border-[#DDE3EA] bg-white p-8 text-center shadow-[0_20px_60px_rgba(31,41,55,0.08)]">

            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#FDEDEF] text-[#B51F35]">
              <FiInfo size={28} />
            </div>

            <h1 className="mt-5 text-2xl font-bold text-[#20252D]">
              Withdrawal Receipt
            </h1>

            <p className="mt-3 text-sm leading-6 text-[#66707D]">
              {error ||
                "This withdrawal receipt could not be loaded."}
            </p>

            <button
              type="button"
              onClick={() =>
                router.push("/withdraw")
              }
              className="mt-7 rounded-xl bg-[#B51F35] px-6 py-3 text-sm font-bold text-white transition hover:bg-[#C9213A]"
            >
              Return to Withdraw
            </button>

          </div>

        </div>
      </main>
    );
  }

  const fee = Number(
    withdrawal.verification_fee ?? 0
  );

  const status = statusLabel(
    withdrawal.status
  );

  const rejected = statusIsRejected(
    withdrawal.status
  );

  const accountHolder =
    buildAccountHolderName(
      profile,
      userMetadata,
      withdrawal.account_holder_name
    );

  const maskedDestination =
    maskDestination(
      withdrawal.destination,
      withdrawal.withdrawal_method
    );

  return (
    <main className="ff-product-page ff-withdraw-receipt min-h-screen bg-[#E7ECF2] text-[#20252D]">

      <div className="mx-auto w-full max-w-5xl px-4 py-7 sm:px-6 lg:px-8">

        <button
          type="button"
          onClick={() =>
            router.push("/withdraw")
          }
          className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-[#596270] transition hover:text-[#B51F35]"
        >
          <FiArrowLeft size={17} />
          Back to Withdraw
        </button>

        <section className="overflow-hidden rounded-[30px] border border-[#D9E0E7] bg-white shadow-[0_22px_65px_rgba(31,41,55,0.09)]">

          {/* =========================================================
              SUBMITTED HEADER
              ========================================================= */}

          <div className="relative border-b border-[#E5E9ED] bg-white px-6 py-10 text-center sm:px-10 sm:py-12">

            <div className="absolute left-0 right-0 top-0 h-1 bg-[#219653]" />

            <div className="mx-auto flex max-w-2xl flex-col items-center">

              <div className="flex h-[82px] w-[82px] items-center justify-center rounded-full border-[5px] border-[#C7E8D2] bg-[#EAF8EF] text-[#219653] shadow-[0_8px_28px_rgba(33,150,83,0.12)]">

                {rejected ? (
                  <FiInfo
                    size={38}
                    strokeWidth={2}
                  />
                ) : (
                  <FiCheckCircle
                    size={45}
                    strokeWidth={2.1}
                  />
                )}

              </div>

              <div
                className={`mt-6 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold ${
                  rejected
                    ? "border border-[#F3C7CE] bg-[#FFF2F4] text-[#B51F35]"
                    : "border border-[#CFE0F7] bg-[#F1F7FF] text-[#245B91]"
                }`}
              >
                <FiClock size={16} />
                {status}
              </div>

              <h1 className="mt-5 text-3xl font-bold tracking-tight text-[#18202A] sm:text-[38px]">
                {rejected
                  ? "Withdrawal update"
                  : "Withdrawal submitted"}
              </h1>

              <p className="mt-3 max-w-xl text-sm leading-6 text-[#68717D] sm:text-base">
                {rejected
                  ? "Your withdrawal request has been updated. Please review the information below."
                  : "Your withdrawal request has been submitted and is now being processed."}
              </p>

            </div>

          </div>

          {/* =========================================================
              RECEIPT BODY
              ========================================================= */}

          <div className="bg-[#F4F6F8] p-4 sm:p-7">

            {/* =======================================================
                WITHDRAWAL AMOUNT
                ======================================================= */}

            <div className="overflow-hidden rounded-[24px] border border-[#DCE2E8] bg-white shadow-[0_8px_25px_rgba(31,41,55,0.045)]">

              <div className="border-b border-[#E8ECF0] px-6 py-4 text-center sm:px-7">

                <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#89929D]">
                  Withdrawal Amount
                </p>

              </div>

              <div className="flex flex-col items-center justify-center px-6 py-9 text-center sm:px-7 sm:py-10">

                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#FDEDEF] text-[#B51F35]">
                  <FiDollarSign size={27} />
                </div>

                <p className="mt-4 text-xs font-medium text-[#89929D]">
                  Amount requested
                </p>

                <p className="mt-1 text-[36px] font-bold tracking-tight text-[#171B21] sm:text-[44px]">
                  {formatMoney(
                    withdrawal.amount
                  )}
                </p>

                <div className="mt-4 flex h-9 w-9 items-center justify-center rounded-full bg-[#EAF8EF] text-[#219653]">
                  <FiCheck
                    size={18}
                    strokeWidth={3}
                  />
                </div>

              </div>

            </div>

            {/* =======================================================
                WITHDRAWAL INFORMATION
                ======================================================= */}

            <div className="mt-5 overflow-hidden rounded-[24px] border border-[#DCE2E8] bg-white shadow-[0_8px_25px_rgba(31,41,55,0.045)]">

              <div className="flex items-center gap-3 border-b border-[#E8ECF0] px-6 py-5 sm:px-7">

                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FDEDEF] text-[#B51F35]">
                  <FiShield size={18} />
                </div>

                <div>

                  <h2 className="text-lg font-bold text-[#20252D]">
                    Withdrawal Information
                  </h2>

                  <p className="mt-0.5 text-xs text-[#89929D]">
                    Details associated with this withdrawal
                  </p>

                </div>

              </div>

              <div className="px-6 sm:px-7">

                {/* ACCOUNT HOLDER */}

                <div className="flex items-start justify-between gap-6 border-b border-[#ECEFF2] py-5">

                  <p className="text-sm text-[#68717D]">
                    Account Holder
                  </p>

                  <p className="max-w-[65%] text-right text-sm font-bold text-[#252B33] sm:text-base">
                    {accountHolder}
                  </p>

                </div>

                {/* PAYMENT METHOD */}

                <div className="flex items-start justify-between gap-6 border-b border-[#ECEFF2] py-5">

                  <p className="text-sm text-[#68717D]">
                    Payment Method
                  </p>

                  <p className="max-w-[65%] text-right text-sm font-bold capitalize text-[#252B33] sm:text-base">
                    {withdrawal.withdrawal_method}
                  </p>

                </div>

                {/* DESTINATION */}

                <div className="flex items-start justify-between gap-6 border-b border-[#ECEFF2] py-5">

                  <p className="text-sm text-[#68717D]">
                    Destination
                  </p>

                  <p className="max-w-[70%] break-all text-right text-sm font-bold text-[#252B33] sm:text-base">
                    {maskedDestination}
                  </p>

                </div>

                {/* VERIFICATION FEE */}

                <div className="flex items-start justify-between gap-6 border-b border-[#ECEFF2] py-5">

                  <p className="text-sm text-[#68717D]">
                    Verification Fee
                  </p>

                  <p className="text-right text-sm font-bold text-[#B51F35] sm:text-base">
                    {fee > 0
                      ? formatMoney(fee)
                      : "No fee"}
                  </p>

                </div>

                {/* ARRIVAL */}

                <div className="flex items-start justify-between gap-6 py-5">

                  <p className="text-sm text-[#68717D]">
                    Arrival
                  </p>

                  <p className="max-w-[65%] text-right text-sm font-bold text-[#252B33] sm:text-base">
                    {withdrawal.processing_text ||
                      "Processing"}
                  </p>

                </div>

              </div>

            </div>

            {/* =======================================================
                REFERENCE / SUBMITTED
                ======================================================= */}

            <div className="mt-5 overflow-hidden rounded-[24px] border border-[#DCE2E8] bg-white shadow-[0_8px_25px_rgba(31,41,55,0.045)]">

              <div className="grid sm:grid-cols-2">

                <div className="border-b border-[#E8ECF0] px-6 py-6 sm:border-b-0 sm:border-r sm:px-7">

                  <p className="text-xs font-bold uppercase tracking-[0.15em] text-[#89929D]">
                    Reference
                  </p>

                  <div className="mt-3 flex items-start gap-3">

                    <p className="min-w-0 break-all text-sm font-bold leading-6 text-[#252B33]">
                      {withdrawal.id}
                    </p>

                    <button
                      type="button"
                      onClick={() =>
                        void handleCopyReference()
                      }
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#DDE2E8] bg-[#F5F7F9] text-[#68717D] transition hover:border-[#F0C8CE] hover:bg-[#FFF5F6] hover:text-[#B51F35]"
                      title="Copy reference"
                    >
                      <FiCopy size={16} />
                    </button>

                  </div>

                </div>

                <div className="px-6 py-6 sm:px-7">

                  <p className="text-xs font-bold uppercase tracking-[0.15em] text-[#89929D]">
                    Submitted
                  </p>

                  <p className="mt-3 text-sm font-bold leading-6 text-[#505965]">
                    {formatDate(
                      withdrawal.receipt_created_at ||
                        withdrawal.created_at
                    )}
                  </p>

                </div>

              </div>

            </div>

          </div>

          {/* =========================================================
              BOTTOM ACTIONS
              ALL THREE RED
              ========================================================= */}

          <div className="border-t border-[#DCE2E8] bg-white px-5 py-6 sm:px-7">

            <div className="grid gap-3 sm:grid-cols-3">

              <button
                type="button"
                onClick={() =>
                  router.push(
                    `/withdraw/verification-fee/${encodeURIComponent(
                      withdrawal.id
                    )}`
                  )
                }
                disabled={fee <= 0}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-bold text-white shadow-[0_7px_20px_rgba(181,31,53,0.18)] transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:bg-[#B51F35] disabled:opacity-50"
              >
                <FiDollarSign size={18} />
                Make Payment
              </button>

              <button
                type="button"
                onClick={() =>
                  router.push("/withdraw")
                }
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-bold text-white shadow-[0_7px_20px_rgba(181,31,53,0.18)] transition hover:bg-[#C9213A]"
              >
                <FiArrowLeft size={18} />
                Return to Withdraw
              </button>

              <button
                type="button"
                onClick={() =>
                  router.push("/dashboard")
                }
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-5 py-3.5 text-sm font-bold text-white shadow-[0_7px_20px_rgba(181,31,53,0.18)] transition hover:bg-[#C9213A]"
              >
                Dashboard
              </button>

            </div>

          </div>

        </section>

      </div>
    </main>
  );
}

function WithdrawalSuccessLoading() {
  return (
    <main className="ff-product-page ff-withdraw-receipt min-h-screen bg-[#E7ECF2] px-4 py-10 text-[#20252D]">

      <div className="mx-auto max-w-4xl">

        <div className="overflow-hidden rounded-[30px] border border-[#DDE3EA] bg-white shadow-[0_20px_60px_rgba(31,41,55,0.08)]">

          <div className="border-b border-[#E8ECF0] px-6 py-10 text-center sm:px-10">

            <div className="mx-auto h-20 w-20 animate-pulse rounded-full bg-[#E2E7EC]" />

            <div className="mx-auto mt-6 h-4 w-28 animate-pulse rounded-full bg-[#E7EBEF]" />

            <div className="mx-auto mt-4 h-10 w-64 animate-pulse rounded bg-[#E7EBEF]" />

            <div className="mx-auto mt-3 h-4 w-80 max-w-full animate-pulse rounded bg-[#EEF1F4]" />

          </div>

          <div className="bg-[#F4F6F8] p-6 sm:p-8">

            <div className="h-40 animate-pulse rounded-[24px] bg-white" />

            <div className="mt-5 h-72 animate-pulse rounded-[24px] bg-white" />

            <div className="mt-5 h-44 animate-pulse rounded-[24px] bg-white" />

          </div>

        </div>

      </div>

    </main>
  );
}

export default function WithdrawalSuccessPage() {
  return (
    <Suspense
      fallback={
        <WithdrawalSuccessLoading />
      }
    >
      <WithdrawalSuccessContent />
    </Suspense>
  );
}