"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FiArrowLeft,
  FiArrowUpRight,
  FiCheck,
  FiCheckCircle,
  FiClock,
  FiDollarSign,
  FiHome,
  FiLoader,
  FiSend,
  FiShield,
  FiUser,
  FiXCircle,
} from "react-icons/fi";
import { FaPaypal, FaBitcoin } from "react-icons/fa";
import {
  SiCashapp,
  SiZelle,
  SiVenmo,
} from "react-icons/si";
import { createClient } from "@/lib/supabase";
import PlaidBankConnect from "../../components/PlaidBankConnect";

type Account = {
  balance: number | null;
  currency: string | null;
};

type Withdrawal = {
  id: string;
  amount: number;
  withdrawal_method: string;
  destination: string;
  note: string | null;
  status: string;
  rejection_note: string | null;
  created_at: string;
  reviewed_at: string | null;
};

type WithdrawalMethod = {
  id: string;
  name: string;
  description: string;
  requirements: string[];
};

type PlaidAccount = {
  id: string;
  name: string;
  official_name?: string | null;
  type: string;
  subtype?: string | null;
  mask?: string | null;
};

const withdrawalMethods: WithdrawalMethod[] = [
  {
    id: "Bank Transfer",
    name: "Bank Transfer",
    description:
      "Connect and verify your bank account with Plaid",
    requirements: [
      "Bank account",
      "Account verification",
      "Plaid connection",
    ],
  },
  {
    id: "PayPal",
    name: "PayPal",
    description:
      "Withdraw using your PayPal account",
    requirements: [
      "Account holder name",
      "PayPal email",
    ],
  },
  {
    id: "Cash App",
    name: "Cash App",
    description:
      "Withdraw using your Cash App account",
    requirements: [
      "Cash App $Cashtag",
    ],
  },
  {
    id: "Bitcoin",
    name: "Bitcoin",
    description:
      "Withdraw to a cryptocurrency wallet",
    requirements: [
      "Wallet address",
      "Cryptocurrency",
      "Network",
    ],
  },
  {
    id: "Zelle",
    name: "Zelle",
    description:
      "Withdraw using your Zelle information",
    requirements: [
      "Full name",
      "Email address",
    ],
  },
  {
    id: "Venmo",
    name: "Venmo",
    description:
      "Withdraw using your Venmo account",
    requirements: [
      "Venmo username",
    ],
  },
  {
    id: "Chime",
    name: "Chime",
    description:
      "Withdraw using your Chime account",
    requirements: [
      "Account holder name",
      "Email or phone number",
    ],
  },
];

const cryptoOptions = [
  "Bitcoin (BTC)",
  "Ethereum (ETH)",
  "Tether (USDT)",
  "USD Coin (USDC)",
  "BNB (BNB)",
  "Solana (SOL)",
  "XRP (XRP)",
  "Dogecoin (DOGE)",
  "Cardano (ADA)",
  "Polygon (POL)",
  "Litecoin (LTC)",
  "TRON (TRX)",
];

function formatMoney(
  amount: number,
  currency = "USD",
) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

function formatDate(dateString: string) {
  return new Date(
    dateString,
  ).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatStatus(status: string) {
  return status
    .replace(/_/g, " ")
    .replace(
      /\b\w/g,
      (letter) =>
        letter.toUpperCase(),
    );
}

function MethodLogo({
  method,
}: {
  method: string;
}) {
  if (method === "PayPal") {
    return (
      <FaPaypal
        size={25}
        className="text-[#0070ba]"
      />
    );
  }

  if (method === "Cash App") {
    return (
      <SiCashapp
        size={26}
        className="text-[#00a63e]"
      />
    );
  }

  if (method === "Bitcoin") {
    return (
      <FaBitcoin
        size={26}
        className="text-[#b45309]"
      />
    );
  }

  if (method === "Zelle") {
    return (
      <SiZelle
        size={26}
        className="text-[#6d28d9]"
      />
    );
  }

  if (method === "Venmo") {
    return (
      <SiVenmo
        size={27}
        className="text-[#3d95ce]"
      />
    );
  }

  if (method === "Chime") {
    return (
      <div className="text-xl font-black text-[#00A86B]">
        C
      </div>
    );
  }

  return (
    <FiHome
      size={25}
      className="text-[#B51F35]"
    />
  );
}

export default function WithdrawPage() {
  const router = useRouter();
  const supabase = createClient();

  const [userId, setUserId] = useState("");

  const [account, setAccount] =
    useState<Account | null>(null);

  const [withdrawals, setWithdrawals] =
    useState<Withdrawal[]>([]);

  const [
    selectedMethod,
    setSelectedMethod,
  ] = useState<string | null>(null);

  const [
    plaidAccounts,
    setPlaidAccounts,
  ] = useState<PlaidAccount[]>([]);

  const [
    selectedPlaidAccount,
    setSelectedPlaidAccount,
  ] =
    useState<PlaidAccount | null>(null);

  const [paypalName, setPaypalName] =
    useState("");

  const [paypalEmail, setPaypalEmail] =
    useState("");

  const [cashAppTag, setCashAppTag] =
    useState("");

  const [bitcoinAddress, setBitcoinAddress] =
    useState("");

  const [bitcoinCrypto, setBitcoinCrypto] =
    useState("Bitcoin (BTC)");

  const [zelleName, setZelleName] =
    useState("");

  const [zelleEmail, setZelleEmail] =
    useState("");

  const [venmoUsername, setVenmoUsername] =
    useState("");

  const [chimeName, setChimeName] =
    useState("");

  const [chimeContact, setChimeContact] =
    useState("");

  const [amount, setAmount] =
    useState("");

  const [note, setNote] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [submitting, setSubmitting] =
    useState(false);

  const [error, setError] =
    useState("");

  const [success, setSuccess] =
    useState("");

  const balance =
    Number(account?.balance || 0);

  const currency =
    account?.currency || "USD";

  const numericAmount =
    Number(amount || 0);

  const isBankTransfer =
    selectedMethod === "Bank Transfer";

  const bankConnected =
    isBankTransfer &&
    plaidAccounts.length > 0;

  function isDestinationComplete() {
    if (!selectedMethod) {
      return false;
    }

    if (selectedMethod === "Bank Transfer") {
      return selectedPlaidAccount !== null;
    }

    if (selectedMethod === "PayPal") {
      return (
        paypalName.trim().length > 0 &&
        paypalEmail.trim().length > 0
      );
    }

    if (selectedMethod === "Cash App") {
      return cashAppTag.trim().length > 0;
    }

    if (selectedMethod === "Bitcoin") {
      return (
        bitcoinAddress.trim().length > 0 &&
        bitcoinCrypto.trim().length > 0
      );
    }

    if (selectedMethod === "Zelle") {
      return (
        zelleName.trim().length > 0 &&
        zelleEmail.trim().length > 0
      );
    }

    if (selectedMethod === "Venmo") {
      return venmoUsername.trim().length > 0;
    }

    if (selectedMethod === "Chime") {
      return (
        chimeName.trim().length > 0 &&
        chimeContact.trim().length > 0
      );
    }

    return false;
  }

  const canSubmit =
    numericAmount > 0 &&
    numericAmount <= balance &&
    selectedMethod !== null &&
    isDestinationComplete();

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    setError("");

    const {
      data: {
        user,
      },
    } =
      await supabase.auth.getUser();

    if (!user) {
      router.push("/login");
      return;
    }

    setUserId(user.id);

    const [
      {
        data: accountData,
        error: accountError,
      },
      {
        data: withdrawalData,
        error: withdrawalError,
      },
    ] =
      await Promise.all([
        supabase
          .from("accounts")
          .select(
            "balance, currency",
          )
          .eq(
            "user_id",
            user.id,
          )
          .maybeSingle(),

        supabase
          .from(
            "withdrawal_requests",
          )
          .select(
            "id, amount, withdrawal_method, destination, note, status, rejection_note, created_at, reviewed_at",
          )
          .eq(
            "user_id",
            user.id,
          )
          .order(
            "created_at",
            {
              ascending: false,
            },
          ),
      ]);

    if (accountError) {
      setError(
        accountError.message,
      );
    }

    if (withdrawalError) {
      setError(
        withdrawalError.message,
      );
    }

    setAccount(
      accountData ?? null,
    );

    setWithdrawals(
      withdrawalData ?? [],
    );

    setLoading(false);
  }

  function clearPaymentFields() {
    setPaypalName("");
    setPaypalEmail("");
    setCashAppTag("");
    setBitcoinAddress("");
    setBitcoinCrypto("Bitcoin (BTC)");
    setZelleName("");
    setZelleEmail("");
    setVenmoUsername("");
    setChimeName("");
    setChimeContact("");
  }

  function handleMethodSelect(
    methodId: string,
  ) {
    setSelectedMethod(
      methodId,
    );

    setError("");
    setSuccess("");
    setAmount("");
    setNote("");

    clearPaymentFields();

    setSelectedPlaidAccount(null);
    setPlaidAccounts([]);
  }

  function buildDestination() {
    if (
      selectedMethod ===
        "Bank Transfer" &&
      selectedPlaidAccount
    ) {
      return `Plaid verified bank ••••${
        selectedPlaidAccount.mask ||
        "----"
      }`;
    }

    if (
      selectedMethod ===
      "PayPal"
    ) {
      return `Account holder: ${paypalName.trim()} | PayPal email: ${paypalEmail.trim()}`;
    }

    if (
      selectedMethod ===
      "Cash App"
    ) {
      return `Cash App $Cashtag: ${cashAppTag.trim()}`;
    }

    if (
      selectedMethod ===
      "Bitcoin"
    ) {
      return `Cryptocurrency: ${bitcoinCrypto.trim()} | Wallet address: ${bitcoinAddress.trim()}`;
    }

    if (
      selectedMethod ===
      "Zelle"
    ) {
      return `Full name: ${zelleName.trim()} | Email: ${zelleEmail.trim()}`;
    }

    if (
      selectedMethod ===
      "Venmo"
    ) {
      return `Venmo username: ${venmoUsername.trim()}`;
    }

    if (
      selectedMethod ===
      "Chime"
    ) {
      return `Account holder: ${chimeName.trim()} | Email or phone: ${chimeContact.trim()}`;
    }

    return "";
  }

  function validateDestination() {
    if (!selectedMethod) {
      return "Choose a withdrawal method first.";
    }

    if (
      selectedMethod ===
        "Bank Transfer" &&
      !selectedPlaidAccount
    ) {
      return "Connect and select a verified bank account first.";
    }

    if (
      selectedMethod ===
      "PayPal"
    ) {
      if (!paypalName.trim()) {
        return "Enter the PayPal account holder name.";
      }

      if (!paypalEmail.trim()) {
        return "Enter the PayPal email address.";
      }
    }

    if (
      selectedMethod ===
      "Cash App"
    ) {
      if (!cashAppTag.trim()) {
        return "Enter the Cash App $Cashtag.";
      }
    }

    if (
      selectedMethod ===
      "Bitcoin"
    ) {
      if (!bitcoinAddress.trim()) {
        return "Enter the cryptocurrency wallet address.";
      }

      if (!bitcoinCrypto.trim()) {
        return "Select the cryptocurrency.";
      }
    }

    if (
      selectedMethod ===
      "Zelle"
    ) {
      if (!zelleName.trim()) {
        return "Enter the Zelle recipient's full name.";
      }

      if (!zelleEmail.trim()) {
        return "Enter the Zelle email address.";
      }
    }

    if (
      selectedMethod ===
      "Venmo"
    ) {
      if (!venmoUsername.trim()) {
        return "Enter the Venmo username.";
      }
    }

    if (
      selectedMethod ===
      "Chime"
    ) {
      if (!chimeName.trim()) {
        return "Enter the Chime account holder name.";
      }

      if (!chimeContact.trim()) {
        return "Enter the Chime email address or phone number.";
      }
    }

    return "";
  }

  async function handleSubmit(
    event: React.FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    setError("");
    setSuccess("");

    const destinationError =
      validateDestination();

    if (destinationError) {
      setError(
        destinationError,
      );
      return;
    }

    if (
      !numericAmount ||
      numericAmount <= 0
    ) {
      setError(
        "Enter a withdrawal amount greater than zero.",
      );
      return;
    }

    if (
      numericAmount > balance
    ) {
      setError(
        "You do not have enough available balance.",
      );
      return;
    }

    setSubmitting(
      true,
    );

    const {
      data: {
        user,
      },
    } =
      await supabase.auth.getUser();

    if (!user) {
      router.push(
        "/login",
      );
      setSubmitting(false);
      return;
    }

    const destination =
      buildDestination();

    if (!destination) {
      setError(
        "Enter the required payment information.",
      );
      setSubmitting(false);
      return;
    }

    const {
      data,
      error: rpcError,
    } =
      await supabase.rpc(
        "request_withdrawal",
        {
          p_amount:
            numericAmount,
          p_withdrawal_method:
            selectedMethod,
          p_destination:
            destination,
          p_note:
            note.trim() ||
            null,
        },
      );

    if (rpcError) {
      setError(
        rpcError.message,
      );
      setSubmitting(
        false,
      );
      return;
    }

    if (
      !data?.success
    ) {
      setError(
        "Your withdrawal request could not be submitted.",
      );
      setSubmitting(
        false,
      );
      return;
    }

    const withdrawalId =
      data.withdrawal_id;

    const successParams =
      new URLSearchParams({
        amount:
          numericAmount.toFixed(2),
        method:
          selectedMethod || "",
        id:
          withdrawalId
            ? String(withdrawalId)
            : "",
      });

    router.push(
      `/withdraw/success?${successParams.toString()}`,
    );
  }

  function renderPaymentFields(
    method: WithdrawalMethod,
  ) {
    if (
      method.id ===
      "PayPal"
    ) {
      return (
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label
              htmlFor="paypalName"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              Account holder name
            </label>

            <input
              id="paypalName"
              type="text"
              value={paypalName}
              onChange={(
                event,
              ) => {
                setPaypalName(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              placeholder="Enter the full name on the PayPal account"
              autoComplete="name"
              className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
            />
          </div>

          <div>
            <label
              htmlFor="paypalEmail"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              PayPal email
            </label>

            <input
              id="paypalEmail"
              type="email"
              value={paypalEmail}
              onChange={(
                event,
              ) => {
                setPaypalEmail(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              placeholder="name@example.com"
              autoComplete="email"
              className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
            />
          </div>
        </div>
      );
    }

    if (
      method.id ===
      "Cash App"
    ) {
      return (
        <div>
          <label
            htmlFor="cashAppTag"
            className="mb-2 block text-sm font-bold !text-[#252932]"
          >
            Cash App $Cashtag
          </label>

          <input
            id="cashAppTag"
            type="text"
            value={cashAppTag}
            onChange={(
              event,
            ) => {
              setCashAppTag(
                event.target.value,
              );
              setError("");
              setSuccess("");
            }}
            placeholder="$Cashtag"
            autoComplete="off"
            className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
          />

          <p className="mt-2 text-[11px] !text-[#9298A3]">
            Enter the Cash App $Cashtag you want this
            withdrawal sent to.
          </p>
        </div>
      );
    }

    if (
      method.id ===
      "Bitcoin"
    ) {
      return (
        <div className="space-y-5">
          <div>
            <label
              htmlFor="bitcoinCrypto"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              Cryptocurrency
            </label>

            <select
              id="bitcoinCrypto"
              value={bitcoinCrypto}
              onChange={(
                event,
              ) => {
                setBitcoinCrypto(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none focus:border-[#B51F35] focus:bg-white"
            >
              {cryptoOptions.map(
                (
                  crypto,
                ) => (
                  <option
                    key={
                      crypto
                    }
                    value={
                      crypto
                    }
                  >
                    {
                      crypto
                    }
                  </option>
                ),
              )}
            </select>
          </div>

          <div>
            <label
              htmlFor="bitcoinAddress"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              Wallet address
            </label>

            <textarea
              id="bitcoinAddress"
              value={bitcoinAddress}
              onChange={(
                event,
              ) => {
                setBitcoinAddress(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              rows={3}
              placeholder="Enter the cryptocurrency wallet address"
              autoComplete="off"
              className="w-full resize-none rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
            />

            <p className="mt-2 text-[11px] !text-[#9298A3]">
              Make sure the wallet address supports the
              cryptocurrency selected above.
            </p>
          </div>
        </div>
      );
    }

    if (
      method.id ===
      "Zelle"
    ) {
      return (
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label
              htmlFor="zelleName"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              Full name
            </label>

            <input
              id="zelleName"
              type="text"
              value={zelleName}
              onChange={(
                event,
              ) => {
                setZelleName(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              placeholder="Enter the recipient's full name"
              autoComplete="name"
              className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
            />
          </div>

          <div>
            <label
              htmlFor="zelleEmail"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              Email address
            </label>

            <input
              id="zelleEmail"
              type="email"
              value={zelleEmail}
              onChange={(
                event,
              ) => {
                setZelleEmail(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              placeholder="name@example.com"
              autoComplete="email"
              className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
            />
          </div>
        </div>
      );
    }

    if (
      method.id ===
      "Venmo"
    ) {
      return (
        <div>
          <label
            htmlFor="venmoUsername"
            className="mb-2 block text-sm font-bold !text-[#252932]"
          >
            Venmo username
          </label>

          <input
            id="venmoUsername"
            type="text"
            value={venmoUsername}
            onChange={(
              event,
            ) => {
              setVenmoUsername(
                event.target.value,
              );
              setError("");
              setSuccess("");
            }}
            placeholder="@username"
            autoComplete="off"
            className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
          />
        </div>
      );
    }

    if (
      method.id ===
      "Chime"
    ) {
      return (
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label
              htmlFor="chimeName"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              Account holder name
            </label>

            <input
              id="chimeName"
              type="text"
              value={chimeName}
              onChange={(
                event,
              ) => {
                setChimeName(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              placeholder="Enter the full account holder name"
              autoComplete="name"
              className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
            />
          </div>

          <div>
            <label
              htmlFor="chimeContact"
              className="mb-2 block text-sm font-bold !text-[#252932]"
            >
              Email or phone number
            </label>

            <input
              id="chimeContact"
              type="text"
              value={chimeContact}
              onChange={(
                event,
              ) => {
                setChimeContact(
                  event.target.value,
                );
                setError("");
                setSuccess("");
              }}
              placeholder="Email address or phone number"
              autoComplete="email"
              className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm font-semibold !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
            />
          </div>
        </div>
      );
    }

    return null;
  }

  if (loading) {
    return (
      <main className="ff-product-page ff-withdraw-page flex min-h-screen items-center justify-center bg-[#F8F9FB] font-sans !text-[#111318]">
        <div className="w-full max-w-5xl px-4 py-10 sm:px-6">
          <div className="h-8 w-40 animate-pulse rounded-xl bg-white/80" />
          <div className="mt-8 h-44 animate-pulse rounded-[1.75rem] bg-[#1c3b5b]/15" />
          <div className="mt-6 h-72 animate-pulse rounded-[1.75rem] bg-white/80" />
        </div>
      </main>
    );
  }

  return (
    <main className="ff-product-page ff-withdraw-page min-h-screen bg-[#F8F9FB] font-sans !text-[#111318]">
      <div className="min-h-screen bg-[#F8F9FB]">
        <header className="sticky top-0 z-40 border-b border-[#E2E5E9] bg-[#0B0E17]/95 text-white backdrop-blur-xl">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
            <button
              type="button"
              onClick={() =>
                router.push(
                  "/dashboard",
                )
              }
              className="flex items-center gap-2 text-sm font-semibold text-white/70 transition hover:text-white"
            >
              <FiArrowLeft size={18} />
              Dashboard
            </button>

            <div className="text-lg font-black tracking-tight">
              FLASH
              <span className="text-[#B51F35]">
                FINANCE
              </span>
            </div>

            <button
              type="button"
              onClick={() =>
                router.push(
                  "/profile",
                )
              }
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-[#0B0E17] transition hover:bg-[#F1F3F6]"
            >
              <FiUser size={17} />
            </button>
          </div>
        </header>

        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
          <section className="mb-7">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
              Withdraw
            </p>

            <h1 className="mt-2 text-3xl font-black tracking-tight !text-[#111318]">
              Withdraw money
            </h1>

            <p className="mt-2 max-w-2xl text-sm leading-6 !text-[#69707D]">
              Choose a payment method, enter your
              destination details, and submit your
              withdrawal.
            </p>
          </section>

          <section className="rounded-3xl border border-[#B51F35]/20 bg-gradient-to-br from-[#B51F35] via-[#B51F35] to-[#8F172B] p-6 text-white shadow-sm sm:p-7">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/65">
                  Available balance
                </p>

                <p className="mt-2 text-3xl font-black">
                  {formatMoney(
                    balance,
                    currency,
                  )}
                </p>
              </div>

              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 text-white">
                <FiDollarSign size={22} />
              </div>
            </div>
          </section>

          {error && (
            <section className="mt-5 rounded-2xl border border-red-200 bg-red-50 p-4">
              <div className="flex items-start gap-3">
                <FiXCircle
                  size={19}
                  className="mt-0.5 shrink-0 text-red-600"
                />

                <p className="text-sm leading-6 text-red-700">
                  {error}
                </p>
              </div>
            </section>
          )}

          <section className="mt-7">
            <div className="mb-5">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
                Withdrawal details
              </p>

              <h2 className="mt-1 text-xl font-black !text-[#111318] sm:text-2xl">
                Choose how you want to withdraw
              </h2>

              <p className="mt-2 text-sm !text-[#69707D]">
                Enter the payment information for the
                destination you want to use.
              </p>
            </div>

            <form
              onSubmit={
                handleSubmit
              }
              className="space-y-4"
            >
              {withdrawalMethods.map(
                (method) => {
                  const selected =
                    selectedMethod ===
                    method.id;

                  return (
                    <div
                      key={
                        method.id
                      }
                      className={`overflow-hidden rounded-3xl border transition ${
                        selected
                          ? "border-[#B51F35]/40 bg-white shadow-sm"
                          : "border-[#E2E5E9] bg-white shadow-sm hover:border-[#B51F35]/20"
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() =>
                          handleMethodSelect(
                            method.id,
                          )
                        }
                        className="w-full p-5 text-left sm:p-6"
                      >
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-4">
                            <div
                              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
                                method.id ===
                                "Bank Transfer"
                                  ? "bg-[#B51F35]/10"
                                  : "bg-[#F1F3F6]"
                              }`}
                            >
                              <MethodLogo
                                method={
                                  method.id
                                }
                              />
                            </div>

                            <div>
                              <h3 className="text-base font-black !text-[#111318] sm:text-lg">
                                {
                                  method.name
                                }
                              </h3>

                              <p className="mt-1 text-xs leading-5 !text-[#69707D]">
                                {
                                  method.description
                                }
                              </p>
                            </div>
                          </div>

                          <div
                            className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full border ${
                              selected
                                ? "border-[#B51F35] bg-[#B51F35] text-white"
                                : "border-[#D5D9DE] text-transparent"
                            }`}
                          >
                            <FiCheck
                              size={15}
                            />
                          </div>
                        </div>
                      </button>

                      {selected && (
                        <div className="border-t border-[#E2E5E9] p-5 sm:p-6">
                          <div className="mb-5">
                            <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.16em] !text-[#9298A3]">
                              Required information
                            </p>

                            <div className="flex flex-wrap gap-2">
                              {method.requirements.map(
                                (
                                  requirement,
                                ) => (
                                  <span
                                    key={
                                      requirement
                                    }
                                    className="rounded-full border border-[#E2E5E9] bg-[#F8F9FB] px-3 py-1.5 text-[10px] font-semibold !text-[#69707D]"
                                  >
                                    {
                                      requirement
                                    }
                                  </span>
                                ),
                              )}
                            </div>
                          </div>

                          {method.id ===
                          "Bank Transfer" ? (
                            <div className="space-y-4">
                              <PlaidBankConnect
                                clientUserId={
                                  userId
                                }
                                onConnected={({
                                  accounts,
                                }) => {
                                  setPlaidAccounts(
                                    accounts,
                                  );

                                  setSelectedPlaidAccount(
                                    null,
                                  );

                                  setError("");

                                  setSuccess(
                                    "Your bank connection was verified. Select the account you want to use.",
                                  );
                                }}
                              />

                              {bankConnected && (
                                <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-4">
                                  <p className="text-[10px] font-bold uppercase tracking-[0.16em] !text-[#9298A3]">
                                    Verified bank
                                  </p>

                                  <div className="mt-3 space-y-2">
                                    {plaidAccounts.map(
                                      (
                                        plaidAccount,
                                      ) => {
                                        const selectedAccount =
                                          selectedPlaidAccount?.id ===
                                          plaidAccount.id;

                                        return (
                                          <button
                                            type="button"
                                            key={
                                              plaidAccount.id
                                            }
                                            onClick={() => {
                                              setSelectedPlaidAccount(
                                                plaidAccount,
                                              );

                                              setError("");
                                              setSuccess("");
                                            }}
                                            className={`flex w-full items-center justify-between rounded-2xl border p-4 text-left transition ${
                                              selectedAccount
                                                ? "border-emerald-200 bg-emerald-50"
                                                : "border-[#E2E5E9] bg-white hover:border-[#B51F35]/30"
                                            }`}
                                          >
                                            <div className="flex items-center gap-3">
                                              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                                                <FiHome
                                                  size={
                                                    18
                                                  }
                                                />
                                              </div>

                                              <div>
                                                <p className="text-sm font-black !text-[#111318]">
                                                  {
                                                    plaidAccount.name
                                                  }
                                                </p>

                                                <p className="mt-1 text-xs !text-[#69707D]">
                                                  {plaidAccount.subtype ||
                                                    plaidAccount.type}{" "}
                                                  ••••{" "}
                                                  {plaidAccount.mask ||
                                                    "----"}
                                                </p>
                                              </div>
                                            </div>

                                            {selectedAccount && (
                                              <FiCheckCircle
                                                size={
                                                  19
                                                }
                                                className="text-emerald-600"
                                              />
                                            )}
                                          </button>
                                        );
                                      },
                                    )}
                                  </div>
                                </div>
                              )}

                              {selectedPlaidAccount && (
                                <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-700">
                                  <FiCheckCircle
                                    size={15}
                                  />

                                  <span>
                                    Selected verified bank
                                    account ending in{" "}
                                    ••••
                                    {
                                      selectedPlaidAccount.mask ||
                                      "----"
                                    }
                                  </span>
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="space-y-5">
                              {renderPaymentFields(
                                method,
                              )}

                              <div className="flex items-start gap-2 rounded-xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-3 text-xs leading-5 !text-[#69707D]">
                                <FiCheckCircle
                                  size={15}
                                  className="mt-0.5 shrink-0 text-emerald-600"
                                />

                                <span>
                                  You can enter a new
                                  destination each time you
                                  make a withdrawal. A saved
                                  payment profile is not
                                  required.
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                },
              )}

              {selectedMethod && (
                <div className="rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm sm:p-8">
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                      <FiArrowUpRight
                        size={20}
                      />
                    </div>

                    <div>
                      <p className="text-xs !text-[#69707D]">
                        Withdrawal amount
                      </p>

                      <h3 className="text-xl font-black !text-[#111318]">
                        How much would you like
                        to withdraw?
                      </h3>
                    </div>
                  </div>

                  <div className="mt-7">
                    <label
                      htmlFor="withdrawAmount"
                      className="mb-2 block text-sm font-bold !text-[#252932]"
                    >
                      Amount
                    </label>

                    <div className="flex items-center rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 transition focus-within:border-[#B51F35] focus-within:bg-white">
                      <span className="mr-2 !text-[#69707D]">
                        $
                      </span>

                      <input
                        id="withdrawAmount"
                        type="number"
                        min="0.01"
                        max={balance}
                        step="0.01"
                        value={amount}
                        onChange={(
                          event,
                        ) => {
                          setAmount(
                            event.target.value,
                          );

                          setError("");
                          setSuccess("");
                        }}
                        placeholder="0.00"
                        className="w-full bg-transparent py-4 text-xl font-black !text-[#111318] outline-none placeholder:text-[#9298A3]"
                      />
                    </div>

                    <div className="mt-2 flex items-center justify-between text-xs">
                      <span className="!text-[#69707D]">
                        Available{" "}
                        {formatMoney(
                          balance,
                          currency,
                        )}
                      </span>

                      <button
                        type="button"
                        onClick={() =>
                          setAmount(
                            balance.toFixed(
                              2,
                            ),
                          )
                        }
                        className="font-bold text-[#B51F35] hover:text-[#991B30]"
                      >
                        Use full balance
                      </button>
                    </div>
                  </div>

                  <div className="mt-6">
                    <label
                      htmlFor="withdrawNote"
                      className="mb-2 block text-sm font-bold !text-[#252932]"
                    >
                      Note
                      <span className="ml-2 text-xs font-normal !text-[#9298A3]">
                        Optional
                      </span>
                    </label>

                    <textarea
                      id="withdrawNote"
                      value={note}
                      onChange={(
                        event,
                      ) =>
                        setNote(
                          event.target.value,
                        )
                      }
                      rows={3}
                      placeholder="Add a note for this withdrawal..."
                      className="w-full resize-none rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-4 text-sm !text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={
                      submitting ||
                      !canSubmit
                    }
                    className="mt-7 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#B51F35] px-5 py-4 text-sm font-black text-white transition hover:bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    {submitting ? (
                      <>
                        <FiLoader
                          size={18}
                          className="animate-spin"
                        />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <FiSend
                          size={18}
                        />
                        Submit withdrawal
                      </>
                    )}
                  </button>

                  {!canSubmit && (
                    <p className="mt-3 text-center text-xs !text-[#9298A3]">
                      {isBankTransfer
                        ? "Connect and select your verified bank account before submitting."
                        : "Enter all required payment information before submitting."}
                    </p>
                  )}
                </div>
              )}
            </form>
          </section>

          <section className="mt-10">
            <div className="mb-5">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
                Withdrawal activity
              </p>

              <h2 className="mt-1 text-xl font-black !text-[#111318] sm:text-2xl">
                Your withdrawal requests
              </h2>
            </div>

            {withdrawals.length ===
            0 ? (
              <div className="rounded-3xl border border-[#E2E5E9] bg-white p-10 text-center shadow-sm">
                <FiArrowUpRight
                  size={28}
                  className="mx-auto text-[#9298A3]"
                />

                <p className="mt-4 text-sm font-bold !text-[#111318]">
                  No withdrawals yet
                </p>

                <p className="mt-2 text-xs !text-[#69707D]">
                  Your withdrawal requests will appear
                  here.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {withdrawals.map(
                  (
                    withdrawal,
                  ) => {
                    const status =
                      withdrawal.status.toLowerCase();

                    const isPending =
                      status ===
                      "pending";

                    const isApproved =
                      status ===
                      "approved";

                    return (
                      <div
                        key={
                          withdrawal.id
                        }
                        className="rounded-3xl border border-[#E2E5E9] bg-white p-5 shadow-sm sm:p-6"
                      >
                        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                          <div className="flex items-start gap-3">
                            <div
                              className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                                isPending
                                  ? "bg-[#B51F35]/10 text-[#B51F35]"
                                  : isApproved
                                    ? "bg-emerald-50 text-emerald-600"
                                    : "bg-orange-50 text-orange-600"
                              }`}
                            >
                              {isPending ? (
                                <FiClock
                                  size={20}
                                />
                              ) : isApproved ? (
                                <FiArrowUpRight
                                  size={20}
                                />
                              ) : (
                                <FiXCircle
                                  size={20}
                                />
                              )}
                            </div>

                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <h3 className="font-black !text-[#111318]">
                                  {formatMoney(
                                    Number(
                                      withdrawal.amount,
                                    ),
                                    currency,
                                  )}
                                </h3>

                                <span
                                  className={`text-xs font-bold ${
                                    isPending
                                      ? "text-[#B51F35]"
                                      : isApproved
                                        ? "text-emerald-600"
                                        : "text-orange-600"
                                  }`}
                                >
                                  {formatStatus(
                                    withdrawal.status,
                                  )}
                                </span>
                              </div>

                              <p className="mt-1 text-xs !text-[#69707D]">
                                {
                                  withdrawal.withdrawal_method
                                }
                              </p>

                              <p className="mt-1 text-xs break-words !text-[#9298A3]">
                                {
                                  withdrawal.destination
                                }
                              </p>
                            </div>
                          </div>

                          <div className="text-left lg:text-right">
                            <p className="text-[10px] uppercase tracking-wider !text-[#9298A3]">
                              Submitted
                            </p>

                            <p className="mt-1 text-sm font-bold !text-[#252932]">
                              {formatDate(
                                withdrawal.created_at,
                              )}
                            </p>
                          </div>
                        </div>

                        {withdrawal.note && (
                          <div className="mt-5 rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider !text-[#9298A3]">
                              Note
                            </p>

                            <p className="mt-1 text-xs leading-5 !text-[#69707D]">
                              {
                                withdrawal.note
                              }
                            </p>
                          </div>
                        )}

                        {withdrawal.rejection_note && (
                          <div className="mt-5 rounded-2xl border border-orange-200 bg-orange-50 p-4">
                            <p className="text-[10px] uppercase tracking-wider text-orange-600">
                              Rejection reason
                            </p>

                            <p className="mt-1 text-xs leading-5 text-orange-700">
                              {
                                withdrawal.rejection_note
                              }
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  },
                )}
              </div>
            )}
          </section>

          <section className="mt-10 rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                <FiShield size={19} />
              </div>

              <div>
                <p className="text-sm font-bold !text-[#111318]">
                  Secure withdrawal
                </p>

                <p className="mt-1 text-xs !text-[#69707D]">
                  Your withdrawal request is securely
                  submitted for processing.
                </p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}