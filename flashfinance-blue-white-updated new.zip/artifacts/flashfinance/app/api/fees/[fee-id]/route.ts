﻿import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ "fee-id": string }> },
) {
  try {
    const { "fee-id": feeId } = await params;

    if (!feeId) {
      return NextResponse.json(
        { error: "Fee ID is required." },
        { status: 400 },
      );
    }

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !serviceRoleKey) {
      console.error("Missing Supabase server environment variables.");

      return NextResponse.json(
        { error: "Server configuration is incomplete." },
        { status: 500 },
      );
    }

    const supabase = createClient(
      supabaseUrl,
      serviceRoleKey,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      },
    );

    const { data: fee, error } = await supabase
      .from("admin_fee_requests")
      .select(
        "id, user_id, admin_id, fee_type, amount, currency, title, message, status, created_at, paid_at, expires_at, instructions, updated_at",
      )
      .eq("id", feeId)
      .maybeSingle();

    if (error) {
      console.error("Fee API database error:", error);

      return NextResponse.json(
        { error: error.message },
        { status: 500 },
      );
    }

    if (!fee) {
      return NextResponse.json(
        { error: "Fee request not found." },
        { status: 404 },
      );
    }

    return NextResponse.json({ fee });
  } catch (error) {
    console.error("Fee API error:", error);

    return NextResponse.json(
      { error: "Unable to load fee request." },
      { status: 500 },
    );
  }
}
