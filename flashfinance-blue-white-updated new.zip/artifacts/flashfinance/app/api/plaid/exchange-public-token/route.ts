import { NextResponse } from "next/server";
import {
  Configuration,
  PlaidApi,
} from "plaid";

const plaidClient =
  new PlaidApi(
    new Configuration({
      basePath:
        "https://sandbox.plaid.com",
      baseOptions: {
        headers: {
          "PLAID-CLIENT-ID":
            process.env
              .PLAID_CLIENT_ID!,
          "PLAID-SECRET":
            process.env
              .PLAID_SECRET!,
        },
      },
    }),
  );

type PlaidItemAddResult = {
  public_token?: string;
  accounts?: Array<{
    id: string;
    name: string;
    official_name?: string | null;
    type: string;
    subtype?: string | null;
    mask?: string | null;
  }>;
};

type PlaidLinkSession = {
  on_success?: {
    public_token?: string;
  } | null;
  results?: {
    item_add_results?: PlaidItemAddResult[];
  } | null;
};

function findPublicToken(
  linkSessions: PlaidLinkSession[],
) {
  for (
    let index =
      linkSessions.length - 1;
    index >= 0;
    index--
  ) {
    const session =
      linkSessions[index];

    const directToken =
      session?.on_success
        ?.public_token;

    if (directToken) {
      return directToken;
    }

    const itemResults =
      session?.results
        ?.item_add_results || [];

    for (
      let resultIndex =
        itemResults.length - 1;
      resultIndex >= 0;
      resultIndex--
    ) {
      const token =
        itemResults[resultIndex]
          ?.public_token;

      if (token) {
        return token;
      }
    }
  }

  return "";
}

export async function POST(
  request: Request,
) {
  try {
    const body =
      await request.json();

    let publicToken =
      typeof body.public_token ===
      "string"
        ? body.public_token.trim()
        : "";

    const linkToken =
      typeof body.link_token ===
      "string"
        ? body.link_token.trim()
        : "";

    /*
     * Normal React Link flow:
     * public_token comes directly from onSuccess.
     */
    if (!publicToken && !linkToken) {
      return NextResponse.json(
        {
          error:
            "Neither a Plaid public token nor a Link token was provided.",
        },
        {
          status: 400,
        },
      );
    }

    /*
     * Fallback:
     * If the React callback does not provide the
     * public token, retrieve the completed Link session
     * from Plaid using the link token.
     */
    if (!publicToken && linkToken) {
      const linkTokenResponse =
        await plaidClient.linkTokenGet({
          link_token:
            linkToken,
        });

      const linkData =
        linkTokenResponse.data as {
          link_sessions?: PlaidLinkSession[];
        };

      const sessions =
        linkData.link_sessions || [];

      publicToken =
        findPublicToken(
          sessions,
        );
    }

    if (!publicToken) {
      return NextResponse.json(
        {
          error:
            "Plaid completed the connection, but no public token was available from the completed Link session.",
        },
        {
          status: 400,
        },
      );
    }

    /*
     * Exchange the public token for
     * the permanent Item access token.
     */
    const exchangeResponse =
      await plaidClient.itemPublicTokenExchange(
        {
          public_token:
            publicToken,
        },
      );

    const accessToken =
      exchangeResponse.data
        .access_token;

    const itemId =
      exchangeResponse.data
        .item_id;

    /*
     * Retrieve the bank accounts associated
     * with the verified Plaid Item.
     */
    const authResponse =
      await plaidClient.authGet({
        access_token:
          accessToken,
      });

    const accounts =
      authResponse.data.accounts.map(
        (account) => ({
          id:
            account.account_id,
          name:
            account.name,
          official_name:
            account.official_name ??
            null,
          type:
            account.type,
          subtype:
            account.subtype ??
            null,
          mask:
            account.mask ??
            null,
        }),
      );

    return NextResponse.json({
      success: true,
      item_id:
        itemId,
      accounts,
    });
  } catch (error: any) {
    console.error(
      "Plaid public token exchange error:",
      error?.response?.data ??
        error,
    );

    return NextResponse.json(
      {
        error:
          error?.response?.data
            ?.error_message ||
          error?.message ||
          "Unable to verify the connected bank account.",
      },
      {
        status: 500,
      },
    );
  }
}