import { NextResponse } from "next/server";
import {
  Configuration,
  CountryCode,
  LinkTokenCreateRequest,
  PlaidApi,
  Products,
} from "plaid";

export async function POST(request: Request) {
  try {
    const clientId = process.env.PLAID_CLIENT_ID;
    const secret = process.env.PLAID_SECRET;

    if (!clientId || !secret) {
      console.error("Plaid environment variables are missing.");

      return NextResponse.json(
        {
          error:
            "Plaid is not configured on the server. Please check the production environment variables.",
        },
        { status: 500 }
      );
    }

    const plaidClient = new PlaidApi(
      new Configuration({
        basePath: "https://sandbox.plaid.com",
        baseOptions: {
          headers: {
            "PLAID-CLIENT-ID": clientId,
            "PLAID-SECRET": secret,
          },
        },
      })
    );

    const body = await request.json().catch(() => ({}));

    const clientUserId =
      typeof body.client_user_id === "string" &&
      body.client_user_id.trim()
        ? body.client_user_id.trim()
        : crypto.randomUUID();

    const requestData: LinkTokenCreateRequest = {
      user: {
        client_user_id: clientUserId,
      },
      client_name: "FlashFinance",
      products: [Products.Auth],
      country_codes: [CountryCode.Us],
      language: "en",
    };

    const response = await plaidClient.linkTokenCreate(requestData);

    return NextResponse.json({
      success: true,
      link_token: response.data.link_token,
      expiration: response.data.expiration,
    });
  } catch (error: any) {
    console.error(
      "Plaid create link token error:",
      error?.response?.data ?? error
    );

    return NextResponse.json(
      {
        error:
          error?.response?.data?.error_message ||
          error?.response?.data?.display_message ||
          error?.message ||
          "Unable to create Plaid bank connection.",
      },
      {
        status: 500,
      }
    );
  }
}