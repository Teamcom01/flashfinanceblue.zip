import { NextResponse } from "next/server";
import {
  Configuration,
  PlaidApi,
} from "plaid";

const plaidClient =
  new PlaidApi(
    new Configuration({
      basePath:
        "https://sandbox.plaid.com",
      baseOptions: {
        headers: {
          "PLAID-CLIENT-ID":
            process.env
              .PLAID_CLIENT_ID!,
          "PLAID-SECRET":
            process.env
              .PLAID_SECRET!,
        },
      },
    }),
  );

type PlaidLinkSession = {
  link_session_id?: string;
  finished_at?: string | null;
  on_success?: {
    public_token?: string | null;
  } | null;
  results?: {
    item_add_results?: Array<{
      public_token?: string | null;
      accounts?: Array<{
        id: string;
        name: string;
        official_name?: string | null;
        type: string;
        subtype?: string | null;
        mask?: string | null;
      }>;
    }>;
  } | null;
};

export async function POST(
  request: Request,
) {
  try {
    const body =
      await request.json();

    let publicToken =
      typeof body.public_token ===
      "string"
        ? body.public_token.trim()
        : "";

    const linkToken =
      typeof body.link_token ===
      "string"
        ? body.link_token.trim()
        : "";

    const linkSessionId =
      typeof body.link_session_id ===
      "string"
        ? body.link_session_id.trim()
        : "";

    /*
     * Normal flow:
     * use the public token supplied by Link.
     */
    if (publicToken) {
      return await exchangeAndGetAccounts(
        publicToken,
      );
    }

    /*
     * Fallback:
     * ask Plaid for the completed Link session
     * using the link token.
     */
    if (!linkToken) {
      return NextResponse.json(
        {
          error:
            "Plaid did not provide a Link token for the completed session.",
        },
        { status: 400 },
      );
    }

    const linkTokenResponse =
      await plaidClient.linkTokenGet({
        link_token:
          linkToken,
      });

    const linkData =
      linkTokenResponse.data as {
        link_sessions?: PlaidLinkSession[];
      };

    const sessions =
      linkData.link_sessions || [];

    let completedSession:
      PlaidLinkSession | null =
      null;

    /*
     * Prefer the exact Link session that just
     * completed.
     */
    if (linkSessionId) {
      completedSession =
        sessions.find(
          (session) =>
            session.link_session_id ===
            linkSessionId,
        ) || null;
    }

    /*
     * Otherwise use the most recently completed
     * session.
     */
    if (!completedSession) {
      const completedSessions =
        sessions
          .filter(
            (session) =>
              !!session.finished_at,
          )
          .sort(
            (a, b) =>
              new Date(
                b.finished_at!,
              ).getTime() -
              new Date(
                a.finished_at!,
              ).getTime(),
          );

      completedSession =
        completedSessions[0] ||
        null;
    }

    if (!completedSession) {
      return NextResponse.json(
        {
          error:
            "Plaid could not find the completed Link session yet. Please try again.",
        },
        { status: 400 },
      );
    }

    /*
     * Newer Plaid response:
     * results.item_add_results[].public_token
     */
    const itemResults =
      completedSession
        .results?.item_add_results ||
      [];

    for (const result of itemResults) {
      if (result.public_token) {
        publicToken =
          result.public_token;
        break;
      }
    }

    /*
     * Backward-compatible fallback:
     * on_success.public_token
     */
    if (
      !publicToken &&
      completedSession.on_success
        ?.public_token
    ) {
      publicToken =
        completedSession.on_success
          .public_token;
    }

    if (!publicToken) {
      return NextResponse.json(
        {
          error:
            "Plaid found the completed session, but the session does not contain a public token.",
        },
        { status: 400 },
      );
    }

    return await exchangeAndGetAccounts(
      publicToken,
    );
  } catch (error: any) {
    console.error(
      "Plaid exchange error:",
      error?.response?.data ??
        error,
    );

    return NextResponse.json(
      {
        error:
          error?.response?.data
            ?.error_message ||
          error?.message ||
          "Unable to verify the connected bank account.",
      },
      { status: 500 },
    );
  }
}

async function exchangeAndGetAccounts(
  publicToken: string,
) {
  const exchangeResponse =
    await plaidClient.itemPublicTokenExchange(
      {
        public_token:
          publicToken,
      },
    );

  const accessToken =
    exchangeResponse.data
      .access_token;

  const itemId =
    exchangeResponse.data.item_id;

  const authResponse =
    await plaidClient.authGet({
      access_token:
        accessToken,
    });

  const accounts =
    authResponse.data.accounts.map(
      (account) => ({
        id:
          account.account_id,
        name:
          account.name,
        official_name:
          account.official_name ??
          null,
        type:
          account.type,
        subtype:
          account.subtype ??
          null,
        mask:
          account.mask ??
          null,
      }),
    );

  return NextResponse.json({
    success: true,
    item_id: itemId,
    accounts,
  });
}