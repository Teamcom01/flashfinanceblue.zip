"use client";

import { useEffect, useState } from "react";
import { createClient } from "../../lib/supabase";

type SavingsAccount = {
  id: string;
  user_id: string;
  balance: number;
  created_at: string;
  updated_at: string;
};

type SavingsTransaction = {
  id: string;
  user_id: string;
  savings_account_id: string;
  type: string;
  amount: number;
  description: string | null;
  created_at: string;
};

export default function SavingsPage() {
  const supabase = createClient();

  const [account, setAccount] = useState<SavingsAccount | null>(null);
  const [transactions, setTransactions] = useState<SavingsTransaction[]>([]);
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function loadSavings() {
    setLoading(true);
    setError("");

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setError("Please log in to continue.");
      setLoading(false);
      return;
    }

    const { data: savingsAccount, error: accountError } =
      await supabase.rpc("ensure_savings_account");

    if (accountError) {
      setError(accountError.message);
      setLoading(false);
      return;
    }

    setAccount(savingsAccount);

    const { data: savingsTransactions, error: transactionsError } =
      await supabase
        .from("savings_transactions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

    if (transactionsError) {
      setError(transactionsError.message);
      setLoading(false);
      return;
    }

    setTransactions(savingsTransactions || []);
    setLoading(false);
  }

  useEffect(() => {
    loadSavings();
  }, []);

  async function depositSavings() {
    setMessage("");
    setError("");

    const value = Number(amount);

    if (!value || value <= 0) {
      setError("Enter a valid amount.");
      return;
    }

    setProcessing(true);

    const { error: depositError } = await supabase.rpc("deposit_to_savings", {
      p_amount: value,
    });

    if (depositError) {
      setError(depositError.message);
      setProcessing(false);
      return;
    }

    setAmount("");
    setMessage("Money added to savings successfully.");
    await loadSavings();
    setProcessing(false);
  }

  async function withdrawSavings() {
    setMessage("");
    setError("");

    const value = Number(amount);

    if (!value || value <= 0) {
      setError("Enter a valid amount.");
      return;
    }

    setProcessing(true);

    const { error: withdrawError } = await supabase.rpc(
      "withdraw_from_savings",
      {
        p_amount: value,
      },
    );

    if (withdrawError) {
      setError(withdrawError.message);
      setProcessing(false);
      return;
    }

    setAmount("");
    setMessage("Money withdrawn from savings successfully.");
    await loadSavings();
    setProcessing(false);
  }

  function formatMoney(value: number) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value || 0);
  }

  return (
    <main className="min-h-screen !bg-[#F8F9FB] !text-[#111318] px-4 py-8">
      <div className="mx-auto max-w-5xl">
        {/* HEADER */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm font-semibold text-[#69707D]">
              FlashFinance
            </p>

            <h1 className="mt-1 text-3xl font-black tracking-tight text-[#111318]">
              Savings
            </h1>

            <p className="mt-2 text-sm text-[#69707D]">
              Put money aside and manage your savings in one place.
            </p>
          </div>

          <a
            href="/dashboard"
            className="rounded-xl border border-[#E2E5E9] bg-white px-4 py-2 text-sm font-semibold text-[#252932] shadow-sm transition hover:border-[#B51F35]/30 hover:text-[#B51F35]"
          >
            Dashboard
          </a>
        </div>

        {loading ? (
          <div className="rounded-3xl border border-[#E2E5E9] bg-white p-8 text-center text-[#69707D] shadow-sm">
            <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-[#B51F35] border-t-transparent" />

            <p className="mt-4 text-sm">
              Loading savings...
            </p>
          </div>
        ) : (
          <>
            {/* SAVINGS BALANCE */}
            <section className="rounded-3xl bg-gradient-to-br from-[#B51F35] to-[#C9213A] p-6 text-white shadow-lg shadow-[#B51F35]/15">
              <p className="text-sm font-medium text-white/70">
                Savings balance
              </p>

              <div className="mt-2 text-4xl font-black tracking-tight">
                {formatMoney(Number(account?.balance || 0))}
              </div>

              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-white/15 bg-white/10 p-4">
                  <p className="text-xs text-white/60">
                    Account
                  </p>

                  <p className="mt-1 text-sm font-semibold text-white">
                    Personal Savings
                  </p>
                </div>

                <div className="rounded-2xl border border-white/15 bg-white/10 p-4">
                  <p className="text-xs text-white/60">
                    Status
                  </p>

                  <p className="mt-1 text-sm font-semibold text-white">
                    Active
                  </p>
                </div>
              </div>
            </section>

            {/* MOVE MONEY */}
            <section className="mt-6 rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm">
              <h2 className="text-lg font-black text-[#111318]">
                Move money
              </h2>

              <p className="mt-1 text-sm text-[#69707D]">
                Add money to savings or move money back to your main account.
              </p>

              <div className="mt-5">
                <label className="mb-2 block text-sm font-semibold text-[#252932]">
                  Amount
                </label>

                <div className="flex items-center rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 transition focus-within:border-[#B51F35]">
                  <span className="font-semibold text-[#69707D]">
                    $
                  </span>

                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    value={amount}
                    onChange={(event) => setAmount(event.target.value)}
                    placeholder="0.00"
                    className="w-full bg-transparent px-3 py-4 text-[#111318] outline-none placeholder:text-[#9298A3]"
                  />
                </div>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <button
                  onClick={depositSavings}
                  disabled={processing}
                  className="rounded-2xl bg-[#B51F35] px-5 py-3 font-bold text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {processing ? "Processing..." : "Add to Savings"}
                </button>

                <button
                  onClick={withdrawSavings}
                  disabled={processing}
                  className="rounded-2xl border border-[#E2E5E9] bg-white px-5 py-3 font-bold text-[#252932] transition hover:border-[#B51F35]/30 hover:bg-[#F8F9FB] hover:text-[#B51F35] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {processing ? "Processing..." : "Withdraw from Savings"}
                </button>
              </div>

              {message && (
                <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                  {message}
                </div>
              )}

              {error && (
                <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {error}
                </div>
              )}
            </section>

            {/* SAVINGS ACTIVITY */}
            <section className="mt-6 rounded-3xl border border-[#E2E5E9] bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-black text-[#111318]">
                    Savings activity
                  </h2>

                  <p className="mt-1 text-sm text-[#69707D]">
                    Your recent savings transactions.
                  </p>
                </div>

                <span className="text-xs font-medium text-[#9298A3]">
                  {transactions.length} transactions
                </span>
              </div>

              <div className="mt-5">
                {transactions.length === 0 ? (
                  <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-6 text-center text-sm text-[#69707D]">
                    No savings transactions yet.
                  </div>
                ) : (
                  <div className="divide-y divide-[#E2E5E9]">
                    {transactions.map((transaction) => {
                      const isCredit =
                        transaction.type === "deposit" ||
                        transaction.type === "credit";

                      return (
                        <div
                          key={transaction.id}
                          className="flex items-center justify-between gap-4 py-4"
                        >
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-[#111318]">
                              {transaction.description ||
                                (isCredit
                                  ? "Added to savings"
                                  : "Withdrawn from savings")}
                            </p>

                            <p className="mt-1 text-xs text-[#9298A3]">
                              {new Date(
                                transaction.created_at,
                              ).toLocaleString()}
                            </p>
                          </div>

                          <p
                            className={`shrink-0 text-sm font-bold ${
                              isCredit
                                ? "text-emerald-600"
                                : "text-red-600"
                            }`}
                          >
                            {isCredit ? "+" : "-"}
                            {formatMoney(Number(transaction.amount))}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </section>
          </>
        )}
      </div>
    </main>
  );
}