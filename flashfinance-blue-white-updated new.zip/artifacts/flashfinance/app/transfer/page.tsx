"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FiArrowLeft,
  FiArrowRight,
  FiCheck,
  FiCheckCircle,
  FiChevronRight,
  FiDollarSign,
  FiInfo,
  FiLoader,
  FiMail,
  FiPhone,
  FiSearch,
  FiSend,
  FiShield,
  FiUser,
  FiX,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type Account = {
  balance: number | null;
  currency: string | null;
};

type Recipient = {
  id: string;
  full_name: string | null;
  phone: string | null;
  email: string | null;
};

type TransferResult = {
  success?: boolean;
  new_balance?: number;
  amount?: number;
};

function formatMoney(amount: number, currency = "USD") {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(amount);
}

export default function TransferPage() {
  const router = useRouter();
  const supabase = createClient();

  const [account, setAccount] = useState<Account | null>(null);
  const [searchValue, setSearchValue] = useState("");
  const [searchType, setSearchType] = useState<"phone" | "email">("email");
  const [recipient, setRecipient] = useState<Recipient | null>(null);
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [searching, setSearching] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    async function loadAccount() {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const { data, error: accountError } = await supabase
        .from("accounts")
        .select("balance, currency")
        .eq("user_id", user.id)
        .maybeSingle();

      if (accountError) {
        setError(accountError.message);
        return;
      }

      setAccount(data as Account | null);
    }

    loadAccount();
  }, [router]);

  const balance = Number(account?.balance || 0);
  const currency = account?.currency || "USD";
  const numericAmount = Number(amount || 0);
  const amountValid = numericAmount > 0 && numericAmount <= balance;
  const remainingBalance = Math.max(balance - numericAmount, 0);

  const recipientInitial =
    recipient?.full_name?.trim()?.charAt(0).toUpperCase() ||
    recipient?.email?.charAt(0).toUpperCase() ||
    "U";

  const searchPlaceholder =
    searchType === "email"
      ? "Enter recipient email"
      : "Enter recipient phone number";

  const searchLabel =
    searchType === "email"
      ? "Recipient email"
      : "Recipient phone number";

  const searchInputType = searchType === "email" ? "email" : "tel";

  const searchIsValid = useMemo(() => {
    const value = searchValue.trim();

    if (!value) return false;

    if (searchType === "email") {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    }

    return value.replace(/\D/g, "").length >= 7;
  }, [searchValue, searchType]);

  async function findRecipient() {
    setError("");
    setSuccess("");
    setRecipient(null);
    setShowConfirmation(false);

    if (!searchIsValid) {
      setError(
        searchType === "email"
          ? "Enter a valid email address."
          : "Enter a valid phone number.",
      );
      return;
    }

    setSearching(true);

    try {
      const { data, error: searchError } = await supabase.rpc(
        "find_transfer_recipient",
        {
          p_search: searchValue.trim(),
          p_search_type: searchType,
        },
      );

      if (searchError) {
        throw new Error(searchError.message);
      }

      if (!data) {
        setError(
          "No FlashFinance account was found with those details.",
        );
        return;
      }

      setRecipient(data as Recipient);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to find that account.",
      );
    } finally {
      setSearching(false);
    }
  }

  function prepareTransfer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setSuccess("");

    if (!recipient) {
      setError("Find the recipient before continuing.");
      return;
    }

    if (!numericAmount || numericAmount <= 0) {
      setError("Enter a valid amount.");
      return;
    }

    if (numericAmount > balance) {
      setError("You do not have enough available balance.");
      return;
    }

    setShowConfirmation(true);
  }

  async function confirmTransfer() {
    if (!recipient) return;

    setSending(true);
    setError("");
    setSuccess("");

    try {
      const { data, error: transferError } = await supabase.rpc(
        "create_transfer",
        {
          p_recipient_user_id: recipient.id,
          p_amount: numericAmount,
          p_description: description.trim() || "Transfer",
        },
      );

      if (transferError) {
        throw new Error(transferError.message);
      }

      const result = data as TransferResult | null;

      if (!result?.success) {
        throw new Error("The transfer could not be completed.");
      }

      setAccount((current) => ({
        balance: Number(result.new_balance ?? 0),
        currency: current?.currency || currency,
      }));

      setSuccess(
        `${formatMoney(
          numericAmount,
          currency,
        )} was sent successfully.`,
      );

      setAmount("");
      setDescription("");
      setRecipient(null);
      setSearchValue("");
      setShowConfirmation(false);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Transfer failed. Please try again.",
      );
    } finally {
      setSending(false);
    }
  }

  return (
    <main className="min-h-screen !bg-[#F1F3F6] font-sans !text-[#111318]">
      <div className="min-h-screen !bg-[#F1F3F6]">
        {/* HEADER */}
        <header className="border-b border-white/10 !bg-[#0B0E17]">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
            <button
              type="button"
              onClick={() => router.push("/dashboard")}
              className="flex items-center gap-2 text-sm font-semibold !text-white/70 transition hover:!text-white"
            >
              <FiArrowLeft size={18} />
              Dashboard
            </button>

            <div className="text-lg font-black tracking-tight !text-white">
              FLASH<span className="!text-[#C9213A]">FINANCE</span>
            </div>

            <button
              type="button"
              onClick={() => router.push("/profile")}
              className="flex h-9 w-9 items-center justify-center rounded-full !bg-[#B51F35] !text-white transition hover:!bg-[#C9213A]"
            >
              <FiUser size={17} />
            </button>
          </div>
        </header>

        {/* CONTENT */}
        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
          <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
            {/* MAIN CARD */}
            <section className="overflow-hidden rounded-[28px] border !border-[#E2E5E9] !bg-white shadow-sm">
              <div className="border-b !border-[#E2E5E9] px-6 py-7 sm:px-8">
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl !bg-[#B51F35] !text-white shadow-lg shadow-[#B51F35]/15">
                    <FiSend size={22} />
                  </div>

                  <div>
                    <h1 className="text-2xl font-black tracking-tight !text-[#111318] sm:text-3xl">
                      Transfer Money
                    </h1>

                    <p className="mt-2 max-w-xl text-sm leading-6 !text-[#69707D]">
                      Send money securely to another registered FlashFinance
                      account using their email address or phone number.
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-6 sm:p-8">
                {/* BALANCE */}
                <div className="mb-7 overflow-hidden rounded-2xl bg-gradient-to-br from-[#B51F35] to-[#C9213A] p-5 !text-white shadow-lg shadow-[#B51F35]/10">
                  <p className="text-xs font-bold uppercase tracking-[0.18em] !text-white/70">
                    Available Balance
                  </p>

                  <div className="mt-2 flex items-end justify-between gap-4">
                    <p className="text-3xl font-black !text-white">
                      {formatMoney(balance, currency)}
                    </p>

                    <div className="hidden items-center gap-2 text-xs !text-white/70 sm:flex">
                      <FiShield size={15} />
                      Secure transfer
                    </div>
                  </div>
                </div>

                {/* MESSAGES */}
                {error && (
                  <div className="mb-5 flex items-start gap-3 rounded-2xl border border-red-200 !bg-red-50 p-4">
                    <FiX
                      size={18}
                      className="mt-0.5 shrink-0 !text-red-600"
                    />

                    <p className="text-sm leading-6 !text-red-700">
                      {error}
                    </p>
                  </div>
                )}

                {success && (
                  <div className="mb-5 flex items-start gap-3 rounded-2xl border border-emerald-200 !bg-emerald-50 p-4">
                    <FiCheckCircle
                      size={18}
                      className="mt-0.5 shrink-0 !text-emerald-600"
                    />

                    <div>
                      <p className="text-sm font-bold !text-emerald-700">
                        Transfer successful
                      </p>

                      <p className="mt-1 text-sm leading-6 !text-emerald-600">
                        {success}
                      </p>
                    </div>
                  </div>
                )}

                {/* SEARCH TYPE */}
                <div className="mb-5">
                  <p className="mb-3 text-sm font-bold !text-[#252932]">
                    Find recipient using
                  </p>

                  <div className="grid grid-cols-2 gap-2 rounded-2xl !bg-[#F1F3F6] p-1">
                    <button
                      type="button"
                      onClick={() => {
                        setSearchType("email");
                        setSearchValue("");
                        setRecipient(null);
                        setError("");
                      }}
                      className={`flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition ${
                        searchType === "email"
                          ? "!bg-[#B51F35] !text-white shadow-sm"
                          : "!text-[#69707D] hover:!text-[#111318]"
                      }`}
                    >
                      <FiMail size={16} />
                      Email
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setSearchType("phone");
                        setSearchValue("");
                        setRecipient(null);
                        setError("");
                      }}
                      className={`flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition ${
                        searchType === "phone"
                          ? "!bg-[#B51F35] !text-white shadow-sm"
                          : "!text-[#69707D] hover:!text-[#111318]"
                      }`}
                    >
                      <FiPhone size={16} />
                      Phone
                    </button>
                  </div>
                </div>

                {/* RECIPIENT SEARCH */}
                <div className="mb-6">
                  <label
                    htmlFor="recipientSearch"
                    className="mb-2 block text-sm font-bold !text-[#252932]"
                  >
                    {searchLabel}
                  </label>

                  <div className="flex gap-2">
                    <div className="flex min-w-0 flex-1 items-center rounded-2xl border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 transition focus-within:!border-[#B51F35] focus-within:!bg-white">
                      {searchType === "email" ? (
                        <FiMail
                          size={18}
                          className="mr-3 shrink-0 !text-[#9298A3]"
                        />
                      ) : (
                        <FiPhone
                          size={18}
                          className="mr-3 shrink-0 !text-[#9298A3]"
                        />
                      )}

                      <input
                        id="recipientSearch"
                        type={searchInputType}
                        value={searchValue}
                        onChange={(event) => {
                          setSearchValue(event.target.value);
                          setRecipient(null);
                          setError("");
                        }}
                        onKeyDown={(event) => {
                          if (event.key === "Enter" && searchIsValid) {
                            event.preventDefault();
                            findRecipient();
                          }
                        }}
                        placeholder={searchPlaceholder}
                        className="w-full bg-transparent py-4 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3]"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={findRecipient}
                      disabled={searching || !searchIsValid}
                      className="flex min-w-[88px] items-center justify-center gap-2 rounded-2xl !bg-[#B51F35] px-4 text-sm font-black !text-white transition hover:!bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      {searching ? (
                        <FiLoader size={18} className="animate-spin" />
                      ) : (
                        <>
                          <FiSearch size={17} />
                          Find
                        </>
                      )}
                    </button>
                  </div>

                  <p className="mt-2 text-[11px] !text-[#9298A3]">
                    Search by the recipient&apos;s registered email or phone
                    number.
                  </p>
                </div>

                {/* RECIPIENT */}
                {recipient && (
                  <div className="mb-6 overflow-hidden rounded-2xl border border-emerald-200 !bg-emerald-50">
                    <div className="flex items-center justify-between gap-4 p-4">
                      <div className="flex min-w-0 items-center gap-3">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full !bg-[#B51F35] text-lg font-black !text-white">
                          {recipientInitial}
                        </div>

                        <div className="min-w-0">
                          <p className="truncate text-sm font-black !text-[#111318]">
                            {recipient.full_name || "FlashFinance User"}
                          </p>

                          <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs !text-[#69707D]">
                            {recipient.email && (
                              <span className="flex items-center gap-1">
                                <FiMail size={12} />
                                {recipient.email}
                              </span>
                            )}

                            {recipient.phone && (
                              <span className="flex items-center gap-1">
                                <FiPhone size={12} />
                                {recipient.phone}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex h-9 w-9 items-center justify-center rounded-full !bg-emerald-100">
                        <FiCheck
                          size={18}
                          className="!text-emerald-600"
                        />
                      </div>
                    </div>

                    <div className="border-t border-emerald-200 px-4 py-3">
                      <p className="text-xs !text-emerald-700">
                        Recipient verified. Check the details below before
                        continuing.
                      </p>
                    </div>
                  </div>
                )}

                {/* TRANSFER FORM */}
                <form onSubmit={prepareTransfer} className="space-y-5">
                  <div>
                    <label
                      htmlFor="amount"
                      className="mb-2 block text-sm font-bold !text-[#252932]"
                    >
                      Amount
                    </label>

                    <div className="flex items-center rounded-2xl border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 transition focus-within:!border-[#B51F35] focus-within:!bg-white">
                      <FiDollarSign
                        size={18}
                        className="mr-2 !text-[#9298A3]"
                      />

                      <input
                        id="amount"
                        type="number"
                        min="1"
                        max={balance}
                        step="0.01"
                        value={amount}
                        onChange={(event) =>
                          setAmount(event.target.value)
                        }
                        placeholder="0.00"
                        className="w-full bg-transparent py-4 text-xl font-black !text-[#111318] outline-none placeholder:!text-[#9298A3]"
                      />

                      <span className="text-xs font-bold !text-[#69707D]">
                        {currency}
                      </span>
                    </div>

                    <div className="mt-2 flex justify-between text-[11px] !text-[#9298A3]">
                      <span>Minimum: $1.00</span>

                      <span>
                        Available: {formatMoney(balance, currency)}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="description"
                      className="mb-2 block text-sm font-bold !text-[#252932]"
                    >
                      Description

                      <span className="ml-2 font-normal !text-[#9298A3]">
                        Optional
                      </span>
                    </label>

                    <input
                      id="description"
                      type="text"
                      maxLength={100}
                      value={description}
                      onChange={(event) =>
                        setDescription(event.target.value)
                      }
                      placeholder="What is this transfer for?"
                      className="w-full rounded-2xl border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-4 text-sm !text-[#111318] outline-none transition focus:!border-[#B51F35] focus:!bg-white placeholder:!text-[#9298A3]"
                    />
                  </div>

                  {/* PREVIEW */}
                  {numericAmount > 0 && (
                    <div className="rounded-2xl border !border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs !text-[#69707D]">
                          Amount to send
                        </span>

                        <span className="text-sm font-black !text-[#111318]">
                          {formatMoney(
                            numericAmount,
                            currency,
                          )}
                        </span>
                      </div>

                      <div className="my-3 border-t !border-[#E2E5E9]" />

                      <div className="flex items-center justify-between">
                        <span className="text-xs !text-[#69707D]">
                          Balance after transfer
                        </span>

                        <span
                          className={`text-sm font-black ${
                            amountValid
                              ? "!text-emerald-600"
                              : "!text-red-600"
                          }`}
                        >
                          {formatMoney(
                            remainingBalance,
                            currency,
                          )}
                        </span>
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={
                      !recipient ||
                      !amount ||
                      numericAmount <= 0 ||
                      numericAmount > balance
                    }
                    className="flex w-full items-center justify-center gap-2 rounded-2xl !bg-[#B51F35] px-5 py-4 text-sm font-black !text-white transition hover:!bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Continue
                    <FiArrowRight size={18} />
                  </button>
                </form>
              </div>
            </section>

            {/* SIDE PANEL */}
            <aside className="space-y-4">
              <div className="rounded-[28px] border !border-[#E2E5E9] !bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl !bg-[#B51F35]/10 !text-[#B51F35]">
                    <FiInfo size={20} />
                  </div>

                  <div>
                    <h2 className="font-black !text-[#111318]">
                      Before you send
                    </h2>

                    <p className="mt-1 text-xs !text-[#9298A3]">
                      Check these details carefully
                    </p>
                  </div>
                </div>

                <div className="mt-5 space-y-4">
                  <div className="flex gap-3">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full !bg-[#F1F3F6] text-xs font-black !text-[#252932]">
                      1
                    </div>

                    <p className="text-sm leading-6 !text-[#69707D]">
                      Make sure the recipient&apos;s email or phone number
                      belongs to the correct person.
                    </p>
                  </div>

                  <div className="flex gap-3">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full !bg-[#F1F3F6] text-xs font-black !text-[#252932]">
                      2
                    </div>

                    <p className="text-sm leading-6 !text-[#69707D]">
                      Confirm the amount before approving the transfer.
                    </p>
                  </div>

                  <div className="flex gap-3">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full !bg-[#F1F3F6] text-xs font-black !text-[#252932]">
                      3
                    </div>

                    <p className="text-sm leading-6 !text-[#69707D]">
                      The transfer updates both accounts together.
                    </p>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => router.push("/dashboard")}
                className="flex w-full items-center justify-between rounded-[24px] border !border-[#E2E5E9] !bg-white p-5 text-left shadow-sm transition hover:!border-[#B51F35]/30"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl !bg-[#F1F3F6] !text-[#252932]">
                    <FiHomeIcon />
                  </div>

                  <div>
                    <p className="text-sm font-bold !text-[#111318]">
                      Back to dashboard
                    </p>

                    <p className="mt-1 text-xs !text-[#9298A3]">
                      Return to your account overview
                    </p>
                  </div>
                </div>

                <FiChevronRight
                  size={17}
                  className="!text-[#9298A3]"
                />
              </button>
            </aside>
          </div>
        </div>
      </div>

      {/* CONFIRMATION MODAL */}
      {showConfirmation && recipient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center !bg-[#0B0E17]/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md overflow-hidden rounded-[28px] border !border-[#E2E5E9] !bg-white shadow-2xl">
            <div className="border-b !border-[#E2E5E9] p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.18em] !text-[#B51F35]">
                    Confirm Transfer
                  </p>

                  <h2 className="mt-2 text-2xl font-black !text-[#111318]">
                    Review before sending
                  </h2>
                </div>

                <button
                  type="button"
                  onClick={() => setShowConfirmation(false)}
                  className="rounded-xl border !border-[#E2E5E9] p-2 !text-[#69707D] transition hover:!bg-[#F1F3F6] hover:!text-[#111318]"
                >
                  <FiX size={18} />
                </button>
              </div>
            </div>

            <div className="space-y-5 p-6">
              <div className="flex items-center gap-3 rounded-2xl border !border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-full !bg-[#B51F35] font-black !text-white">
                  {recipientInitial}
                </div>

                <div className="min-w-0">
                  <p className="truncate font-black !text-[#111318]">
                    {recipient.full_name || "FlashFinance User"}
                  </p>

                  <p className="mt-1 truncate text-xs !text-[#69707D]">
                    {recipient.email ||
                      recipient.phone ||
                      "Verified recipient"}
                  </p>
                </div>
              </div>

              <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-[#B51F35] to-[#C9213A] p-5 !text-white">
                <p className="text-xs !text-white/70">
                  You are sending
                </p>

                <p className="mt-2 text-3xl font-black !text-white">
                  {formatMoney(
                    numericAmount,
                    currency,
                  )}
                </p>

                {description.trim() && (
                  <p className="mt-2 text-sm !text-white/75">
                    {description.trim()}
                  </p>
                )}
              </div>

              <div className="flex items-start gap-3 rounded-2xl border !border-[#E2E5E9] !bg-[#F8F9FB] p-4">
                <FiShield
                  size={18}
                  className="mt-0.5 shrink-0 !text-[#B51F35]"
                />

                <p className="text-xs leading-5 !text-[#69707D]">
                  Transfers can affect your account balance immediately.
                  Verify the recipient and amount before confirming.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setShowConfirmation(false)}
                  disabled={sending}
                  className="rounded-2xl border !border-[#E2E5E9] px-4 py-4 text-sm font-bold !text-[#252932] transition hover:!bg-[#F1F3F6] disabled:opacity-50"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={confirmTransfer}
                  disabled={sending}
                  className="flex items-center justify-center gap-2 rounded-2xl !bg-[#B51F35] px-4 py-4 text-sm font-black !text-white transition hover:!bg-[#C9213A] disabled:opacity-50"
                >
                  {sending ? (
                    <>
                      <FiLoader
                        size={18}
                        className="animate-spin"
                      />
                      Sending
                    </>
                  ) : (
                    <>
                      <FiCheck size={18} />
                      Confirm
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function FiHomeIcon() {
  return (
    <span className="!text-[#252932]">
      <FiArrowLeft size={18} />
    </span>
  );
}