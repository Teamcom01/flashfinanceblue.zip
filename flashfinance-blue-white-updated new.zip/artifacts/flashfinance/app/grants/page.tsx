"use client";

import { useState } from "react";
import Link from "next/link";
import {
  FiArrowRight,
  FiCheckCircle,
  FiClock,
  FiDollarSign,
  FiFileText,
  FiHeart,
  FiHome,
  FiLock,
  FiShield,
  FiUsers,
  FiZap,
  FiChevronDown,
  FiHelpCircle,
} from "react-icons/fi";

type GrantType =
  | "financial"
  | "housing"
  | "utilities"
  | "food"
  | "emergency";

const applicationLink = (type: GrantType) =>
  `/grants/apply?type=${encodeURIComponent(type)}`;

const eligibilityItems: {
  icon: typeof FiDollarSign;
  title: string;
  text: string;
  type: GrantType;
}[] = [
  {
    icon: FiDollarSign,
    title: "Financial hardship",
    text: "Applicants experiencing a genuine financial difficulty may request assistance.",
    type: "financial",
  },
  {
    icon: FiHome,
    title: "Housing expenses",
    text: "Support may be requested for qualifying rent, housing, or emergency accommodation needs.",
    type: "housing",
  },
  {
    icon: FiZap,
    title: "Essential bills",
    text: "Applicants may request assistance with qualifying essential household expenses.",
    type: "utilities",
  },
  {
    icon: FiHeart,
    title: "Family emergencies",
    text: "Unexpected family or personal emergencies may qualify for consideration.",
    type: "emergency",
  },
];

const processSteps = [
  {
    number: "01",
    icon: FiFileText,
    title: "Submit your application",
    text: "Complete the grant application with accurate information about your financial situation.",
    details:
      "Start by selecting the type of assistance you need and provide information about your circumstances, requested amount, income, expenses, and hardship.",
    action: "Apply Now",
    href: "/grants/apply",
  },
  {
    number: "02",
    icon: FiUsers,
    title: "Application review",
    text: "Our review process evaluates the information and supporting documents provided.",
    details:
      "Applications are reviewed individually. The information you provide helps determine whether your request meets the program requirements.",
    action: "Start Application",
    href: "/grants/apply",
  },
  {
    number: "03",
    icon: FiShield,
    title: "Verification",
    text: "Additional information or documents may be requested before a final decision.",
    details:
      "If additional information is needed, you may be contacted through the designated application or support process.",
    action: "View Application",
    href: "/grants/apply",
  },
  {
    number: "04",
    icon: FiCheckCircle,
    title: "Decision",
    text: "You will receive an update when your application reaches a decision.",
    details:
      "A request may be approved, declined, placed on hold, or require additional information. Submission does not guarantee approval.",
    action: "Apply Now",
    href: "/grants/apply",
  },
];

const requirements = [
  "Be at least 18 years old",
  "Provide accurate personal information",
  "Explain the financial hardship you are experiencing",
  "Provide supporting documentation when requested",
  "Provide valid contact information",
  "Agree to the application terms and privacy notice",
];

const supportingInformation: {
  title: string;
  description: string;
  type: GrantType;
}[] = [
  {
    title: "Proof of identity",
    description: "Information that can help verify your identity.",
    type: "financial",
  },
  {
    title: "Income information",
    description: "Information about your current income or employment.",
    type: "financial",
  },
  {
    title: "Housing information",
    description: "Rent, housing, or accommodation information.",
    type: "housing",
  },
  {
    title: "Expense information",
    description: "Information about qualifying household expenses.",
    type: "financial",
  },
  {
    title: "Emergency documentation",
    description: "Documentation relating to an unexpected hardship.",
    type: "emergency",
  },
  {
    title: "Other supporting records",
    description: "Other information relevant to your request.",
    type: "financial",
  },
];

const faqs = [
  {
    question: "Who can apply for financial assistance?",
    answer:
      "Individuals experiencing a genuine financial hardship may submit an application for consideration. Eligibility and approval are determined through the review process.",
  },
  {
    question: "How much assistance can I request?",
    answer:
      "The amount requested should reflect your actual financial need. The final amount, if any, is determined during the review process.",
  },
  {
    question: "Does submitting an application guarantee approval?",
    answer:
      "No. Submitting an application does not guarantee approval or payment. Every application is subject to review and verification.",
  },
  {
    question: "What documents might I need?",
    answer:
      "Depending on your circumstances, you may be asked for documents supporting your identity, income, expenses, housing situation, or the hardship described in your application.",
  },
  {
    question: "How long does the review take?",
    answer:
      "Review times can vary depending on the information provided and whether additional verification is required. You will be notified if more information is needed.",
  },
  {
    question: "Can I apply if I already have a FlashFinance account?",
    answer:
      "Yes. Existing users can apply through the grant application page. Your application will be reviewed separately from your normal account activity.",
  },
];

const impactStories = [
  {
    image:
      "https://images.unsplash.com/photo-1494386346843-e12284507169?auto=format&fit=crop&w=1200&q=85",
    title: "Housing support",
    text: "This section can feature a genuine recipient story explaining how approved assistance helped with a qualifying housing hardship.",
  },
  {
    image:
      "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=85",
    title: "Essential needs",
    text: "Verified community stories can explain how approved assistance helped with qualifying food or essential needs.",
  },
  {
    image:
      "https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=1200&q=85",
    title: "Community support",
    text: "Real recipient stories can be added when genuine information and permission to publish are available.",
  },
];

export default function GrantsPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [openProcess, setOpenProcess] = useState<number | null>(null);

  const scrollToHowItWorks = () => {
    document
      .getElementById("how-it-works")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const scrollToTransparency = () => {
    document
      .getElementById("transparency")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <main className="ff-product-page ff-grants-page min-h-screen !bg-[#F1F3F6] !text-[#111318]">
      {/* NAVIGATION */}
      <header className="sticky top-0 z-50 border-b !border-[#E2E5E9] !bg-white/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <Link href="/dashboard" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl !bg-[#2563EB] text-white shadow-lg shadow-[#2563EB]/20">
              <FiDollarSign size={21} />
            </div>

            <div>
              <div className="text-lg font-bold tracking-tight !text-[#111318]">
                FlashFinance
              </div>

              <div className="text-[10px] font-semibold uppercase tracking-[0.18em] !text-[#2563EB]">
                Financial Assistance
              </div>
            </div>
          </Link>

          <div className="flex items-center gap-3">
            <Link
              href="/dashboard"
              className="hidden rounded-xl px-4 py-2.5 text-sm font-semibold !text-[#69707D] transition hover:!bg-[#F1F3F6] hover:!text-[#B51F35] sm:block"
            >
              Dashboard
            </Link>

            <Link
              href="/grants/apply"
              className="inline-flex items-center gap-2 rounded-xl !bg-[#2563EB] px-4 py-2.5 text-sm font-black text-white shadow-lg shadow-[#2563EB]/10 transition hover:-translate-y-0.5 hover:!bg-[#1D4ED8]"
            >
              Apply Now
              <FiArrowRight size={16} />
            </Link>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden border-b !border-[#DBE5F0] !bg-[#EFF6FF] !text-[#172B4D]">
        <div className="absolute -left-32 -top-32 h-96 w-96 rounded-full bg-[#2563EB]/10 blur-3xl" />
        <div className="absolute -bottom-40 right-0 h-96 w-96 rounded-full bg-[#60A5FA]/15 blur-3xl" />

        <div className="relative mx-auto grid max-w-7xl gap-14 px-5 py-20 lg:grid-cols-[1.1fr_.9fr] lg:px-8 lg:py-28">
          <div className="flex flex-col justify-center">
            <div className="mb-6 inline-flex w-fit items-center gap-2 rounded-full border border-[#2563EB]/20 bg-[#2563EB]/10 px-4 py-2 text-xs font-semibold text-[#2563EB]">
              <FiHeart size={14} />
              Financial assistance program
            </div>

            <h1 className="max-w-4xl text-4xl font-black leading-[1.05] tracking-tight sm:text-5xl lg:text-7xl">
              When life gets difficult,
              <span className="block text-[#2563EB]">
                financial help matters.
              </span>
            </h1>

            <p className="mt-7 max-w-2xl text-base leading-7 text-[#607089] sm:text-lg">
              The FlashFinance Financial Assistance Grant provides a way for
              eligible applicants experiencing financial hardship to request
              assistance for qualifying needs.
            </p>

            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link
                href="/grants/apply"
                className="inline-flex items-center justify-center gap-2 rounded-2xl !bg-[#2563EB] px-6 py-4 text-sm font-black text-white shadow-xl shadow-[#2563EB]/15 transition hover:-translate-y-1 hover:!bg-[#1D4ED8]"
              >
                Apply for Assistance
                <FiArrowRight size={18} />
              </Link>

              <button
                type="button"
                onClick={scrollToHowItWorks}
                className="inline-flex items-center justify-center rounded-2xl border border-[#CBD8E8] !bg-white px-6 py-4 text-sm font-bold !text-[#172B4D] transition hover:border-[#2563EB]/40 hover:!bg-[#EFF6FF] hover:!text-[#2563EB]"
              >
                Learn How It Works
              </button>
            </div>

            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-xs font-medium text-[#607089]">
              <button
                type="button"
                onClick={scrollToTransparency}
                className="flex items-center gap-2 transition hover:text-[#2563EB]"
              >
                <FiLock size={14} />
                Secure application
              </button>

              <button
                type="button"
                onClick={scrollToHowItWorks}
                className="flex items-center gap-2 transition hover:text-[#2563EB]"
              >
                <FiFileText size={14} />
                Review based on need
              </button>

              <button
                type="button"
                onClick={scrollToTransparency}
                className="flex items-center gap-2 transition hover:text-[#2563EB]"
              >
                <FiShield size={14} />
                Privacy focused
              </button>
            </div>
          </div>

          {/* HERO CARD */}
          <div className="relative flex items-center">
            <div className="w-full rounded-[2rem] border border-[#D9E4F0] !bg-white p-5 shadow-[0_24px_60px_rgba(29,78,216,.12)] sm:p-7">
              <div className="rounded-[1.5rem] border border-[#D9E4F0] !bg-[#F8FBFF] p-6 !text-[#172B4D] sm:p-8">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#607089]">
                      Assistance request
                    </p>

                    <h2 className="mt-2 text-2xl font-black">
                      Financial Support
                    </h2>
                  </div>

                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#2563EB]/10 text-[#2563EB]">
                    <FiHeart size={22} />
                  </div>
                </div>

                <div className="mt-7 rounded-2xl !bg-[#2563EB] p-5 text-white">
                  <div className="text-xs font-semibold text-white/70">
                    Request amount
                  </div>

                  <div className="mt-2 text-2xl font-black">
                    Tell us what you need
                  </div>

                  <div className="mt-2 text-xs leading-5 text-white/70">
                    Choose the type of assistance that best describes your
                    current situation.
                  </div>
                </div>

                <div className="mt-5 space-y-2">
                  {eligibilityItems.map((item) => {
                    const Icon = item.icon;

                    return (
                      <Link
                        key={item.title}
                        href={applicationLink(item.type)}
                        className="group flex items-center justify-between rounded-xl border border-[#D9E4F0] !bg-white p-3 transition hover:border-[#2563EB]/40 hover:!bg-[#EFF6FF]"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#2563EB]/10 text-[#2563EB]">
                            <Icon size={17} />
                          </div>

                          <span className="text-sm font-semibold text-[#172B4D]">
                            {item.title}
                          </span>
                        </div>

                        <FiArrowRight
                          className="text-[#607089] transition group-hover:translate-x-1 group-hover:text-[#2563EB]"
                          size={16}
                        />
                      </Link>
                    );
                  })}
                </div>

                <Link
                  href="/grants/apply"
                  className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl !bg-[#2563EB] px-5 py-3.5 text-sm font-bold text-white transition hover:!bg-[#1D4ED8]"
                >
                  Start Application
                  <FiArrowRight size={16} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST STRIP */}
      <section className="border-b !border-[#E2E5E9] !bg-white">
        <div className="mx-auto grid max-w-7xl gap-4 px-5 py-6 sm:grid-cols-3 lg:px-8">
          {[
            {
              icon: FiShield,
              title: "Secure process",
              text: "Information handled carefully",
              action: scrollToTransparency,
            },
            {
              icon: FiUsers,
              title: "Need-based review",
              text: "Applications reviewed individually",
              action: scrollToHowItWorks,
            },
            {
              icon: FiClock,
              title: "Clear process",
              text: "Application status updates",
              action: scrollToHowItWorks,
            },
          ].map((item) => {
            const Icon = item.icon;

            return (
              <button
                key={item.title}
                type="button"
                onClick={item.action}
                className="group flex items-center gap-3 rounded-2xl p-3 text-left transition hover:!bg-[#F8F9FB]"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                  <Icon size={19} />
                </div>

                <div>
                  <div className="text-sm font-bold !text-[#111318]">
                    {item.title}
                  </div>

                  <div className="text-xs !text-[#69707D]">
                    {item.text}
                  </div>
                </div>

                <FiArrowRight
                  className="ml-auto text-[#A1A7B2] transition group-hover:translate-x-1 group-hover:text-[#B51F35]"
                  size={16}
                />
              </button>
            );
          })}
        </div>
      </section>

      {/* ABOUT */}
      <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
          <div>
            <div className="mb-4 text-xs font-black uppercase tracking-[0.2em] !text-[#B51F35]">
              About the program
            </div>

            <h2 className="text-3xl font-black tracking-tight !text-[#111318] sm:text-4xl">
              Built around real financial hardship
            </h2>

            <p className="mt-5 text-base leading-7 !text-[#69707D]">
              Financial emergencies can happen unexpectedly. A sudden expense,
              loss of income, housing difficulty, or family emergency can make
              it difficult to keep up with everyday responsibilities.
            </p>

            <p className="mt-4 text-base leading-7 !text-[#69707D]">
              This program provides an organized process for individuals to
              explain their circumstances and request assistance for qualifying
              needs.
            </p>

            <Link
              href="/grants/apply"
              className="mt-7 inline-flex items-center gap-2 rounded-xl !bg-[#B51F35] px-5 py-3.5 text-sm font-bold text-white transition hover:!bg-[#991B30]"
            >
              Start an Application
              <FiArrowRight size={16} />
            </Link>
          </div>

          {/* ELIGIBILITY CARDS */}
          <div className="grid gap-4 sm:grid-cols-2">
            {eligibilityItems.map((item) => {
              const Icon = item.icon;

              return (
                <Link
                  key={item.title}
                  href={applicationLink(item.type)}
                  className="group rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.04)] transition hover:-translate-y-1 hover:!border-[#B51F35]/40 hover:shadow-[0_10px_30px_rgba(0,0,0,0.08)]"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#B51F35]/10 text-[#B51F35] transition group-hover:!bg-[#B51F35] group-hover:text-white">
                      <Icon size={21} />
                    </div>

                    <FiArrowRight
                      className="text-[#A1A7B2] transition group-hover:translate-x-1 group-hover:text-[#B51F35]"
                      size={18}
                    />
                  </div>

                  <h3 className="mt-5 text-lg font-black !text-[#111318]">
                    {item.title}
                  </h3>

                  <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                    {item.text}
                  </p>

                  <div className="mt-5 text-xs font-black uppercase tracking-wider !text-[#B51F35]">
                    Apply for this assistance
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* IMPACT */}
      <section className="border-y !border-[#E2E5E9] !bg-[#F8F9FB] py-20">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="max-w-2xl">
            <div className="text-xs font-black uppercase tracking-[0.2em] !text-[#B51F35]">
              Community impact
            </div>

            <h2 className="mt-3 text-3xl font-black tracking-tight !text-[#111318] sm:text-4xl">
              Real stories from the community
            </h2>

            <p className="mt-4 !text-[#69707D]">
              Genuine recipient stories can help applicants understand how
              approved assistance has supported people facing hardship.
            </p>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {impactStories.map((story) => (
              <article
                key={story.title}
                className="overflow-hidden rounded-[1.75rem] !border !border-[#E2E5E9] !bg-white shadow-[0_4px_20px_rgba(0,0,0,0.04)] transition hover:-translate-y-1 hover:shadow-[0_10px_30px_rgba(0,0,0,0.08)]"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={story.image}
                    alt={story.title}
                    className="h-full w-full object-cover"
                  />

                  <div className="absolute left-4 top-4 rounded-full !bg-[#B51F35] px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.12em] text-white">
                    Community
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-black !text-[#111318]">
                    {story.title}
                  </h3>

                  <p className="mt-3 text-sm leading-6 !text-[#69707D]">
                    {story.text}
                  </p>

                  <Link
                    href="/grants/apply"
                    className="mt-5 inline-flex items-center gap-2 text-xs font-black uppercase tracking-wider !text-[#B51F35] transition hover:!text-[#991B30]"
                  >
                    Start your application
                    <FiArrowRight size={14} />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section
        id="how-it-works"
        className="scroll-mt-24 !bg-[#F1F3F6] py-20"
      >
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <div className="text-xs font-black uppercase tracking-[0.2em] !text-[#B51F35]">
              Simple process
            </div>

            <h2 className="mt-3 text-3xl font-black tracking-tight !text-[#111318] sm:text-4xl">
              How the grant process works
            </h2>

            <p className="mt-4 !text-[#69707D]">
              Click any step to see more information.
            </p>
          </div>

          <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {processSteps.map((step, index) => {
              const Icon = step.icon;
              const isOpen = openProcess === index;

              return (
                <div
                  key={step.number}
                  className={`rounded-3xl !border !bg-white p-6 transition ${
                    isOpen
                      ? "!border-[#B51F35]/50 shadow-[0_10px_30px_rgba(181,31,53,0.08)]"
                      : "!border-[#E2E5E9] hover:!border-[#B51F35]/25 hover:shadow-[0_8px_25px_rgba(0,0,0,0.06)]"
                  }`}
                >
                  <button
                    type="button"
                    onClick={() =>
                      setOpenProcess(isOpen ? null : index)
                    }
                    className="w-full text-left"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl !bg-[#B51F35] text-white">
                        <Icon size={20} />
                      </div>

                      <span className="text-3xl font-black !text-[#111318]/10">
                        {step.number}
                      </span>
                    </div>

                    <div className="mt-6 flex items-start justify-between gap-3">
                      <h3 className="text-lg font-black !text-[#111318]">
                        {step.title}
                      </h3>

                      <FiChevronDown
                        className={`mt-1 shrink-0 !text-[#B51F35] transition-transform ${
                          isOpen ? "rotate-180" : ""
                        }`}
                        size={18}
                      />
                    </div>

                    <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                      {step.text}
                    </p>
                  </button>

                  {isOpen && (
                    <div className="mt-5 border-t !border-[#E2E5E9] pt-5">
                      <p className="text-sm leading-6 !text-[#69707D]">
                        {step.details}
                      </p>

                      <Link
                        href={step.href}
                        className="mt-5 inline-flex items-center gap-2 rounded-xl !bg-[#B51F35] px-4 py-3 text-xs font-bold text-white transition hover:!bg-[#991B30]"
                      >
                        {step.action}
                        <FiArrowRight size={14} />
                      </Link>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ELIGIBILITY */}
      <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-[2rem] !border !border-[#E2E5E9] !bg-white p-8 shadow-[0_6px_25px_rgba(0,0,0,0.05)] sm:p-10">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl !bg-[#B51F35] text-white">
              <FiCheckCircle size={22} />
            </div>

            <h2 className="mt-6 text-3xl font-black !text-[#111318]">
              Basic eligibility requirements
            </h2>

            <p className="mt-4 text-sm leading-6 !text-[#69707D]">
              Meeting the basic requirements allows an application to be
              submitted. It does not guarantee approval.
            </p>

            <div className="mt-7 space-y-4">
              {requirements.map((item) => (
                <Link
                  key={item}
                  href="/grants/apply"
                  className="group flex items-center gap-3 rounded-xl p-2 transition hover:!bg-[#F8F9FB]"
                >
                  <FiCheckCircle
                    className="shrink-0 !text-[#B51F35]"
                    size={17}
                  />

                  <span className="text-sm !text-[#252932]">{item}</span>

                  <FiArrowRight
                    className="ml-auto !text-[#A1A7B2] transition group-hover:translate-x-1 group-hover:!text-[#B51F35]"
                    size={15}
                  />
                </Link>
              ))}
            </div>

            <Link
              href="/grants/apply"
              className="mt-8 inline-flex items-center gap-2 rounded-xl !bg-[#B51F35] px-5 py-3 text-sm font-black text-white transition hover:!bg-[#991B30]"
            >
              Start Application
              <FiArrowRight size={16} />
            </Link>
          </div>

          {/* SUPPORTING INFORMATION */}
          <div className="rounded-[2rem] !border !border-[#E2E5E9] !bg-white p-8 shadow-[0_4px_20px_rgba(0,0,0,0.04)] sm:p-10">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#B51F35]/10 !text-[#B51F35]">
              <FiFileText size={22} />
            </div>

            <h2 className="mt-6 text-3xl font-black !text-[#111318]">
              Supporting information
            </h2>

            <p className="mt-4 text-sm leading-6 !text-[#69707D]">
              Depending on the circumstances described in an application, the
              review team may request information that helps verify the need.
            </p>

            <div className="mt-7 grid gap-3 sm:grid-cols-2">
              {supportingInformation.map((item) => (
                <Link
                  key={item.title}
                  href={applicationLink(item.type)}
                  className="group rounded-xl !border !border-[#E2E5E9] !bg-[#F8F9FB] px-4 py-4 transition hover:!border-[#B51F35]/30 hover:!bg-[#B51F35]/5"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-sm font-bold !text-[#252932]">
                      {item.title}
                    </span>

                    <FiArrowRight
                      className="shrink-0 !text-[#A1A7B2] transition group-hover:translate-x-1 group-hover:!text-[#B51F35]"
                      size={15}
                    />
                  </div>

                  <p className="mt-1 text-xs leading-5 !text-[#69707D]">
                    {item.description}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* TRANSPARENCY */}
      <section
        id="transparency"
        className="scroll-mt-24 border-y !border-[#E2E5E9] !bg-[#0B0E17] py-20"
      >
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-center">
            <div>
              <div className="text-xs font-black uppercase tracking-[0.2em] !text-[#C9213A]">
                Transparency
              </div>

              <h2 className="mt-3 text-3xl font-black text-white sm:text-4xl">
                No promises. Just a clear process.
              </h2>

              <p className="mt-5 max-w-xl text-base leading-7 !text-[#B8BDC6]">
                Financial assistance decisions depend on the information
                submitted and the program's eligibility and review criteria.
                Applying does not guarantee that assistance will be approved.
              </p>

              <Link
                href="/grants/apply"
                className="mt-7 inline-flex items-center gap-2 rounded-xl !bg-[#B51F35] px-5 py-3.5 text-sm font-bold text-white transition hover:!bg-[#991B30]"
              >
                Apply for Assistance
                <FiArrowRight size={16} />
              </Link>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {[
                {
                  icon: FiShield,
                  title: "Verification",
                  text: "Information may be verified before a decision is made.",
                  action: scrollToHowItWorks,
                },
                {
                  icon: FiLock,
                  title: "Privacy",
                  text: "Application information should only be provided through the designated application process.",
                  href: "/grants/apply",
                },
                {
                  icon: FiClock,
                  title: "Review",
                  text: "Applications are reviewed based on the information provided.",
                  action: scrollToHowItWorks,
                },
                {
                  icon: FiHelpCircle,
                  title: "Support",
                  text: "Applicants can use the support system if they need help with the process.",
                  href: "/support",
                },
              ].map((item) => {
                const Icon = item.icon;

                const content = (
                  <>
                    <Icon size={22} className="!text-[#C9213A]" />

                    <div className="mt-4 flex items-center justify-between">
                      <h3 className="font-black text-white">
                        {item.title}
                      </h3>

                      <FiArrowRight
                        className="!text-[#667085] transition group-hover:translate-x-1 group-hover:!text-[#E15A6D]"
                        size={16}
                      />
                    </div>

                    <p className="mt-2 text-sm leading-6 !text-[#B8BDC6]">
                      {item.text}
                    </p>
                  </>
                );

                if (item.href) {
                  return (
                    <Link
                      key={item.title}
                      href={item.href}
                      className="group rounded-3xl border border-white/10 !bg-white/[0.04] p-6 transition hover:border-[#B51F35]/30 hover:!bg-[#B51F35]/10 hover:shadow-lg"
                    >
                      {content}
                    </Link>
                  );
                }

                return (
                  <button
                    key={item.title}
                    type="button"
                    onClick={item.action}
                    className="group rounded-3xl border border-white/10 !bg-white/[0.04] p-6 text-left transition hover:border-[#B51F35]/30 hover:!bg-[#B51F35]/10 hover:shadow-lg"
                  >
                    {content}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-4xl px-5 py-20 lg:px-8">
        <div className="text-center">
          <div className="text-xs font-black uppercase tracking-[0.2em] !text-[#B51F35]">
            FAQ
          </div>

          <h2 className="mt-3 text-3xl font-black !text-[#111318] sm:text-4xl">
            Frequently asked questions
          </h2>

          <p className="mt-4 !text-[#69707D]">
            Everything you need to know before starting your application.
          </p>
        </div>

        <div className="mt-10 space-y-3">
          {faqs.map((faq, index) => {
            const isOpen = openFaq === index;

            return (
              <div
                key={faq.question}
                className="overflow-hidden rounded-2xl !border !border-[#E2E5E9] !bg-white shadow-[0_2px_12px_rgba(0,0,0,0.03)]"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaq(isOpen ? null : index)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left transition hover:!bg-[#F8F9FB]"
                >
                  <span className="font-bold !text-[#111318]">
                    {faq.question}
                  </span>

                  <FiChevronDown
                    className={`shrink-0 !text-[#B51F35] transition-transform ${
                      isOpen ? "rotate-180" : ""
                    }`}
                    size={19}
                  />
                </button>

                {isOpen && (
                  <div className="border-t !border-[#E2E5E9] px-5 pb-5 pt-4">
                    <p className="text-sm leading-6 !text-[#69707D]">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="border-t !border-[#1E2430] !bg-[#0B0E17] px-5 py-20 text-white">
        <div className="mx-auto max-w-5xl text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl !bg-[#B51F35] text-white">
            <FiHeart size={25} />
          </div>

          <h2 className="mt-6 text-3xl font-black tracking-tight sm:text-5xl">
            If you are facing financial hardship,
            <span className="block text-[#C9213A]">
              you can start an application.
            </span>
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-sm leading-6 !text-[#B8BDC6] sm:text-base">
            Tell us about your circumstances and the type of assistance you
            need. Your application will go through the appropriate review
            process.
          </p>

          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Link
              href="/grants/apply"
              className="inline-flex items-center justify-center gap-2 rounded-2xl !bg-[#B51F35] px-7 py-4 text-sm font-black text-white transition hover:-translate-y-1 hover:!bg-[#991B30]"
            >
              Apply for Financial Assistance
              <FiArrowRight size={18} />
            </Link>

            <Link
              href="/support"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 !bg-white/5 px-7 py-4 text-sm font-bold text-white transition hover:border-[#B51F35]/30 hover:!bg-[#B51F35]/10 hover:text-[#E15A6D]"
            >
              Contact Support
              <FiHelpCircle size={17} />
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t !border-[#1E2430] !bg-[#080A10]">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-8 text-xs !text-[#7F8794] sm:flex-row sm:items-center sm:justify-between lg:px-8">
          <div>
            © {new Date().getFullYear()} FlashFinance. Financial assistance
            application portal.
          </div>

          <div className="flex gap-5">
            <Link
              href="/dashboard"
              className="transition hover:!text-[#C9213A]"
            >
              Dashboard
            </Link>

            <Link
              href="/support"
              className="transition hover:!text-[#C9213A]"
            >
              Support
            </Link>

            <Link
              href="/grants/apply"
              className="font-bold !text-[#C9213A] transition hover:!text-[#E15A6D]"
            >
              Apply
            </Link>
          </div>
        </div>
      </footer>
    </main>
  );
}