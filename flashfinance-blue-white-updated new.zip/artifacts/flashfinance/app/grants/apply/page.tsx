"use client";

import {
  Suspense,
  useEffect,
  useState,
} from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { createClient } from "../../../lib/supabase";
import {
  FiArrowLeft,
  FiArrowRight,
  FiCheck,
  FiDollarSign,
  FiHome,
  FiHeart,
  FiZap,
  FiUser,
  FiMail,
  FiPhone,
  FiBriefcase,
  FiCreditCard,
  FiMapPin,
  FiFileText,
  FiShield,
  FiAlertCircle,
  FiUsers,
} from "react-icons/fi";

type AssistanceType =
  | "financial"
  | "housing"
  | "utilities"
  | "emergency";

type PaymentMethod =
  | "cash_delivery"
  | "paypal"
  | "bank_transfer"
  | "cash_app"
  | "venmo"
  | "zelle"
  | "check"
  | "other";

const assistanceTypes = [
  {
    id: "financial" as AssistanceType,
    title: "Financial Hardship",
    description:
      "General financial assistance for qualifying hardship.",
    icon: FiDollarSign,
  },
  {
    id: "housing" as AssistanceType,
    title: "Housing Expenses",
    description:
      "Help with qualifying rent or housing-related expenses.",
    icon: FiHome,
  },
  {
    id: "utilities" as AssistanceType,
    title: "Essential Bills",
    description:
      "Assistance with qualifying essential household bills.",
    icon: FiZap,
  },
  {
    id: "emergency" as AssistanceType,
    title: "Family Emergency",
    description:
      "Support for qualifying unexpected emergencies.",
    icon: FiHeart,
  },
];

const paymentMethods = [
  {
    id: "cash_delivery" as PaymentMethod,
    title: "Cash Delivery",
    description:
      "Receive approved assistance by cash delivery.",
  },
  {
    id: "paypal" as PaymentMethod,
    title: "PayPal",
    description:
      "Receive approved assistance through PayPal.",
  },
  {
    id: "bank_transfer" as PaymentMethod,
    title: "Bank Transfer",
    description:
      "Receive approved assistance by bank transfer.",
  },
  {
    id: "cash_app" as PaymentMethod,
    title: "Cash App",
    description:
      "Receive approved assistance through Cash App.",
  },
  {
    id: "venmo" as PaymentMethod,
    title: "Venmo",
    description:
      "Receive approved assistance through Venmo.",
  },
  {
    id: "zelle" as PaymentMethod,
    title: "Zelle",
    description:
      "Receive approved assistance through Zelle.",
  },
  {
    id: "check" as PaymentMethod,
    title: "Check",
    description:
      "Receive approved assistance by check.",
  },
  {
    id: "other" as PaymentMethod,
    title: "Other",
    description:
      "Use another preferred receiving method.",
  },
];

function GrantApplicationPageContent() {
  const searchParams = useSearchParams();
  const supabase = createClient();

  const [assistanceType, setAssistanceType] =
    useState<AssistanceType>("financial");

  const [paymentMethod, setPaymentMethod] =
    useState<PaymentMethod>("cash_delivery");

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  const [amount, setAmount] = useState("");
  const [monthlyIncome, setMonthlyIncome] = useState("");
  const [monthlyExpenses, setMonthlyExpenses] = useState("");
  const [employmentStatus, setEmploymentStatus] = useState("");

  const [description, setDescription] = useState("");
  const [additionalInfo, setAdditionalInfo] = useState("");

  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [paymentDetails, setPaymentDetails] = useState("");

  const [agreeToTerms, setAgreeToTerms] = useState(false);

  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const type = searchParams.get("type");

    if (
      type === "financial" ||
      type === "housing" ||
      type === "utilities" ||
      type === "emergency"
    ) {
      setAssistanceType(type);
    }
  }, [searchParams]);

  const paymentFieldLabel = () => {
    switch (paymentMethod) {
      case "paypal":
        return "PayPal Email";

      case "bank_transfer":
        return "Bank Transfer Contact Information";

      case "cash_app":
        return "Cash App Username";

      case "venmo":
        return "Venmo Username";

      case "zelle":
        return "Zelle Email or Phone Number";

      case "check":
        return "Mailing Information";

      case "other":
        return "Preferred Payment Information";

      default:
        return "Payment Information";
    }
  };

  const paymentPlaceholder = () => {
    switch (paymentMethod) {
      case "paypal":
        return "Enter the email associated with your PayPal account";

      case "bank_transfer":
        return "Enter the appropriate bank transfer contact information";

      case "cash_app":
        return "Example: $username";

      case "venmo":
        return "Example: @username";

      case "zelle":
        return "Enter the email address or phone number used for Zelle";

      case "check":
        return "Enter the mailing information where the check should be sent";

      case "other":
        return "Enter the information needed for your preferred method";

      default:
        return "Enter payment information";
    }
  };

  const handleSubmit = async (
    e: React.FormEvent<HTMLFormElement>,
  ) => {
    e.preventDefault();
    setError("");

    if (!amount || Number(amount) <= 0) {
      setError(
        "Please enter the amount of assistance you are requesting.",
      );
      return;
    }

    if (!fullName.trim()) {
      setError("Please enter your full name.");
      return;
    }

    if (!email.trim()) {
      setError("Please enter your email address.");
      return;
    }

    if (!phone.trim()) {
      setError("Please enter your phone number.");
      return;
    }

    if (!employmentStatus) {
      setError(
        "Please select your employment status.",
      );
      return;
    }

    if (!monthlyIncome) {
      setError(
        "Please enter your monthly income.",
      );
      return;
    }

    if (!monthlyExpenses) {
      setError(
        "Please enter your monthly expenses.",
      );
      return;
    }

    if (!description.trim()) {
      setError(
        "Please explain the financial hardship or need.",
      );
      return;
    }

    if (
      paymentMethod === "cash_delivery" &&
      !deliveryAddress.trim()
    ) {
      setError(
        "Please enter the address for cash delivery.",
      );
      return;
    }

    if (
      paymentMethod !== "cash_delivery" &&
      !paymentDetails.trim()
    ) {
      setError(
        `Please enter your ${paymentFieldLabel().toLowerCase()}.`,
      );
      return;
    }

    if (!agreeToTerms) {
      setError(
        "Please confirm that the information provided is accurate.",
      );
      return;
    }

    try {
      setSubmitting(true);

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) {
        throw userError;
      }

      if (!user) {
        setError(
          "Please sign in to your account before submitting an application.",
        );
        return;
      }

      const assistanceTitle =
        assistanceTypes.find(
          (item) => item.id === assistanceType,
        )?.title || "Financial Assistance";

      const paymentTitle =
        paymentMethods.find(
          (method) => method.id === paymentMethod,
        )?.title || "Selected Payment Method";

      const note = [
        `Applicant Name: ${fullName.trim()}`,
        `Email: ${email.trim()}`,
        `Phone: ${phone.trim()}`,
        `Monthly Income: $${Number(monthlyIncome).toFixed(2)}`,
        `Monthly Expenses: $${Number(monthlyExpenses).toFixed(2)}`,
        `Employment Status: ${employmentStatus}`,
        `Reason: ${description.trim()}`,
        additionalInfo.trim()
          ? `Additional Information: ${additionalInfo.trim()}`
          : "",
        `Receiving Method: ${paymentTitle}`,
        paymentMethod === "cash_delivery"
          ? `Delivery Address: ${deliveryAddress.trim()}`
          : `Payment Information: ${paymentDetails.trim()}`,
      ]
        .filter(Boolean)
        .join("\n");

      const { error: insertError } =
        await supabase
          .from("grant_requests")
          .insert({
            user_id: user.id,
            amount: Number(amount),
            purpose: assistanceTitle,
            status: "pending",
            note,
          });

      if (insertError) {
        throw insertError;
      }

      setSubmitted(true);

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Unable to submit your application. Please try again.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    const assistanceTitle =
      assistanceTypes.find(
        (item) => item.id === assistanceType,
      )?.title || "Financial Assistance";

    const paymentTitle =
      paymentMethods.find(
        (method) => method.id === paymentMethod,
      )?.title || "Selected Payment Method";

    return (
      <main className="ff-product-page ff-grant-application min-h-screen !bg-[#F1F3F6] !text-[#111318]">
        <header className="border-b !border-[#E2E5E9] !bg-white">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
            <Link
              href="/dashboard"
              className="text-xl font-bold tracking-tight"
            >
              <span className="!text-[#111318]">Flash</span>
              <span className="!text-[#B51F35]">Finance</span>
            </Link>

            <Link
              href="/dashboard"
              className="text-sm font-medium !text-[#69707D] transition hover:!text-[#B51F35]"
            >
              Return to Dashboard
            </Link>
          </div>
        </header>

        <section className="px-6 py-16">
          <div className="mx-auto max-w-2xl">
            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-8 text-center shadow-[0_10px_40px_rgba(0,0,0,0.07)] md:p-12">
              <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full !bg-[#B51F35]">
                <FiCheck className="h-10 w-10 text-white" />
              </div>

              <h1 className="text-3xl font-bold !text-[#111318]">
                Application Submitted Successfully
              </h1>

              <p className="mx-auto mt-4 max-w-xl text-base leading-7 !text-[#69707D]">
                Thank you for choosing FlashFinance to submit your financial
                assistance request. Your application has been received and
                is now ready for review.
              </p>

              <div className="mt-8 rounded-2xl !border !border-[#E2E5E9] !bg-[#F8F9FB] p-6 text-left">
                <div className="flex items-center justify-between border-b !border-[#E2E5E9] pb-4">
                  <span className="text-sm !text-[#9298A3]">
                    Assistance Type
                  </span>

                  <span className="font-semibold !text-[#111318]">
                    {assistanceTitle}
                  </span>
                </div>

                <div className="flex items-center justify-between border-b !border-[#E2E5E9] py-4">
                  <span className="text-sm !text-[#9298A3]">
                    Amount Requested
                  </span>

                  <span className="font-semibold !text-[#B51F35]">
                    ${Number(amount).toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-4">
                  <span className="text-sm !text-[#9298A3]">
                    Preferred Payment
                  </span>

                  <span className="font-semibold !text-[#111318]">
                    {paymentTitle}
                  </span>
                </div>
              </div>

              <div className="mt-6 rounded-2xl !border !border-[#B51F35]/20 !bg-[#B51F35]/5 p-5 text-left">
                <div className="flex gap-3">
                  <FiAlertCircle className="mt-0.5 h-5 w-5 shrink-0 !text-[#B51F35]" />

                  <div className="text-sm leading-6 !text-[#69707D]">
                    <p>
                      We care about you, and we are grateful that you chose
                      FlashFinance to reach out for support during this time.
                      Many people and families have benefited from financial
                      assistance programs, and we are committed to providing
                      support to those who qualify.
                    </p>

                    <p className="mt-4">
                      Your application has been successfully received. Our
                      team will carefully review the information you provided
                      and get back to you with an update as soon as possible.
                    </p>

                    <p className="mt-4">
                      We are happy that you considered FlashFinance when you
                      needed assistance, and we sincerely appreciate your
                      trust in us. Thank you for giving us the opportunity to
                      review your request and hopefully be of help to you.
                    </p>

                    <p className="mt-4">
                      United Power to Success and Focus is dedicated to
                      supporting Deaf people, hearing individuals, and retired
                      workers in our communities through programs created to
                      provide meaningful assistance and opportunities for
                      those who qualify.
                    </p>

                    <div className="mt-5 rounded-xl !border !border-[#E2E5E9] !bg-white p-4">
                      <p className="font-semibold !text-[#111318]">
                        What happens next
                      </p>

                      <p className="mt-2 !text-[#69707D]">
                        Your application will now be reviewed by our team.
                        If your application is approved, the approved
                        assistance will be sent using your selected payment
                        method and the payment information you provided.
                      </p>

                      <p className="mt-3 !text-[#69707D]">
                        If the review team needs additional information or
                        documentation before completing the review, you will
                        receive a message in your FlashFinance account
                        explaining exactly what is needed.
                      </p>

                      <p className="mt-3 !text-[#69707D]">
                        Please check your FlashFinance account regularly for
                        application updates and messages from the review team.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <Link
                href="/dashboard"
                className="mt-8 inline-flex items-center justify-center gap-2 rounded-xl !bg-[#B51F35] px-6 py-3.5 text-sm font-bold text-white transition hover:!bg-[#991B30]"
              >
                Return to Dashboard
                <FiArrowRight />
              </Link>
            </div>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="ff-product-page ff-grant-application min-h-screen !bg-[#F1F3F6] !text-[#111318]">
      <header className="border-b !border-[#E2E5E9] !bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
          <Link
            href="/dashboard"
            className="text-2xl font-bold tracking-tight"
          >
            <span className="!text-[#111318]">Flash</span>
            <span className="!text-[#B51F35]">Finance</span>
          </Link>

          <Link
            href="/grants"
            className="inline-flex items-center gap-2 text-sm font-medium !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            <FiArrowLeft />
            Back to Financial Assistance
          </Link>
        </div>
      </header>

      <section className="relative overflow-hidden border-b !border-[#0B0E17] !bg-[#0B0E17]">
        <div className="absolute right-0 top-0 h-72 w-72 rounded-full bg-[#B51F35]/15 blur-3xl" />
        <div className="absolute bottom-0 left-0 h-64 w-64 rounded-full bg-[#C9213A]/10 blur-3xl" />

        <div className="relative mx-auto max-w-7xl px-6 py-14">
          <div className="max-w-4xl">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#B51F35]/40 bg-[#B51F35]/10 px-4 py-2 text-sm font-semibold !text-[#C9213A]">
              <FiFileText />
              Financial Assistance Application
            </div>

            <h1 className="text-4xl font-bold tracking-tight text-white md:text-5xl">
              Apply for financial assistance
            </h1>

            <p className="mt-5 max-w-3xl text-lg leading-8 !text-[#B8BDC6]">
              Complete the application below with your requested amount,
              financial information, hardship details, and preferred method
              for receiving approved assistance.
            </p>

            <div className="mt-7 rounded-2xl border border-white/10 !bg-[#111827] p-5 md:p-6">
              <div className="flex gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl !bg-[#B51F35]">
                  <FiUsers className="h-5 w-5 text-white" />
                </div>

                <div>
                  <h2 className="text-base font-bold !text-[#C9213A]">
                    United Power to Success and Focus
                  </h2>

                  <p className="mt-2 max-w-3xl text-sm leading-6 !text-[#B8BDC6]">
                    We are United Power to Success and Focus, an organization
                    dedicated to supporting Deaf people, hearing individuals,
                    and retired workers in our communities.
                  </p>

                  <p className="mt-2 max-w-3xl text-sm leading-6 !text-[#9298A3]">
                    We work to connect eligible individuals and families with
                    resources and financial assistance opportunities.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="!bg-[#F1F3F6] px-6 py-10">
        <div className="mx-auto max-w-5xl">
          <form
            onSubmit={handleSubmit}
            className="space-y-8"
          >
            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="mb-6">
                <p className="text-sm font-semibold !text-[#B51F35]">
                  STEP 1
                </p>

                <h2 className="mt-1 text-2xl font-bold !text-[#111318]">
                  What type of assistance do you need?
                </h2>

                <p className="mt-2 text-sm !text-[#69707D]">
                  Select the category that best describes your situation.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                {assistanceTypes.map((item) => {
                  const Icon = item.icon;
                  const selected =
                    assistanceType === item.id;

                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() =>
                        setAssistanceType(item.id)
                      }
                      className={`rounded-2xl border p-5 text-left transition ${
                        selected
                          ? "!border-[#B51F35] !bg-[#B51F35] text-white shadow-lg shadow-[#B51F35]/10"
                          : "!border-[#E2E5E9] !bg-[#F8F9FB] !text-[#111318] hover:!border-[#B51F35]/40 hover:!bg-white"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div
                          className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                            selected
                              ? "bg-white/15"
                              : "!bg-[#B51F35]/10"
                          }`}
                        >
                          <Icon
                            className={`h-5 w-5 ${
                              selected
                                ? "text-white"
                                : "!text-[#B51F35]"
                            }`}
                          />
                        </div>

                        {selected && (
                          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-white">
                            <FiCheck className="h-4 w-4 !text-[#B51F35]" />
                          </div>
                        )}
                      </div>

                      <h3 className="mt-5 font-bold">
                        {item.title}
                      </h3>

                      <p
                        className={`mt-2 text-sm leading-6 ${
                          selected
                            ? "text-white/75"
                            : "!text-[#69707D]"
                        }`}
                      >
                        {item.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="mb-6">
                <p className="text-sm font-semibold !text-[#B51F35]">
                  STEP 2
                </p>

                <h2 className="mt-1 text-2xl font-bold !text-[#111318]">
                  How much assistance are you requesting?
                </h2>
              </div>

              <label className="block text-sm font-semibold !text-[#252932]">
                Amount Requested
              </label>

              <div className="relative mt-2">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-semibold !text-[#B51F35]">
                  $
                </span>

                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={amount}
                  onChange={(e) =>
                    setAmount(e.target.value)
                  }
                  placeholder="0.00"
                  className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-4 pl-9 pr-4 text-lg font-semibold !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                />
              </div>

              <p className="mt-2 text-sm !text-[#69707D]">
                Enter the total amount you are requesting for your qualifying
                need.
              </p>
            </div>

            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="mb-6">
                <p className="text-sm font-semibold !text-[#B51F35]">
                  STEP 3
                </p>

                <h2 className="mt-1 text-2xl font-bold !text-[#111318]">
                  Personal information
                </h2>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label className="text-sm font-semibold !text-[#252932]">
                    Full Name
                  </label>

                  <div className="relative mt-2">
                    <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#9298A3]" />

                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) =>
                        setFullName(e.target.value)
                      }
                      placeholder="Enter your full name"
                      className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-11 pr-4 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold !text-[#252932]">
                    Email Address
                  </label>

                  <div className="relative mt-2">
                    <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#9298A3]" />

                    <input
                      type="email"
                      value={email}
                      onChange={(e) =>
                        setEmail(e.target.value)
                      }
                      placeholder="you@example.com"
                      className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-11 pr-4 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold !text-[#252932]">
                    Phone Number
                  </label>

                  <div className="relative mt-2">
                    <FiPhone className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#9298A3]" />

                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) =>
                        setPhone(e.target.value)
                      }
                      placeholder="Enter your phone number"
                      className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-11 pr-4 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold !text-[#252932]">
                    Employment Status
                  </label>

                  <div className="relative mt-2">
                    <FiBriefcase className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#9298A3]" />

                    <select
                      value={employmentStatus}
                      onChange={(e) =>
                        setEmploymentStatus(
                          e.target.value,
                        )
                      }
                      className="w-full appearance-none rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-11 pr-4 text-sm !text-[#111318] outline-none focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    >
                      <option value="">
                        Select status
                      </option>
                      <option value="employed">
                        Employed
                      </option>
                      <option value="self_employed">
                        Self-employed
                      </option>
                      <option value="part_time">
                        Part-time
                      </option>
                      <option value="unemployed">
                        Unemployed
                      </option>
                      <option value="retired">
                        Retired
                      </option>
                      <option value="student">
                        Student
                      </option>
                      <option value="other">
                        Other
                      </option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="mb-6">
                <p className="text-sm font-semibold !text-[#B51F35]">
                  STEP 4
                </p>

                <h2 className="mt-1 text-2xl font-bold !text-[#111318]">
                  Financial information
                </h2>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label className="text-sm font-semibold !text-[#252932]">
                    Monthly Income
                  </label>

                  <div className="relative mt-2">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-semibold !text-[#B51F35]">
                      $
                    </span>

                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={monthlyIncome}
                      onChange={(e) =>
                        setMonthlyIncome(
                          e.target.value,
                        )
                      }
                      placeholder="0.00"
                      className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-9 pr-4 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold !text-[#252932]">
                    Monthly Expenses
                  </label>

                  <div className="relative mt-2">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-semibold !text-[#B51F35]">
                      $
                    </span>

                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={monthlyExpenses}
                      onChange={(e) =>
                        setMonthlyExpenses(
                          e.target.value,
                        )
                      }
                      placeholder="0.00"
                      className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-9 pr-4 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="mb-6">
                <p className="text-sm font-semibold !text-[#B51F35]">
                  STEP 5
                </p>

                <h2 className="mt-1 text-2xl font-bold !text-[#111318]">
                  Tell us about your situation
                </h2>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  Explain the financial hardship or need that led you to
                  request assistance.
                </p>
              </div>

              <label className="text-sm font-semibold !text-[#252932]">
                Why are you requesting assistance?
              </label>

              <textarea
                value={description}
                onChange={(e) =>
                  setDescription(e.target.value)
                }
                rows={6}
                placeholder="Please explain your current financial situation and what the requested assistance would help you cover."
                className="mt-2 w-full resize-none rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] p-4 text-sm leading-6 !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
              />

              <label className="mt-6 block text-sm font-semibold !text-[#252932]">
                Additional Information
                <span className="ml-2 font-normal !text-[#9298A3]">
                  Optional
                </span>
              </label>

              <textarea
                value={additionalInfo}
                onChange={(e) =>
                  setAdditionalInfo(e.target.value)
                }
                rows={4}
                placeholder="Add anything else you would like the review team to know."
                className="mt-2 w-full resize-none rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] p-4 text-sm leading-6 !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
              />
            </div>

            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="mb-6">
                <p className="text-sm font-semibold !text-[#B51F35]">
                  STEP 6
                </p>

                <h2 className="mt-1 text-2xl font-bold !text-[#111318]">
                  How would you like to receive approved assistance?
                </h2>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  Select your preferred receiving method.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {paymentMethods.map((method) => {
                  const selected =
                    paymentMethod === method.id;

                  return (
                    <button
                      key={method.id}
                      type="button"
                      onClick={() => {
                        setPaymentMethod(method.id);
                        setPaymentDetails("");
                        setDeliveryAddress("");
                      }}
                      className={`relative rounded-2xl border p-4 text-left transition ${
                        selected
                          ? "!border-[#B51F35] !bg-[#B51F35] text-white shadow-lg shadow-[#B51F35]/10"
                          : "!border-[#E2E5E9] !bg-[#F8F9FB] !text-[#111318] hover:!border-[#B51F35]/40 hover:!bg-white"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div
                          className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                            selected
                              ? "bg-white/15"
                              : "!bg-[#B51F35]/10"
                          }`}
                        >
                          <FiCreditCard
                            className={
                              selected
                                ? "text-white"
                                : "!text-[#B51F35]"
                            }
                          />
                        </div>

                        {selected && (
                          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-white">
                            <FiCheck className="h-3 w-3 !text-[#B51F35]" />
                          </div>
                        )}
                      </div>

                      <h3 className="mt-4 text-sm font-bold">
                        {method.title}
                      </h3>

                      <p
                        className={`mt-1 text-xs leading-5 ${
                          selected
                            ? "text-white/75"
                            : "!text-[#69707D]"
                        }`}
                      >
                        {method.description}
                      </p>
                    </button>
                  );
                })}
              </div>

              {paymentMethod === "cash_delivery" && (
                <div className="mt-6 rounded-2xl !border !border-[#E2E5E9] !bg-[#F8F9FB] p-5">
                  <label className="text-sm font-semibold !text-[#252932]">
                    Cash Delivery Address
                  </label>

                  <div className="relative mt-2">
                    <FiMapPin className="absolute left-4 top-4 !text-[#B51F35]" />

                    <textarea
                      value={deliveryAddress}
                      onChange={(e) =>
                        setDeliveryAddress(
                          e.target.value,
                        )
                      }
                      rows={3}
                      placeholder="Enter the address where approved cash assistance should be delivered."
                      className="w-full resize-none rounded-xl !border !border-[#E2E5E9] !bg-white p-4 pl-11 text-sm leading-6 !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    />
                  </div>
                </div>
              )}

              {paymentMethod !== "cash_delivery" && (
                <div className="mt-6 rounded-2xl !border !border-[#E2E5E9] !bg-[#F8F9FB] p-5">
                  <label className="text-sm font-semibold !text-[#252932]">
                    {paymentFieldLabel()}
                  </label>

                  <input
                    type="text"
                    value={paymentDetails}
                    onChange={(e) =>
                      setPaymentDetails(
                        e.target.value,
                      )
                    }
                    placeholder={paymentPlaceholder()}
                    className="mt-2 w-full rounded-xl !border !border-[#E2E5E9] !bg-white px-4 py-3.5 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                  />

                  <div className="mt-3 flex gap-2 text-xs leading-5 !text-[#69707D]">
                    <FiShield className="mt-0.5 h-4 w-4 shrink-0 !text-[#B51F35]" />

                    <p>
                      Only provide the contact or receiving information
                      needed for your selected method. Never provide a
                      password, PIN, security code, or one-time verification
                      code.
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="flex items-start gap-3">
                <button
                  type="button"
                  onClick={() =>
                    setAgreeToTerms(!agreeToTerms)
                  }
                  className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border transition ${
                    agreeToTerms
                      ? "!border-[#B51F35] !bg-[#B51F35] text-white"
                      : "!border-[#D2D6DC] !bg-[#F1F3F6]"
                  }`}
                >
                  {agreeToTerms && (
                    <FiCheck className="h-4 w-4" />
                  )}
                </button>

                <div>
                  <p className="text-sm font-semibold !text-[#111318]">
                    I confirm that the information I provided is accurate
                    and complete.
                  </p>

                  <p className="mt-1 text-sm leading-6 !text-[#69707D]">
                    I understand that my application will be reviewed based
                    on the information provided and that additional
                    information may be requested if needed.
                  </p>
                </div>
              </div>
            </div>

            {error && (
              <div className="rounded-2xl !border !border-[#B51F35]/25 !bg-[#B51F35]/5 p-4">
                <div className="flex items-start gap-3">
                  <FiAlertCircle className="mt-0.5 h-5 w-5 shrink-0 !text-[#B51F35]" />

                  <p className="text-sm leading-6 !text-[#991B30]">
                    {error}
                  </p>
                </div>
              </div>
            )}

            <div className="rounded-3xl !border !border-[#B51F35]/20 !bg-white p-6 shadow-[0_5px_25px_rgba(0,0,0,0.05)] md:p-8">
              <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 className="text-xl font-bold !text-[#111318]">
                    Ready to submit your application?
                  </h2>

                  <p className="mt-2 max-w-xl text-sm leading-6 !text-[#69707D]">
                    Review your information before submitting your financial
                    assistance application.
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl !bg-[#B51F35] px-7 py-4 text-sm font-bold text-white transition hover:!bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {submitting
                    ? "Submitting..."
                    : "Submit Application"}
                  <FiArrowRight />
                </button>
              </div>
            </div>
          </form>
        </div>
      </section>

      <footer className="border-t !border-[#E2E5E9] !bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-6 py-8 text-sm !text-[#69707D] md:flex-row md:items-center md:justify-between">
          <p>
            © 2026 FlashFinance. All rights reserved.
          </p>

          <div className="flex items-center gap-2">
            <FiShield className="!text-[#B51F35]" />
            <span>
              Your information should be handled securely.
            </span>
          </div>
        </div>
      </footer>
    </main>
  );
}

export default function GrantApplicationPage() {
  return (
    <Suspense
      fallback={
        <main className="ff-product-page min-h-screen flex items-center justify-center !bg-[#F1F3F6] !text-[#111318]">
          <div className="text-center">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-2 !border-[#B51F35] border-t-transparent" />

            <p className="mt-4 text-sm !text-[#69707D]">
              Loading application...
            </p>
          </div>
        </main>
      }
    >
      <GrantApplicationPageContent />
    </Suspense>
  );
}