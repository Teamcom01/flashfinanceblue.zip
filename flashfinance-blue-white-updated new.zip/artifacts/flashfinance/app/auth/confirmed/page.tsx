"use client";

import Link from "next/link";

export default function ConfirmedPage() {
  return (
    <main className="flex min-h-screen items-center justify-center !bg-[#F1F3F6] px-6 py-12 !text-[#111318]">
      <div className="w-full max-w-md text-center">
        <div className="mb-10">
          <Link href="/" className="text-3xl font-bold tracking-wide">
            <span className="!text-[#0B0E17]">FLASH</span>
            <span className="!text-[#B51F35]">FINANCE</span>
          </Link>
        </div>

        <div className="rounded-[28px] !border !border-[#E2E5E9] !bg-white p-8 shadow-[0_12px_40px_rgba(0,0,0,0.07)]">
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full !bg-[#B51F35] text-3xl font-bold text-white">
            ✓
          </div>

          <h1 className="text-3xl font-bold !text-[#111318]">
            Email Confirmed!
          </h1>

          <p className="mt-4 text-base leading-7 !text-[#69707D]">
            Your email address has been successfully verified.
          </p>

          <p className="mt-3 text-base leading-7 !text-[#69707D]">
            Your FlashFinance account is now ready. You can log in to access
            your account.
          </p>

          <Link
            href="/login"
            className="mt-8 block w-full rounded-2xl !bg-[#B51F35] py-3.5 font-bold text-white transition hover:!bg-[#991B30]"
          >
            Continue to Login
          </Link>

          <Link
            href="/"
            className="mt-5 block text-sm !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            ← Back to FlashFinance
          </Link>
        </div>
      </div>
    </main>
  );
}