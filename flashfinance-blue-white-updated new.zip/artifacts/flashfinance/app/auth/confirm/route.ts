import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);

  const token_hash = searchParams.get("token_hash");
  const type = searchParams.get("type");

  if (!token_hash || !type) {
    return NextResponse.redirect(
      `${origin}/auth/confirmed?status=error&message=Invalid%20confirmation%20link`
    );
  }

  const cookieStore = await cookies();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options);
            });
          } catch {
            // Cookies can fail to be written in some server contexts.
          }
        },
      },
    }
  );

  const { error } = await supabase.auth.verifyOtp({
    token_hash,
    type: type as "signup" | "email",
  });

  if (error) {
    console.error("FlashFinance email confirmation error:", error);

    return NextResponse.redirect(
      `${origin}/auth/confirmed?status=error&message=${encodeURIComponent(
        "This confirmation link is invalid or has expired. Please request a new confirmation email."
      )}`
    );
  }

  return NextResponse.redirect(
    `${origin}/auth/confirmed?status=success`
  );
}