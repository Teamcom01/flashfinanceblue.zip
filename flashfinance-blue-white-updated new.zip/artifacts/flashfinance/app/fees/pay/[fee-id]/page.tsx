"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ComponentType,
} from "react";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";

import {
  FiAlertCircle,
  FiArrowLeft,
  FiCheckCircle,
  FiChevronRight,
  FiCreditCard,
  FiDollarSign,
  FiFileText,
  FiInfo,
  FiRefreshCw,
  FiShield,
  FiUpload,
} from "react-icons/fi";

import {
  SiBitcoin,
  SiCashapp,
  SiPaypal,
  SiVenmo,
  SiZelle,
} from "react-icons/si";

import { FaUniversity } from "react-icons/fa";

import { createClient } from "@/lib/supabase";

type FeeRequest = {
  id: string;
  user_id: string;
  amount: number;
  fee_type: string | null;
  title: string | null;
  message: string | null;
  status: string | null;
  created_at: string;
  updated_at: string;
};

type PaymentTransaction = {
  id: string;
  amount: number;
  status: string | null;
  reference: string | null;
  type: string | null;
  description: string | null;
  created_at: string;
};

type AdminPaymentInstruction = {
  id: string;
  user_id: string;
  payment_method: PaymentMethodKey;
  amount: number | null;
  destination: string;
  note: string;
  status: string;
  reference: string | null;
  created_at: string;
};

type PaymentMethodKey =
  | "paypal"
  | "cashapp"
  | "bitcoin"
  | "bank"
  | "zelle"
  | "venmo"
  | "chime";

type PaymentMethodConfig = {
  key: PaymentMethodKey;
  name: string;
  shortDescription: string;
  icon: ComponentType<{
    size?: number;
    className?: string;
  }>;
  iconClass: string;
  iconBackground: string;
};

type PaymentInformationField = {
  label: string;
  value: string;
};

type DemoPaymentInformation = {
  fields: PaymentInformationField[];
  instructions: string;
};

const PAYMENT_METHODS: PaymentMethodConfig[] = [
  {
    key: "paypal",
    name: "PayPal",
    shortDescription: "Pay through your PayPal account.",
    icon: SiPaypal,
    iconClass: "text-[#0070BA]",
    iconBackground: "bg-[#E8F4FB]",
  },
  {
    key: "cashapp",
    name: "Cash App",
    shortDescription: "Send your payment through Cash App.",
    icon: SiCashapp,
    iconClass: "text-[#00C244]",
    iconBackground: "bg-[#E8F9EE]",
  },
  {
    key: "bitcoin",
    name: "Bitcoin",
    shortDescription: "Submit a Bitcoin payment for review.",
    icon: SiBitcoin,
    iconClass: "text-[#F7931A]",
    iconBackground: "bg-[#FFF4E5]",
  },
  {
    key: "bank",
    name: "Bank Transfer",
    shortDescription: "Pay your fee by bank transfer.",
    icon: FaUniversity,
    iconClass: "text-[#2563EB]",
    iconBackground: "bg-[#EAF1FF]",
  },
  {
    key: "zelle",
    name: "Zelle",
    shortDescription: "Submit your Zelle payment details.",
    icon: SiZelle,
    iconClass: "text-[#6D28D9]",
    iconBackground: "bg-[#F1EAFE]",
  },
  {
    key: "venmo",
    name: "Venmo",
    shortDescription: "Pay your fee using Venmo.",
    icon: SiVenmo,
    iconClass: "text-[#008CFF]",
    iconBackground: "bg-[#E8F5FF]",
  },
  {
    key: "chime",
    name: "Chime",
    shortDescription: "Pay your outstanding fee using Chime.",
    icon: FiCreditCard,
    iconClass: "text-[#16A34A]",
    iconBackground: "bg-[#EAF8EE]",
  },
];


const DEMO_PAYMENT_INFORMATION: Record<
  PaymentMethodKey,
  DemoPaymentInformation
> = {
  paypal: {
    fields: [
      {
        label: "PayPal Email",
        value: "Paypalinvestpay@FlashFinance.com",
      },
      {
        label: "Account Name",
        value: "Flash Finance",
      },
    ],
    instructions:
      "Send your selected payment amount to the PayPal account shown above. Enter your payment reference after completing the payment and upload your receipt.",
  },

  cashapp: {
    fields: [
      {
        label: "Cash App",
        value: "$FlashFinance",
      },
      {
        label: "Account Name",
        value: "Flash Finance",
      },
    ],
    instructions:
      "Send your selected payment amount using the Cash App information shown above. Enter your payment reference and upload your receipt after completing the payment.",
  },

  bitcoin: {
    fields: [
      {
        label: "Bitcoin Wallet",
        value:
          "1zq2xVz3TwRNMyAFeKXAt5AKFr7QAEs9V",
      },
      {
        label: "Payment Network",
        value: "Bitcoin Network",
      },
    ],
    instructions:
      "Send your selected payment amount to the Bitcoin wallet shown above. After the transaction is made, enter your transaction reference and upload your receipt for review.",
  },

  bank: {
    fields: [
      {
        label: "Bank Name",
        value: "Bank of America",
      },
      {
        label: "Account Name",
        value: "FlashFinance Invest",
      },
      {
        label: "Account Number",
        value: "6000535341",
      },
      {
        label: "Routing Number",
        value: "322271627",
      },
    ],
    instructions:
      "Use your verified business bank information to complete the transfer. Enter the transfer reference after completing the payment and upload your payment receipt.",
  },

  zelle: {
    fields: [
      {
        label: "Zelle Email",
        value: "zelleinvestpay@FlashFinance.com",
      },
      {
        label: "Recipient Name",
        value: "Flash Finance",
      },
    ],
    instructions:
      "Send your selected payment amount using the Zelle recipient information shown above. Enter your payment reference and upload your receipt for review.",
  },

  venmo: {
    fields: [
      {
        label: "Venmo Username",
        value: "Pay@FlashFinance",
      },
      {
        label: "Account Name",
        value: "Flash Finance",
      },
    ],
    instructions:
      "Send your selected payment amount using the Venmo information shown above. Enter your payment reference and upload your receipt after completing the payment.",
  },

  chime: {
    fields: [
      {
        label: "Chime Account",
        value: "Chimeinvestpay@FlashFinance.com",
      },
      {
        label: "Account Name",
        value: "Flash Finance",
      },
    ],
    instructions:
      "Complete your Chime payment using the information shown above. Enter your payment reference and upload your receipt for review.",
  },
};

type DepositPaymentMethod = {
  name: string;
  details: Record<string, unknown> | null;
  is_active: boolean | null;
};

type DepositPaymentFieldDefinition = {
  key: string;
  label: string;
  type?: "text" | "multiline";
};

function parseDepositPaymentDetails(
  details: unknown,
): Record<string, unknown> {
  if (
    details &&
    typeof details === "object" &&
    !Array.isArray(details)
  ) {
    return details as Record<string, unknown>;
  }

  if (typeof details === "string") {
    try {
      const parsed = JSON.parse(details);

      if (
        parsed &&
        typeof parsed === "object" &&
        !Array.isArray(parsed)
      ) {
        return parsed as Record<string, unknown>;
      }

      return {};
    } catch {
      return {
        instructions: details,
      };
    }
  }

  return {};
}

function normalizeDepositPaymentKey(
  value: string,
) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function isForbiddenDepositPaymentKey(
  key: string,
) {
  const normalized =
    normalizeDepositPaymentKey(key);

  return (
    normalized.includes("fee") ||
    normalized.includes("destination") ||
    normalized.includes("walletlabel") ||
    normalized.includes("accounttype") ||
    normalized.includes("bankaddress")
  );
}

function depositStringValueObject(
  value: unknown,
) {
  if (
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean"
  ) {
    return String(value).trim();
  }

  return "";
}

const depositMethodFieldDefinitions: Record<
  PaymentMethodKey,
  DepositPaymentFieldDefinition[]
> = {
  paypal: [
    {
      key: "accountName",
      label: "Account Name",
    },
    {
      key: "email",
      label: "PayPal Email",
    },
  ],

  cashapp: [
    {
      key: "accountName",
      label: "Account Name",
    },
    {
      key: "cashtag",
      label: "Cash App",
    },
  ],

  bitcoin: [
    {
      key: "network",
      label: "Payment Network",
    },
    {
      key: "walletAddress",
      label: "Bitcoin Wallet",
    },
  ],

  bank: [
    {
      key: "bankName",
      label: "Bank Name",
    },
    {
      key: "accountName",
      label: "Account Name",
    },
    {
      key: "accountNumber",
      label: "Account Number",
    },
    {
      key: "routingNumber",
      label: "Routing Number",
    },
    {
      key: "accountType",
      label: "Account Type",
    },
    {
      key: "swiftCode",
      label: "SWIFT / BIC",
    },
  ],

  zelle: [
    {
      key: "accountName",
      label: "Recipient Name",
    },
    {
      key: "emailOrPhone",
      label: "Zelle Email or Phone",
    },
  ],

  venmo: [
    {
      key: "accountName",
      label: "Account Name",
    },
    {
      key: "username",
      label: "Venmo Username",
    },
  ],

  chime: [
    {
      key: "accountName",
      label: "Account Name",
    },
    {
      key: "email",
      label: "Chime Email",
    },
  ],
};

function getDepositFields(
  method: PaymentMethodKey,
) {
  return (
    depositMethodFieldDefinitions[method] ||
    []
  );
}

function getDepositMethodAliases(
  method: PaymentMethodKey,
) {
  switch (method) {
    case "paypal":
      return ["paypal", "paypals"];

    case "cashapp":
      return [
        "cashapp",
        "cash",
        "cashapptransfer",
      ];

    case "bitcoin":
      return ["bitcoin", "btc"];

    case "bank":
      return [
        "banktransfer",
        "bank",
        "wiretransfer",
        "bankwire",
      ];

    case "zelle":
      return ["zelle"];

    case "venmo":
      return ["venmo"];

    case "chime":
      return ["chime"];

    default:
      return [];
  }
}

function getDepositNestedMethodObjects(
  details: Record<string, unknown>,
  method: PaymentMethodKey,
) {
  const aliases =
    getDepositMethodAliases(method).map(
      normalizeDepositPaymentKey,
    );

  const nested: Record<
    string,
    unknown
  >[] = [];

  for (const [key, value] of Object.entries(
    details,
  )) {
    const normalizedKey =
      normalizeDepositPaymentKey(key);

    if (
      aliases.includes(normalizedKey) &&
      value &&
      typeof value === "object" &&
      !Array.isArray(value)
    ) {
      nested.push(
        value as Record<string, unknown>,
      );
    }
  }

  return nested;
}

function getDepositCandidateKeysForField(
  method: PaymentMethodKey,
  field: DepositPaymentFieldDefinition,
) {
  const methodAliases =
    getDepositMethodAliases(method);

  const fieldAliases: Record<
    string,
    string[]
  > = {
    accountName: [
      "accountname",
      "name",
      "account",
    ],

    email: [
      "email",
      "emailaddress",
    ],

    cashtag: [
      "cashtag",
      "cashtagname",
      "cashtagid",
      "cashtagvalue",
      "cashtagaccount",
      "cashtagusername",
      "cashapptag",
    ],

    network: [
      "network",
      "networkname",
      "chain",
      "blockchain",
    ],

    walletAddress: [
      "walletaddress",
      "address",
      "wallet",
      "walletid",
    ],

    bankName: [
      "bankname",
      "bank",
      "financialinstitution",
    ],

    accountNumber: [
      "accountnumber",
      "acctnumber",
      "accountno",
    ],

    routingNumber: [
      "routingnumber",
      "routing",
      "routingno",
    ],

    swiftCode: [
      "swiftcode",
      "swift",
      "bic",
    ],

    emailOrPhone: [
      "emailorphone",
      "emailphone",
      "emailorphonenumber",
      "phone",
      "phonenumber",
      "zelleemailphone",
    ],

    username: [
      "username",
      "user",
      "venmousername",
    ],
  };

  const aliases =
    fieldAliases[field.key] || [];

  const candidates = new Set<string>();

  for (const alias of methodAliases) {
    for (const fieldAlias of aliases) {
      candidates.add(
        normalizeDepositPaymentKey(
          `${alias}${fieldAlias}`,
        ),
      );

      candidates.add(
        normalizeDepositPaymentKey(
          `deposit${alias}${fieldAlias}`,
        ),
      );

      candidates.add(
        normalizeDepositPaymentKey(
          `${alias}deposit${fieldAlias}`,
        ),
      );

      candidates.add(
        normalizeDepositPaymentKey(
          `deposit${fieldAlias}${alias}`,
        ),
      );
    }
  }

  for (const fieldAlias of aliases) {
    candidates.add(
      normalizeDepositPaymentKey(
        fieldAlias,
      ),
    );

    candidates.add(
      normalizeDepositPaymentKey(
        `deposit${fieldAlias}`,
      ),
    );
  }

  return candidates;
}

function getDepositFieldValue(
  details: Record<string, unknown>,
  method: PaymentMethodKey,
  field: DepositPaymentFieldDefinition,
) {
  const nestedObjects =
    getDepositNestedMethodObjects(
      details,
      method,
    );

  const directEntries =
    Object.entries(details);

  const candidates =
    getDepositCandidateKeysForField(
      method,
      field,
    );

  for (const [key, value] of directEntries) {
    const normalizedKey =
      normalizeDepositPaymentKey(key);

    if (
      isForbiddenDepositPaymentKey(
        normalizedKey,
      )
    ) {
      continue;
    }

    if (
      candidates.has(normalizedKey)
    ) {
      const text =
        depositStringValueObject(value);

      if (text) {
        return text;
      }
    }
  }

  for (const nested of nestedObjects) {
    for (const [key, value] of Object.entries(
      nested,
    )) {
      const normalizedKey =
        normalizeDepositPaymentKey(key);

      if (
        isForbiddenDepositPaymentKey(
          normalizedKey,
        )
      ) {
        continue;
      }

      if (
        candidates.has(normalizedKey)
      ) {
        const text =
          depositStringValueObject(value);

        if (text) {
          return text;
        }
      }

      for (const alias of getDepositMethodAliases(
        method,
      )) {
        const normalizedAlias =
          normalizeDepositPaymentKey(
            alias,
          );

        if (
          normalizedKey.startsWith(
            normalizedAlias,
          )
        ) {
          const withoutAlias =
            normalizedKey.slice(
              normalizedAlias.length,
            );

          if (
            candidates.has(
              normalizedAlias +
                withoutAlias,
            ) ||
            candidates.has(
              withoutAlias,
            )
          ) {
            const text =
              depositStringValueObject(
                value,
              );

            if (text) {
              return text;
            }
          }
        }
      }
    }
  }

  const normalizedField =
    normalizeDepositPaymentKey(
      field.key,
    );

  const fallbackAliases: Record<
    string,
    string[]
  > = {
    accountname: [
      "accountname",
      "name",
    ],

    email: [
      "email",
    ],

    walletaddress: [
      "walletaddress",
      "address",
      "wallet",
    ],

    network: [
      "network",
      "chain",
      "blockchain",
    ],
  };

  for (const key of
    fallbackAliases[normalizedField] ||
    []) {
    const value =
      details[key];

    const text =
      depositStringValueObject(value);

    if (text) {
      return text;
    }
  }

  return "";
}

function getFeePaymentInformationFromAdmin(
  method: PaymentMethodKey,
  detailsInput: unknown,
  fallback: DemoPaymentInformation,
) {
  const rawDetails =
    detailsInput &&
    typeof detailsInput === "object"
      ? (detailsInput as Record<string, unknown>)
      : {};

  const feeDetails =
    rawDetails.fee &&
    typeof rawDetails.fee === "object"
      ? (rawDetails.fee as Record<string, unknown>)
      : {};

  const details =
    Object.keys(feeDetails).length > 0
      ? feeDetails
      : parseDepositPaymentDetails(
          detailsInput,
        );

  const fields =
    getDepositFields(method);

  const adminFields: PaymentInformationField[] =
    [];

  for (const field of fields) {
    const value =
      getDepositFieldValue(
        details,
        method,
        field,
      );

    if (value) {
      adminFields.push({
        label: field.label,
        value,
      });
    }
  }

  const instructionKeys = [
    "instructions",
    "paymentinstructions",
    "instruction",
    "note",
    "paymentnote",
    "message",
    "description",
  ];

  let instructions = "";

  for (const key of instructionKeys) {
    const value =
      details[key];

    const text =
      depositStringValueObject(value);

    if (text) {
      instructions = text;
      break;
    }
  }

  if (!instructions) {
    for (const [
      key,
      value,
    ] of Object.entries(details)) {
      const normalizedKey =
        normalizeDepositPaymentKey(
          key,
        );

      if (
        normalizedKey.includes(
          "instruction",
        ) ||
        normalizedKey.includes(
          "paymentnote",
        )
      ) {
        const text =
          depositStringValueObject(
            value,
          );

        if (text) {
          instructions = text;
          break;
        }
      }
    }
  }

  return {
    fields:
      adminFields.length > 0
        ? adminFields
        : fallback.fields,

    instructions:
      instructions ||
      fallback.instructions,
  };
}
function formatCurrency(
  value: number,
  currency = "USD",
) {
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(
      Number.isFinite(value) ? value : 0,
    );
  } catch {
    return `$${(
      Number.isFinite(value) ? value : 0
    ).toFixed(2)}`;
  }
}

function normalizeCurrency(value: unknown) {
  const text = String(value || "USD")
    .trim()
    .toUpperCase();

  if (!/^[A-Z]{3}$/.test(text)) {
    return "USD";
  }

  return text;
}

function normalizeStatus(value: unknown) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
}

function safeString(value: unknown) {
  return typeof value === "string"
    ? value.trim()
    : "";
}

function firstValue(...values: unknown[]) {
  for (const value of values) {
    const text = safeString(value);

    if (text) {
      return text;
    }
  }

  return "";
}

function normalizePaymentMethod(
  value: unknown,
): PaymentMethodKey | null {
  const text = safeString(value)
    .toLowerCase()
    .replace(/[\s_-]+/g, "");

  if (text.includes("paypal")) {
    return "paypal";
  }

  if (text.includes("cashapp")) {
    return "cashapp";
  }

  if (
    text.includes("bitcoin") ||
    text === "btc"
  ) {
    return "bitcoin";
  }

  if (
    text.includes("bank") ||
    text.includes("wire") ||
    text.includes("transfer")
  ) {
    return "bank";
  }

  if (text.includes("zelle")) {
    return "zelle";
  }

  if (text.includes("venmo")) {
    return "venmo";
  }

  if (text.includes("chime")) {
    return "chime";
  }

  return null;
}

function normalizeAdminPaymentInstruction(
  row: Record<string, unknown>,
): AdminPaymentInstruction | null {
  const paymentMethod =
    normalizePaymentMethod(
      firstValue(
        row.payment_method,
        row.method,
        row.provider,
        row.payment_type,
      ),
    );

  if (!paymentMethod) {
    return null;
  }

  const destination = firstValue(
    row.destination,
    row.payment_destination,
    row.payment_details,
    row.details,
    row.account_details,
    row.instructions,
    row.wallet_address,
    row.account_number,
    row.email,
  );

  const note = firstValue(
    row.note,
    row.payment_note,
    row.message,
    row.description,
    row.payment_instructions,
  );

  return {
    id: safeString(row.id),
    user_id: safeString(row.user_id),
    payment_method: paymentMethod,
    amount:
      typeof row.amount === "number"
        ? row.amount
        : Number(row.amount || 0) || null,
    destination,
    note,
    status:
      safeString(row.status) || "pending",
    reference:
      firstValue(
        row.reference,
        row.payment_reference,
      ) || null,
    created_at: safeString(row.created_at),
  };
}

/**
 * ONLY these statuses count as money actually paid toward the fee.
 *
 * Pending payments do NOT count.
 * Rejected payments do NOT count.
 */
function isApprovedTransaction(
  transaction: PaymentTransaction,
) {
  const status = normalizeStatus(
    transaction.status,
  );

  return [
    "completed",
    "complete",
    "approved",
    "paid",
    "success",
    "successful",
    "confirmed",
  ].includes(status);
}

/**
 * Calculate how much has actually been approved
 * toward ONE specific fee.
 *
 * Important:
 * - type must be fee_payment
 * - reference must equal the fee ID
 * - status must be approved/completed
 *
 * Pending $140 therefore does NOT reduce a $230 fee.
 */
function getPaidAmount(
  fee: FeeRequest,
  transactions: PaymentTransaction[],
) {
  const feeId = safeString(fee.id);

  if (!feeId) {
    return 0;
  }

  const total = transactions
    .filter((transaction) => {
      return (
        normalizeStatus(transaction.type) ===
          "fee_payment" &&
        safeString(transaction.reference) ===
          feeId &&
        isApprovedTransaction(transaction)
      );
    })
    .reduce((sum, transaction) => {
      return (
        sum +
        Math.max(
          Number(transaction.amount) || 0,
          0,
        )
      );
    }, 0);

  return Math.min(
    Math.max(Number(fee.amount) || 0, 0),
    total,
  );
}

function isFeeStillPayable(
  fee: FeeRequest,
  transactions: PaymentTransaction[],
) {
  const feeStatus = normalizeStatus(
    fee.status,
  );

  if (
    [
      "cancelled",
      "canceled",
      "rejected",
    ].includes(feeStatus)
  ) {
    return false;
  }

  const originalAmount = Math.max(
    Number(fee.amount) || 0,
    0,
  );

  const paidAmount = getPaidAmount(
    fee,
    transactions,
  );

  const remaining = Math.max(
    originalAmount - paidAmount,
    0,
  );

  return remaining > 0.000001;
}

function getTransactionStatusLabel(
  status: string | null,
) {
  const normalized = normalizeStatus(status);

  if (
    [
      "completed",
      "complete",
      "approved",
      "paid",
      "success",
      "successful",
      "confirmed",
    ].includes(normalized)
  ) {
    return "Completed";
  }

  if (
    [
      "rejected",
      "declined",
      "failed",
      "cancelled",
      "canceled",
    ].includes(normalized)
  ) {
    return "Rejected";
  }

  return "Pending";
}

function getTransactionStatusClass(
  status: string | null,
) {
  const normalized = normalizeStatus(status);

  if (
    [
      "completed",
      "complete",
      "approved",
      "paid",
      "success",
      "successful",
      "confirmed",
    ].includes(normalized)
  ) {
    return "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300";
  }

  if (
    [
      "rejected",
      "declined",
      "failed",
      "cancelled",
      "canceled",
    ].includes(normalized)
  ) {
    return "bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-300";
  }

  return "bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300";
}

export default function FeePaymentPage() {
  const [paymentMethods, setPaymentMethods] =
    useState(PAYMENT_METHODS);
  const params = useParams();
  const router = useRouter();

  const supabase = useMemo(
    () => createClient(),
    [],
  );

  const feeIdParam = params?.["fee-id"];

  const feeId = useMemo(() => {
    if (Array.isArray(feeIdParam)) {
      return feeIdParam[0] || "";
    }

    return typeof feeIdParam === "string"
      ? feeIdParam
      : "";
  }, [feeIdParam]);

  const [fees, setFees] = useState<
    FeeRequest[]
  >([]);

  const [fee, setFee] =
    useState<FeeRequest | null>(null);

  const [transactions, setTransactions] =
    useState<PaymentTransaction[]>([]);

  const [allFeePayments, setAllFeePayments] =
    useState<PaymentTransaction[]>([]);

  const [
    paymentInstructions,
    setPaymentInstructions,
  ] = useState<
    AdminPaymentInstruction[]
  >([]);

  const [selectedMethod, setSelectedMethod] =
    useState<PaymentMethodKey>("paypal");

  const [currency, setCurrency] =
    useState("USD");

  const [paymentAmount, setPaymentAmount] =
    useState("");

  const [paymentReference, setPaymentReference] =
    useState("");

  const [receiptFileName, setReceiptFileName] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [
    loadingInstructions,
    setLoadingInstructions,
  ] = useState(false);

  const [submitting, setSubmitting] =
    useState(false);

  const [error, setError] =
    useState("");

  const [success, setSuccess] =
    useState("");

  const selectedMethodConfig = useMemo(() => {
    return (
      PAYMENT_METHODS.find(
        (method) =>
          method.key === selectedMethod,
      ) || PAYMENT_METHODS[0]
    );
  }, [selectedMethod]);

  const selectedAdminInstruction =
    useMemo(() => {
      return (
        paymentInstructions.find(
          (instruction) =>
            instruction.payment_method ===
            selectedMethod,
        ) || null
      );
    }, [
      paymentInstructions,
      selectedMethod,
    ]);

  const selectedDemoInformation =
    DEMO_PAYMENT_INFORMATION[
      selectedMethod
    ];

  const selectedAdminPaymentMethod =
    useMemo(() => {
      return (
        paymentMethods.find(
          (method: any) => {
            const methodKey =
              normalizePaymentMethod(
                method?.key ||
                  method?.type ||
                  method?.name,
              );

            return (
              methodKey ===
              selectedMethod
            );
          },
        ) || null
      );
    }, [
      paymentMethods,
      selectedMethod,
    ]);

  const selectedPaymentInformation =
    useMemo(() => {
      const demoInformation =
        DEMO_PAYMENT_INFORMATION[
          selectedMethod
        ];

      const adminMethod =
        selectedAdminPaymentMethod as any;

      if (!adminMethod) {
        return demoInformation;
      }

      return getFeePaymentInformationFromAdmin(
        selectedMethod,
        adminMethod?.details,
        demoInformation,
      );
    }, [
      selectedAdminPaymentMethod,
      selectedMethod,
    ]);

  const totalFeeAmount = useMemo(() => {
    return Math.max(
      0,
      Number(fee?.amount || 0),
    );
  }, [fee]);

  const paidAmount = useMemo(() => {
    if (!fee) {
      return 0;
    }

    return getPaidAmount(
      fee,
      allFeePayments,
    );
  }, [fee, allFeePayments]);

  /**
   * This is the ONLY amount the user is allowed
   * to submit now.
   *
   * Pending payments are intentionally ignored.
   */
  const remainingAmount = useMemo(() => {
    return Math.max(
      0,
      totalFeeAmount - paidAmount,
    );
  }, [
    totalFeeAmount,
    paidAmount,
  ]);

  const enteredPaymentAmount =
    useMemo(() => {
      const value = Number(
        paymentAmount
          .replace(/,/g, "")
          .trim(),
      );

      return Number.isFinite(value)
        ? value
        : 0;
    }, [paymentAmount]);

  const paymentAmountValid =
    enteredPaymentAmount > 0 &&
    enteredPaymentAmount <=
      remainingAmount + 0.000001;

  const paymentAmountError =
    useMemo(() => {
      if (!paymentAmount) {
        return "";
      }

      if (enteredPaymentAmount <= 0) {
        return "Enter an amount greater than $0.00.";
      }

      if (
        enteredPaymentAmount >
        remainingAmount + 0.000001
      ) {
        return `You can pay up to ${formatCurrency(
          remainingAmount,
          currency,
        )}.`;
      }

      return "";
    }, [
      paymentAmount,
      enteredPaymentAmount,
      remainingAmount,
      currency,
    ]);

  const currentSummaryAmount =
    paymentAmountValid
      ? enteredPaymentAmount
      : 0;

  const loadPaymentInstructions =
    useCallback(
      async (userId: string) => {
        setLoadingInstructions(true);

        try {
          const {
            data,
            error: paymentError,
          } = await supabase
            .from("payment_requests")
            .select("*")
            .eq("user_id", userId)
            .order("created_at", {
              ascending: false,
            });

          if (paymentError) {
            console.error(
              "Payment instruction load error:",
              paymentError,
            );

            setPaymentInstructions([]);
            return;
          }

          const normalized =
            (data || [])
              .map((row) =>
                normalizeAdminPaymentInstruction(
                  row as Record<
                    string,
                    unknown
                  >,
                ),
              )
              .filter(
                (
                  item,
                ): item is AdminPaymentInstruction =>
                  item !== null,
              );

          setPaymentInstructions(
            normalized,
          );
        } catch (instructionError) {
          console.error(
            "Payment instruction load error:",
            instructionError,
          );

          setPaymentInstructions([]);
        } finally {
          setLoadingInstructions(false);
        }
      },
      [supabase],
    );

  const loadPage = useCallback(
    async () => {
      setLoading(true);
      setError("");

      try {
        const {
          data: { user },
          error: authError,
        } =
          await supabase.auth.getUser();

        if (authError) {
          throw authError;
        }

        if (!user) {
          router.replace("/login");
          return;
        }

        let loadedFees: FeeRequest[] =
          [];

        let feeLoadError: unknown =
          null;

        try {
          const feeRpcResult =
            await supabase.rpc(
              "get_my_fee_requests",
            );

          if (!feeRpcResult.error) {
            loadedFees =
              (feeRpcResult.data ||
                []) as FeeRequest[];
          } else {
            feeLoadError =
              feeRpcResult.error;

            console.error(
              "Fee request RPC error:",
              feeRpcResult.error,
            );
          }
        } catch (rpcError) {
          feeLoadError = rpcError;

          console.error(
            "Fee request RPC exception:",
            rpcError,
          );
        }

        if (
          loadedFees.length === 0 &&
          feeLoadError
        ) {
          try {
            const {
              data: directFees,
              error: directFeeError,
            } = await supabase
              .from("fee_requests")
              .select(
                "id, user_id, amount, fee_type, title, message, status, created_at, updated_at",
              )
              .eq(
                "user_id",
                user.id,
              )
              .order(
                "created_at",
                {
                  ascending: false,
                },
              );

            if (!directFeeError) {
              loadedFees =
                (directFees ||
                  []) as FeeRequest[];

              feeLoadError = null;
            } else {
              console.error(
                "Direct fee request fallback error:",
                directFeeError,
              );
            }
          } catch (
            directFeeLoadError
          ) {
            console.error(
              "Direct fee request fallback error:",
              directFeeLoadError,
            );
          }
        }

        setFees(loadedFees);

        let accountCurrency = "USD";

        try {
          const {
            data: accountData,
            error: accountError,
          } = await supabase
            .from("accounts")
            .select("currency")
            .eq(
              "user_id",
              user.id,
            )
            .maybeSingle();

          if (
            !accountError &&
            accountData?.currency
          ) {
            accountCurrency =
              normalizeCurrency(
                accountData.currency,
              );
          }
        } catch (
          accountLoadError
        ) {
          console.error(
            "Optional account currency load error:",
            accountLoadError,
          );
        }

        setCurrency(
          accountCurrency,
        );

        /**
         * Load ALL fee_payment transactions for
         * this user.
         *
         * We deliberately do not filter by status
         * because pending and rejected payments
         * must remain visible in history.
         */
        let loadedTransactions: PaymentTransaction[] =
          [];

        try {
          const {
            data: transactionData,
            error: transactionError,
          } = await supabase
            .from("transactions")
            .select(
              "id, amount, status, reference, type, description, created_at",
            )
            .eq(
              "user_id",
              user.id,
            )
            .eq(
              "type",
              "fee_payment",
            )
            .order(
              "created_at",
              {
                ascending: false,
              },
            );

          if (!transactionError) {
            loadedTransactions =
              (transactionData ||
                []) as PaymentTransaction[];
          } else {
            console.error(
              "Fee transaction load error:",
              transactionError,
            );
          }
        } catch (
          transactionLoadError
        ) {
          console.error(
            "Fee transaction load error:",
            transactionLoadError,
          );
        }

        setAllFeePayments(
          loadedTransactions,
        );

        await loadPaymentInstructions(
          user.id,
        );

        let selectedFee:
          | FeeRequest
          | null = null;

        /**
         * When a fee ID is supplied, always load
         * that exact fee first.
         */
        if (feeId) {
          selectedFee =
            loadedFees.find(
              (item) =>
                item.id === feeId,
            ) || null;

          if (!selectedFee) {
            setFee(null);
            setTransactions([]);

            setError(
              feeLoadError
                ? "Unable to load your fee request. Please refresh the page and try again."
                : "This fee request could not be found or is no longer available.",
            );

            return;
          }
        }

        /**
         * If there is no exact fee ID, select the
         * first fee that still has money outstanding.
         *
         * Pending transactions are ignored by
         * getPaidAmount().
         */
        if (!selectedFee) {
          selectedFee =
            loadedFees.find(
              (item) =>
                isFeeStillPayable(
                  item,
                  loadedTransactions,
                ),
            ) || null;
        }

        if (!selectedFee) {
          setFee(null);
          setTransactions([]);

          setError(
            "There are currently no outstanding fee requests on your account.",
          );

          return;
        }

        const selectedTransactions =
          loadedTransactions.filter(
            (transaction) =>
              safeString(
                transaction.reference,
              ) === selectedFee?.id,
          );

        setFee(selectedFee);
        setTransactions(
          selectedTransactions,
        );

        /**
         * Clear the form whenever the page is
         * freshly loaded.
         */
        setPaymentAmount("");
        setPaymentReference("");
        setReceiptFileName("");
        setSuccess("");
      } catch (loadError) {
        console.error(
          "Fee payment page load error:",
          loadError,
        );

        setFee(null);
        setFees([]);
        setTransactions([]);

        setError(
          "We could not load your fee payment information. Please refresh the page and try again.",
        );
      } finally {
        setLoading(false);
      }
    },
    [
      feeId,
      loadPaymentInstructions,
      router,
      supabase,
    ],
  );

  
  // Live synchronization for admin payment method changes.
  //
  // The payment_methods table is the source of truth,
  // exactly like the working Deposit page.
  useEffect(() => {
    let mounted = true;
    let refreshTimer: number | null = null;

    const loadAdminPaymentInformation =
      async () => {
        if (!mounted) {
          return;
        }

        try {
          const {
            data,
            error: methodsError,
          } = await supabase
            .from("payment_methods")
            .select(
              "name, details, is_active, sort_order, updated_at",
            )
            .order("created_at", {
              ascending: true,
            });

          if (methodsError) {
            console.error(
              "Fee payment methods refresh error:",
              methodsError,
            );
            return;
          }

          if (
            !mounted ||
            !data
          ) {
            return;
          }

          const activeMethods =
            data.filter(
              (method: any) =>
                method?.is_active !== false,
            );

          const adminMethods =
            activeMethods
              .map((method: any) => {
                const normalizedKey =
                  normalizePaymentMethod(
                    method?.name,
                  );

                if (!normalizedKey) {
                  return null;
                }

                const baseMethod =
                  PAYMENT_METHODS.find(
                    (item) =>
                      item.key ===
                      normalizedKey,
                  );

                if (!baseMethod) {
                  return null;
                }

                return {
                  ...baseMethod,
                  name:
                    safeString(
                      method?.name,
                    ) ||
                    baseMethod.name,
                  details:
                    parseDepositPaymentDetails(
                      method?.details,
                    ),
                  is_active:
                    method?.is_active !==
                    false,
                  sort_order:
                    method?.sort_order,
                };
              })
              .filter(
                (
                  method,
                ): method is PaymentMethodConfig & {
                  details: Record<
                    string,
                    unknown
                  >;
                  is_active: boolean;
                  sort_order: number;
                } =>
                  method !== null,
              );

          if (!mounted) {
            return;
          }

          if (
            adminMethods.length > 0
          ) {
            setPaymentMethods(
              adminMethods as any,
            );

            const selectedStillActive =
              adminMethods.some(
                (method) =>
                  method !== null &&
                  method.key === selectedMethod,
              );

            if (!selectedStillActive && adminMethods.length > 0) {
              const firstActiveMethod = adminMethods[0];

              if (firstActiveMethod) {
                setSelectedMethod(firstActiveMethod.key);
              }
            }
          } else {
            setPaymentMethods(
              PAYMENT_METHODS,
            );
          }
        } catch (refreshError) {
          console.error(
            "Fee payment admin information refresh failed:",
            refreshError,
          );
        }
      };

    void loadAdminPaymentInformation();

    refreshTimer =
      window.setInterval(
        () => {
          void loadAdminPaymentInformation();
        },
        3000,
      );

    const paymentMethodsChannel =
      supabase
        .channel(
          "fee-payment-methods-live",
        )
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "payment_methods",
          },
          () => {
            void loadAdminPaymentInformation();
          },
        )
        .subscribe();

    return () => {
      mounted = false;

      if (
        refreshTimer !== null
      ) {
        window.clearInterval(
          refreshTimer,
        );
      }

      supabase.removeChannel(
        paymentMethodsChannel,
      );
    };
  }, [selectedMethod, supabase]);

  useEffect(() => {
    void loadPage();
  }, [loadPage]);

  function handlePaymentAmountChange(
    value: string,
  ) {
    let next = value.replace(
      /[^0-9.]/g,
      "",
    );

    const dot =
      next.indexOf(".");

    if (dot !== -1) {
      next = `${next.slice(
        0,
        dot,
      )}.${next
        .slice(dot + 1)
        .replace(/\./g, "")
        .slice(0, 2)}`;
    }

    setPaymentAmount(next);
    setSuccess("");
    setError("");
  }

  function handlePayFullFee() {
    if (remainingAmount <= 0) {
      return;
    }

    setPaymentAmount(
      remainingAmount.toFixed(2),
    );

    setSuccess("");
    setError("");
  }

  /**
   * IMPORTANT:
   *
   * This creates a PENDING transaction.
   *
   * It does NOT call pay_admin_fee.
   * It does NOT mark the fee paid.
   * It does NOT subtract the amount from
   * remainingAmount.
   *
   * The admin must later approve the transaction.
   */
  async function handleSubmitPayment() {
    setSuccess("");
    setError("");

    if (submitting) {
      return;
    }

    if (!fee) {
      setError(
        "No fee payment request is currently available.",
      );
      return;
    }

    /**
     * Re-check authentication before inserting.
     */
    const {
      data: { user },
      error: authError,
    } =
      await supabase.auth.getUser();

    if (authError) {
      console.error(
        "Authentication error:",
        authError,
      );

      setError(
        "Your session could not be verified. Please log in again.",
      );

      return;
    }

    if (!user) {
      router.replace("/login");
      return;
    }

    /**
     * Re-check the amount against the current
     * approved amount before inserting.
     *
     * This protects against a stale page.
     */
    const currentPaidAmount =
      getPaidAmount(
        fee,
        allFeePayments,
      );

    const currentRemainingAmount =
      Math.max(
        Number(fee.amount || 0) -
          currentPaidAmount,
        0,
      );

    if (
      enteredPaymentAmount <= 0 ||
      enteredPaymentAmount >
        currentRemainingAmount +
          0.000001
    ) {
      setError(
        `You can only submit up to ${formatCurrency(
          currentRemainingAmount,
          currency,
        )}. Please refresh the page and try again.`,
      );

      return;
    }

    const methodName =
      paymentMethods.find(
        (method: any) =>
          method?.key ===
          selectedMethod,
      )?.name ||
      PAYMENT_METHODS.find(
        (method) =>
          method.key ===
          selectedMethod,
      )?.name ||
      "Payment method";

    const cleanReference =
      paymentReference.trim();

    const cleanReceiptName =
      receiptFileName.trim();

    let description = `${methodName} fee payment`;

    if (cleanReference) {
      description += ` Ã¢â‚¬Â¢ Reference: ${cleanReference}`;
    }

    if (cleanReceiptName) {
      description += ` Ã¢â‚¬Â¢ Receipt: ${cleanReceiptName}`;
    }

    setSubmitting(true);

    try {
      /**
       * This is the critical change.
       *
       * The transaction is created as PENDING.
       *
       * reference = fee.id
       * type = fee_payment
       *
       * Therefore the dashboard can show it,
       * while getPaidAmount() ignores it until
       * admin changes status to completed/approved.
       */
      const {
        data: insertedTransaction,
        error: transactionError,
      } = await supabase
        .from("transactions")
        .insert({
          user_id: user.id,
          amount:
            Number(
              enteredPaymentAmount.toFixed(
                2,
              ),
            ),
          status: "pending",
          reference: fee.id,
          type: "fee_payment",
          description,
        })
        .select(
          "id, amount, status, reference, type, description, created_at",
        )
        .single();

      if (transactionError) {
        console.error(
          "Fee payment transaction insert error:",
          transactionError,
        );

        throw new Error(
          transactionError.message ||
            "The pending fee payment could not be created.",
        );
      }

      if (!insertedTransaction) {
        throw new Error(
          "The pending fee payment was not returned by the server.",
        );
      }

      /**
       * Add the new pending transaction locally.
       * It will appear in payment history immediately.
       *
       * It will NOT change paidAmount because
       * pending is not an approved status.
       */
      const newTransaction =
        insertedTransaction as PaymentTransaction;

      setAllFeePayments((current) => [
        newTransaction,
        ...current,
      ]);

      setTransactions((current) => [
        newTransaction,
        ...current,
      ]);

      /**
       * Keep the original outstanding amount.
       *
       * This is intentionally NOT:
       *
       * remainingAmount - enteredPaymentAmount
       *
       * because the payment is still pending.
       */
      const outstandingAfterSubmission =
        currentRemainingAmount;

            if (!receiptFileName || !receiptFileName.trim()) {
        setError(
          "Payment receipt is required. Upload your receipt before submitting."
        );
        setSuccess("");
        return;
      }
const query =
        new URLSearchParams();

      query.set(
        "method",
        methodName,
      );

      query.set(
        "amount",
        enteredPaymentAmount.toFixed(
          2,
        ),
      );

      query.set(
        "currency",
        currency,
      );

      query.set(
        "outstanding",
        outstandingAfterSubmission.toFixed(
          2,
        ),
      );

      query.set(
        "transaction",
        newTransaction.id,
      );

      router.push(
        `/fees/pay/${encodeURIComponent(
          fee.id,
        )}/confirmation?${query.toString()}`,
      );
    } catch (submitError) {
      console.error(
        "Fee payment submission error:",
        submitError,
      );

      const message =
        submitError instanceof Error
          ? submitError.message
          : "";

      /**
       * Give a useful error rather than hiding
       * the actual database problem.
       */
      if (
        message
          .toLowerCase()
          .includes("row-level security")
      ) {
        setError(
          "The payment could not be submitted because the transactions table is blocking customer inserts. The transactions INSERT policy needs to allow the signed-in user to create their own pending fee payment.",
        );
      } else if (
        message
          .toLowerCase()
          .includes("check constraint")
      ) {
        setError(
          "The payment could not be submitted because the transactions table does not currently allow the pending fee payment status or fee payment type.",
        );
      } else {
        setError(
          message ||
            "We could not submit your fee payment for review. Please try again.",
        );
      }
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-[#eef2f7] px-4 py-10 dark:bg-[#070b12]">
        <div className="mx-auto max-w-6xl">
          <div className="animate-pulse space-y-6">
            <div className="h-8 w-48 rounded-xl bg-slate-300 dark:bg-slate-800" />

            <div className="h-32 rounded-3xl bg-slate-200 dark:bg-[#111827]" />

            <div className="h-72 rounded-3xl bg-slate-200 dark:bg-[#111827]" />

            <div className="h-80 rounded-3xl bg-slate-200 dark:bg-[#111827]" />
          </div>
        </div>
      </main>
    );
  }

  if (!fee) {
    return (
      <main className="min-h-screen bg-[#eef2f7] px-4 py-10 text-slate-950 dark:bg-[#070b12] dark:text-white">
        <div className="mx-auto max-w-3xl">
          <Link
            href="/dashboard"
            className="mb-8 inline-flex items-center gap-2 text-sm font-bold text-slate-600 transition hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
          >
            <FiArrowLeft size={16} />
            Back to Dashboard
          </Link>

          <div className="rounded-[28px] border border-slate-300 bg-slate-100 p-8 text-center shadow-sm dark:border-slate-800 dark:bg-[#111827]">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-100 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400">
              <FiDollarSign size={30} />
            </div>

            <h1 className="text-2xl font-black tracking-tight">
              No Outstanding Fee
            </h1>

            <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-slate-600 dark:text-slate-400">
              There is currently no
              outstanding fee available
              for payment on your
              account.
            </p>

            <Link
              href="/dashboard"
              className="mt-7 inline-flex h-12 items-center justify-center rounded-xl bg-blue-600 px-6 text-sm font-bold text-white transition hover:bg-blue-700"
            >
              Return to Dashboard
            </Link>
          </div>
        </div>
      </main>
    );
  }

  const feeTitle =
    fee.title ||
    fee.fee_type ||
    "Account Fee";

  return (
    <main className="min-h-screen bg-[#eef2f7] text-slate-950 dark:bg-[#070b12] dark:text-white">
      <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-10">
        <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <Link
              href="/dashboard"
              className="mb-4 inline-flex items-center gap-2 text-sm font-bold text-slate-600 transition hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
            >
              <FiArrowLeft size={16} />
              Back to Dashboard
            </Link>

            <h1 className="text-3xl font-black tracking-tight sm:text-4xl">
              Pay Fee
            </h1>

            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Choose your preferred payment
              method and submit your payment
              for review.
            </p>
          </div>

          <button
            type="button"
            onClick={() => void loadPage()}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-slate-300 bg-slate-100 px-4 text-sm font-bold text-slate-800 transition hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700 dark:border-slate-700 dark:bg-[#111827] dark:text-slate-200 dark:hover:border-blue-500/40 dark:hover:bg-blue-500/10 dark:hover:text-blue-300"
          >
            <FiRefreshCw size={16} />
            Refresh
          </button>
        </div>

        {error && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-red-300 bg-red-50 px-4 py-4 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-950/30 dark:text-red-300">
            <FiAlertCircle
              className="mt-0.5 shrink-0"
              size={18}
            />

            <div className="flex-1">
              <p className="font-bold">
                Something went wrong
              </p>

              <p className="mt-1 leading-6">
                {error}
              </p>
            </div>
          </div>
        )}

        {success && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-emerald-300 bg-emerald-50 px-4 py-4 text-sm text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-950/30 dark:text-emerald-300">
            <FiCheckCircle
              className="mt-0.5 shrink-0"
              size={18}
            />

            <div>
              <p className="font-bold">
                Payment Ready
              </p>

              <p className="mt-1 leading-6">
                {success}
              </p>
            </div>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
          <div className="space-y-6">
            <section className="overflow-hidden rounded-[28px] border border-slate-300 bg-slate-100 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
              <div className="border-b border-slate-300 px-5 py-6 dark:border-slate-800 sm:px-7">
                <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-blue-600 dark:text-blue-400">
                      Outstanding Fee
                    </p>

                    <h2 className="mt-2 text-2xl font-black tracking-tight">
                      {feeTitle}
                    </h2>

                    {fee.message && (
                      <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600 dark:text-slate-400">
                        {fee.message}
                      </p>
                    )}
                  </div>

                  <div className="rounded-2xl border border-blue-200 bg-blue-100 px-5 py-4 text-left dark:border-blue-500/20 dark:bg-blue-500/10 sm:text-right">
                    <p className="text-xs font-black uppercase tracking-wider text-blue-700 dark:text-blue-400">
                      Remaining
                    </p>

                    <p className="mt-1 text-2xl font-black text-slate-950 dark:text-white">
                      {formatCurrency(
                        remainingAmount,
                        currency,
                      )}
                    </p>

                    <p className="mt-1 text-[11px] font-semibold text-blue-700 dark:text-blue-300">
                      Approved payments only
                    </p>
                  </div>
                </div>
              </div>

              <div className="px-5 py-6 sm:px-7">
                <div className="mb-5">
                  <h3 className="text-lg font-black">
                    Payment Method
                  </h3>

                  <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                    Select how you want to pay
                    your fee.
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {paymentMethods.map(
                    (method) => {
                      const Icon =
                        method.icon;

                      const selected =
                        selectedMethod ===
                        method.key;

                      return (
                        <button
                          key={method.key}
                          type="button"
                          onClick={() => {
                            setSelectedMethod(
                              method.key,
                            );

                            setSuccess("");
                            setError("");
                          }}
                          className={`group relative overflow-hidden rounded-2xl border p-4 text-left transition-all duration-200 ${
                            selected
                              ? "border-blue-500 bg-blue-100 ring-2 ring-blue-500/10 dark:border-blue-400 dark:bg-blue-500/10"
                              : "border-slate-300 bg-slate-200/80 hover:border-blue-300 hover:bg-slate-200 dark:border-slate-700 dark:bg-[#172131] dark:hover:border-blue-500/40 dark:hover:bg-[#1b283b]"
                          }`}
                        >
                          {selected && (
                            <div className="absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white dark:bg-blue-500">
                              <FiCheckCircle
                                size={15}
                              />
                            </div>
                          )}

                          <div className="flex items-start gap-3">
                            <div
                              className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-slate-300 ${method.iconBackground} dark:border-slate-700`}
                            >
                              <Icon
                                size={26}
                                className={
                                  method.iconClass
                                }
                              />
                            </div>

                            <div className="min-w-0 pr-6">
                              <p className="font-black text-slate-950 dark:text-white">
                                {method.name}
                              </p>

                              <p className="mt-1 text-xs leading-5 text-slate-600 dark:text-slate-400">
                                {
                                  method.shortDescription
                                }
                              </p>
                            </div>
                          </div>
                        </button>
                      );
                    },
                  )}
                </div>
              </div>
            </section>

            <section className="rounded-[28px] border border-slate-300 bg-slate-100 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
              <div className="border-b border-slate-300 px-5 py-6 dark:border-slate-800 sm:px-7">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-300 bg-slate-200 dark:border-slate-700 dark:bg-[#182334]">
                    {(() => {
                      const Icon =
                        selectedMethodConfig.icon;

                      return (
                        <Icon
                          size={24}
                          className={
                            selectedMethodConfig.iconClass
                          }
                        />
                      );
                    })()}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-xl font-black text-slate-950 dark:text-white">
                        {
                          selectedMethodConfig.name
                        }{" "}
                        Payment
                      </h2>

                      <span className="rounded-full border border-blue-300 bg-blue-100 px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-blue-700 dark:border-blue-500/30 dark:bg-blue-500/10 dark:text-blue-300">
                        Demo
                      </span>
                    </div>

                    <p className="mt-1 text-sm font-medium text-slate-600 dark:text-slate-400">
                      Payment Information
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-7 px-5 py-6 sm:px-7">
                <div className="grid gap-4 sm:grid-cols-2">
                  {selectedPaymentInformation.fields.map(
                    (field) => (
                      <div
                        key={`${field.label}-${field.value}`}
                        className="overflow-hidden rounded-2xl border border-slate-300 bg-slate-200 dark:border-slate-700 dark:bg-[#172131]"
                      >
                        <div className="border-b border-slate-300 bg-slate-300 px-5 py-3 dark:border-slate-700 dark:bg-[#1d2a3c]">
                          <p className="text-[11px] font-black uppercase tracking-[0.14em] text-slate-700 dark:text-slate-300">
                            {field.label}
                          </p>
                        </div>

                        <div className="p-3">
                          <div className="min-h-[62px] rounded-xl border border-slate-400 bg-slate-100 px-4 py-4 shadow-sm dark:border-slate-600 dark:bg-[#0f1724]">
                            <p className="break-all text-base font-black leading-6 text-slate-950 dark:text-white">
                              {field.value}
                            </p>
                          </div>
                        </div>
                      </div>
                    ),
                  )}
                </div>

                <div className="rounded-2xl border border-blue-300 bg-blue-100 p-5 dark:border-blue-500/20 dark:bg-blue-500/10">
                  <div className="flex gap-3">
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-200 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400">
                      {selectedMethod ===
                      "bank" ? (
                        <FaUniversity
                          size={17}
                        />
                      ) : (
                        <FiInfo size={18} />
                      )}
                    </div>

                    <div>
                      <p className="text-sm font-black text-blue-950 dark:text-blue-100">
                        {selectedMethod ===
                        "bank"
                          ? "Bank Transfer"
                          : "Payment Instructions"}
                      </p>

                      <p className="mt-2 whitespace-pre-line text-sm leading-6 text-blue-900 dark:text-blue-200">
                        {
                          selectedPaymentInformation.instructions
                        }
                      </p>
                    </div>
                  </div>
                </div>

                {loadingInstructions && (
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                    <FiRefreshCw
                      size={13}
                      className="animate-spin"
                    />
                    Updating payment
                    information...
                  </div>
                )}

                <div className="rounded-2xl border border-slate-300 bg-slate-200/80 p-5 dark:border-slate-700 dark:bg-[#172131]">
                  <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                      <label
                        htmlFor="paymentAmount"
                        className="text-base font-black text-slate-950 dark:text-white"
                      >
                        Fee Amount
                      </label>

                      <p className="mt-1 text-xs leading-5 text-slate-600 dark:text-slate-400">
                        Enter how much you want
                        to pay now.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={
                        handlePayFullFee
                      }
                      disabled={
                        remainingAmount <=
                          0 ||
                        submitting
                      }
                      className="inline-flex h-10 items-center justify-center rounded-xl border border-blue-300 bg-blue-100 px-4 text-xs font-black text-blue-700 transition hover:bg-blue-200 disabled:cursor-not-allowed disabled:opacity-50 dark:border-blue-500/30 dark:bg-blue-500/10 dark:text-blue-300 dark:hover:bg-blue-500/20"
                    >
                      Pay Full Fee
                    </button>
                  </div>

                  <div
                    className={`flex h-[72px] overflow-hidden rounded-2xl border-2 bg-slate-100 shadow-sm transition dark:bg-[#0f1724] ${
                      paymentAmountError
                        ? "border-red-400 dark:border-red-500"
                        : "border-slate-400 focus-within:border-blue-500 dark:border-slate-600 dark:focus-within:border-blue-400"
                    }`}
                  >
                    <div className="flex w-[70px] shrink-0 items-center justify-center border-r border-slate-300 bg-slate-300 text-2xl font-black text-slate-800 dark:border-slate-600 dark:bg-[#1d2a3c] dark:text-slate-200">
                      $
                    </div>

                    <input
                      id="paymentAmount"
                      type="text"
                      inputMode="decimal"
                      value={paymentAmount}
                      onChange={(event) =>
                        handlePaymentAmountChange(
                          event.target.value,
                        )
                      }
                      placeholder="Enter amount"
                      disabled={submitting}
                      className="h-full min-w-0 flex-1 bg-transparent px-5 text-2xl font-black text-slate-950 outline-none placeholder:text-slate-400 disabled:cursor-not-allowed disabled:opacity-60 dark:text-white dark:placeholder:text-slate-600"
                    />

                    <div className="flex items-center border-l border-slate-300 bg-slate-300 px-4 text-xs font-black uppercase tracking-wider text-slate-700 dark:border-slate-600 dark:bg-[#1d2a3c] dark:text-slate-300">
                      {currency}
                    </div>
                  </div>

                  <div className="mt-3 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                    <p
                      className={`text-xs font-semibold ${
                        paymentAmountError
                          ? "text-red-600 dark:text-red-400"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      {paymentAmountError ||
                        `You can pay any amount up to ${formatCurrency(
                          remainingAmount,
                          currency,
                        )}.`}
                    </p>

                    <p className="text-xs font-bold text-slate-600 dark:text-slate-400">
                      Total fee:{" "}
                      {formatCurrency(
                        totalFeeAmount,
                        currency,
                      )}
                    </p>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="paymentReference"
                    className="text-sm font-black text-slate-950 dark:text-white"
                  >
                    Payment Reference{" "}
                    <span className="font-normal text-slate-500 dark:text-slate-400">
                      (optional)
                    </span>
                  </label>

                  <div className="mt-3 flex min-h-[56px] items-center rounded-2xl border border-slate-400 bg-slate-100 px-4 shadow-sm transition focus-within:border-blue-500 dark:border-slate-600 dark:bg-[#0f1724] dark:focus-within:border-blue-400">
                    <FiFileText
                      size={18}
                      className="mr-3 shrink-0 text-slate-500 dark:text-slate-400"
                    />

                    <input
                      id="paymentReference"
                      type="text"
                      value={
                        paymentReference
                      }
                      disabled={submitting}
                      onChange={(event) =>
                        setPaymentReference(
                          event.target.value,
                        )
                      }
                      placeholder="Enter transaction ID or payment reference"
                      className="min-w-0 flex-1 bg-transparent py-4 text-sm font-semibold text-slate-950 outline-none placeholder:text-slate-500 disabled:opacity-60 dark:text-white dark:placeholder:text-slate-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-black text-slate-950 dark:text-white">
                    Payment Receipt <span className="text-red-500">*</span>
                  </label>

                  <div className="mt-3">
                    <label
                      htmlFor="paymentReceipt"
                      className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-400 bg-slate-200 px-5 py-8 text-center transition hover:border-blue-400 hover:bg-blue-100 dark:border-slate-600 dark:bg-[#172131] dark:hover:border-blue-400/50 dark:hover:bg-blue-500/5"
                    >
                      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-slate-300 bg-slate-300 text-blue-600 shadow-sm dark:border-slate-600 dark:bg-[#1d2a3c] dark:text-blue-400">
                        <FiUpload
                          size={21}
                        />
                      </div>

                      <p className="mt-4 break-all text-sm font-black text-slate-950 dark:text-white">
                        {receiptFileName ||
                          "Upload your payment receipt"}
                      </p>

                      <p className="mt-1 text-xs font-medium text-slate-600 dark:text-slate-400">
                        PNG, JPG or PDF
                      </p>

                      <input
                        id="paymentReceipt"
                        type="file"
                        accept="image/png,image/jpeg,application/pdf"
                        className="hidden"
                        disabled={submitting}
                        onChange={(
                          event,
                        ) => {
                          const file =
                            event.target
                              .files?.[0];

                          setReceiptFileName(
                            file?.name ||
                              "",
                          );

                          setSuccess("");
                          setError("");
                        }}
                      />
                    </label>
                  </div>

                  <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-500">
                    The selected file name is
                    included with the payment
                    submission. This page does
                    not upload the file itself
                    to storage.
                  </p>
                </div>
              </div>
            </section>

            <section className="rounded-[28px] border border-slate-300 bg-slate-100 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
              <div className="border-b border-slate-300 px-5 py-6 dark:border-slate-800 sm:px-7">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-300 text-slate-800 dark:bg-[#1d2a3c] dark:text-slate-200">
                    <FiFileText
                      size={21}
                    />
                  </div>

                  <div>
                    <h2 className="text-xl font-black">
                      Fee Payment Summary
                    </h2>

                    <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                      Review your payment
                      before submitting.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-1 px-5 py-3 sm:px-7">
                <div className="flex items-center justify-between gap-5 border-b border-slate-300 py-4 dark:border-slate-800">
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    Payment Method
                  </span>

                  <span className="text-sm font-black text-slate-950 dark:text-white">
                    {
                      selectedMethodConfig.name
                    }
                  </span>
                </div>

                <div className="flex items-center justify-between gap-5 border-b border-slate-300 py-4 dark:border-slate-800">
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    Payment Amount
                  </span>

                  <span className="text-sm font-black text-slate-950 dark:text-white">
                    {formatCurrency(
                      currentSummaryAmount,
                      currency,
                    )}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-5 border-b border-slate-300 py-4 dark:border-slate-800">
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    Current Outstanding
                  </span>

                  <span className="text-sm font-black text-slate-950 dark:text-white">
                    {formatCurrency(
                      remainingAmount,
                      currency,
                    )}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-5 border-b border-slate-300 py-4 dark:border-slate-800">
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    Outstanding After
                    Approval
                  </span>

                  <span className="text-sm font-black text-slate-950 dark:text-white">
                    {formatCurrency(
                      Math.max(
                        0,
                        remainingAmount -
                          currentSummaryAmount,
                      ),
                      currency,
                    )}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-5 py-4">
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    Status
                  </span>

                  <span
                    className={`rounded-full px-3 py-1 text-xs font-black ${
                      paymentAmountValid
                        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300"
                        : "bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300"
                    }`}
                  >
                    {paymentAmountValid
                      ? "Ready to Submit"
                      : "Amount Required"}
                  </span>
                </div>
              </div>
            </section>

            <section className="rounded-[28px] border border-slate-300 bg-slate-100 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
              <div className="px-5 py-6 sm:px-7">
                <div className="flex items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400">
                    <FiShield
                      size={19}
                    />
                  </div>

                  <div>
                    <h3 className="font-black">
                      Payment Instructions
                    </h3>

                    <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-400">
                      Complete your payment
                      using the payment
                      information shown
                      above. Enter the
                      amount you want to
                      pay, add your
                      reference if
                      available, upload
                      your receipt, and
                      submit the payment
                      for review.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={
                    handleSubmitPayment
                  }
                  disabled={
                    !paymentAmountValid ||
                    submitting
                  }
                  className={`mt-6 flex h-14 w-full items-center justify-center gap-2 rounded-2xl px-6 text-sm font-black transition ${
                    paymentAmountValid &&
                    !submitting
                      ? "bg-blue-600 text-white shadow-sm hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
                      : "cursor-not-allowed bg-slate-300 text-slate-600 dark:bg-slate-700 dark:text-slate-400"
                  }`}
                >
                  {submitting ? (
                    <FiRefreshCw
                      size={18}
                      className="animate-spin"
                    />
                  ) : (
                    <FiCheckCircle
                      size={18}
                    />
                  )}

                  {submitting
                    ? "Submitting..."
                    : "Submit Payment for Review"}

                  {!submitting && (
                    <FiChevronRight
                      size={17}
                    />
                  )}
                </button>

                <p className="mt-3 text-center text-xs text-slate-500 dark:text-slate-500">
                  Your payment will be
                  recorded as Pending until
                  an administrator reviews
                  and approves it. A pending
                  payment does not reduce your
                  outstanding fee.
                </p>
              </div>
            </section>
          </div>

          <aside className="space-y-6 lg:sticky lg:top-6 lg:self-start">
            <div className="overflow-hidden rounded-[28px] border border-slate-300 bg-slate-100 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 px-6 py-7 text-white dark:from-blue-700 dark:to-blue-900">
                <p className="text-xs font-black uppercase tracking-[0.16em] text-blue-100">
                  Fee Payment
                </p>

                <h2 className="mt-3 text-3xl font-black tracking-tight">
                  {formatCurrency(
                    currentSummaryAmount,
                    currency,
                  )}
                </h2>

                <p className="mt-2 text-sm text-blue-100">
                  Amount selected for this
                  payment
                </p>
              </div>

              <div className="space-y-1 px-6 py-5">
                <div className="flex items-center justify-between gap-4 py-3">
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    Total Fee
                  </span>

                  <span className="text-sm font-black text-slate-950 dark:text-white">
                    {formatCurrency(
                      totalFeeAmount,
                      currency,
                    )}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-4 py-3">
                  <span className="text-sm text-slate-600 dark:text-slate-400">
                    Already Approved
                  </span>

                  <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                    {formatCurrency(
                      paidAmount,
                      currency,
                    )}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-4 border-t border-slate-300 py-4 dark:border-slate-800">
                  <span className="text-sm font-bold text-slate-700 dark:text-slate-300">
                    Remaining
                  </span>

                  <span className="text-base font-black text-slate-950 dark:text-white">
                    {formatCurrency(
                      remainingAmount,
                      currency,
                    )}
                  </span>
                </div>

                <div className="rounded-xl border border-amber-300 bg-amber-100 px-3 py-3 dark:border-amber-500/20 dark:bg-amber-500/10">
                  <p className="text-xs font-bold leading-5 text-amber-800 dark:text-amber-300">
                    Pending payments are not
                    included in Already
                    Approved or Remaining.
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-[28px] border border-slate-300 bg-slate-100 p-6 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-300 bg-slate-200 dark:border-slate-700 dark:bg-[#182334]">
                  {(() => {
                    const Icon =
                      selectedMethodConfig.icon;

                    return (
                      <Icon
                        size={25}
                        className={
                          selectedMethodConfig.iconClass
                        }
                      />
                    );
                  })()}
                </div>

                <div>
                  <p className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-500">
                    Selected Method
                  </p>

                  <p className="mt-1 font-black text-slate-950 dark:text-white">
                    {
                      selectedMethodConfig.name
                    }
                  </p>
                </div>
              </div>

              <div className="mt-5 rounded-2xl border border-slate-300 bg-slate-200 p-4 dark:border-slate-700 dark:bg-[#172131]">
                <div className="flex items-center gap-3">
                  {(() => {
                    const Icon =
                      selectedMethodConfig.icon;

                    return (
                      <Icon
                        size={26}
                        className={
                          selectedMethodConfig.iconClass
                        }
                      />
                    );
                  })()}

                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {
                      selectedMethodConfig.shortDescription
                    }
                  </p>
                </div>
              </div>
            </div>

            {transactions.length >
              0 && (
              <div className="rounded-[28px] border border-slate-300 bg-slate-100 p-6 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400">
                    <FiFileText
                      size={19}
                    />
                  </div>

                  <div>
                    <p className="font-black">
                      Payment History
                    </p>

                    <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">
                      Payments submitted toward
                      this fee
                    </p>
                  </div>
                </div>

                <div className="mt-5 space-y-3">
                  {transactions
                    .slice(0, 5)
                    .map(
                      (
                        transaction,
                      ) => {
                        const statusLabel =
                          getTransactionStatusLabel(
                            transaction.status,
                          );

                        return (
                          <div
                            key={
                              transaction.id
                            }
                            className="rounded-xl border border-slate-300 bg-slate-200 p-3 dark:border-slate-700 dark:bg-[#172131]"
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0">
                                <p className="break-words text-xs font-bold text-slate-950 dark:text-white">
                                  {transaction.description ||
                                    "Fee payment"}
                                </p>

                                <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-500">
                                  {new Date(
                                    transaction.created_at,
                                  ).toLocaleString()}
                                </p>
                              </div>

                              <p className="shrink-0 text-sm font-black text-slate-950 dark:text-white">
                                {formatCurrency(
                                  Math.max(
                                    Number(
                                      transaction.amount,
                                    ) || 0,
                                    0,
                                  ),
                                  currency,
                                )}
                              </p>
                            </div>

                            <div className="mt-3">
                              <span
                                className={`inline-flex rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-wide ${getTransactionStatusClass(
                                  transaction.status,
                                )}`}
                              >
                                {statusLabel}
                              </span>
                            </div>
                          </div>
                        );
                      },
                    )}
                </div>
              </div>
            )}
          </aside>
        </div>
      </div>
    </main>
  );
}










