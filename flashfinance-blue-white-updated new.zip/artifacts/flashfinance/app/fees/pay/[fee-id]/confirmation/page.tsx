"use client";

import Link from "next/link";
import { useParams, useSearchParams } from "next/navigation";
import {
  FiArrowLeft,
  FiCheckCircle,
  FiChevronRight,
  FiDollarSign,
  FiHome,
  FiShield,
} from "react-icons/fi";

function formatCurrency(
  value: number,
  currency = "USD",
) {
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(
      Number.isFinite(value)
        ? value
        : 0,
    );
  } catch {
    return `$${(
      Number.isFinite(value)
        ? value
        : 0
    ).toFixed(2)}`;
  }
}

function normalizeCurrency(
  value: string,
) {
  const text = String(
    value || "USD",
  )
    .trim()
    .toUpperCase();

  if (!/^[A-Z]{3}$/.test(text)) {
    return "USD";
  }

  return text;
}

export default function FeePaymentConfirmationPage() {
  const params = useParams();
  const searchParams = useSearchParams();

  const feeIdParam =
    params?.["fee-id"];

  const feeId = Array.isArray(
    feeIdParam,
  )
    ? feeIdParam[0]
    : feeIdParam;

  const method =
    searchParams.get("method") ||
    "payment method";

  const amountValue = Number(
    searchParams.get("amount") ||
      "0",
  );

  const amount = Number.isFinite(
    amountValue,
  )
    ? amountValue
    : 0;

  const currency =
    normalizeCurrency(
      searchParams.get(
        "currency",
      ) || "USD",
    );

  return (
    <main className="min-h-screen bg-[#eef2f7] px-4 py-8 text-slate-950 dark:bg-[#070b12] dark:text-white sm:px-6 lg:px-8">
      <div className="mx-auto flex min-h-[calc(100vh-4rem)] w-full max-w-3xl items-center justify-center">
        <div className="w-full">
          <Link
            href={
              feeId
                ? `/fees/pay/${encodeURIComponent(
                    feeId,
                  )}`
                : "/dashboard"
            }
            className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-slate-600 transition hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
          >
            <FiArrowLeft size={16} />
            Back to Fee Payment
          </Link>

          <section className="overflow-hidden rounded-[30px] border border-slate-300 bg-slate-100 shadow-sm dark:border-slate-800 dark:bg-[#111827]">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 px-6 py-10 text-center text-white dark:from-blue-700 dark:to-blue-900 sm:px-10">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-white/15 ring-8 ring-white/5">
                <FiCheckCircle
                  size={42}
                />
              </div>

              <p className="mt-6 text-xs font-black uppercase tracking-[0.2em] text-blue-100">
                Payment Confirmation
              </p>

              <h1 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">
                Payment Ready
              </h1>

              <p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-blue-100 sm:text-base">
                Your {method} payment of{" "}
                {formatCurrency(
                  amount,
                  currency,
                )}{" "}
                is ready to be submitted
                for review. Your payment
                receipt and reference will be
                reviewed before the fee is
                marked as paid.
              </p>
            </div>

            <div className="space-y-6 px-5 py-7 sm:px-10 sm:py-9">
              <div className="rounded-2xl border border-blue-300 bg-blue-100 p-5 dark:border-blue-500/20 dark:bg-blue-500/10">
                <div className="flex items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-200 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400">
                    <FiDollarSign
                      size={20}
                    />
                  </div>

                  <div className="min-w-0">
                    <p className="text-xs font-black uppercase tracking-wider text-blue-700 dark:text-blue-400">
                      Outstanding Fee
                    </p>

                    <p className="mt-1 text-xl font-black text-blue-950 dark:text-blue-100">
                      {formatCurrency(
                        amount,
                        currency,
                      )}
                    </p>

                    <p className="mt-2 text-sm leading-6 text-blue-900 dark:text-blue-200">
                      Payment method:{" "}
                      <span className="font-black">
                        {method}
                      </span>
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-slate-300 bg-slate-200 p-5 dark:border-slate-700 dark:bg-[#172131]">
                <div className="flex items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400">
                    <FiShield
                      size={19}
                    />
                  </div>

                  <div>
                    <h2 className="font-black">
                      Payment Review
                    </h2>

                    <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-400">
                      Your payment details
                      are ready for review.
                      Please make sure the
                      payment has been
                      completed using the
                      selected payment method
                      and that your receipt and
                      reference are available
                      when requested.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row">
                <Link
                  href="/dashboard"
                  className="flex h-14 flex-1 items-center justify-center gap-2 rounded-2xl bg-blue-600 px-6 text-sm font-black text-white transition hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
                >
                  <FiHome
                    size={18}
                  />
                  Dashboard
                </Link>

                <Link
                  href={
                    feeId
                      ? `/fees/pay/${encodeURIComponent(
                          feeId,
                        )}`
                      : "/dashboard"
                  }
                  className="flex h-14 flex-1 items-center justify-center gap-2 rounded-2xl border border-slate-300 bg-slate-200 px-6 text-sm font-black text-slate-800 transition hover:border-blue-300 hover:bg-blue-100 hover:text-blue-700 dark:border-slate-700 dark:bg-[#172131] dark:text-slate-200 dark:hover:border-blue-500/40 dark:hover:bg-blue-500/10 dark:hover:text-blue-300"
                >
                  Back to Payment
                  <FiChevronRight
                    size={17}
                  />
                </Link>
              </div>

              <p className="text-center text-xs leading-5 text-slate-500 dark:text-slate-500">
                Your submitted payment will
                remain pending until it has
                been reviewed.
              </p>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}