"use client";

import { FormEvent, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FiArrowLeft,
  FiCheckCircle,
  FiClock,
  FiMessageCircle,
  FiPlus,
  FiRefreshCw,
  FiSend,
  FiShield,
  FiX,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type Ticket = {
  id: string;
  subject: string;
  message: string;
  status: string;
  priority: string;
  category: string;
  admin_reply: string | null;
  replied_at: string | null;
  user_reply: string | null;
  user_replied_at: string | null;
  created_at: string;
  updated_at: string;
};

function formatDate(date: string) {
  return new Date(date).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function statusStyle(status: string) {
  const value = status.toLowerCase();

  if (value === "closed" || value === "resolved") {
    return "border-emerald-200 bg-emerald-50 text-emerald-700";
  }

  if (value === "pending") {
    return "border-orange-200 bg-orange-50 text-orange-700";
  }

  return "border-blue-200 bg-blue-50 text-blue-700";
}

function priorityStyle(priority: string) {
  const value = priority.toLowerCase();

  if (value === "urgent") {
    return "text-red-600";
  }

  if (value === "high") {
    return "text-orange-600";
  }

  if (value === "normal") {
    return "text-[#69707D]";
  }

  return "text-[#9298A3]";
}

export default function SupportPage() {
  const router = useRouter();
  const supabase = createClient();

  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [replying, setReplying] = useState(false);

  const [newTicketOpen, setNewTicketOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] =
    useState<Ticket | null>(null);

  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [category, setCategory] = useState("general");
  const [priority, setPriority] = useState("normal");

  const [replyMessage, setReplyMessage] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function getCurrentUser() {
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError) {
      setError(authError.message);
      return null;
    }

    if (!user) {
      router.push("/login");
      return null;
    }

    return user;
  }

  async function loadTickets() {
    setLoading(true);
    setError("");

    const user = await getCurrentUser();

    if (!user) {
      setLoading(false);
      return;
    }

    const { data, error: ticketError } = await supabase
      .from("admin_support_tickets")
      .select(
        "id, subject, message, status, priority, category, admin_reply, replied_at, user_reply, user_replied_at, created_at, updated_at",
      )
      .eq("user_id", user.id)
      .order("created_at", {
        ascending: false,
      });

    if (ticketError) {
      setError(ticketError.message);
      setTickets([]);
    } else {
      setTickets((data ?? []) as Ticket[]);
    }

    setLoading(false);
  }

  useEffect(() => {
    loadTickets();

    const interval = window.setInterval(() => {
      loadTickets();
    }, 30000);

    return () => {
      window.clearInterval(interval);
    };
  }, []);

  async function createTicket(event: FormEvent) {
    event.preventDefault();

    setError("");
    setSuccess("");

    const trimmedSubject = subject.trim();
    const trimmedMessage = message.trim();

    if (!trimmedSubject) {
      setError("Please enter a subject.");
      return;
    }

    if (!trimmedMessage) {
      setError("Please describe your issue.");
      return;
    }

    if (trimmedSubject.length < 3) {
      setError("Your subject is too short.");
      return;
    }

    if (trimmedMessage.length < 5) {
      setError("Please provide more details about your issue.");
      return;
    }

    setCreating(true);

    const { data, error: rpcError } = await supabase.rpc(
      "user_create_support_ticket",
      {
        p_subject: trimmedSubject,
        p_message: trimmedMessage,
        p_category: category,
        p_priority: priority,
      },
    );

    if (rpcError) {
      setError(rpcError.message);
      setCreating(false);
      return;
    }

    setSuccess(
      data
        ? `Support ticket ${data} was created successfully.`
        : "Your support ticket was created successfully.",
    );

    setSubject("");
    setMessage("");
    setCategory("general");
    setPriority("normal");
    setNewTicketOpen(false);

    await loadTickets();

    setCreating(false);
  }

  async function sendReply(event: FormEvent) {
    event.preventDefault();

    if (!selectedTicket) {
      return;
    }

    setError("");
    setSuccess("");

    const trimmedReply = replyMessage.trim();

    if (!trimmedReply) {
      setError("Please enter a reply.");
      return;
    }

    if (trimmedReply.length < 2) {
      setError("Your reply is too short.");
      return;
    }

    if (
      selectedTicket.status.toLowerCase() === "closed" ||
      selectedTicket.status.toLowerCase() === "resolved"
    ) {
      setError(
        "This ticket is closed. Please open a new ticket if you still need help.",
      );
      return;
    }

    setReplying(true);

    const { error: replyError } = await supabase.rpc(
      "user_reply_support_ticket",
      {
        p_ticket_id: selectedTicket.id,
        p_message: trimmedReply,
      },
    );

    if (replyError) {
      setError(replyError.message);
      setReplying(false);
      return;
    }

    setReplyMessage("");
    setSuccess("Your reply was sent to the Support Team.");

    await loadTickets();

    const {
      data: updatedTicket,
      error: updatedTicketError,
    } = await supabase
      .from("admin_support_tickets")
      .select(
        "id, subject, message, status, priority, category, admin_reply, replied_at, user_reply, user_replied_at, created_at, updated_at",
      )
      .eq("id", selectedTicket.id)
      .maybeSingle();

    if (!updatedTicketError && updatedTicket) {
      setSelectedTicket(updatedTicket as Ticket);
    } else {
      const refreshedTicket = tickets.find(
        (ticket) => ticket.id === selectedTicket.id,
      );

      if (refreshedTicket) {
        setSelectedTicket(refreshedTicket);
      }
    }

    setReplying(false);
  }

  function closeNewTicketModal() {
    if (creating) {
      return;
    }

    setNewTicketOpen(false);
  }

  function closeTicketModal() {
    if (replying) {
      return;
    }

    setSelectedTicket(null);
    setReplyMessage("");
  }

  return (
    <main className="min-h-screen !bg-[#F8F9FB] !text-[#111318]">
      <div className="min-h-screen">
        {/* HEADER */}
        <header className="border-b border-white/10 bg-[#0B0E17]">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
            <button
              type="button"
              onClick={() => router.push("/dashboard")}
              className="flex items-center gap-2 text-sm font-semibold text-white/70 transition hover:text-white"
            >
              <FiArrowLeft size={17} />
              Back to dashboard
            </button>

            <div className="text-lg font-black tracking-tight text-white">
              FLASH<span className="text-[#C9213A]">FINANCE</span>
            </div>

            <button
              type="button"
              onClick={() => router.push("/profile")}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-[#B51F35] text-white transition hover:bg-[#C9213A]"
            >
              <FiMessageCircle size={17} />
            </button>
          </div>
        </header>

        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
          {/* PAGE HEADER */}
          <div className="mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <button
                type="button"
                onClick={() => router.push("/dashboard")}
                className="mb-5 flex items-center gap-2 text-sm font-semibold text-[#69707D] transition hover:text-[#B51F35]"
              >
                <FiArrowLeft size={16} />
                Back to dashboard
              </button>

              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#B51F35] text-white shadow-lg shadow-[#B51F35]/15">
                  <FiMessageCircle size={22} />
                </div>

                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
                    FlashFinance
                  </p>

                  <h1 className="mt-1 text-3xl font-black tracking-tight text-[#111318]">
                    Support Center
                  </h1>
                </div>
              </div>

              <p className="mt-4 max-w-2xl text-sm leading-6 text-[#69707D]">
                Contact the FlashFinance Support Team, report an issue,
                ask a question, or follow up on an existing request.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setError("");
                setSuccess("");
                setNewTicketOpen(true);
              }}
              className="flex items-center justify-center gap-2 rounded-2xl bg-[#B51F35] px-5 py-3.5 text-sm font-black text-white shadow-sm transition hover:bg-[#C9213A]"
            >
              <FiPlus size={18} />
              Open Support Ticket
            </button>
          </div>

          {/* SUCCESS */}
          {success && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
              <FiCheckCircle
                size={19}
                className="mt-0.5 shrink-0 text-emerald-600"
              />

              <p className="text-sm text-emerald-700">
                {success}
              </p>

              <button
                type="button"
                onClick={() => setSuccess("")}
                className="ml-auto text-emerald-600 transition hover:text-emerald-700"
              >
                <FiX size={17} />
              </button>
            </div>
          )}

          {/* ERROR */}
          {error && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4">
              <p className="text-sm leading-6 text-red-700">
                {error}
              </p>

              <button
                type="button"
                onClick={() => setError("")}
                className="ml-auto shrink-0 text-red-600 transition hover:text-red-700"
              >
                <FiX size={17} />
              </button>
            </div>
          )}

          {/* SUPPORT INFO */}
          <section className="mb-8 grid gap-4 md:grid-cols-3">
            <div className="rounded-3xl border border-[#E2E5E9] bg-white p-5 shadow-sm">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                <FiMessageCircle size={19} />
              </div>

              <h2 className="mt-4 font-black text-[#111318]">
                Contact Support
              </h2>

              <p className="mt-2 text-xs leading-5 text-[#69707D]">
                Send a message directly to FlashFinance Support Team.
              </p>
            </div>

            <div className="rounded-3xl border border-[#E2E5E9] bg-white p-5 shadow-sm">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                <FiShield size={19} />
              </div>

              <h2 className="mt-4 font-black text-[#111318]">
                Account Help
              </h2>

              <p className="mt-2 text-xs leading-5 text-[#69707D]">
                Report problems with verification, payments, transfers,
                withdrawals, or your account.
              </p>
            </div>

            <div className="rounded-3xl border border-[#E2E5E9] bg-white p-5 shadow-sm">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                <FiClock size={19} />
              </div>

              <h2 className="mt-4 font-black text-[#111318]">
                Track Your Ticket
              </h2>

              <p className="mt-2 text-xs leading-5 text-[#69707D]">
                Every support request stays in your account so you can
                follow the conversation.
              </p>
            </div>
          </section>

          {/* TICKETS */}
          <section>
            <div className="mb-4 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#B51F35]">
                  My Tickets
                </p>

                <h2 className="mt-1 text-xl font-black text-[#111318]">
                  Support requests
                </h2>
              </div>

              <button
                type="button"
                onClick={loadTickets}
                disabled={loading}
                className="flex items-center gap-2 rounded-xl border border-[#E2E5E9] bg-white px-3 py-2 text-xs font-bold text-[#69707D] shadow-sm transition hover:border-[#B51F35]/30 hover:text-[#B51F35] disabled:cursor-not-allowed disabled:opacity-50"
              >
                <FiRefreshCw
                  size={14}
                  className={loading ? "animate-spin" : ""}
                />
                Refresh
              </button>
            </div>

            <div className="overflow-hidden rounded-3xl border border-[#E2E5E9] bg-white shadow-sm">
              {loading ? (
                <div className="p-12 text-center">
                  <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-[#B51F35] border-t-transparent" />

                  <p className="mt-4 text-sm text-[#69707D]">
                    Loading support tickets...
                  </p>
                </div>
              ) : tickets.length === 0 ? (
                <div className="p-12 text-center">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#F1F3F6] text-[#9298A3]">
                    <FiMessageCircle size={25} />
                  </div>

                  <h3 className="mt-4 font-black text-[#111318]">
                    No support tickets
                  </h3>

                  <p className="mx-auto mt-2 max-w-sm text-xs leading-5 text-[#69707D]">
                    If you have an issue or need help, open a support ticket
                    and the Support Team will respond here.
                  </p>

                  <button
                    type="button"
                    onClick={() => {
                      setError("");
                      setSuccess("");
                      setNewTicketOpen(true);
                    }}
                    className="mt-5 rounded-xl bg-[#B51F35] px-4 py-2.5 text-xs font-black text-white transition hover:bg-[#C9213A]"
                  >
                    Open a Ticket
                  </button>
                </div>
              ) : (
                tickets.map((ticket) => (
                  <button
                    key={ticket.id}
                    type="button"
                    onClick={() => {
                      setError("");
                      setSuccess("");
                      setSelectedTicket(ticket);
                    }}
                    className="flex w-full items-start justify-between gap-4 border-b border-[#E2E5E9] p-5 text-left transition last:border-b-0 hover:bg-[#F8F9FB]"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`rounded-full border px-2 py-1 text-[9px] font-bold uppercase tracking-wider ${statusStyle(
                            ticket.status,
                          )}`}
                        >
                          {ticket.status}
                        </span>

                        <span
                          className={`text-[10px] font-bold capitalize ${priorityStyle(
                            ticket.priority,
                          )}`}
                        >
                          {ticket.priority} priority
                        </span>

                        <span className="rounded-full bg-[#F1F3F6] px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-[#69707D]">
                          {ticket.category}
                        </span>
                      </div>

                      <h3 className="mt-3 truncate text-sm font-black text-[#111318]">
                        {ticket.subject}
                      </h3>

                      <p className="mt-1 line-clamp-2 text-xs leading-5 text-[#69707D]">
                        {ticket.message}
                      </p>

                      {ticket.admin_reply && (
                        <p className="mt-2 text-xs font-bold text-[#B51F35]">
                          Support Team replied
                        </p>
                      )}

                      {ticket.user_reply && (
                        <p className="mt-1 text-xs font-bold text-[#69707D]">
                          You replied
                        </p>
                      )}

                      <p className="mt-2 text-[10px] text-[#9298A3]">
                        {formatDate(ticket.created_at)}
                      </p>
                    </div>

                    <FiMessageCircle
                      size={18}
                      className="mt-2 shrink-0 text-[#9298A3]"
                    />
                  </button>
                ))
              )}
            </div>
          </section>
        </div>
      </div>

      {/* NEW TICKET MODAL */}
      {newTicketOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B0E17]/75 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-[#E2E5E9] bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#E2E5E9] p-5 sm:p-6">
              <div>
                <h2 className="text-xl font-black text-[#111318]">
                  Open Support Ticket
                </h2>

                <p className="mt-1 text-xs text-[#69707D]">
                  Tell the Support Team what happened.
                </p>
              </div>

              <button
                type="button"
                onClick={closeNewTicketModal}
                className="rounded-xl border border-[#E2E5E9] p-2 text-[#69707D] transition hover:bg-[#F1F3F6] hover:text-[#111318]"
              >
                <FiX size={18} />
              </button>
            </div>

            <form
              onSubmit={createTicket}
              className="space-y-5 p-5 sm:p-6"
            >
              <div>
                <label className="mb-2 block text-xs font-bold text-[#252932]">
                  Subject
                </label>

                <input
                  value={subject}
                  onChange={(event) =>
                    setSubject(event.target.value)
                  }
                  maxLength={120}
                  placeholder="What do you need help with?"
                  className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3.5 text-sm text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
                />

                <p className="mt-1 text-right text-[10px] text-[#9298A3]">
                  {subject.length}/120
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-xs font-bold text-[#252932]">
                    Category
                  </label>

                  <select
                    value={category}
                    onChange={(event) =>
                      setCategory(event.target.value)
                    }
                    className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3.5 text-sm text-[#111318] outline-none focus:border-[#B51F35] focus:bg-white"
                  >
                    <option value="general">General</option>
                    <option value="account">Account</option>
                    <option value="payment">Payment</option>
                    <option value="deposit">Deposit</option>
                    <option value="withdrawal">Withdrawal</option>
                    <option value="transfer">Transfer</option>
                    <option value="kyc">KYC / Verification</option>
                    <option value="technical">Technical Issue</option>
                    <option value="complaint">Complaint</option>
                  </select>
                </div>

                <div>
                  <label className="mb-2 block text-xs font-bold text-[#252932]">
                    Priority
                  </label>

                  <select
                    value={priority}
                    onChange={(event) =>
                      setPriority(event.target.value)
                    }
                    className="w-full rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3.5 text-sm text-[#111318] outline-none focus:border-[#B51F35] focus:bg-white"
                  >
                    <option value="low">Low</option>
                    <option value="normal">Normal</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-xs font-bold text-[#252932]">
                  Describe your issue
                </label>

                <textarea
                  value={message}
                  onChange={(event) =>
                    setMessage(event.target.value)
                  }
                  maxLength={5000}
                  rows={7}
                  placeholder="Explain what happened and how we can help..."
                  className="w-full resize-none rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3.5 text-sm leading-6 text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
                />

                <p className="mt-1 text-right text-[10px] text-[#9298A3]">
                  {message.length}/5000
                </p>
              </div>

              <button
                type="submit"
                disabled={creating}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#B51F35] px-5 py-4 text-sm font-black text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
              >
                <FiSend size={17} />

                {creating
                  ? "Opening Ticket..."
                  : "Submit Support Ticket"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TICKET DETAIL */}
      {selectedTicket && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B0E17]/75 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-[#E2E5E9] bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-[#E2E5E9] p-5 sm:p-6">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`rounded-full border px-2 py-1 text-[9px] font-bold uppercase tracking-wider ${statusStyle(
                      selectedTicket.status,
                    )}`}
                  >
                    {selectedTicket.status}
                  </span>

                  <span className="text-[10px] text-[#9298A3]">
                    Ticket #{selectedTicket.id.slice(0, 8)}
                  </span>

                  <span className="rounded-full bg-[#F1F3F6] px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-[#69707D]">
                    {selectedTicket.category}
                  </span>
                </div>

                <h2 className="mt-3 text-xl font-black text-[#111318]">
                  {selectedTicket.subject}
                </h2>

                <div className="mt-2 flex flex-wrap gap-3 text-[10px]">
                  <span
                    className={priorityStyle(
                      selectedTicket.priority,
                    )}
                  >
                    {selectedTicket.priority} priority
                  </span>

                  <span className="text-[#9298A3]">
                    Opened {formatDate(selectedTicket.created_at)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={closeTicketModal}
                className="rounded-xl border border-[#E2E5E9] p-2 text-[#69707D] transition hover:bg-[#F1F3F6] hover:text-[#111318]"
              >
                <FiX size={18} />
              </button>
            </div>

            <div className="space-y-5 p-5 sm:p-6">
              {/* USER ORIGINAL MESSAGE */}
              <div>
                <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#9298A3]">
                  You
                </p>

                <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-5">
                  <p className="whitespace-pre-wrap text-sm leading-7 text-[#252932]">
                    {selectedTicket.message}
                  </p>
                </div>
              </div>

              {/* ADMIN REPLY */}
              {selectedTicket.admin_reply && (
                <div>
                  <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#B51F35]">
                    FlashFinance Support Team
                  </p>

                  <div className="rounded-2xl border border-[#B51F35]/20 bg-[#B51F35]/[0.04] p-5">
                    <p className="whitespace-pre-wrap text-sm leading-7 text-[#252932]">
                      {selectedTicket.admin_reply}
                    </p>

                    {selectedTicket.replied_at && (
                      <p className="mt-3 text-[10px] text-[#9298A3]">
                        {formatDate(selectedTicket.replied_at)}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* USER REPLY */}
              {selectedTicket.user_reply && (
                <div>
                  <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#9298A3]">
                    Your latest reply
                  </p>

                  <div className="rounded-2xl border border-[#E2E5E9] bg-[#F8F9FB] p-5">
                    <p className="whitespace-pre-wrap text-sm leading-7 text-[#252932]">
                      {selectedTicket.user_reply}
                    </p>

                    {selectedTicket.user_replied_at && (
                      <p className="mt-3 text-[10px] text-[#9298A3]">
                        {formatDate(
                          selectedTicket.user_replied_at,
                        )}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* CLOSED MESSAGE */}
              {(selectedTicket.status.toLowerCase() ===
                "closed" ||
                selectedTicket.status.toLowerCase() ===
                  "resolved") && (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                  <div className="flex items-start gap-3">
                    <FiCheckCircle
                      size={18}
                      className="mt-0.5 shrink-0 text-emerald-600"
                    />

                    <div>
                      <p className="text-sm font-bold text-emerald-700">
                        This ticket has been{" "}
                        {selectedTicket.status.toLowerCase()}.
                      </p>

                      <p className="mt-1 text-xs leading-5 text-[#69707D]">
                        If you still need assistance, please open a new
                        support ticket.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* REPLY FORM */}
              {selectedTicket.status.toLowerCase() !==
                "closed" &&
                selectedTicket.status.toLowerCase() !==
                  "resolved" && (
                  <form
                    onSubmit={sendReply}
                    className="border-t border-[#E2E5E9] pt-5"
                  >
                    <label className="mb-2 block text-xs font-bold text-[#252932]">
                      Reply to Support Team
                    </label>

                    <textarea
                      value={replyMessage}
                      onChange={(event) =>
                        setReplyMessage(event.target.value)
                      }
                      maxLength={5000}
                      rows={5}
                      placeholder="Write your reply..."
                      className="w-full resize-none rounded-2xl border border-[#E2E5E9] bg-[#F1F3F6] px-4 py-3.5 text-sm leading-6 text-[#111318] outline-none placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white"
                    />

                    <div className="mt-1 text-right text-[10px] text-[#9298A3]">
                      {replyMessage.length}/5000
                    </div>

                    <button
                      type="submit"
                      disabled={replying}
                      className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-4 py-3 text-sm font-black text-white transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <FiSend size={16} />

                      {replying ? "Sending..." : "Send Reply"}
                    </button>
                  </form>
                )}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}