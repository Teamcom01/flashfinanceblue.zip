﻿"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  FiArrowLeft,
  FiCheck,
  FiClock,
  FiRefreshCw,
  FiSave,
  FiShield,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type ProcessingType =
  | "instant"
  | "3_business_days"
  | "after_verification_fee"
  | "custom";

type WithdrawalSettings = {
  id: string;
  verification_fee: number;
  processing_type: ProcessingType;
  custom_processing_text: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

const processingOptions: {
  value: ProcessingType;
  label: string;
  description: string;
}[] = [
  {
    value: "instant",
    label: "Instant",
    description: "Tell customers their withdrawal is processed instantly.",
  },
  {
    value: "3_business_days",
    label: "3 Business Days",
    description: "Tell customers processing takes up to 3 business days.",
  },
  {
    value: "after_verification_fee",
    label: "After Verification Fee Is Paid",
    description:
      "Tell customers processing continues after the verification fee is paid.",
  },
  {
    value: "custom",
    label: "Custom",
    description: "Enter your own arrival or processing message.",
  },
];

export default function WithdrawalSettingsPage() {
  const supabase = createClient();

  const [settings, setSettings] = useState<WithdrawalSettings | null>(null);
  const [verificationFee, setVerificationFee] = useState("");
  const [processingType, setProcessingType] =
    useState<ProcessingType>("instant");
  const [customProcessingText, setCustomProcessingText] = useState("");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function loadSettings() {
    setLoading(true);
    setError("");

    const { data, error } = await supabase
      .from("withdrawal_settings")
      .select(
        "id, verification_fee, processing_type, custom_processing_text, is_active, created_at, updated_at"
      )
      .eq("is_active", true)
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Withdrawal settings load error:", error);
      setError(error.message);
      setLoading(false);
      return;
    }

    if (data) {
      const row = data as WithdrawalSettings;

      setSettings(row);
      setVerificationFee(String(row.verification_fee ?? 0));
      setProcessingType(row.processing_type);
      setCustomProcessingText(row.custom_processing_text ?? "");
    }

    setLoading(false);
  }

  useEffect(() => {
    loadSettings();
  }, []);

  async function handleSave() {
    setMessage("");
    setError("");

    const parsedFee = Number(verificationFee);

    if (!Number.isFinite(parsedFee) || parsedFee < 0) {
      setError("Please enter a valid verification fee.");
      return;
    }

    if (processingType === "custom" && !customProcessingText.trim()) {
      setError("Please enter your custom processing information.");
      return;
    }

    setSaving(true);

    const payload = {
      verification_fee: parsedFee,
      processing_type: processingType,
      custom_processing_text:
        processingType === "custom"
          ? customProcessingText.trim()
          : null,
      is_active: true,
      updated_at: new Date().toISOString(),
    };

    let saveError = null;
    let savedData: WithdrawalSettings | null = null;

    if (settings?.id) {
      const result = await supabase
        .from("withdrawal_settings")
        .update(payload)
        .eq("id", settings.id)
        .select(
          "id, verification_fee, processing_type, custom_processing_text, is_active, created_at, updated_at"
        )
        .single();

      saveError = result.error;
      savedData = result.data as WithdrawalSettings | null;
    } else {
      const result = await supabase
        .from("withdrawal_settings")
        .insert(payload)
        .select(
          "id, verification_fee, processing_type, custom_processing_text, is_active, created_at, updated_at"
        )
        .single();

      saveError = result.error;
      savedData = result.data as WithdrawalSettings | null;
    }

    if (saveError) {
      console.error("Withdrawal settings save error:", saveError);
      setError(saveError.message);
      setSaving(false);
      return;
    }

    if (savedData) {
      setSettings(savedData);
      setVerificationFee(String(savedData.verification_fee ?? 0));
      setProcessingType(savedData.processing_type);
      setCustomProcessingText(savedData.custom_processing_text ?? "");
    }

    setMessage("Withdrawal settings saved successfully.");
    setSaving(false);
  }

  const selectedOption = processingOptions.find(
    (option) => option.value === processingType
  );

  return (
    <main className="min-h-screen bg-[#F1F3F6] text-[#111318]">
      <div className="mx-auto max-w-5xl px-5 py-8 sm:px-8 lg:py-10">
        <Link
          href="/admin"
          className="inline-flex items-center gap-2 text-sm font-semibold text-[#69707D] transition hover:text-[#B51F35]"
        >
          <FiArrowLeft size={16} />
          Back to Admin
        </Link>

        <div className="mt-6 overflow-hidden rounded-[30px] bg-white shadow-[0_12px_40px_rgba(15,23,42,0.07)]">
          <div className="bg-[#0B0E17] px-6 py-8 text-white sm:px-9 sm:py-9">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#B51F35]">
                    <FiShield size={23} />
                  </div>

                  <div>
                    <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#C9213A]">
                      Withdrawal Management
                    </p>

                    <h1 className="mt-1 text-2xl font-black tracking-tight sm:text-3xl">
                      Withdrawal Settings
                    </h1>
                  </div>
                </div>

                <p className="mt-4 max-w-2xl text-sm leading-6 text-[#B8BDC6]">
                  Control the verification fee and arrival or processing
                  information shown with new withdrawal receipts.
                </p>
              </div>

              <button
                type="button"
                onClick={loadSettings}
                disabled={loading || saving}
                className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <FiRefreshCw
                  size={16}
                  className={loading ? "animate-spin" : ""}
                />
                Refresh
              </button>
            </div>
          </div>

          <div className="p-6 sm:p-9">
            {loading ? (
              <div className="flex min-h-[300px] items-center justify-center">
                <div className="flex items-center gap-3 text-sm font-semibold text-[#69707D]">
                  <FiRefreshCw size={18} className="animate-spin" />
                  Loading withdrawal settings...
                </div>
              </div>
            ) : (
              <>
                {message && (
                  <div className="mb-6 flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3.5 text-sm font-semibold text-emerald-700">
                    <FiCheck size={18} />
                    {message}
                  </div>
                )}

                {error && (
                  <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3.5 text-sm font-semibold text-red-700">
                    {error}
                  </div>
                )}

                <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
                  <section className="rounded-[24px] border border-[#E2E5E9] bg-[#FAFBFC] p-6">
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35] text-white">
                        <FiShield size={19} />
                      </div>

                      <div>
                        <h2 className="text-lg font-black text-[#111318]">
                          Verification Fee
                        </h2>

                        <p className="text-sm text-[#69707D]">
                          Applied to new withdrawal receipts.
                        </p>
                      </div>
                    </div>

                    <div className="mt-6">
                      <label
                        htmlFor="verification-fee"
                        className="mb-2 block text-sm font-bold text-[#3F4652]"
                      >
                        Fee Amount
                      </label>

                      <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-[#69707D]">
                          $
                        </span>

                        <input
                          id="verification-fee"
                          type="number"
                          min="0"
                          step="0.01"
                          value={verificationFee}
                          onChange={(event) => {
                            setVerificationFee(event.target.value);
                            setMessage("");
                          }}
                          className="w-full rounded-2xl border border-[#DDE1E6] bg-white py-4 pl-9 pr-4 text-lg font-bold text-[#111318] outline-none transition focus:border-[#B51F35] focus:ring-4 focus:ring-[#B51F35]/10"
                          placeholder="0.00"
                        />
                      </div>

                      <p className="mt-3 text-xs leading-5 text-[#8A919C]">
                        Enter 0 if no verification fee should be attached to
                        new withdrawals.
                      </p>
                    </div>
                  </section>

                  <section className="rounded-[24px] border border-[#E2E5E9] bg-[#FAFBFC] p-6">
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#F1F3F6] text-[#4B5563]">
                        <FiClock size={19} />
                      </div>

                      <div>
                        <h2 className="text-lg font-black text-[#111318]">
                          Arrival / Processing
                        </h2>

                        <p className="text-sm text-[#69707D]">
                          Choose what appears on new withdrawal receipts.
                        </p>
                      </div>
                    </div>

                    <div className="mt-6 space-y-3">
                      {processingOptions.map((option) => {
                        const active = processingType === option.value;

                        return (
                          <button
                            key={option.value}
                            type="button"
                            onClick={() => {
                              setProcessingType(option.value);
                              setMessage("");
                            }}
                            className={`w-full rounded-2xl border p-4 text-left transition ${
                              active
                                ? "border-[#B51F35] bg-[#FFF6F7] ring-2 ring-[#B51F35]/10"
                                : "border-[#E1E4E8] bg-white hover:border-[#C9CDD3]"
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <div
                                className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${
                                  active
                                    ? "border-[#B51F35] bg-[#B51F35]"
                                    : "border-[#C9CDD3] bg-white"
                                }`}
                              >
                                {active && (
                                  <div className="h-2 w-2 rounded-full bg-white" />
                                )}
                              </div>

                              <div>
                                <p className="text-sm font-bold text-[#111318]">
                                  {option.label}
                                </p>

                                <p className="mt-1 text-xs leading-5 text-[#69707D]">
                                  {option.description}
                                </p>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {processingType === "custom" && (
                      <div className="mt-4">
                        <label
                          htmlFor="custom-processing"
                          className="mb-2 block text-sm font-bold text-[#3F4652]"
                        >
                          Custom Processing Information
                        </label>

                        <textarea
                          id="custom-processing"
                          value={customProcessingText}
                          onChange={(event) => {
                            setCustomProcessingText(event.target.value);
                            setMessage("");
                          }}
                          rows={4}
                          className="w-full resize-none rounded-2xl border border-[#DDE1E6] bg-white px-4 py-3.5 text-sm font-medium text-[#111318] outline-none transition focus:border-[#B51F35] focus:ring-4 focus:ring-[#B51F35]/10"
                          placeholder="Enter the arrival or processing information..."
                        />
                      </div>
                    )}
                  </section>
                </div>

                <section className="mt-6 rounded-[24px] border border-[#E2E5E9] bg-white p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#F1F3F6] text-[#4B5563]">
                      <FiCheck size={19} />
                    </div>

                    <div>
                      <h2 className="text-base font-black text-[#111318]">
                        Current receipt setting
                      </h2>

                      <p className="mt-1 text-sm leading-6 text-[#69707D]">
                        New withdrawals will use these settings when they are
                        submitted. Existing withdrawals will keep their own
                        saved receipt information.
                      </p>

                      <div className="mt-4 grid gap-3 sm:grid-cols-2">
                        <div className="rounded-xl bg-[#F7F8FA] px-4 py-3">
                          <p className="text-[11px] font-bold uppercase tracking-wide text-[#8A919C]">
                            Verification Fee
                          </p>

                          <p className="mt-1 text-sm font-black text-[#111318]">
                            $
                            {Number(verificationFee || 0).toLocaleString(
                              "en-US",
                              {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                              }
                            )}
                          </p>
                        </div>

                        <div className="rounded-xl bg-[#F7F8FA] px-4 py-3">
                          <p className="text-[11px] font-bold uppercase tracking-wide text-[#8A919C]">
                            Processing
                          </p>

                          <p className="mt-1 text-sm font-black text-[#111318]">
                            {selectedOption?.label ?? "Instant"}
                          </p>
                        </div>
                      </div>

                      {processingType === "custom" &&
                        customProcessingText.trim() && (
                          <div className="mt-3 rounded-xl bg-[#F7F8FA] px-4 py-3">
                            <p className="text-[11px] font-bold uppercase tracking-wide text-[#8A919C]">
                              Custom Information
                            </p>

                            <p className="mt-1 text-sm font-semibold text-[#111318]">
                              {customProcessingText}
                            </p>
                          </div>
                        )}
                    </div>
                  </div>
                </section>

                <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-end">
                  <button
                    type="button"
                    onClick={loadSettings}
                    disabled={saving}
                    className="rounded-2xl border border-[#DDE1E6] bg-white px-6 py-3.5 text-sm font-bold text-[#3F4652] transition hover:bg-[#F7F8FA] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Cancel Changes
                  </button>

                  <button
                    type="button"
                    onClick={handleSave}
                    disabled={saving}
                    className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#B51F35] px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-[#B51F35]/15 transition hover:bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {saving ? (
                      <>
                        <FiRefreshCw size={17} className="animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <FiSave size={17} />
                        Save Withdrawal Settings
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
