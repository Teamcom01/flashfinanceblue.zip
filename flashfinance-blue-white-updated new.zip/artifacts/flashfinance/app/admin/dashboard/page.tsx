﻿"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FiActivity,
  FiAlertCircle,
  FiArrowDownLeft,
  FiArrowUpRight,
  FiBell,
  FiCheck,
  FiCheckCircle,
  FiChevronDown,
  FiChevronRight,
  FiClock,
  FiCreditCard,
  FiDollarSign,
  FiDownload,
  FiEdit3,
  FiEye,
  FiFileText,
  FiFilter,
  FiHeart,
  FiHome,
  FiInfo,
  FiLock,
  FiLogOut,
  FiMail,
  FiMenu,
  FiMessageSquare,
  FiMoreHorizontal,
  FiRefreshCw,
  FiSearch,
  FiSend,
  FiSettings,
  FiShield,
  FiUser,
  FiUsers,
  FiX,
  FiZap,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type Section =
  | "overview"
  | "applications"
  | "customers"
  | "kyc"
  | "transactions"
  | "support"
  | "activity"
  | "payment-settings";

type ApplicationType = "grant" | "loan";

type User = {
  id: string;
  full_name: string | null;
  phone: string | null;
  email?: string | null;
  role: string | null;
  account_status: string | null;
  account_type: string | null;
  created_at: string;
  balance: number;
};

type Deposit = {
  id: string;
  user_id: string;
  amount: number;
  payment_method: string | null;
  status: string | null;
  reference: string | null;
  created_at: string;
  user_name: string;
};

type Withdrawal = {
  id: string;
  user_id: string;
  amount: number;
  withdrawal_method: string | null;
  destination: string | null;
  note: string | null;
  status: string | null;
  rejection_note: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  user_name: string;
};

type AuditLog = {
  id: string;
  action: string;
  target_user_id: string | null;
  description: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
};

type SupportTicket = {
  id: string;
  user_id: string;
  subject: string | null;
  message: string | null;
  status: string | null;
  priority: string | null;
  assigned_to: string | null;
  admin_reply: string | null;
  replied_at: string | null;
  created_at: string;
  updated_at: string;
  category?: string | null;
  closed_at?: string | null;
  closed_by?: string | null;
  last_admin_id?: string | null;
  user_name: string;
};

type ApplicationRecord = {
  id: string;
  type: ApplicationType;
  user_id: string | null;
  user_name: string;
  status: string;
  amount: number;
  approved_amount: number | null;
  payment_method: string | null;
  payment_destination: string | null;
  purpose: string | null;
  reason: string | null;
  description: string | null;
  income: unknown;
  employment: unknown;
  expenses: unknown;
  documents: unknown;
  created_at: string;
  updated_at: string | null;
  raw: Record<string, unknown>;
};

type FeeRequest = {
  id: string;
  user_id: string;
  user_name: string;
  amount: number;
  fee_type: string | null;
  title: string | null;
  message: string | null;
  status: string | null;
  created_at: string;
  updated_at: string | null;
};

type FeePayment = {
  id: string;
  user_id: string;
  customer_name: string;
  customer_email: string | null;
  amount: number;
  status: string | null;
  reference: string | null;
  description: string | null;
  created_at: string;
};

type PaymentMethodRecord = {
  id: string;
  name: string;
  type: string;
  details: Record<string, unknown>;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
};

type PaymentSettingsRecord = {
  id: string;
  deposit_fee: number;
  withdrawal_fee: number;
  network_fee: number;
  minimum_deposit: number;
  minimum_withdrawal: number;
  deposit_instructions: string | null;
  withdrawal_instructions: string | null;
  fee_payment_instructions: string | null;
  updated_at: string;
};

type InboxMessage = {
  id: string;
  user_id: string;
  user_name: string;
  title: string | null;
  message: string | null;
  action_required: boolean;
  read_at: string | null;
  created_at: string;
};

type KycSubmission = {
  id: string;
  user_id: string;
  first_name: string;
  last_name: string;
  date_of_birth: string;
  address: string;
  city: string;
  state: string;
  zip_code: string | null;
  id_type: string;
  id_document_path: string;
  selfie_path: string;
  status: "under_review" | "approved" | "rejected" | "changes_requested";
  admin_note: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
  user_name: string;
};

const paymentMethods = {
  paypal: { name: "PayPal", icon: "P" },
  cashapp: { name: "Cash App", icon: "$" },
  zelle: { name: "Zelle", icon: "Z" },
  venmo: { name: "Venmo", icon: "V" },
  chime: { name: "Chime", icon: "C" },
  bitcoin: { name: "Bitcoin", icon: "₿" },
  usdt: { name: "USDT", icon: "₮" },
  ethereum: { name: "Ethereum", icon: "Ξ" },
  bank: { name: "Bank Transfer", icon: "B" },
};

const paymentMethodSeed = [
  { type: "paypal", name: "PayPal", sort_order: 0 },
  { type: "bitcoin", name: "Bitcoin", sort_order: 1 },
  { type: "zelle", name: "Zelle", sort_order: 2 },
  { type: "chime", name: "Chime", sort_order: 3 },
  { type: "ethereum", name: "Ethereum", sort_order: 4 },
  { type: "cashapp", name: "Cash App", sort_order: 5 },
  { type: "bank", name: "Bank Transfer", sort_order: 6 },
  { type: "venmo", name: "Venmo", sort_order: 7 },
  { type: "usdt", name: "USDT", sort_order: 8 },
] as const;

const paymentFieldDefinitions: Record<string, { key: string; label: string; placeholder: string }[]> = {
  paypal: [
    { key: "account_name", label: "Account Name", placeholder: "Account holder name" },
    { key: "email", label: "PayPal Email", placeholder: "payments@example.com" },
  ],
  cashapp: [
    { key: "account_name", label: "Account Name", placeholder: "Account holder name" },
    { key: "cashtag", label: "Cash App $Cashtag", placeholder: "$YourCashtag" },
  ],
  zelle: [
    { key: "account_name", label: "Account Name", placeholder: "Account holder name" },
    { key: "email_or_phone", label: "Zelle Email or Phone", placeholder: "Email address or phone number" },
  ],
  venmo: [
    { key: "account_name", label: "Account Name", placeholder: "Account holder name" },
    { key: "username", label: "Venmo Username", placeholder: "@username" },
  ],
  chime: [
    { key: "account_name", label: "Account Name", placeholder: "Account holder name" },
    { key: "chimetag", label: "$ChimeTag", placeholder: "$YourChimeTag" },
  ],
  bitcoin: [
    { key: "network", label: "Network", placeholder: "Bitcoin" },
    { key: "wallet_address", label: "Bitcoin Address", placeholder: "Bitcoin wallet address" },
  ],
  usdt: [
    { key: "network", label: "Network", placeholder: "TRC20, ERC20, BEP20..." },
    { key: "wallet_address", label: "USDT Wallet Address", placeholder: "USDT wallet address" },
  ],
  ethereum: [
    { key: "network", label: "Network", placeholder: "Ethereum (ERC20)" },
    { key: "wallet_address", label: "Ethereum Wallet Address", placeholder: "Ethereum wallet address" },
  ],
  bank: [
    { key: "bank_name", label: "Bank Name", placeholder: "Bank name" },
    { key: "account_name", label: "Account Name", placeholder: "Account holder name" },
    { key: "account_number", label: "Account Number", placeholder: "Account number" },
    { key: "routing_number", label: "Routing Number", placeholder: "Routing number" },
    { key: "account_type", label: "Account Type", placeholder: "Checking, Savings..." },
    { key: "swift_code", label: "SWIFT / BIC", placeholder: "SWIFT or BIC code" },
    { key: "bank_address", label: "Bank Address", placeholder: "Bank branch address" },
  ],
};

function normalizePaymentMethodType(type: unknown, name: unknown) {
  const value = `${safeString(type)} ${safeString(name)}`.toLowerCase().replace(/[_-]+/g, " ");

  if (value.includes("paypal")) return "paypal";
  if (value.includes("bitcoin") || value.includes("btc")) return "bitcoin";
  if (value.includes("zelle")) return "zelle";
  if (value.includes("chime")) return "chime";
  if (value.includes("ethereum") || /\beth\b/.test(value)) return "ethereum";
  if (value.includes("cash app") || value.includes("cashapp")) return "cashapp";
  if (value.includes("bank transfer") || value === "bank") return "bank";
  if (value.includes("venmo")) return "venmo";
  if (value.includes("usdt")) return "usdt";

  return safeString(type).toLowerCase().trim();
}

function paymentFieldAliases(type: string, field: string) {
  const aliases = [field];

  if (field === "wallet_address") {
    aliases.push("bitcoin_address", "address");
  }

  if (type === "chime" && field === "chimetag") {
    // Older builds stored the Chime destination under email/tag.
    aliases.push("tag", "email");
  }

  if (field === "swift_code") aliases.push("swift_bic");
  if (field === "cashtag") aliases.push("tag");

  return [...new Set(aliases)];
}

function paymentDetailValue(
  details: Record<string, unknown>,
  side: "deposit" | "fee",
  type: string,
  field: string,
) {
  const aliases = paymentFieldAliases(type, field);

  for (const alias of aliases) {
    const direct = details[`${side}_${type}_${alias}`];
    if (direct !== undefined && direct !== null && safeString(direct).trim()) {
      return safeString(direct);
    }
  }

  const nested = details[side];
  if (nested && typeof nested === "object") {
    for (const alias of aliases) {
      const nestedValue = (nested as Record<string, unknown>)[alias];
      if (nestedValue !== undefined && nestedValue !== null && safeString(nestedValue).trim()) {
        return safeString(nestedValue);
      }
    }
  }

  // Compatibility with earlier fee keys such as fee_email / fee_account_name.
  if (side === "fee") {
    for (const alias of aliases) {
      const legacyFee = details[`fee_${alias}`];
      if (legacyFee !== undefined && legacyFee !== null && safeString(legacyFee).trim()) {
        return safeString(legacyFee);
      }
    }
  }

  // Deposit fields also populate the original destination keys used by older user screens.
  if (side === "deposit") {
    for (const alias of aliases) {
      const legacy = details[alias];
      if (legacy !== undefined && legacy !== null && safeString(legacy).trim()) {
        return safeString(legacy);
      }
    }
  }

  return "";
}

function writePaymentSideDetails(
  method: PaymentMethodRecord,
  side: "deposit" | "fee",
) {
  const details: Record<string, unknown> = { ...method.details };
  const currentNested =
    details[side] && typeof details[side] === "object"
      ? { ...(details[side] as Record<string, unknown>) }
      : {};

  for (const field of paymentFieldDefinitions[method.type] || []) {
    const value = paymentDetailValue(details, side, method.type, field.key).trim();
    const aliases = paymentFieldAliases(method.type, field.key);

    details[`${side}_${method.type}_${field.key}`] = value;
    currentNested[field.key] = value;

    // Keep compatibility aliases synchronized so existing customer payment screens
    // immediately receive the newly saved destination without needing a data migration.
    for (const alias of aliases) {
      details[`${side}_${method.type}_${alias}`] = value;
      currentNested[alias] = value;

      if (side === "deposit") details[alias] = value;
      if (side === "fee") details[`fee_${alias}`] = value;
    }
  }

  const instructions = paymentInstructionValue(details, side, method.type).trim();
  details[`${side}_${method.type}_instructions`] = instructions;
  currentNested.instructions = instructions;
  details[side] = currentNested;

  if (side === "deposit") details.deposit_note = instructions;
  if (side === "fee") details.fee_note = instructions;

  return details;
}

function paymentInstructionValue(
  details: Record<string, unknown>,
  side: "deposit" | "fee",
  type: string,
) {
  const directKey = `${side}_${type}_instructions`;
  const direct = details[directKey];
  if (direct !== undefined && direct !== null && safeString(direct).trim()) {
    return safeString(direct);
  }

  const nested = details[side];
  if (nested && typeof nested === "object") {
    const nestedInstructions = (nested as Record<string, unknown>).instructions;
    if (nestedInstructions !== undefined && nestedInstructions !== null) {
      return safeString(nestedInstructions);
    }
  }

  if (side === "deposit") {
    return safeString(details.deposit_note || "");
  }

  return "";
}

const withdrawalMethods = paymentMethods;

function money(value: number | string | null | undefined) {
  return Number(value || 0).toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function formatDate(value: string | null | undefined) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "—";

  return date.toLocaleString("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function safeString(value: unknown) {
  if (value === null || value === undefined) return "";

  if (typeof value === "string") return value;

  if (typeof value === "number" || typeof value === "boolean") {
    return String(value);
  }

  try {
    return JSON.stringify(value);
  } catch {
    return "";
  }
}

function firstValue(
  row: Record<string, unknown>,
  keys: string[],
) {
  for (const key of keys) {
    const value = row[key];

    if (
      value !== undefined &&
      value !== null &&
      String(value).trim() !== ""
    ) {
      return value;
    }
  }

  return null;
}

function statusClass(status: string | null | undefined) {
  const value = (status || "pending").toLowerCase();

  if (
    value === "approved" ||
    value === "payment_processing" ||
    value === "active" ||
    value === "answered" ||
    value === "resolved" ||
    value === "paid" ||
    value === "disbursed"
  ) {
    return "border-green-500/20 bg-green-500/10 text-green-400";
  }

  if (
    value === "rejected" ||
    value === "suspended" ||
    value === "closed"
  ) {
    return "border-red-500/20 bg-red-500/10 text-red-400";
  }

  if (
    value === "more_info" ||
    value === "information_requested" ||
    value === "needs_information"
  ) {
    return "border-blue-500/20 bg-blue-500/10 text-blue-400";
  }

  return "border-[#B51F35]/20 bg-[#B51F35]/10 text-[#B51F35]";
}

function priorityClass(priority: string | null | undefined) {
  const value = (priority || "normal").toLowerCase();

  if (value === "urgent") {
    return "border-red-500/30 bg-red-500/10 text-red-400";
  }

  if (value === "high") {
    return "border-orange-500/30 bg-orange-500/10 text-orange-400";
  }

  if (value === "low") {
    return "border-blue-500/20 bg-blue-500/10 text-blue-400";
  }

  return "border-[#E3E7ED] bg-white/5 text-[#6B4A50]";
}

function normalizeApplication(
  row: Record<string, unknown>,
  type: ApplicationType,
  names: Map<string, string>,
): ApplicationRecord {
  const userId = firstValue(row, [
    "user_id",
    "applicant_id",
    "customer_id",
    "profile_id",
  ]);

  const statusValue =
    firstValue(row, [
      "status",
      "application_status",
      "review_status",
    ]) || "pending";

  const amountValue = firstValue(row, [
    "amount",
    "requested_amount",
    "loan_amount",
    "grant_amount",
    "amount_requested",
  ]);

  const approvedAmountValue = firstValue(row, [
    "approved_amount",
    "approvedAmount",
    "final_amount",
    "disbursement_amount",
  ]);

  const paymentMethod = firstValue(row, [
    "payment_method",
    "payout_method",
    "preferred_payment_method",
    "disbursement_method",
    "withdrawal_method",
  ]);

  const paymentDestination = firstValue(row, [
    "payment_destination",
    "payout_destination",
    "destination",
    "payment_account",
    "payout_account",
    "account_number",
    "wallet_address",
    "email",
  ]);

  const purpose = firstValue(row, [
    "purpose",
    "loan_purpose",
    "grant_purpose",
    "assistance_type",
    "reason_for_application",
  ]);

  const reason = firstValue(row, [
    "reason",
    "hardship_reason",
    "financial_hardship",
    "application_reason",
  ]);

  const description = firstValue(row, [
    "description",
    "message",
    "details",
    "additional_information",
    "hardship_description",
  ]);

  const income = firstValue(row, [
    "income",
    "monthly_income",
    "annual_income",
    "income_information",
  ]);

  const employment = firstValue(row, [
    "employment",
    "employment_status",
    "employer",
    "job",
    "occupation",
  ]);

  const expenses = firstValue(row, [
    "expenses",
    "monthly_expenses",
    "expense_information",
  ]);

  const documents = firstValue(row, [
    "documents",
    "supporting_documents",
    "attachments",
    "document_urls",
    "files",
  ]);

  const createdAt = safeString(
    firstValue(row, [
      "created_at",
      "submitted_at",
      "application_date",
    ]),
  );

  const updatedAt = safeString(
    firstValue(row, [
      "updated_at",
      "reviewed_at",
      "modified_at",
    ]),
  );

  return {
    id: safeString(
      firstValue(row, ["id", "application_id"]),
    ),
    type,
    user_id:
      userId === null ? null : safeString(userId),
    user_name:
      userId !== null
        ? names.get(safeString(userId)) || "Unknown Customer"
        : safeString(
            firstValue(row, [
              "full_name",
              "name",
              "applicant_name",
            ]),
          ) || "Unknown Customer",
    status: safeString(statusValue).toLowerCase(),
    amount: Number(amountValue || 0),
    approved_amount:
      approvedAmountValue === null
        ? null
        : Number(approvedAmountValue || 0),
    payment_method:
      paymentMethod === null
        ? null
        : safeString(paymentMethod),
    payment_destination:
      paymentDestination === null
        ? null
        : safeString(paymentDestination),
    purpose:
      purpose === null ? null : safeString(purpose),
    reason:
      reason === null ? null : safeString(reason),
    description:
      description === null
        ? null
        : safeString(description),
    income,
    employment,
    expenses,
    documents,
    created_at: createdAt,
    updated_at: updatedAt || null,
    raw: row,
  };
}

export default function AdminDashboardPage() {
  const router = useRouter();
  const supabase = createClient();

  const applicationsRef =
    useRef<HTMLDivElement | null>(null);
  const transactionsRef =
    useRef<HTMLDivElement | null>(null);
  const depositsRef =
    useRef<HTMLDivElement | null>(null);
  const withdrawalsRef =
    useRef<HTMLDivElement | null>(null);
  const supportRef =
    useRef<HTMLDivElement | null>(null);
  const customerControlRef =
    useRef<HTMLDivElement | null>(null);

  const [adminName, setAdminName] = useState("Admin");

  const [users, setUsers] = useState<User[]>([]);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [withdrawals, setWithdrawals] =
    useState<Withdrawal[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [supportTickets, setSupportTickets] =
    useState<SupportTicket[]>([]);

  const [kycSubmissions, setKycSubmissions] =
    useState<KycSubmission[]>([]);

  const [kycBusyId, setKycBusyId] = useState("");
  const [kycNote, setKycNote] = useState<Record<string, string>>({});

  const [feeRequests, setFeeRequests] = useState<FeeRequest[]>([]);
  const [feePayments, setFeePayments] = useState<FeePayment[]>([]);
  const [paymentMethodsData, setPaymentMethodsData] = useState<PaymentMethodRecord[]>([]);

  // Payment Settings must always render exactly one card per supported payment type.
  // This defensive layer prevents duplicate database rows or stale state from ever
  // producing duplicate payment method cards in the admin UI.
  const uniquePaymentMethodsData = useMemo(() => {
    const byType = new Map<string, PaymentMethodRecord>();

    for (const method of paymentMethodsData) {
      const normalizedType = normalizePaymentMethodType(method.type, method.name);
      if (!paymentMethodSeed.some((seed) => seed.type === normalizedType)) continue;

      if (!byType.has(normalizedType)) {
        byType.set(normalizedType, {
          ...method,
          type: normalizedType,
        });
      }
    }

    return paymentMethodSeed.map((seed) => {
      const existing = byType.get(seed.type);
      return (
        existing || {
          id: `payment-${seed.type}`,
          name: seed.name,
          type: seed.type,
          details: {},
          is_active: true,
          sort_order: seed.sort_order,
          created_at: "",
          updated_at: "",
        }
      );
    });
  }, [paymentMethodsData]);
  const [paymentSettingsData, setPaymentSettingsData] = useState<PaymentSettingsRecord | null>(null);
  const [paymentSettingsLoading, setPaymentSettingsLoading] = useState(false);
  const [paymentSettingsSaving, setPaymentSettingsSaving] = useState(false);
  const [expandedPaymentMethod, setExpandedPaymentMethod] = useState<string | null>(null);
  const [paymentMethodSaving, setPaymentMethodSaving] = useState<string | null>(null);
  const [feePaymentReviewing, setFeePaymentReviewing] = useState("");
  const [paymentSettingsForm, setPaymentSettingsForm] = useState({
    deposit_fee: "0",
    withdrawal_fee: "0",
    network_fee: "0",
    minimum_deposit: "0",
    minimum_withdrawal: "0",
    deposit_instructions: "",
    withdrawal_instructions: "",
    fee_payment_instructions: "",
  });
  const [inboxMessages, setInboxMessages] = useState<InboxMessage[]>([]);
  const [feeEditOpen, setFeeEditOpen] = useState(false);
  const [editingFee, setEditingFee] = useState<FeeRequest | null>(null);
  const [feeEditAmount, setFeeEditAmount] = useState("");
  const [feeEditTitle, setFeeEditTitle] = useState("");
  const [feeEditMessage, setFeeEditMessage] = useState("");
  const [feeEditStatus, setFeeEditStatus] = useState("pending");

  const [grantApplications, setGrantApplications] =
    useState<ApplicationRecord[]>([]);
  const [loanApplications, setLoanApplications] =
    useState<ApplicationRecord[]>([]);

  const [selectedApplication, setSelectedApplication] =
    useState<ApplicationRecord | null>(null);

  const [applicationPaymentMethod, setApplicationPaymentMethod] =
    useState("paypal");
  const [applicationPaymentDestination, setApplicationPaymentDestination] =
    useState("");

  const [applicationTypeFilter, setApplicationTypeFilter] =
    useState<"all" | ApplicationType>("all");

  const [applicationStatusFilter, setApplicationStatusFilter] =
    useState("all");

  const [applicationSearch, setApplicationSearch] =
    useState("");

  const [selectedUser, setSelectedUser] = useState("");
  const [customerSearch, setCustomerSearch] =
    useState("");

  const [activeSection, setActiveSection] =
    useState<Section>("overview");

  const [balanceAmount, setBalanceAmount] = useState("");
  const [balanceReason, setBalanceReason] = useState(
    "FlashFinance balance adjustment",
  );

  const [kycTitle, setKycTitle] = useState(
    "Identity verification required",
  );

  const [kycMessage, setKycMessage] = useState(
    "Please update your identity verification documents to continue using all FlashFinance services.",
  );

  const [userMessageTitle, setUserMessageTitle] =
    useState("Message from FlashFinance");

  const [userMessage, setUserMessage] = useState("");

  const [feeAmount, setFeeAmount] = useState("");
  const [feeType, setFeeType] = useState("service_fee");
  const [feeTitle, setFeeTitle] = useState("Service fee");

  const [feeMessage, setFeeMessage] = useState(
    "A service fee has been requested on your account.",
  );

  const [paymentMethod, setPaymentMethod] =
    useState("paypal");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentDestination, setPaymentDestination] =
    useState("");

  const [paymentNote, setPaymentNote] = useState(
    "Payment instruction created by FlashFinance.",
  );

  const [selectedStatus, setSelectedStatus] =
    useState("active");

  const [selectedRole, setSelectedRole] =
    useState("user");

  const [supportFilter, setSupportFilter] =
    useState("all");

  const [supportSearch, setSupportSearch] =
    useState("");

  const [selectedTicket, setSelectedTicket] =
    useState<SupportTicket | null>(null);

  const [ticketReply, setTicketReply] = useState("");

  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [supportBusy, setSupportBusy] =
    useState(false);

  const [reviewingDeposit, setReviewingDeposit] =
    useState("");

  const [reviewingWithdrawal, setReviewingWithdrawal] =
    useState("");

  const [applicationBusy, setApplicationBusy] =
    useState("");

  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] =
    useState("");

  const [lastRefreshed, setLastRefreshed] =
    useState("");

  const [mobileMenuOpen, setMobileMenuOpen] =
    useState(false);

  const [reviewRequestOpen, setReviewRequestOpen] =
    useState(false);
  const [reviewRequestItems, setReviewRequestItems] =
    useState<string[]>([]);
  const [reviewRequestMessage, setReviewRequestMessage] =
    useState(
      "Please provide the requested information or supporting documents so we can continue reviewing your application.",
    );
  const [reviewRequestSubmitting, setReviewRequestSubmitting] =
    useState(false);

  const [applicationFeeOpen, setApplicationFeeOpen] =
    useState(false);
  const [applicationFeeAmount, setApplicationFeeAmount] =
    useState("");
  const [applicationFeeType, setApplicationFeeType] =
    useState("application_processing");
  const [applicationFeeTitle, setApplicationFeeTitle] =
    useState("Application processing fee");
  const [applicationFeeMessage, setApplicationFeeMessage] =
    useState(
      "A processing fee has been requested for your application.",
    );
  const [applicationFeeSubmitting, setApplicationFeeSubmitting] =
    useState(false);

  const applicationReviewItems = [
    "Government-issued ID",
    "Proof of address",
    "Proof of income",
    "Employment verification",
    "Bank/account verification",
    "Proof of financial hardship",
    "Supporting financial documents",
    "Loan-purpose clarification",
    "Grant-purpose clarification",
    "Payment information",
    "Identity verification",
    "Additional supporting documents",
  ];

  const clearMessages = () => {
    setMessage("");
    setErrorMessage("");
  };

  const getErrorMessage = (error: unknown, fallback: string) => {
    if (error && typeof error === "object" && "message" in error) {
      const value = (error as { message?: unknown }).message;
      if (typeof value === "string" && value.trim()) return value;
    }

    return error instanceof Error && error.message
      ? error.message
      : fallback;
  };

  const loadUsers = async () => {
    const [
      { data: profiles, error: profileError },
      { data: accounts, error: accountError },
    ] = await Promise.all([
      supabase.from("profiles").select("*"),
      supabase.from("accounts").select("user_id, balance"),
    ]);

    if (profileError) throw profileError;
    if (accountError) throw accountError;

    const accountMap = new Map(
      (accounts || []).map((account) => [
        account.user_id,
        Number(account.balance || 0),
      ]),
    );

    const mappedUsers: User[] = (profiles || []).map(
      (profile) => ({
        id: profile.id,
        full_name: profile.full_name || null,
        phone: profile.phone || null,
        role: profile.role || "user",
        account_status:
          profile.account_status || "active",
        account_type:
          profile.account_type || "personal",
        created_at: profile.created_at,
        balance:
          accountMap.get(profile.id) || 0,
      }),
    );

    setUsers(mappedUsers);
  };

  const loadKycSubmissions = async () => {
    const { data, error } = await supabase
      .from("kyc_submissions")
      .select(
        "id, user_id, first_name, last_name, date_of_birth, address, city, state, zip_code, id_type, id_document_path, selfie_path, status, admin_note, reviewed_by, reviewed_at, created_at, updated_at",
      )
      .order("created_at", { ascending: false });

    if (error) throw error;

    const rows = data || [];

    setKycSubmissions(
      rows.map((row) => {
        const user = users.find((item) => item.id === row.user_id);
        const userName =
          [row.first_name, row.last_name].filter(Boolean).join(" ") ||
          user?.full_name ||
          "Customer";

        return {
          ...(row as KycSubmission),
          user_name: userName,
          status: row.status as KycSubmission["status"],
        };
      }),
    );
  };

  const loadDeposits = async () => {
    const { data, error } = await supabase
      .from("deposits")
      .select(
        "id, user_id, amount, payment_method, status, reference, created_at",
      )
      .order("created_at", { ascending: false });

    if (error) throw error;

    const rows = data || [];
    const ids = [
      ...new Set(rows.map((item) => item.user_id)),
    ];

    let profiles: Array<{
      id: string;
      full_name: string | null;
    }> = [];

    if (ids.length) {
      const {
        data: profileData,
        error: profileError,
      } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", ids);

      if (profileError) throw profileError;

      profiles = profileData || [];
    }

    const names = new Map(
      profiles.map((profile) => [
        profile.id,
        profile.full_name || "Unknown User",
      ]),
    );

    setDeposits(
      rows.map((deposit) => ({
        ...deposit,
        amount: Number(deposit.amount || 0),
        user_name:
          names.get(deposit.user_id) ||
          "Unknown User",
      })),
    );
  };

  const loadWithdrawals = async () => {
    const { data, error } = await supabase
      .from("withdrawal_requests")
      .select(
        "id, user_id, amount, withdrawal_method, destination, note, status, rejection_note, reviewed_by, reviewed_at, created_at",
      )
      .order("created_at", { ascending: false });

    if (error) throw error;

    const rows = data || [];
    const ids = [
      ...new Set(rows.map((item) => item.user_id)),
    ];

    let profiles: Array<{
      id: string;
      full_name: string | null;
    }> = [];

    if (ids.length) {
      const {
        data: profileData,
        error: profileError,
      } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", ids);

      if (profileError) throw profileError;

      profiles = profileData || [];
    }

    const names = new Map(
      profiles.map((profile) => [
        profile.id,
        profile.full_name || "Unknown User",
      ]),
    );

    setWithdrawals(
      rows.map((withdrawal) => ({
        ...withdrawal,
        amount: Number(withdrawal.amount || 0),
        user_name:
          names.get(withdrawal.user_id) ||
          "Unknown User",
      })),
    );
  };

  const loadFeeRequests = async () => {
    try {
      const { data, error } = await supabase
        .from("fee_requests")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        setFeeRequests([]);
        return;
      }

      const rows = (data || []) as Record<string, unknown>[];
      const ids = [
        ...new Set(
          rows
            .map((row) =>
              safeString(
                firstValue(row, [
                  "user_id",
                  "recipient_id",
                  "customer_id",
                ]),
              ),
            )
            .filter(Boolean),
        ),
      ];

      let profiles: Array<{ id: string; full_name: string | null }> = [];
      if (ids.length) {
        const { data: profileData } = await supabase
          .from("profiles")
          .select("id, full_name")
          .in("id", ids);
        profiles = profileData || [];
      }

      const names = new Map(
        profiles.map((profile) => [
          profile.id,
          profile.full_name || "Unknown Customer",
        ]),
      );

      setFeeRequests(
        rows.map((row) => {
          const userId = safeString(
            firstValue(row, ["user_id", "recipient_id", "customer_id"]),
          );
          const amountValue = firstValue(row, ["amount", "fee_amount"]);
          const titleValue = firstValue(row, ["title", "subject", "fee_title"]);
          const messageValue = firstValue(row, ["message", "body", "fee_message"]);
          return {
            id: safeString(row.id),
            user_id: userId,
            user_name:
              names.get(userId) ||
              safeString(firstValue(row, ["user_name", "customer_name"])) ||
              "Unknown Customer",
            amount: Number(amountValue || 0),
            fee_type: firstValue(row, ["fee_type", "type"]) === null ? null : safeString(firstValue(row, ["fee_type", "type"])),
            title: titleValue === null ? null : safeString(titleValue),
            message: messageValue === null ? null : safeString(messageValue),
            status: firstValue(row, ["status", "state"]) === null ? "pending" : safeString(firstValue(row, ["status", "state"])),
            created_at: safeString(firstValue(row, ["created_at", "sent_at", "requested_at"])),
            updated_at: firstValue(row, ["updated_at", "modified_at"]) === null ? null : safeString(firstValue(row, ["updated_at", "modified_at"])),
          };
        }),
      );
    } catch {
      setFeeRequests([]);
    }
  };

  const loadInboxMessages = async () => {
    try {
      let rows: Record<string, unknown>[] = [];
      const first = await supabase.from("user_messages").select("*").order("created_at", { ascending: false });
      if (!first.error) rows = (first.data || []) as Record<string, unknown>[];
      if (!rows.length) {
        const second = await supabase.from("notifications").select("*").order("created_at", { ascending: false });
        if (!second.error) rows = (second.data || []) as Record<string, unknown>[];
      }
      const ids = [...new Set(rows.map((row) => safeString(firstValue(row, ["user_id", "recipient_id"]))).filter(Boolean))];
      let profiles: Array<{ id: string; full_name: string | null }> = [];
      if (ids.length) {
        const { data } = await supabase.from("profiles").select("id, full_name").in("id", ids);
        profiles = data || [];
      }
      const names = new Map(profiles.map((profile) => [profile.id, profile.full_name || "Unknown Customer"]));
      setInboxMessages(rows.map((row) => {
        const userId = safeString(firstValue(row, ["user_id", "recipient_id"]));
        return {
          id: safeString(row.id), user_id: userId,
          user_name: names.get(userId) || "Unknown Customer",
          title: firstValue(row, ["title", "subject"]) === null ? null : safeString(firstValue(row, ["title", "subject"])),
          message: firstValue(row, ["message", "body", "content"]) === null ? null : safeString(firstValue(row, ["message", "body", "content"])),
          action_required: Boolean(firstValue(row, ["action_required"])) ,
          read_at: firstValue(row, ["read_at", "opened_at"]) === null ? null : safeString(firstValue(row, ["read_at", "opened_at"])),
          created_at: safeString(firstValue(row, ["created_at", "sent_at"])),
        };
      }));
    } catch {
      setInboxMessages([]);
    }
  };

  const loadAuditLogs = async () => {
    const { data, error } = await supabase.rpc(
      "admin_get_audit_logs",
    );

    if (error) throw error;

    setAuditLogs(data || []);
  };

  const loadSupportTickets = async () => {
    const { data, error } = await supabase
      .from("admin_support_tickets")
      .select(
        "id, user_id, subject, message, status, priority, assigned_to, admin_reply, replied_at, created_at, updated_at, category, closed_at, closed_by, last_admin_id",
      )
      .order("created_at", { ascending: false });

    if (error) throw error;

    const rows = data || [];
    const ids = [
      ...new Set(rows.map((item) => item.user_id)),
    ];

    let profiles: Array<{
      id: string;
      full_name: string | null;
    }> = [];

    if (ids.length) {
      const {
        data: profileData,
        error: profileError,
      } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", ids);

      if (profileError) throw profileError;

      profiles = profileData || [];
    }

    const names = new Map(
      profiles.map((profile) => [
        profile.id,
        profile.full_name || "Unknown User",
      ]),
    );

    setSupportTickets(
      rows.map((ticket) => ({
        ...ticket,
        user_name:
          names.get(ticket.user_id) ||
          "Unknown User",
      })),
    );
  };

  const loadApplications = async () => {
    const { data: profileRows, error: profileError } =
      await supabase
        .from("profiles")
        .select("id, full_name");

    if (profileError) throw profileError;

    const names = new Map<string, string>(
      (profileRows || []).map((profile) => [
        profile.id,
        profile.full_name || "Unknown Customer",
      ]),
    );

    const [
      { data: grantRows, error: grantError },
      { data: loanRows, error: loanError },
    ] = await Promise.all([
      supabase
        .from("grant_requests")
        .select("*")
        .order("created_at", { ascending: false }),
      supabase
        .from("loan_requests")
        .select("*")
        .order("created_at", { ascending: false }),
    ]);

    const grants = !grantError
      ? (grantRows || []).map((row) =>
          normalizeApplication(
            row as Record<string, unknown>,
            "grant",
            names,
          ),
        )
      : [];

    const loans = !loanError
      ? (loanRows || []).map((row) =>
          normalizeApplication(
            row as Record<string, unknown>,
            "loan",
            names,
          ),
        )
      : [];

    setGrantApplications(grants);
    setLoanApplications(loans);

    return { grantError, loanError };
  };

  const loadFeePayments = async () => {
    const collected = new Map<string, Record<string, unknown>>();

    const addRows = (rows: unknown) => {
      const list: Record<string, unknown>[] = [];
      if (Array.isArray(rows)) {
        for (const row of rows) if (row && typeof row === "object") list.push(row as Record<string, unknown>);
      } else if (rows && typeof rows === "object") {
        const objectRows = rows as Record<string, unknown>;
        for (const key of ["data", "payments", "fee_payments", "transactions", "results", "items"]) {
          if (Array.isArray(objectRows[key])) {
            for (const row of objectRows[key] as unknown[]) {
              if (row && typeof row === "object") list.push(row as Record<string, unknown>);
            }
          }
        }
      }
      for (const row of list) {
        const id = safeString(firstValue(row, ["transaction_id", "payment_id", "fee_payment_id", "submission_id", "id"]));
        if (id) collected.set(id, row);
      }
    };

    // Primary source: secure admin RPC. Handle both array and object-shaped RPC responses.
    const rpcResult = await supabase.rpc("admin_get_fee_payments");
    if (!rpcResult.error) addRows(rpcResult.data);

    // Some customer builds store the submitted fee payment in transactions rather than
    // the table used by the RPC. Read all transaction metadata available to the admin and
    // identify fee submissions by fee request IDs, fee descriptors, or fee-related metadata.
    const [feeTableResult, transactionResult, feeRequestResult] = await Promise.all([
      supabase.from("fee_payments").select("*").order("created_at", { ascending: false }),
      supabase.from("transactions").select("*").order("created_at", { ascending: false }),
      supabase.from("fee_requests").select("*").order("created_at", { ascending: false }),
    ]);

    if (!feeTableResult.error) addRows(feeTableResult.data);

    const feeRows = !feeRequestResult.error
      ? ((feeRequestResult.data || []) as Record<string, unknown>[])
      : [];
    const feeRequestIds = new Set<string>();
    const feeRequestUserIds = new Set<string>();
    for (const row of feeRows) {
      const id = safeString(row.id);
      const userId = safeString(firstValue(row, ["user_id", "recipient_id", "customer_id", "profile_id"]));
      if (id) feeRequestIds.add(id);
      if (userId) feeRequestUserIds.add(userId);
    }

    if (!transactionResult.error) {
      for (const row of (transactionResult.data || []) as Record<string, unknown>[]) {
        const id = safeString(firstValue(row, ["transaction_id", "payment_id", "fee_payment_id", "submission_id", "id"]));
        if (!id) continue;

        const reference = safeString(firstValue(row, [
          "reference", "fee_request_id", "request_id", "fee_id", "fee_request", "parent_id"
        ]));
        const userId = safeString(firstValue(row, ["user_id", "customer_id", "profile_id", "recipient_id"]));
        const descriptor = [
          firstValue(row, ["type", "transaction_type", "payment_type", "category", "kind", "transaction_category"]),
          firstValue(row, ["description", "note", "memo", "title", "subject"]),
          firstValue(row, ["payment_method", "method"]),
        ].map((value) => safeString(value).toLowerCase()).join(" ");

        let metadataText = "";
        for (const key of ["metadata", "meta", "details", "payment_details", "receipt", "note", "description"]) {
          const value = row[key];
          if (value !== undefined && value !== null) {
            try { metadataText += ` ${typeof value === "string" ? value : JSON.stringify(value)}`; } catch { /* ignore malformed metadata */ }
          }
        }
        metadataText = metadataText.toLowerCase();

        const status = safeString(firstValue(row, ["status", "payment_status", "state"])).toLowerCase();
        const isFeePayment =
          feeRequestIds.has(reference) ||
          /fee[ _-]?payment/.test(descriptor) ||
          /(?:^|[ _-])fee(?:$|[ _-])/.test(descriptor) ||
          /fee[ _-]?(?:request|payment|id)/.test(metadataText) ||
          (feeRequestUserIds.has(userId) && /pending|submitted|awaiting|review/.test(status) && /paypal|cash ?app|zelle|venmo|chime|bitcoin|usdt|ethereum|bank/.test(descriptor));

        if (isFeePayment && !collected.has(id)) collected.set(id, row);
      }
    }

    const rawRows = [...collected.values()];
    const userIds = [...new Set(rawRows.map((row) => safeString(firstValue(row, ["user_id", "customer_id", "profile_id", "recipient_id"]))).filter(Boolean))];

    let profiles: Array<{ id: string; full_name: string | null; email?: string | null }> = [];
    if (userIds.length) {
      const profileResult = await supabase.from("profiles").select("id, full_name, email").in("id", userIds);
      if (!profileResult.error) profiles = profileResult.data || [];
    }
    const profileMap = new Map(profiles.map((profile) => [profile.id, profile]));

    const mapped = rawRows.map((row): FeePayment => {
      const userId = safeString(firstValue(row, ["user_id", "customer_id", "profile_id", "recipient_id"]));
      const profile = profileMap.get(userId);
      const referenceValue = firstValue(row, ["reference", "fee_request_id", "request_id", "fee_id", "parent_id"]);
      const descriptionValue = firstValue(row, ["description", "note", "memo", "payment_method", "method", "type"]);
      return {
        id: safeString(firstValue(row, ["transaction_id", "payment_id", "fee_payment_id", "submission_id", "id"])),
        user_id: userId,
        customer_name: safeString(firstValue(row, ["customer_name", "user_name", "full_name"])) || profile?.full_name || "Unknown Customer",
        customer_email: safeString(firstValue(row, ["customer_email", "email"])) || profile?.email || null,
        amount: Number(firstValue(row, ["amount", "payment_amount", "fee_amount", "paid_amount"]) || 0),
        status: safeString(firstValue(row, ["status", "payment_status", "state"])) || "pending",
        reference: referenceValue === null ? null : safeString(referenceValue),
        description: descriptionValue === null ? null : safeString(descriptionValue),
        created_at: safeString(firstValue(row, ["created_at", "submitted_at", "paid_at", "payment_date"])) || new Date().toISOString(),
      };
    }).filter((row) => row.id && row.amount > 0).sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());

    setFeePayments(mapped);

    // Do not blank the admin queue if the RPC is stale but another permitted source worked.
    if (rpcResult.error && feeTableResult.error && transactionResult.error) throw rpcResult.error;
  };

  const loadPaymentSettings = async () => {
    setPaymentSettingsLoading(true);
    try {
      const [settingsResult, methodsResult] = await Promise.all([
        supabase
          .from("payment_settings")
          .select("id, deposit_fee, withdrawal_fee, network_fee, minimum_deposit, minimum_withdrawal, deposit_instructions, withdrawal_instructions, fee_payment_instructions, updated_at")
          .order("updated_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        supabase
          .from("payment_methods")
          .select("id, name, type, details, is_active, sort_order, created_at, updated_at")
          .order("sort_order", { ascending: true })
          .order("created_at", { ascending: true }),
      ]);

      if (settingsResult.error) throw settingsResult.error;
      if (methodsResult.error) throw methodsResult.error;

      const settings = settingsResult.data as PaymentSettingsRecord | null;
      setPaymentSettingsData(settings);
      setPaymentSettingsForm({
        deposit_fee: String(Number(settings?.deposit_fee || 0)),
        withdrawal_fee: String(Number(settings?.withdrawal_fee || 0)),
        network_fee: String(Number(settings?.network_fee || 0)),
        minimum_deposit: String(Number(settings?.minimum_deposit || 0)),
        minimum_withdrawal: String(Number(settings?.minimum_withdrawal || 0)),
        deposit_instructions: settings?.deposit_instructions || "",
        withdrawal_instructions: settings?.withdrawal_instructions || "",
        fee_payment_instructions: settings?.fee_payment_instructions || "",
      });

      const existingMethods = new Map<string, Record<string, unknown>>();
      for (const rawRow of (methodsResult.data || []) as Record<string, unknown>[]) {
        const type = normalizePaymentMethodType(rawRow.type, rawRow.name);
        if (paymentMethodSeed.some((seed) => seed.type === type) && !existingMethods.has(type)) {
          existingMethods.set(type, rawRow);
        }
      }

      setPaymentMethodsData(
        paymentMethodSeed.map((seed) => {
          const row = existingMethods.get(seed.type);
          const rawDetails = row?.details;
          const details: Record<string, unknown> =
            rawDetails && typeof rawDetails === "object"
              ? { ...(rawDetails as Record<string, unknown>) }
              : {};

          for (const side of ["deposit", "fee"] as const) {
            for (const field of paymentFieldDefinitions[seed.type] || []) {
              const key = `${side}_${seed.type}_${field.key}`;
              details[key] = paymentDetailValue(details, side, seed.type, field.key);
            }
            details[`${side}_${seed.type}_instructions`] = paymentInstructionValue(details, side, seed.type);
          }

          return {
            id: row?.id ? String(row.id) : crypto.randomUUID(),
            name: String(row?.name || seed.name),
            type: seed.type,
            details,
            is_active: row?.is_active === undefined ? true : Boolean(row.is_active),
            sort_order: seed.sort_order,
            created_at: String(row?.created_at || ""),
            updated_at: String(row?.updated_at || ""),
          };
        }),
      );
    } finally {
      setPaymentSettingsLoading(false);
    }
  };

  const updatePaymentMethodLocal = (id: string, patch: Partial<PaymentMethodRecord>) => {
    setPaymentMethodsData((current) =>
      current.map((method) =>
        method.id === id ? { ...method, ...patch } : method,
      ),
    );
  };

  const updatePaymentMethodDetail = (id: string, key: string, value: string) => {
    setPaymentMethodsData((current) =>
      current.map((method) =>
        method.id === id
          ? { ...method, details: { ...method.details, [key]: value } }
          : method,
      ),
    );
  };

  const upsertPaymentMethodRecord = async (
    method: PaymentMethodRecord,
    details: Record<string, unknown>,
  ) => {
    const rowPayload = {
      name: method.name.trim(),
      type: method.type,
      details,
      is_active: method.is_active,
      sort_order: method.sort_order,
      updated_at: new Date().toISOString(),
    };

    const { data: existingById, error: existingByIdError } = await supabase
      .from("payment_methods")
      .select("id")
      .eq("id", method.id)
      .maybeSingle();

    if (existingByIdError) throw existingByIdError;

    if (existingById?.id) {
      const { error } = await supabase
        .from("payment_methods")
        .update(rowPayload)
        .eq("id", method.id);
      if (error) throw error;
      return;
    }

    const { error } = await supabase.from("payment_methods").insert({
      id: method.id,
      ...rowPayload,
    });
    if (error) throw error;
  };

  const savePaymentMethodSide = async (
    method: PaymentMethodRecord,
    side: "deposit" | "fee",
  ) => {
    const savingKey = `${method.id}:${side}`;

    try {
      setPaymentMethodSaving(savingKey);
      clearMessages();

      const fields = paymentFieldDefinitions[method.type] || [];
      for (const field of fields) {
        const value = paymentDetailValue(method.details, side, method.type, field.key).trim();
        if (!value) {
          throw new Error(
            `${method.name} ${side === "deposit" ? "Deposit" : "Fee"}: ${field.label} is required.`,
          );
        }
      }

      // Only rebuild the side being saved. The opposite side remains untouched.
      const details = writePaymentSideDetails(method, side);
      await upsertPaymentMethodRecord(method, details);
      await loadPaymentSettings();

      setMessage(
        `${method.name} ${side === "deposit" ? "deposit" : "fee payment"} details saved successfully. The other side was not changed.`,
      );
    } catch (error) {
      setErrorMessage(
        getErrorMessage(
          error,
          `Unable to save ${method.name} ${side === "deposit" ? "deposit" : "fee"} details.`,
        ),
      );
    } finally {
      setPaymentMethodSaving(null);
    }
  };

  const savePaymentSettings = async () => {
    try {
      setPaymentSettingsSaving(true);
      clearMessages();

      const numericFields = [
        "deposit_fee",
        "withdrawal_fee",
        "network_fee",
        "minimum_deposit",
        "minimum_withdrawal",
      ] as const;

      for (const field of numericFields) {
        const value = Number(paymentSettingsForm[field]);
        if (!Number.isFinite(value) || value < 0) {
          throw new Error(`Enter a valid non-negative value for ${field.replaceAll("_", " ")}.`);
        }
      }

      const payload = {
        deposit_fee: Number(paymentSettingsForm.deposit_fee),
        withdrawal_fee: Number(paymentSettingsForm.withdrawal_fee),
        network_fee: Number(paymentSettingsForm.network_fee),
        minimum_deposit: Number(paymentSettingsForm.minimum_deposit),
        minimum_withdrawal: Number(paymentSettingsForm.minimum_withdrawal),
        deposit_instructions: paymentSettingsForm.deposit_instructions.trim() || null,
        withdrawal_instructions: paymentSettingsForm.withdrawal_instructions.trim() || null,
        fee_payment_instructions: paymentSettingsForm.fee_payment_instructions.trim() || null,
        updated_at: new Date().toISOString(),
      };

      if (paymentSettingsData?.id) {
        const { error } = await supabase
          .from("payment_settings")
          .update(payload)
          .eq("id", paymentSettingsData.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("payment_settings").insert(payload);
        if (error) throw error;
      }

      // Save populated sides independently. Empty sides are allowed so an admin can
      // configure deposits now and fees later (or the reverse) without blocking Save All.
      for (const method of paymentMethodsData) {
        let details: Record<string, unknown> = { ...method.details };

        for (const side of ["deposit", "fee"] as const) {
          const fields = paymentFieldDefinitions[method.type] || [];
          const hasAnyValue =
            fields.some((field) =>
              paymentDetailValue(details, side, method.type, field.key).trim(),
            ) || paymentInstructionValue(details, side, method.type).trim();

          if (hasAnyValue) {
            const sideMethod = { ...method, details };
            details = writePaymentSideDetails(sideMethod, side);
          }
        }

        await upsertPaymentMethodRecord(method, details);
      }

      await loadPaymentSettings();
      setMessage(
        "Payment settings saved successfully. Deposit and fee destinations remain independent for every payment method.",
      );
    } catch (error) {
      setErrorMessage(getErrorMessage(error, "Unable to save payment settings."));
    } finally {
      setPaymentSettingsSaving(false);
    }
  };

  const handleReviewFeePayment = async (payment: FeePayment, action: "approved" | "rejected") => {
    if (!window.confirm(`Are you sure you want to ${action === "approved" ? "approve" : "reject"} this fee payment of ${money(payment.amount)}?`)) return;

    try {
      setFeePaymentReviewing(payment.id);
      clearMessages();
      const { data, error } = await supabase.rpc("admin_review_fee_payment", {
        p_transaction_id: payment.id,
        p_action: action,
      });
      if (error) throw error;

      const result = Array.isArray(data) ? data[0] : data;
      const remaining = result?.remaining_amount;
      setMessage(
        action === "approved"
          ? `Fee payment approved successfully.${remaining !== undefined ? ` Remaining fee: ${money(Number(remaining))}.` : ""}`
          : "Fee payment rejected successfully. The customer's outstanding fee was not reduced.",
      );

      await Promise.all([loadFeePayments(), loadFeeRequests(), loadAuditLogs()]);
    } catch (error) {
      setErrorMessage(getErrorMessage(error, "Unable to review fee payment."));
    } finally {
      setFeePaymentReviewing("");
    }
  };

  const refreshAll = async () => {
    try {
      clearMessages();

      await Promise.all([
        loadUsers(),
        loadKycSubmissions(),
        loadDeposits(),
        loadWithdrawals(),
        loadAuditLogs(),
        loadSupportTickets(),
        loadFeeRequests(),
        loadFeePayments(),
        loadPaymentSettings(),
        loadInboxMessages(),
      ]);

      const { grantError, loanError } =
        await loadApplications();

      setLastRefreshed(
        new Date().toLocaleTimeString("en-US"),
      );

      if (grantError && loanError) {
        setErrorMessage(
          "Applications could not be loaded because the application tables were not found or are not accessible to FlashFinance.",
        );
      }
    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Unable to refresh FlashFinance data.",
      );
    }
  };

  useEffect(() => {
    const initialize = async () => {
      try {
        setLoading(true);

        const {
          data: { user },
        } = await supabase.auth.getUser();

        if (!user) {
          router.replace("/admin/login");
          return;
        }

        const {
          data: profile,
          error: profileError,
        } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .single();

        if (
          profileError ||
          profile?.role !== "admin"
        ) {
          router.replace("/admin/login");
          return;
        }

        setAdminName(
          profile.full_name || "Admin",
        );

        await refreshAll();
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to load FlashFinance dashboard.",
        );
      } finally {
        setLoading(false);
      }
    };

    initialize();
  }, []);

  useEffect(() => {
    const user = users.find(
      (item) => item.id === selectedUser,
    );

    if (user) {
      setSelectedStatus(
        user.account_status || "active",
      );
      setSelectedRole(
        user.role || "user",
      );
    }
  }, [selectedUser, users]);

  const allApplications = useMemo(
    () => [
      ...grantApplications,
      ...loanApplications,
    ],
    [grantApplications, loanApplications],
  );

  const pendingApplications = useMemo(
    () =>
      allApplications.filter((application) =>
        [
          "pending",
          "submitted",
          "under_review",
          "review",
        ].includes(
          application.status.toLowerCase(),
        ),
      ),
    [allApplications],
  );

  const informationRequestedApplications =
    useMemo(
      () =>
        allApplications.filter((application) =>
          [
            "more_info",
            "information_requested",
            "needs_information",
            "info_requested",
          ].includes(
            application.status.toLowerCase(),
          ),
        ),
      [allApplications],
    );

  const approvedApplications = useMemo(
    () =>
      allApplications.filter((application) =>
        [
          "approved",
          "paid",
          "disbursed",
        ].includes(
          application.status.toLowerCase(),
        ),
      ),
    [allApplications],
  );

  const filteredApplications = useMemo(() => {
    const search =
      applicationSearch.trim().toLowerCase();

    return allApplications
      .filter((application) => {
        if (
          applicationTypeFilter !== "all" &&
          application.type !== applicationTypeFilter
        ) {
          return false;
        }

        if (
          applicationStatusFilter !== "all" &&
          application.status !==
            applicationStatusFilter
        ) {
          return false;
        }

        if (!search) return true;

        return [
          application.id,
          application.user_name,
          application.purpose,
          application.reason,
          application.description,
          application.payment_method,
          application.payment_destination,
          application.status,
        ]
          .filter(Boolean)
          .some((value) =>
            String(value)
              .toLowerCase()
              .includes(search),
          );
      })
      .sort(
        (a, b) =>
          new Date(b.created_at).getTime() -
          new Date(a.created_at).getTime(),
      );
  }, [
    allApplications,
    applicationTypeFilter,
    applicationStatusFilter,
    applicationSearch,
  ]);

  const pendingDeposits = useMemo(
    () =>
      deposits.filter(
        (deposit) =>
          (deposit.status || "").toLowerCase() ===
          "pending",
      ),
    [deposits],
  );

  const pendingWithdrawals = useMemo(
    () =>
      withdrawals.filter(
        (withdrawal) =>
          (
            withdrawal.status || ""
          ).toLowerCase() === "pending",
      ),
    [withdrawals],
  );

  const openSupportTickets = useMemo(
    () =>
      supportTickets.filter((ticket) => {
        const status = (
          ticket.status || "open"
        ).toLowerCase();

        return (
          status !== "resolved" &&
          status !== "closed"
        );
      }),
    [supportTickets],
  );

  const urgentSupportTickets = useMemo(
    () =>
      openSupportTickets.filter(
        (ticket) =>
          (
            ticket.priority || ""
          ).toLowerCase() === "urgent",
      ),
    [openSupportTickets],
  );

  const totalUserBalance = useMemo(
    () =>
      users
        .filter(
          (user) => user.role !== "admin",
        )
        .reduce(
          (total, user) =>
            total + Number(user.balance || 0),
          0,
        ),
    [users],
  );

  const adminUsers = useMemo(
    () =>
      users.filter(
        (user) => user.role === "admin",
      ),
    [users],
  );

  const activeUsers = useMemo(
    () =>
      users.filter(
        (user) =>
          user.role !== "admin" &&
          (user.account_status || "active") ===
            "active",
      ),
    [users],
  );

  const suspendedUsers = useMemo(
    () =>
      users.filter(
        (user) =>
          user.role !== "admin" &&
          (
            user.account_status || ""
          ).toLowerCase() === "suspended",
      ),
    [users],
  );

  const filteredCustomers = useMemo(() => {
    const search =
      customerSearch.trim().toLowerCase();

    return users
      .filter(
        (user) => user.role !== "admin",
      )
      .filter((user) => {
        if (!search) return true;

        return [
          user.full_name,
          user.phone,
          user.email,
          user.account_type,
          user.account_status,
        ]
          .filter(Boolean)
          .some((value) =>
            String(value)
              .toLowerCase()
              .includes(search),
          );
      });
  }, [users, customerSearch]);

  const filteredSupportTickets = useMemo(() => {
    const search =
      supportSearch.trim().toLowerCase();

    return supportTickets.filter((ticket) => {
      const status = (
        ticket.status || "open"
      ).toLowerCase();

      const filterMatches =
        supportFilter === "all" ||
        (supportFilter === "open" &&
          status !== "resolved" &&
          status !== "closed") ||
        status === supportFilter ||
        (supportFilter === "urgent" &&
          (
            ticket.priority || ""
          ).toLowerCase() === "urgent");

      if (!filterMatches) return false;

      if (!search) return true;

      return [
        ticket.subject,
        ticket.message,
        ticket.user_name,
        ticket.category,
        ticket.priority,
        ticket.status,
      ]
        .filter(Boolean)
        .some((value) =>
          String(value)
            .toLowerCase()
            .includes(search),
        );
    });
  }, [
    supportTickets,
    supportFilter,
    supportSearch,
  ]);

  const selectedUserData = useMemo(
    () =>
      users.find(
        (user) => user.id === selectedUser,
      ) || null,
    [users, selectedUser],
  );

  const selectedUserDeposits = useMemo(
    () =>
      deposits.filter(
        (deposit) =>
          deposit.user_id === selectedUser,
      ),
    [deposits, selectedUser],
  );

  const selectedUserWithdrawals = useMemo(
    () =>
      withdrawals.filter(
        (withdrawal) =>
          withdrawal.user_id === selectedUser,
      ),
    [withdrawals, selectedUser],
  );

  const selectedUserTickets = useMemo(
    () =>
      supportTickets.filter(
        (ticket) =>
          ticket.user_id === selectedUser,
      ),
    [supportTickets, selectedUser],
  );

  const selectedUserActivity = useMemo(
    () =>
      auditLogs.filter(
        (log) => log.target_user_id === selectedUser,
      ),
    [auditLogs, selectedUser],
  );

  const selectedUserFees = useMemo(
    () =>
      feeRequests.filter(
        (fee) => fee.user_id === selectedUser,
      ),
    [feeRequests, selectedUser],
  );

  const selectedUserInbox = useMemo(
    () =>
      selectedUserTickets.map((ticket) => ({
        ...ticket,
        inboxState:
          ticket.status &&
          ["open", "pending", "urgent"].includes(
            ticket.status.toLowerCase(),
          ) && !ticket.admin_reply
            ? "Needs attention"
            : ticket.admin_reply
              ? "Replied"
              : "Open",
      })),
    [selectedUserTickets],
  );

  const scrollTo = (
    ref: React.RefObject<HTMLDivElement | null>,
  ) => {
    window.setTimeout(() => {
      ref.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 100);
  };

  const openCustomer = (userId: string) => {
    clearMessages();
    setSelectedUser(userId);
    setActiveSection("customers");
    scrollTo(customerControlRef);
  };

  const openApplication = (
    application: ApplicationRecord,
  ) => {
    clearMessages();
    setSelectedApplication(application);
    setApplicationPaymentMethod(
      application.payment_method || "paypal",
    );
    setApplicationPaymentDestination(
      application.payment_destination || "",
    );
    setActiveSection("applications");

    window.setTimeout(() => {
      applicationsRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 100);
  };

  const openSection = (
    section: Section,
    target?:
      | "applications"
      | "deposits"
      | "withdrawals"
      | "support"
      | "customers",
  ) => {
    clearMessages();
    setActiveSection(section);
    setMobileMenuOpen(false);

    window.setTimeout(() => {
      if (target === "applications") {
        applicationsRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
        return;
      }

      if (target === "deposits") {
        depositsRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
        return;
      }

      if (target === "withdrawals") {
        withdrawalsRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
        return;
      }

      if (target === "support") {
        supportRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
        return;
      }

      if (target === "customers") {
        customerControlRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
        return;
      }

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    }, 100);
  };

  const updateApplicationStatus = async (
    application: ApplicationRecord,
    status: string,
    approvedAmount?: number,
  ) => {
    try {
      setApplicationBusy(application.id);
      clearMessages();

      const table =
        application.type === "grant"
          ? "grant_requests"
          : "loan_requests";

      const payload: Record<string, unknown> = { status };

      if (
        approvedAmount !== undefined &&
        Number.isFinite(approvedAmount)
      ) {
        payload.approved_amount = approvedAmount;
      }

      const { data: updatedRows, error } = await supabase
        .from(table)
        .update(payload)
        .eq("id", application.id)
        .select("id, status, approved_amount");

      if (error) throw error;

      if (!updatedRows || updatedRows.length === 0) {
        throw new Error(
          `No ${application.type} application row was updated. Check the FlashFinance access policy for ${table}.`,
        );
      }

      const updatedRow = updatedRows[0] as Record<string, unknown>;
      const actualStatus = String(updatedRow.status || status);
      const actualApprovedAmount =
        updatedRow.approved_amount !== undefined
          ? Number(updatedRow.approved_amount)
          : approvedAmount !== undefined
            ? approvedAmount
            : application.approved_amount;

      const updated = {
        ...application,
        status: actualStatus,
        approved_amount: Number.isFinite(actualApprovedAmount)
          ? actualApprovedAmount
          : null,
      };

      setSelectedApplication(updated);

      setGrantApplications((current) =>
        current.map((item) =>
          item.id === application.id ? updated : item,
        ),
      );

      setLoanApplications((current) =>
        current.map((item) =>
          item.id === application.id ? updated : item,
        ),
      );

      await loadAuditLogs();

      const applicationLabel =
        application.type === "grant" ? "Grant" : "Loan";

      setMessage(
        `${applicationLabel} application marked ${actualStatus.replace(/_/g, " ")}.`,
      );

      return true;
    } catch (error) {
      setErrorMessage(
        getErrorMessage(error, "Unable to update application status."),
      );
      return false;
    } finally {
      setApplicationBusy("");
    }
  };

  const handleApplicationApprove = async () => {
    if (!selectedApplication) return;

    const amountText = window.prompt(
      `Approved amount for this ${
        selectedApplication.type
      }:`,
      String(
        selectedApplication.approved_amount ??
          selectedApplication.amount ??
          "",
      ),
    );

    if (amountText === null) return;

    const approvedAmount = Number(amountText);

    if (
      !Number.isFinite(approvedAmount) ||
      approvedAmount <= 0
    ) {
      setErrorMessage(
        "Enter a valid approved amount.",
      );
      return;
    }

    if (
      !window.confirm(
        `Approve ${
          selectedApplication.type
        } application for ${money(
          approvedAmount,
        )}?`,
      )
    ) {
      return;
    }

    await updateApplicationStatus(
      selectedApplication,
      "approved",
      approvedAmount,
    );
  };

  const handleApplicationReject = async () => {
    if (!selectedApplication) return;

    const reason = window.prompt(
      "Enter the reason for rejection:",
      "",
    );

    if (reason === null) return;

    if (
      !window.confirm(
        "Reject this application?",
      )
    ) {
      return;
    }

    await updateApplicationStatus(
      selectedApplication,
      "rejected",
    );

    if (selectedApplication.user_id) {
      try {
        await supabase.rpc(
          "admin_send_user_message",
          {
            p_user_id:
              selectedApplication.user_id,
            p_title:
              "Application Update",
            p_message:
              reason.trim() ||
              "Your application has been reviewed and was not approved at this time.",
            p_action_required: false,
            p_action_url: null,
          },
        );
      } catch {
        // Status update remains successful even if notification RPC is unavailable.
      }
    }
  };

  const handleRequestInformation = () => {
    if (!selectedApplication) return;

    clearMessages();
    setReviewRequestItems([]);
    setReviewRequestMessage(
      "Please provide the requested information or supporting documents so we can continue reviewing your application.",
    );
    setReviewRequestOpen(true);
  };

  const submitApplicationReviewRequest = async () => {
    if (!selectedApplication?.user_id) {
      setErrorMessage("This application is not linked to a customer account.");
      return;
    }

    if (reviewRequestItems.length === 0) {
      setErrorMessage("Select at least one item you want the customer to provide.");
      return;
    }

    if (!reviewRequestMessage.trim()) {
      setErrorMessage("Enter a message for the customer.");
      return;
    }

    try {
      setReviewRequestSubmitting(true);
      clearMessages();

      const table =
        selectedApplication.type === "grant"
          ? "grant_requests"
          : "loan_requests";

      const requestedStatus =
        selectedApplication.type === "grant"
          ? "information_requested"
          : "under_review";

      const { data: updatedRows, error: statusError } = await supabase
        .from(table)
        .update({ status: requestedStatus })
        .eq("id", selectedApplication.id)
        .select("id, status");

      if (statusError) throw statusError;

      if (!updatedRows || updatedRows.length === 0) {
        throw new Error(
          `No application row was updated. Check the FlashFinance access policy for ${table}.`,
        );
      }

      const updated = {
        ...selectedApplication,
        status: String(updatedRows[0]?.status || requestedStatus),
      };

      setSelectedApplication(updated);
      setGrantApplications((current) =>
        current.map((item) => item.id === updated.id ? updated : item),
      );
      setLoanApplications((current) =>
        current.map((item) => item.id === updated.id ? updated : item),
      );
      setReviewRequestOpen(false);

      const notificationText = `${reviewRequestMessage.trim()}\n\nRequested items:\n${reviewRequestItems.map((item) => `• ${item}`).join("\n")}`;

      const { error: messageError } = await supabase.rpc(
        "admin_send_user_message",
        {
          p_user_id: selectedApplication.user_id,
          p_title: "Additional information required",
          p_message: notificationText,
          p_action_required: true,
          p_action_url:
            selectedApplication.type === "grant"
              ? "/grants/apply"
              : "/loans",
        },
      );

      if (messageError) {
        setMessage(
          `Application marked as needing information, but the customer notification could not be sent: ${getErrorMessage(messageError, "notification error")}`,
        );
      } else {
        setMessage(
          "Application marked as needing information and the customer was notified.",
        );
      }

      await loadAuditLogs();
    } catch (error) {
      setErrorMessage(
        getErrorMessage(error, "Unable to send the information request."),
      );
    } finally {
      setReviewRequestSubmitting(false);
    }
  };

  const openApplicationFeeRequest = () => {
    if (!selectedApplication?.user_id) {
      setErrorMessage("This application is not linked to a customer account.");
      return;
    }

    clearMessages();
    setApplicationFeeAmount("");
    setApplicationFeeType("application_processing");
    setApplicationFeeTitle("Application processing fee");
    setApplicationFeeMessage(
      "A processing fee has been requested for your application.",
    );
    setApplicationFeeOpen(true);
  };

  const submitApplicationFeeRequest = async () => {
    if (!selectedApplication?.user_id) {
      setErrorMessage("This application is not linked to a customer account.");
      return;
    }

    const amount = Number(applicationFeeAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      setErrorMessage("Enter a valid fee amount.");
      return;
    }

    if (!applicationFeeTitle.trim() || !applicationFeeMessage.trim()) {
      setErrorMessage("Enter a fee title and explanation for the customer.");
      return;
    }

    try {
      setApplicationFeeSubmitting(true);
      clearMessages();

      const { error } = await supabase.rpc("admin_create_fee_request", {
        p_user_id: selectedApplication.user_id,
        p_amount: amount,
        p_fee_type: applicationFeeType,
        p_title: applicationFeeTitle.trim(),
        p_message: applicationFeeMessage.trim(),
      });

      if (error) throw error;

      setApplicationFeeOpen(false);
      setMessage("Application fee request created successfully.");
      await Promise.all([loadFeeRequests(), loadAuditLogs()]);
    } catch (error) {
      setErrorMessage(
        getErrorMessage(error, "Unable to create application fee request."),
      );
    } finally {
      setApplicationFeeSubmitting(false);
    }
  };

  const handleCreateDisbursement =
    async () => {
      if (!selectedApplication) return;

      const approvedAmount =
        Number(
          selectedApplication.approved_amount ||
            selectedApplication.amount ||
            0,
        );

      if (
        !Number.isFinite(approvedAmount) ||
        approvedAmount <= 0
      ) {
        setErrorMessage(
          "Set a valid approved amount first.",
        );
        return;
      }

      if (!selectedApplication.user_id) {
        setErrorMessage(
          "This application is not linked to a customer account.",
        );
        return;
      }

      const method = applicationPaymentMethod.trim();
      const destination =
        applicationPaymentDestination.trim();

      if (!method) {
        setErrorMessage(
          "Select a payment method.",
        );
        return;
      }

      if (!destination) {
        setErrorMessage(
          "Enter the payment destination for the selected method.",
        );
        return;
      }

      const methodName =
        paymentMethods[
          method as keyof typeof paymentMethods
        ]?.name || method;

      if (
        !window.confirm(
          `Create a ${
            selectedApplication.type
          } payout request for ${money(
            approvedAmount,
          )} using ${methodName}?`,
        )
      ) {
        return;
      }

      try {
        setApplicationBusy(
          selectedApplication.id,
        );
        clearMessages();

        const { data, error } =
          await supabase.rpc(
            "admin_create_payment_request",
            {
              p_user_id:
                selectedApplication.user_id,
              p_payment_method: method,
              p_amount: approvedAmount,
              p_destination: destination,
              p_note: `${
                selectedApplication.type ===
                "grant"
                  ? "Grant"
                  : "Loan"
              } application payout for application ${selectedApplication.id}.`,
            },
          );

        if (error) throw error;

        const updated = {
          ...selectedApplication,
          status: "payment_processing",
          approved_amount: approvedAmount,
          payment_method: method,
          payment_destination: destination,
        };

        setSelectedApplication(updated);
        setGrantApplications((current) =>
          current.map((item) =>
            item.id === updated.id
              ? updated
              : item,
          ),
        );
        setLoanApplications((current) =>
          current.map((item) =>
            item.id === updated.id
              ? updated
              : item,
          ),
        );

        await supabase
          .from(
            selectedApplication.type ===
            "grant"
              ? "grant_requests"
              : "loan_requests",
          )
          .update({
            status: "payment_processing",
            approved_amount: approvedAmount,
            payment_method: method,
            payment_destination: destination,
          })
          .eq("id", selectedApplication.id);

        await loadAuditLogs();

        setMessage(
          data?.reference
            ? `Payout request created. Reference: ${data.reference}`
            : "Payout request created successfully.",
        );
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to create payout request.",
        );
      } finally {
        setApplicationBusy("");
      }
    };

  const handleCreditApprovedAmount =
    async () => {
      if (!selectedApplication) return;

      if (!selectedApplication.user_id) {
        setErrorMessage(
          "This application is not linked to a customer.",
        );
        return;
      }

      const amount =
        Number(
          selectedApplication.approved_amount ||
            selectedApplication.amount ||
            0,
        );

      if (
        !Number.isFinite(amount) ||
        amount <= 0
      ) {
        setErrorMessage(
          "Enter a valid approved amount first.",
        );
        return;
      }

      if (
        !window.confirm(
          `Credit ${money(
            amount,
          )} to the customer's FlashFinance internal account?`,
        )
      ) {
        return;
      }

      try {
        setApplicationBusy(
          selectedApplication.id,
        );
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_adjust_user_balance",
            {
              p_user_id:
                selectedApplication.user_id,
              p_amount: amount,
              p_reason: `${
                selectedApplication.type ===
                "grant"
                  ? "Grant"
                  : "Loan"
              } application ${selectedApplication.id} approved.`,
            },
          );

        if (error) throw error;

        await loadUsers();
        await loadAuditLogs();

        setMessage(
          `${money(
            amount,
          )} credited to the customer's internal FlashFinance balance.`,
        );
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to credit approved amount.",
        );
      } finally {
        setApplicationBusy("");
      }
    };

  const handleAdjustBalance =
    async () => {
      if (!selectedUser) {
        setErrorMessage(
          "Please select a customer first.",
        );
        return;
      }

      const amount =
        Number(balanceAmount);

      if (!amount || amount === 0) {
        setErrorMessage(
          "Enter a valid balance adjustment.",
        );
        return;
      }

      if (
        !window.confirm(
          `Confirm ${
            amount > 0
              ? "adding"
              : "removing"
          } ${money(
            Math.abs(amount),
          )} ${
            amount > 0
              ? "to"
              : "from"
          } this customer's balance?`,
        )
      ) {
        return;
      }

      try {
        setBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_adjust_user_balance",
            {
              p_user_id: selectedUser,
              p_amount: amount,
              p_reason:
                balanceReason.trim() ||
                "FlashFinance balance adjustment",
            },
          );

        if (error) throw error;

        setBalanceAmount("");
        setMessage(
          "Customer balance updated successfully.",
        );

        await Promise.all([
          loadUsers(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to adjust customer balance.",
        );
      } finally {
        setBusy(false);
      }
    };

  const handleOpenKycFile = async (path: string) => {
    try {
      clearMessages();

      const { data, error } = await supabase.storage
        .from("kyc-documents")
        .createSignedUrl(path, 300);

      if (error) throw error;

      if (!data?.signedUrl) {
        throw new Error("Unable to create a secure document link.");
      }

      window.open(data.signedUrl, "_blank", "noopener,noreferrer");
    } catch (error) {
      setErrorMessage(
        getErrorMessage(error, "Unable to open KYC document."),
      );
    }
  };

  const handleKycStatus = async (
    submission: KycSubmission,
    status: KycSubmission["status"],
  ) => {
    const label =
      status === "approved"
        ? "approve"
        : status === "rejected"
          ? "reject"
          : "request changes for";

    if (!window.confirm(`Are you sure you want to ${label} ${submission.user_name}'s KYC submission?`)) {
      return;
    }

    try {
      setKycBusyId(submission.id);
      clearMessages();

      const { error } = await supabase.rpc("admin_update_kyc_status", {
        p_kyc_id: submission.id,
        p_status: status,
        p_admin_note: (kycNote[submission.id] || "").trim() || null,
      });

      if (error) throw error;

      setMessage(
        status === "approved"
          ? "KYC submission approved successfully."
          : status === "rejected"
            ? "KYC submission rejected successfully."
            : "Changes requested from the customer successfully.",
      );

      await Promise.all([loadKycSubmissions(), loadUsers(), loadAuditLogs()]);
    } catch (error) {
      setErrorMessage(
        getErrorMessage(error, "Unable to update the KYC submission."),
      );
    } finally {
      setKycBusyId("");
    }
  };

  const handleRemoveKycRequest = async (submission: KycSubmission) => {
    if (!window.confirm(`Remove the outstanding KYC request from ${submission.user_name}'s dashboard?`)) {
      return;
    }

    try {
      setKycBusyId(submission.id);
      clearMessages();

      const { error } = await supabase.rpc("admin_remove_kyc_request", {
        p_user_id: submission.user_id,
      });

      if (error) throw error;

      setMessage("KYC request removed from the customer's dashboard.");
      await loadInboxMessages();
      await loadAuditLogs();
    } catch (error) {
      setErrorMessage(
        getErrorMessage(error, "Unable to remove the KYC request."),
      );
    } finally {
      setKycBusyId("");
    }
  };

  const handleSendKyc = async () => {
    if (!selectedUser) {
      setErrorMessage(
        "Please select a customer first.",
      );
      return;
    }

    try {
      setBusy(true);
      clearMessages();

      const { error } =
        await supabase.rpc(
          "admin_send_kyc_request",
          {
            p_user_id: selectedUser,
            p_title: kycTitle,
            p_message: kycMessage,
            p_required_items: [
              "Government ID",
              "Proof of address",
              "Selfie verification",
            ],
          },
        );

      if (error) throw error;

      setMessage(
        "KYC request sent successfully.",
      );

      await loadAuditLogs();
    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : typeof error === "object" &&
              error !== null &&
              "message" in error
            ? String(
                (error as { message?: unknown })
                  .message ||
                  "Unable to send KYC request.",
              )
            : "Unable to send KYC request.",
      );
    } finally {
      setBusy(false);
    }
  };

  const handleSendMessage =
    async () => {
      if (!selectedUser) {
        setErrorMessage(
          "Please select a customer first.",
        );
        return;
      }

      if (!userMessage.trim()) {
        setErrorMessage(
          "Please enter a message.",
        );
        return;
      }

      try {
        setBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_send_user_message",
            {
              p_user_id: selectedUser,
              p_title:
                userMessageTitle.trim() ||
                "Message from FlashFinance",
              p_message:
                userMessage.trim(),
              p_action_required: false,
              p_action_url: null,
            },
          );

        if (error) throw error;

        setUserMessage("");

        setMessage(
          "Message sent successfully.",
        );

        await loadAuditLogs();
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to send customer message.",
        );
      } finally {
        setBusy(false);
      }
    };

  const openFeeEditor = (fee: FeeRequest) => {
    setEditingFee(fee);
    setFeeEditAmount(String(fee.amount));
    setFeeEditTitle(fee.title || "");
    setFeeEditMessage(fee.message || "");
    setFeeEditStatus(fee.status || "pending");
    setFeeEditOpen(true);
    clearMessages();
  };

  const saveFeeEdit = async () => {
    if (!editingFee) return;
    const amount = Number(feeEditAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      setErrorMessage("Enter a valid fee amount.");
      return;
    }
    try {
      setBusy(true);
      const { error } = await supabase.from("fee_requests").update({
        amount, title: feeEditTitle.trim(), message: feeEditMessage.trim(), status: feeEditStatus, updated_at: new Date().toISOString(),
      }).eq("id", editingFee.id);
      if (error) throw error;
      setFeeEditOpen(false);
      setEditingFee(null);
      setMessage("FlashFinance fee request updated successfully.");
      await loadFeeRequests();
      await loadAuditLogs();
    } catch (error) {
      setErrorMessage(getErrorMessage(error, "Unable to update fee request."));
    } finally {
      setBusy(false);
    }
  };

  const handleCreateFee =
    async () => {
      if (!selectedUser) {
        setErrorMessage(
          "Please select a customer first.",
        );
        return;
      }

      const amount =
        Number(feeAmount);

      if (!amount || amount <= 0) {
        setErrorMessage(
          "Enter a valid fee amount.",
        );
        return;
      }

      try {
        setBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_create_fee_request",
            {
              p_user_id: selectedUser,
              p_amount: amount,
              p_fee_type: feeType,
              p_title: feeTitle,
              p_message: feeMessage,
            },
          );

        if (error) throw error;

        setFeeAmount("");

        setMessage(
          "Fee request created successfully.",
        );

        await Promise.all([loadFeeRequests(), loadAuditLogs()]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to create fee request.",
        );
      } finally {
        setBusy(false);
      }
    };

  const handleCreatePayment =
    async () => {
      if (!selectedUser) {
        setErrorMessage(
          "Please select a customer first.",
        );
        return;
      }

      const amount =
        Number(paymentAmount);

      if (!amount || amount <= 0) {
        setErrorMessage(
          "Enter a valid payment amount.",
        );
        return;
      }

      if (!paymentDestination.trim()) {
        setErrorMessage(
          "Enter a payment destination.",
        );
        return;
      }

      try {
        setBusy(true);
        clearMessages();

        const { data, error } =
          await supabase.rpc(
            "admin_create_payment_request",
            {
              p_user_id: selectedUser,
              p_payment_method:
                paymentMethod,
              p_amount: amount,
              p_destination:
                paymentDestination.trim(),
              p_note:
                paymentNote.trim(),
            },
          );

        if (error) throw error;

        setPaymentAmount("");
        setPaymentDestination("");

        setMessage(
          data?.reference
            ? `Payment instruction created. Reference: ${data.reference}`
            : "Payment instruction created successfully.",
        );

        await loadAuditLogs();
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to create payment request.",
        );
      } finally {
        setBusy(false);
      }
    };

  const handleStatusChange =
    async (status: string) => {
      if (!selectedUser) return;

      try {
        setBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_update_user_status",
            {
              p_user_id: selectedUser,
              p_status: status,
            },
          );

        if (error) throw error;

        setSelectedStatus(status);

        setMessage(
          "Customer account status updated.",
        );

        await Promise.all([
          loadUsers(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to update account status.",
        );
      } finally {
        setBusy(false);
      }
    };

  const handleRoleChange =
    async (role: string) => {
      if (!selectedUser) return;

      if (
        role === "admin" &&
        !window.confirm(
          "Are you sure you want to make this customer an administrator?",
        )
      ) {
        return;
      }

      try {
        setBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_update_user_role",
            {
              p_user_id: selectedUser,
              p_role: role,
            },
          );

        if (error) throw error;

        setSelectedRole(role);

        setMessage(
          "Customer role updated.",
        );

        await Promise.all([
          loadUsers(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to update customer role.",
        );
      } finally {
        setBusy(false);
      }
    };

  const handleReviewDeposit =
    async (
      deposit: Deposit,
      action: "approved" | "rejected",
    ) => {
      if (
        !window.confirm(
          `Are you sure you want to ${
            action === "approved"
              ? "approve"
              : "reject"
          } this deposit?`,
        )
      ) {
        return;
      }

      try {
        setReviewingDeposit(
          deposit.id,
        );
        clearMessages();

        if (action === "approved") {
          const { error } =
            await supabase.rpc(
              "approve_deposit",
              {
                p_deposit_id:
                  deposit.id,
              },
            );

          if (error) throw error;
        } else {
          const { error } =
            await supabase.rpc(
              "admin_review_deposit",
              {
                deposit_id: deposit.id,
                new_status: "rejected",
              },
            );

          if (error) throw error;
        }

        setMessage(
          `Deposit ${
            action === "approved"
              ? "approved"
              : "rejected"
          } successfully.`,
        );

        await Promise.all([
          loadDeposits(),
          loadUsers(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to review deposit.",
        );
      } finally {
        setReviewingDeposit("");
      }
    };

  const handleReviewWithdrawal =
    async (
      withdrawal: Withdrawal,
      action: "approved" | "rejected",
    ) => {
      if (
        !window.confirm(
          `Are you sure you want to ${
            action === "approved"
              ? "approve"
              : "reject"
          } this withdrawal?`,
        )
      ) {
        return;
      }

      try {
        setReviewingWithdrawal(
          withdrawal.id,
        );
        clearMessages();

        if (action === "approved") {
          const { error } =
            await supabase.rpc(
              "approve_withdrawal",
              {
                p_withdrawal_id:
                  withdrawal.id,
              },
            );

          if (error) throw error;
        } else {
          const { error } =
            await supabase.rpc(
              "reject_withdrawal",
              {
                p_withdrawal_id:
                  withdrawal.id,
                p_rejection_note:
                  "Withdrawal request rejected by FlashFinance.",
              },
            );

          if (error) throw error;
        }

        setMessage(
          `Withdrawal ${
            action === "approved"
              ? "approved"
              : "rejected"
          } successfully.`,
        );

        await Promise.all([
          loadWithdrawals(),
          loadUsers(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to review withdrawal.",
        );
      } finally {
        setReviewingWithdrawal("");
      }
    };

  const handleReplyTicket =
    async () => {
      if (!selectedTicket) return;

      if (!ticketReply.trim()) {
        setErrorMessage(
          "Please enter a reply.",
        );
        return;
      }

      try {
        setSupportBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_reply_support_ticket",
            {
              p_ticket_id:
                selectedTicket.id,
              p_reply:
                ticketReply.trim(),
            },
          );

        if (error) throw error;

        setMessage(
          "Support reply sent successfully.",
        );

        await Promise.all([
          loadSupportTickets(),
          loadAuditLogs(),
        ]);

        const {
          data: refreshedTicket,
        } = await supabase
          .from("admin_support_tickets")
          .select(
            "id, user_id, subject, message, status, priority, assigned_to, admin_reply, replied_at, created_at, updated_at, category, closed_at, closed_by, last_admin_id",
          )
          .eq("id", selectedTicket.id)
          .single();

        if (refreshedTicket) {
          setSelectedTicket({
            ...refreshedTicket,
            user_name:
              selectedTicket.user_name,
          });

          setTicketReply(
            refreshedTicket.admin_reply ||
              "",
          );
        }
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to send support reply.",
        );
      } finally {
        setSupportBusy(false);
      }
    };

  const handleTicketStatus =
    async (
      ticket: SupportTicket,
      status: string,
    ) => {
      try {
        setSupportBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_update_support_ticket_status",
            {
              p_ticket_id: ticket.id,
              p_status: status,
            },
          );

        if (error) throw error;

        setSelectedTicket({
          ...ticket,
          status,
        });

        setMessage(
          "Support ticket status updated.",
        );

        await Promise.all([
          loadSupportTickets(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to update support ticket status.",
        );
      } finally {
        setSupportBusy(false);
      }
    };

  const handleTicketPriority =
    async (
      ticket: SupportTicket,
      priority: string,
    ) => {
      try {
        setSupportBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_update_support_ticket_priority",
            {
              p_ticket_id: ticket.id,
              p_priority: priority,
            },
          );

        if (error) throw error;

        setSelectedTicket({
          ...ticket,
          priority,
        });

        setMessage(
          "Support ticket priority updated.",
        );

        await Promise.all([
          loadSupportTickets(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to update support ticket priority.",
        );
      } finally {
        setSupportBusy(false);
      }
    };

  const handleTicketCategory =
    async (
      ticket: SupportTicket,
      category: string,
    ) => {
      try {
        setSupportBusy(true);
        clearMessages();

        const { error } =
          await supabase.rpc(
            "admin_update_support_ticket_category",
            {
              p_ticket_id: ticket.id,
              p_category: category,
            },
          );

        if (error) throw error;

        setSelectedTicket({
          ...ticket,
          category,
        });

        setMessage(
          "Support ticket category updated.",
        );

        await Promise.all([
          loadSupportTickets(),
          loadAuditLogs(),
        ]);
      } catch (error) {
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Unable to update support ticket category.",
        );
      } finally {
        setSupportBusy(false);
      }
    };

  const handleLogout =
    async () => {
      await supabase.auth.signOut();
      router.replace("/admin/login");
    };

  const navItems: Array<{
    id: Section;
    label: string;
    icon: React.ReactNode;
    badge?: number;
  }> = [
    {
      id: "overview",
      label: "Overview",
      icon: <FiActivity />,
    },
    {
      id: "applications",
      label: "Applications",
      icon: <FiFileText />,
      badge:
        pendingApplications.length +
        informationRequestedApplications.length,
    },
    {
      id: "customers",
      label: "Customers",
      icon: <FiUsers />,
    },
    {
      id: "kyc",
      label: "KYC Verification",
      icon: <FiShield />,
      badge: kycSubmissions.filter((item) => item.status === "under_review").length,
    },
    {
      id: "transactions",
      label: "Transactions",
      icon: <FiCreditCard />,
      badge:
        pendingDeposits.length +
        pendingWithdrawals.length +
        feePayments.filter((item) => (item.status || "pending").toLowerCase() === "pending").length,
    },
    {
      id: "payment-settings",
      label: "Payment Settings",
      icon: <FiSettings />,
    },
    {
      id: "support",
      label: "Support",
      icon: <FiMessageSquare />,
      badge:
        openSupportTickets.length,
    },
    {
      id: "activity",
      label: "FlashFinance Activity",
      icon: <FiActivity />,
    },
  ];

  if (loading) {
    return (
      <main className="admin-dashboard-shell flex min-h-screen items-center justify-center bg-[#F8F9FB] text-[#2B1A1E]">
        <div className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#B51F35] text-2xl font-black text-black shadow-2xl shadow-[#B51F35]/10">
            F
          </div>

          <h1 className="mt-5 text-xl font-bold">
            FlashFinance
          </h1>

          <p className="mt-2 text-sm text-gray-600">
            Loading FlashFinance Control Center...
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="admin-dashboard-shell min-h-screen bg-[#F8F9FB] text-[#2B1A1E]">
      <header className="sticky top-0 z-50 border-b border-[#E3E7ED] bg-[#050505]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1700px] items-center justify-between px-4 py-4 lg:px-8">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() =>
                setMobileMenuOpen(
                  !mobileMenuOpen,
                )
              }
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#E3E7ED] bg-white/5 lg:hidden"
            >
              {mobileMenuOpen ? (
                <FiX />
              ) : (
                <FiMenu />
              )}
            </button>

            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35] font-black text-black shadow-lg shadow-[#B51F35]/10">
              F
            </div>

            <div>
              <p className="text-[10px] uppercase tracking-[0.25em] text-[#B51F35]">
                FlashFinance
              </p>

              <h1 className="mt-0.5 text-base font-bold sm:text-lg">
                FlashFinance Control Center
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-xl border border-[#E3E7ED] bg-white/[0.03] px-3 py-2 sm:flex">
              <FiBell className="text-[#5C4147]" />

              <span className="text-xs text-[#6B4A50]">
                {pendingApplications.length +
                  pendingDeposits.length +
                  pendingWithdrawals.length +
                  openSupportTickets.length}{" "}
                items need attention
              </span>
            </div>

            <button
              type="button"
              onClick={refreshAll}
              className="flex h-10 items-center gap-2 rounded-xl border border-[#E3E7ED] px-3 text-sm text-[#4B3439] transition hover:border-[#B51F35]/30 hover:bg-white/5 hover:text-[#1F2937]"
            >
              <FiRefreshCw size={15} />
              <span className="hidden sm:block">
                Refresh
              </span>
            </button>

            <button
              type="button"
              onClick={handleLogout}
              className="flex h-10 items-center gap-2 rounded-xl border border-red-500/20 px-3 text-sm text-red-400 transition hover:bg-red-500/10"
            >
              <FiLogOut size={15} />
              <span className="hidden sm:block">
                Logout
              </span>
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1700px]">
        <aside className="hidden min-h-[calc(100vh-73px)] w-64 shrink-0 border-r border-[#E3E7ED] p-5 lg:block">
          <div className="sticky top-[93px]">
            <div className="mb-6 rounded-2xl border border-[#E3E7ED] bg-white/[0.03] p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35] font-bold text-black">
                  {adminName
                    .charAt(0)
                    .toUpperCase()}
                </div>

                <div className="min-w-0">
                  <p className="truncate text-sm font-bold">
                    {adminName}
                  </p>

                  <p className="mt-1 flex items-center gap-1 text-[10px] uppercase tracking-wider text-[#B51F35]">
                    <FiShield size={10} />
                    Staff
                  </p>
                </div>
              </div>
            </div>

            <p className="mb-3 px-3 text-[10px] uppercase tracking-[0.25em] text-gray-600">
              Workspace
            </p>

            <nav className="space-y-1">
              {navItems.map((item) => {
                const active =
                  activeSection === item.id;

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() =>
                      openSection(
                        item.id,
                      )
                    }
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition ${
                      active
                        ? "bg-[#B51F35] text-black shadow-lg shadow-[#B51F35]/10"
                        : "text-[#5C4147] hover:bg-white/5 hover:text-[#1F2937]"
                    }`}
                  >
                    <span
                      className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                        active
                          ? "bg-[#F8F9FB]/10"
                          : "bg-white/5"
                      }`}
                    >
                      {item.icon}
                    </span>

                    <span className="flex-1">
                      {item.label}
                    </span>

                    {!!item.badge && (
                      <span
                        className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${
                          active
                            ? "bg-[#F8F9FB]/10"
                            : "bg-[#B51F35] text-black"
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            <div className="mt-8 rounded-2xl border border-[#B51F35]/10 bg-[#B51F35]/5 p-4">
              <div className="flex items-center gap-2 text-[#B51F35]">
                <FiLock size={13} />

                <p className="text-[10px] uppercase tracking-wider">
                  FlashFinance access
                </p>
              </div>

              <p className="mt-2 text-xs leading-5 text-[#5C4147]">
                Customer, application, transaction and support controls are available from this workspace.
              </p>
            </div>
          </div>
        </aside>

        {mobileMenuOpen && (
          <div className="fixed inset-x-0 top-[73px] z-40 border-b border-[#E3E7ED] bg-[#080808] p-4 lg:hidden">
            <nav className="grid gap-2 sm:grid-cols-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() =>
                    openSection(
                      item.id,
                    )
                  }
                  className={`flex items-center gap-3 rounded-xl p-3 text-left text-sm ${
                    activeSection === item.id
                      ? "bg-[#B51F35] text-black"
                      : "border border-[#E3E7ED] bg-white/5 text-[#6B4A50]"
                  }`}
                >
                  {item.icon}

                  <span className="flex-1">
                    {item.label}
                  </span>

                  {!!item.badge && (
                    <span className="rounded-full bg-red-500 px-2 py-0.5 text-[9px] font-bold text-[#1F2937]">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>
        )}

        <section className="min-w-0 flex-1 px-4 py-6 lg:px-8 lg:py-8">
          <div className="mb-7">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
              <div>
                <p className="text-sm text-[#5C4147]">
                  Welcome back, {adminName}
                </p>

                <h2 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">
                  {activeSection ===
                    "overview" &&
                    "FlashFinance Overview"}

                  {activeSection ===
                    "applications" &&
                    "Applications"}

                  {activeSection ===
                    "customers" &&
                    "Customer Management"}

                  {activeSection ===
                    "transactions" &&
                    "Transactions"}

                  {activeSection ===
                    "kyc" &&
                    "KYC Verification"}

                  {activeSection ===
                    "support" &&
                    "Support Center"}

                  {activeSection ===
                    "activity" &&
                    "FlashFinance Activity"}

                  {activeSection ===
                    "payment-settings" &&
                    "Payment Settings"}
                </h2>

                <p className="mt-2 max-w-3xl text-sm leading-6 text-gray-600">
                  Manage customers, applications,
                  decisions, disbursements,
                  transactions and support from one FlashFinance workspace.
                </p>
              </div>

              <div className="rounded-xl border border-[#E3E7ED] bg-white/[0.03] px-4 py-3">
                <p className="text-[10px] uppercase tracking-wider text-gray-600">
                  Last refreshed
                </p>

                <p className="mt-1 text-xs font-semibold text-[#6B4A50]">
                  {lastRefreshed ||
                    "Not refreshed yet"}
                </p>
              </div>
            </div>
          </div>

          {message && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm text-green-300">
              <FiCheckCircle
                className="mt-0.5 shrink-0"
                size={17}
              />

              <span>{message}</span>
            </div>
          )}

          {errorMessage && (
            <div className="mb-5 flex items-start gap-3 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-300">
              <FiAlertCircle
                className="mt-0.5 shrink-0"
                size={17}
              />

              <span>{errorMessage}</span>
            </div>
          )}

          {activeSection ===
            "overview" && (
            <>
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <div className="rounded-3xl border border-[#B51F35]/20 bg-gradient-to-br from-[#B51F35]/[0.12] to-transparent p-5">
                  <div className="flex items-center justify-between">
                    <p className="text-xs uppercase tracking-wider text-[#B51F35]">
                      FlashFinance balance
                    </p>

                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                      <FiDollarSign />
                    </div>
                  </div>

                  <p className="mt-4 text-2xl font-black">
                    Not available
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Use the transaction and account records below for current operational totals.
                  </p>
                </div>

                <div className="rounded-3xl border border-[#B51F35]/20 bg-gradient-to-br from-[#B51F35]/[0.12] to-transparent p-5">
                  <div className="flex items-center justify-between">
                    <p className="text-xs uppercase tracking-wider text-[#B51F35]">
                      Customer balances
                    </p>

                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                      <FiDollarSign />
                    </div>
                  </div>

                  <p className="mt-4 text-2xl font-black">
                    {money(
                      totalUserBalance,
                    )}
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Across customer accounts
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    openSection(
                      "applications",
                      "applications",
                    )
                  }
                  className="rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB] p-5 text-left transition hover:border-[#B51F35]/50"
                >
                  <div className="flex items-center justify-between">
                    <p className="text-xs uppercase tracking-wider text-gray-600">
                      Applications
                    </p>

                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                      <FiFileText />
                    </div>
                  </div>

                  <p className="mt-4 text-2xl font-black text-[#B51F35]">
                    {pendingApplications.length}
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Waiting for review
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    openSection(
                      "transactions",
                      "deposits",
                    )
                  }
                  className="rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB] p-5 text-left transition hover:border-[#B51F35]/40"
                >
                  <div className="flex items-center justify-between">
                    <p className="text-xs uppercase tracking-wider text-gray-600">
                      Deposits
                    </p>

                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5 text-[#6B4A50]">
                      <FiArrowDownLeft />
                    </div>
                  </div>

                  <p className="mt-4 text-2xl font-black">
                    {pendingDeposits.length}
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Pending approval
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    openSection(
                      "support",
                      "support",
                    )
                  }
                  className="rounded-3xl border border-red-500/20 bg-[#F8F9FB] p-5 text-left transition hover:border-red-400/50"
                >
                  <div className="flex items-center justify-between">
                    <p className="text-xs uppercase tracking-wider text-gray-600">
                      Support
                    </p>

                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-500/10 text-red-400">
                      <FiMessageSquare />
                    </div>
                  </div>

                  <p className="mt-4 text-2xl font-black text-red-400">
                    {openSupportTickets.length}
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Open tickets
                  </p>
                </button>
              </div>

              <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    Customers
                  </p>

                  <p className="mt-2 text-2xl font-black">
                    {
                      users.filter(
                        (user) =>
                          user.role !==
                          "admin",
                      ).length
                    }
                  </p>

                  <p className="mt-1 text-xs text-green-400">
                    {activeUsers.length} active
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    More information
                  </p>

                  <p className="mt-2 text-2xl font-black text-blue-400">
                    {
                      informationRequestedApplications.length
                    }
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Applications awaiting customer response
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    Withdrawals
                  </p>

                  <p className="mt-2 text-2xl font-black">
                    {pendingWithdrawals.length}
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Pending review
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    Approved applications
                  </p>

                  <p className="mt-2 text-2xl font-black text-green-400">
                    {approvedApplications.length}
                  </p>

                  <p className="mt-1 text-xs text-gray-600">
                    Approved or disbursed
                  </p>
                </div>
              </div>

              <section className="mt-6 rounded-3xl border border-[#B51F35]/20 bg-gradient-to-br from-[#B51F35]/[0.08] to-transparent p-5">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.25em] text-[#B51F35]">
                      Application workflow
                    </p>

                    <h3 className="mt-1 text-xl font-black">
                      Applications requiring attention
                    </h3>

                    <p className="mt-1 text-sm text-gray-600">
                      Review applications, request additional information, approve or reject, then create a disbursement instruction when appropriate.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      openSection(
                        "applications",
                        "applications",
                      )
                    }
                    className="rounded-xl bg-[#B51F35] px-4 py-2.5 text-xs font-bold text-black hover:bg-[#B51F35]"
                  >
                    Open Applications
                  </button>
                </div>

                <div className="mt-5 grid gap-3 md:grid-cols-4">
                  <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB]/30 p-4">
                    <p className="text-xs text-gray-600">
                      Awaiting review
                    </p>

                    <p className="mt-2 text-2xl font-black text-[#B51F35]">
                      {pendingApplications.length}
                    </p>
                  </div>

                  <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB]/30 p-4">
                    <p className="text-xs text-gray-600">
                      More information
                    </p>

                    <p className="mt-2 text-2xl font-black text-blue-400">
                      {
                        informationRequestedApplications.length
                      }
                    </p>
                  </div>

                  <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB]/30 p-4">
                    <p className="text-xs text-gray-600">
                      Grants
                    </p>

                    <p className="mt-2 text-2xl font-black">
                      {
                        grantApplications.length
                      }
                    </p>
                  </div>

                  <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB]/30 p-4">
                    <p className="text-xs text-gray-600">
                      Loans
                    </p>

                    <p className="mt-2 text-2xl font-black">
                      {
                        loanApplications.length
                      }
                    </p>
                  </div>
                </div>
              </section>

              <section className="mt-6 rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]">
                <div className="flex flex-col gap-4 border-b border-[#E3E7ED] p-5 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h3 className="font-bold">
                      Recent Applications
                    </h3>

                    <p className="mt-1 text-xs text-gray-600">
                      The newest grant and loan applications.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      openSection(
                        "applications",
                        "applications",
                      )
                    }
                    className="text-xs font-bold text-[#B51F35] hover:text-[#B51F35]"
                  >
                    View all →
                  </button>
                </div>

                {allApplications.length ===
                0 ? (
                  <div className="p-12 text-center text-sm text-gray-600">
                    No applications found.
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {allApplications
                      .slice(0, 6)
                      .map((application) => (
                        <button
                          key={`${application.type}-${application.id}`}
                          type="button"
                          onClick={() =>
                            openApplication(
                              application,
                            )
                          }
                          className="flex w-full items-center gap-4 p-5 text-left transition hover:bg-white/[0.03]"
                        >
                          <div
                            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                              application.type ===
                              "grant"
                                ? "bg-blue-500/10 text-blue-400"
                                : "bg-[#B51F35]/10 text-[#B51F35]"
                            }`}
                          >
                            <FiFileText />
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <p className="font-semibold">
                                {
                                  application.user_name
                                }
                              </p>

                              <span className="rounded-full border border-[#E3E7ED] bg-white/5 px-2 py-0.5 text-[9px] uppercase tracking-wider text-[#6B4A50]">
                                {
                                  application.type
                                }
                              </span>

                              <span
                                className={`rounded-full border px-2 py-0.5 text-[9px] uppercase ${statusClass(
                                  application.status,
                                )}`}
                              >
                                {application.status.replace(
                                  /_/g,
                                  " ",
                                )}
                              </span>
                            </div>

                            <p className="mt-1 text-xs text-gray-600">
                              {application.id}
                            </p>
                          </div>

                          <div className="text-right">
                            <p className="font-bold">
                              {money(
                                application.amount,
                              )}
                            </p>

                            <p className="mt-1 text-[10px] text-gray-600">
                              {formatDate(
                                application.created_at,
                              )}
                            </p>
                          </div>

                          <FiChevronRight className="shrink-0 text-gray-700" />
                        </button>
                      ))}
                  </div>
                )}
              </section>

              <section className="mt-6 overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]">
                <div className="border-b border-[#E3E7ED] p-5">
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <h3 className="font-bold">Fee Requests Overview</h3>
                      <p className="mt-1 text-xs text-gray-600">All fee requests sent through FlashFinance.</p>
                    </div>
                    <span className="text-xs text-gray-600">{feeRequests.length} total</span>
                  </div>
                </div>
                {feeRequests.length === 0 ? <div className="p-8 text-center text-sm text-gray-600">No fee requests found.</div> : (
                  <div className="divide-y divide-white/5">
                    {feeRequests.slice(0, 12).map((fee) => (
                      <div key={fee.id} className="flex flex-col gap-3 p-5 md:flex-row md:items-center md:justify-between">
                        <div><p className="font-semibold">{fee.user_name}</p><p className="mt-1 text-sm text-[#6B4A50]">{fee.title || "Fee Request"} · {money(fee.amount)}</p><p className="mt-1 text-xs text-gray-600">{fee.status || "pending"} · {formatDate(fee.created_at)}</p></div>
                        <button type="button" onClick={() => openFeeEditor(fee)} className="rounded-xl border border-[#B51F35]/30 px-4 py-2 text-xs font-bold text-[#B51F35] hover:bg-[#B51F35]/10">Edit</button>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section className="mt-6 overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]">
                <div className="border-b border-[#E3E7ED] p-5">
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <h3 className="font-bold">Customer Support Inbox Overview</h3>
                      <p className="mt-1 text-xs text-gray-600">All customer support conversations, with attention status.</p>
                    </div>
                    <div className="flex gap-2 text-[10px] uppercase">
                      <span className="rounded-full border border-blue-500/20 bg-blue-500/10 px-2 py-1 text-blue-400">{supportTickets.filter((t) => !t.admin_reply && ["open", "pending", "urgent"].includes((t.status || "open").toLowerCase())).length} needs attention</span>
                      <span className="rounded-full border border-[#E3E7ED] px-2 py-1 text-[#5C4147]">{supportTickets.length} total</span>
                    </div>
                  </div>
                </div>
                {supportTickets.length === 0 ? (
                  <div className="p-8 text-center text-sm text-gray-600">No customer support conversations found.</div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {supportTickets.slice(0, 12).map((ticket) => {
                      const needsAttention = !ticket.admin_reply && ["open", "pending", "urgent"].includes((ticket.status || "open").toLowerCase());
                      return (
                        <button key={ticket.id} type="button" onClick={() => { setSelectedTicket(ticket); setTicketReply(ticket.admin_reply || ""); setActiveSection("support"); }} className="block w-full p-5 text-left hover:bg-white/[0.03]">
                          <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                            <div className="min-w-0">
                              <div className="flex flex-wrap items-center gap-2">
                                <p className="font-semibold">{ticket.user_name}</p>
                                <span className={`rounded-full border px-2 py-1 text-[9px] uppercase ${needsAttention ? "border-blue-500/20 bg-blue-500/10 text-blue-400" : "border-[#E3E7ED] text-[#5C4147]"}`}>{needsAttention ? "Needs attention" : ticket.admin_reply ? "Replied" : "Open"}</span>
                                <span className="rounded-full border border-[#E3E7ED] px-2 py-1 text-[9px] uppercase text-[#5C4147]">{ticket.status || "open"}</span>
                              </div>
                              <p className="mt-1 text-sm text-[#6B4A50]">{ticket.subject || "Support Request"}</p>
                              <p className="mt-1 line-clamp-2 text-xs text-gray-600">{ticket.message || "No message provided."}</p>
                            </div>
                            <p className="shrink-0 text-[10px] text-gray-700">{formatDate(ticket.created_at)}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </section>

              <section className="mt-6 rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]">
                <div className="border-b border-[#E3E7ED] px-5 py-5">
                  <h3 className="font-bold">
                    Recent FlashFinance Activity
                  </h3>

                  <p className="mt-1 text-xs text-gray-600">
                    Latest FlashFinance actions.
                  </p>
                </div>

                {auditLogs.length ===
                0 ? (
                  <div className="p-10 text-center text-sm text-gray-600">
                    No FlashFinance activity recorded yet.
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {auditLogs
                      .slice(0, 8)
                      .map((log) => (
                        <div
                          key={log.id}
                          className="flex flex-col gap-2 p-5 sm:flex-row sm:items-start sm:justify-between"
                        >
                          <div>
                            <span className="rounded-lg bg-[#B51F35]/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-[#B51F35]">
                              {log.action}
                            </span>

                            <p className="mt-2 text-sm text-[#4B3439]">
                              {log.description ||
                                "FlashFinance action recorded."}
                            </p>
                          </div>

                          <p className="text-xs text-gray-600">
                            {formatDate(
                              log.created_at,
                            )}
                          </p>
                        </div>
                      ))}
                  </div>
                )}
              </section>
            </>
          )}

          {activeSection ===
            "applications" && (
            <div
              ref={applicationsRef}
              className="scroll-mt-28"
            >
              <div className="grid gap-4 md:grid-cols-4">
                <div className="rounded-2xl border border-[#B51F35]/20 bg-[#B51F35]/5 p-5">
                  <p className="text-xs text-[#5C4147]">
                    Awaiting review
                  </p>

                  <p className="mt-2 text-3xl font-black text-[#B51F35]">
                    {pendingApplications.length}
                  </p>
                </div>

                <div className="rounded-2xl border border-blue-500/20 bg-blue-500/5 p-5">
                  <p className="text-xs text-[#5C4147]">
                    More information
                  </p>

                  <p className="mt-2 text-3xl font-black text-blue-400">
                    {
                      informationRequestedApplications.length
                    }
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-[#5C4147]">
                    Grant applications
                  </p>

                  <p className="mt-2 text-3xl font-black">
                    {
                      grantApplications.length
                    }
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-[#5C4147]">
                    Loan applications
                  </p>

                  <p className="mt-2 text-3xl font-black">
                    {
                      loanApplications.length
                    }
                  </p>
                </div>
              </div>

              <section className="mt-5 overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]">
                <div className="border-b border-[#E3E7ED] p-5">
                  <div className="flex flex-col gap-4 xl:flex-row xl:items-center">
                    <div className="flex-1">
                      <h2 className="text-xl font-black">
                        Application Review
                      </h2>

                      <p className="mt-1 text-sm text-gray-600">
                        Review grant and loan applications from one queue.
                      </p>
                    </div>

                    <div className="relative w-full xl:max-w-sm">
                      <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />

                      <input
                        value={
                          applicationSearch
                        }
                        onChange={(event) =>
                          setApplicationSearch(
                            event.target
                              .value,
                          )
                        }
                        placeholder="Search applications..."
                        className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] py-3 pl-10 pr-4 text-sm text-[#1F2937] outline-none placeholder:text-gray-700 focus:border-[#B51F35]"
                      />
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    {[
                      ["all", "All"],
                      ["grant", "Grants"],
                      ["loan", "Loans"],
                    ].map(
                      ([value, label]) => (
                        <button
                          key={value}
                          type="button"
                          onClick={() =>
                            setApplicationTypeFilter(
                              value as
                                | "all"
                                | ApplicationType,
                            )
                          }
                          className={`rounded-xl px-4 py-2 text-xs font-semibold ${
                            applicationTypeFilter ===
                            value
                              ? "bg-[#B51F35] text-black"
                              : "border border-[#E3E7ED] bg-white/5 text-[#5C4147] hover:text-[#1F2937]"
                          }`}
                        >
                          {label}
                        </button>
                      ),
                    )}

                    <select
                      value={
                        applicationStatusFilter
                      }
                      onChange={(event) =>
                        setApplicationStatusFilter(
                          event.target.value,
                        )
                      }
                      className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] px-4 py-2 text-xs text-[#6B4A50] outline-none focus:border-[#B51F35]"
                    >
                      <option value="all">
                        All statuses
                      </option>

                      <option value="pending">
                        Pending
                      </option>

                      <option value="submitted">
                        Submitted
                      </option>

                      <option value="under_review">
                        Under review
                      </option>

                      <option value="information_requested">
                        More information
                      </option>

                      <option value="approved">
                        Approved
                      </option>

                      <option value="rejected">
                        Rejected
                      </option>

                      <option value="disbursed">
                        Disbursed
                      </option>

                      <option value="paid">
                        Paid
                      </option>
                    </select>

                    <button
                      type="button"
                      onClick={() => {
                        setApplicationSearch(
                          "",
                        );
                        setApplicationTypeFilter(
                          "all",
                        );
                        setApplicationStatusFilter(
                          "all",
                        );
                      }}
                      className="rounded-xl border border-[#E3E7ED] px-4 py-2 text-xs text-[#5C4147] hover:text-[#1F2937]"
                    >
                      Clear filters
                    </button>
                  </div>
                </div>

                {filteredApplications.length ===
                0 ? (
                  <div className="p-16 text-center">
                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-white/5 text-gray-600">
                      <FiFileText
                        size={23}
                      />
                    </div>

                    <h3 className="mt-4 font-bold">
                      No applications found
                    </h3>

                    <p className="mt-2 text-sm text-gray-600">
                      There are no applications matching the current filters.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {filteredApplications.map(
                      (application) => (
                        <button
                          key={`${application.type}-${application.id}`}
                          type="button"
                          onClick={() =>
                            openApplication(
                              application,
                            )
                          }
                          className={`w-full p-5 text-left transition hover:bg-white/[0.025] ${
                            selectedApplication?.id ===
                            application.id
                              ? "bg-[#B51F35]/[0.04]"
                              : ""
                          }`}
                        >
                          <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
                            <div
                              className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${
                                application.type ===
                                "grant"
                                  ? "bg-blue-500/10 text-blue-400"
                                  : "bg-[#B51F35]/10 text-[#B51F35]"
                              }`}
                            >
                              {application.type ===
                              "grant" ? (
                                <FiHeart />
                              ) : (
                                <FiDollarSign />
                              )}
                            </div>

                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <p className="font-bold">
                                  {
                                    application.user_name
                                  }
                                </p>

                                <span className="rounded-full border border-[#E3E7ED] bg-white/5 px-2 py-1 text-[9px] uppercase tracking-wider text-[#6B4A50]">
                                  {
                                    application.type
                                  }
                                </span>

                                <span
                                  className={`rounded-full border px-2 py-1 text-[9px] uppercase tracking-wider ${statusClass(
                                    application.status,
                                  )}`}
                                >
                                  {application.status.replace(
                                    /_/g,
                                    " ",
                                  )}
                                </span>
                              </div>

                              <p className="mt-1 text-xs text-gray-600">
                                ID:{" "}
                                {
                                  application.id
                                }
                              </p>

                              <p className="mt-2 line-clamp-1 text-sm text-[#5C4147]">
                                {application.reason ||
                                  application.purpose ||
                                  application.description ||
                                  "No application description provided."}
                              </p>
                            </div>

                            <div className="flex items-center justify-between gap-8 lg:justify-end">
                              <div className="text-left lg:text-right">
                                <p className="text-[10px] uppercase tracking-wider text-gray-600">
                                  Requested
                                </p>

                                <p className="mt-1 text-lg font-black">
                                  {money(
                                    application.amount,
                                  )}
                                </p>
                              </div>

                              <div className="text-left lg:text-right">
                                <p className="text-[10px] uppercase tracking-wider text-gray-600">
                                  Submitted
                                </p>

                                <p className="mt-1 text-xs text-[#6B4A50]">
                                  {formatDate(
                                    application.created_at,
                                  )}
                                </p>
                              </div>

                              <FiChevronRight className="hidden text-gray-700 lg:block" />
                            </div>
                          </div>
                        </button>
                      ),
                    )}
                  </div>
                )}
              </section>

              {selectedApplication && applicationFeeOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#F8F9FB]/80 p-4 backdrop-blur-sm">
                  <div className="w-full max-w-2xl overflow-hidden rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB] shadow-2xl">
                    <div className="flex items-start justify-between border-b border-[#E3E7ED] p-5">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#B51F35]">Application review</p>
                        <h3 className="mt-1 text-xl font-bold text-[#1F2937]">Request a processing fee</h3>
                      </div>
                      <button type="button" onClick={() => setApplicationFeeOpen(false)} disabled={applicationFeeSubmitting} className="rounded-xl border border-[#E3E7ED] px-3 py-2 text-[#6B4A50] hover:text-[#1F2937] disabled:opacity-50">✕</button>
                    </div>

                    <div className="space-y-4 p-5">
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                          <label className="mb-2 block text-xs font-semibold text-[#6B4A50]">Amount</label>
                          <input type="number" min="0.01" step="0.01" value={applicationFeeAmount} onChange={(event) => setApplicationFeeAmount(event.target.value)} disabled={applicationFeeSubmitting} placeholder="0.00" className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]" />
                        </div>
                        <div>
                          <label className="mb-2 block text-xs font-semibold text-[#6B4A50]">Fee type</label>
                          <select value={applicationFeeType} onChange={(event) => setApplicationFeeType(event.target.value)} disabled={applicationFeeSubmitting} className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]">
                            <option value="application_processing">Application Processing</option>
                            <option value="document_review">Document Review</option>
                            <option value="verification">Verification</option>
                            <option value="administrative_processing">Administrative Processing</option>
                            <option value="other">Other</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="mb-2 block text-xs font-semibold text-[#6B4A50]">Customer-facing title</label>
                        <input value={applicationFeeTitle} onChange={(event) => setApplicationFeeTitle(event.target.value)} disabled={applicationFeeSubmitting} className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]" />
                      </div>

                      <div>
                        <label className="mb-2 block text-xs font-semibold text-[#6B4A50]">Why the fee applies</label>
                        <textarea rows={7} value={applicationFeeMessage} onChange={(event) => setApplicationFeeMessage(event.target.value)} disabled={applicationFeeSubmitting} className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm leading-6 text-[#1F2937] outline-none focus:border-[#B51F35]" />
                      </div>

                      <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
                        <button type="button" onClick={() => setApplicationFeeOpen(false)} disabled={applicationFeeSubmitting} className="rounded-xl border border-[#E3E7ED] px-5 py-3 text-sm font-semibold text-[#6B4A50] hover:text-[#1F2937] disabled:opacity-50">Cancel</button>
                        <button type="button" onClick={submitApplicationFeeRequest} disabled={applicationFeeSubmitting} className="rounded-xl bg-[#B51F35] px-5 py-3 text-sm font-bold text-black hover:bg-[#B51F35] disabled:opacity-50">
                          {applicationFeeSubmitting ? "Creating..." : "Send Fee Request"}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {feeEditOpen && editingFee && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center bg-[#F8F9FB]/80 p-4 backdrop-blur-sm">
                  <div className="w-full max-w-xl rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB] shadow-2xl">
                    <div className="flex items-center justify-between border-b border-[#E3E7ED] p-5">
                      <div><p className="text-[10px] uppercase tracking-[0.2em] text-[#B51F35]">FlashFinance</p><h3 className="mt-1 text-xl font-black">Edit Fee Request</h3></div>
                      <button type="button" onClick={() => setFeeEditOpen(false)} className="rounded-xl border border-[#E3E7ED] p-2 text-[#5C4147] hover:text-[#1F2937]"><FiX /></button>
                    </div>
                    <div className="space-y-4 p-5">
                      <input type="number" step="0.01" value={feeEditAmount} onChange={(e) => setFeeEditAmount(e.target.value)} className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]" placeholder="Amount" />
                      <select value={feeEditStatus} onChange={(e) => setFeeEditStatus(e.target.value)} className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"><option value="pending">Pending</option><option value="paid">Paid</option><option value="cancelled">Cancelled</option><option value="rejected">Rejected</option></select>
                      <input value={feeEditTitle} onChange={(e) => setFeeEditTitle(e.target.value)} className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]" placeholder="Fee title" />
                      <textarea rows={6} value={feeEditMessage} onChange={(e) => setFeeEditMessage(e.target.value)} className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]" placeholder="Customer message" />
                      <div className="flex justify-end gap-2"><button type="button" onClick={() => setFeeEditOpen(false)} className="rounded-xl border border-[#E3E7ED] px-5 py-3 text-sm text-[#5C4147]">Cancel</button><button type="button" onClick={saveFeeEdit} disabled={busy} className="rounded-xl bg-[#B51F35] px-5 py-3 text-sm font-bold text-black disabled:opacity-50">Save Changes</button></div>
                    </div>
                  </div>
                </div>
              )}

              {selectedApplication && reviewRequestOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#F8F9FB]/80 p-4 backdrop-blur-sm">
                  <div className="w-full max-w-2xl rounded-3xl border border-blue-500/20 bg-[#F8F9FB] shadow-2xl">
                    <div className="flex items-start justify-between border-b border-[#E3E7ED] p-5">
                      <div>
                        <p className="text-[10px] uppercase tracking-[0.2em] text-blue-400">
                          Application review
                        </p>
                        <h3 className="mt-1 text-xl font-black">
                          Request more information
                        </h3>
                        <p className="mt-1 text-xs text-[#5C4147]">
                          Select exactly what the customer needs to provide.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setReviewRequestOpen(false)}
                        disabled={reviewRequestSubmitting}
                        className="rounded-xl border border-[#E3E7ED] p-2 text-[#5C4147] hover:text-[#1F2937] disabled:opacity-50"
                      >
                        <FiX />
                      </button>
                    </div>

                    <div className="space-y-5 p-5">
                      <div>
                        <label className="mb-2 block text-xs font-semibold text-[#6B4A50]">
                          Information needed
                        </label>
                        <div className="grid gap-2 sm:grid-cols-2">
                          {applicationReviewItems.map((item) => {
                            const checked = reviewRequestItems.includes(item);
                            return (
                              <label
                                key={item}
                                className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 text-sm transition ${
                                  checked
                                    ? "border-blue-500/40 bg-blue-500/10 text-[#1F2937]"
                                    : "border-[#E3E7ED] bg-[#F8F9FB] text-[#5C4147] hover:border-[#DDE2E8]"
                                }`}
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  disabled={reviewRequestSubmitting}
                                  onChange={() =>
                                    setReviewRequestItems((current) =>
                                      checked
                                        ? current.filter((value) => value !== item)
                                        : [...current, item],
                                    )
                                  }
                                  className="h-4 w-4 accent-blue-500"
                                />
                                <span>{item}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>

                      <div>
                        <label className="mb-2 block text-xs font-semibold text-[#6B4A50]">
                          Message to customer
                        </label>
                        <textarea
                          value={reviewRequestMessage}
                          onChange={(event) => setReviewRequestMessage(event.target.value)}
                          disabled={reviewRequestSubmitting}
                          rows={6}
                          className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-blue-400"
                          placeholder="Explain what the customer needs to provide..."
                        />
                      </div>

                      <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
                        <button
                          type="button"
                          onClick={() => setReviewRequestOpen(false)}
                          disabled={reviewRequestSubmitting}
                          className="rounded-xl border border-[#E3E7ED] px-5 py-3 text-sm font-semibold text-[#6B4A50] hover:text-[#1F2937] disabled:opacity-50"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={submitApplicationReviewRequest}
                          disabled={reviewRequestSubmitting}
                          className="rounded-xl bg-blue-500 px-5 py-3 text-sm font-bold text-[#1F2937] hover:bg-blue-400 disabled:opacity-50"
                        >
                          {reviewRequestSubmitting ? "Sending..." : "Send Request"}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedApplication && (
                <section className="mt-5 rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB]">
                  <div className="border-b border-[#E3E7ED] p-5">
                    <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
                      <div className="flex gap-4">
                        <div
                          className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
                            selectedApplication.type ===
                            "grant"
                              ? "bg-blue-500/10 text-blue-400"
                              : "bg-[#B51F35]/10 text-[#B51F35]"
                          }`}
                        >
                          <FiFileText
                            size={22}
                          />
                        </div>

                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] uppercase tracking-[0.2em] text-[#B51F35]">
                              {
                                selectedApplication.type
                              }{" "}
                              application
                            </span>

                            <span
                              className={`rounded-full border px-2 py-1 text-[9px] uppercase ${statusClass(
                                selectedApplication.status,
                              )}`}
                            >
                              {selectedApplication.status.replace(
                                /_/g,
                                " ",
                              )}
                            </span>
                          </div>

                          <h3 className="mt-1 text-2xl font-black">
                            {
                              selectedApplication.user_name
                            }
                          </h3>

                          <p className="mt-1 text-xs text-gray-600">
                            Application ID:{" "}
                            {
                              selectedApplication.id
                            }
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          setSelectedApplication(
                            null,
                          )
                        }
                        className="self-start rounded-xl border border-[#E3E7ED] px-3 py-2 text-xs text-[#5C4147] hover:text-[#1F2937]"
                      >
                        Close
                      </button>
                    </div>
                  </div>

                  <div className="grid gap-4 p-5 sm:grid-cols-2 xl:grid-cols-4">
                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                      <p className="text-[10px] uppercase tracking-wider text-gray-600">
                        Requested
                      </p>

                      <p className="mt-2 text-2xl font-black">
                        {money(
                          selectedApplication.amount,
                        )}
                      </p>
                    </div>

                    <div className="rounded-2xl border border-green-500/20 bg-green-500/5 p-4">
                      <p className="text-[10px] uppercase tracking-wider text-gray-600">
                        Approved amount
                      </p>

                      <p className="mt-2 text-2xl font-black text-green-400">
                        {selectedApplication.approved_amount ===
                        null
                          ? "—"
                          : money(
                              selectedApplication.approved_amount,
                            )}
                      </p>
                    </div>

                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                      <p className="text-[10px] uppercase tracking-wider text-gray-600">
                        Submitted
                      </p>

                      <p className="mt-2 text-sm font-semibold">
                        {formatDate(
                          selectedApplication.created_at,
                        )}
                      </p>
                    </div>

                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                      <p className="text-[10px] uppercase tracking-wider text-gray-600">
                        Payout method
                      </p>

                      <p className="mt-2 font-semibold">
                        {selectedApplication.payment_method ||
                          "Not provided"}
                      </p>
                    </div>
                  </div>

                  <div className="grid gap-5 border-t border-[#E3E7ED] p-5 xl:grid-cols-[1.2fr_.8fr]">
                    <div className="space-y-5">
                      <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                        <div className="flex items-center gap-2">
                          <FiFileText className="text-[#B51F35]" />

                          <h4 className="font-bold">
                            Application details
                          </h4>
                        </div>

                        <div className="mt-5 grid gap-4 sm:grid-cols-2">
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">
                              Purpose
                            </p>

                            <p className="mt-1 text-sm text-[#4B3439]">
                              {selectedApplication.purpose ||
                                "Not provided"}
                            </p>
                          </div>

                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">
                              Reason
                            </p>

                            <p className="mt-1 text-sm text-[#4B3439]">
                              {selectedApplication.reason ||
                                "Not provided"}
                            </p>
                          </div>
                        </div>

                        <div className="mt-5">
                          <p className="text-[10px] uppercase tracking-wider text-gray-600">
                            Description
                          </p>

                          <div className="mt-2 rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4 text-sm leading-6 text-[#4B3439]">
                            {selectedApplication.description ||
                              "No additional description provided."}
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                        <div className="flex items-center gap-2">
                          <FiDollarSign className="text-[#B51F35]" />

                          <h4 className="font-bold">
                            Financial information
                          </h4>
                        </div>

                        <div className="mt-5 grid gap-4 sm:grid-cols-3">
                          <div className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">
                              Income
                            </p>

                            <p className="mt-2 break-words text-sm text-[#4B3439]">
                              {safeString(
                                selectedApplication.income,
                              ) ||
                                "Not provided"}
                            </p>
                          </div>

                          <div className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">
                              Employment
                            </p>

                            <p className="mt-2 break-words text-sm text-[#4B3439]">
                              {safeString(
                                selectedApplication.employment,
                              ) ||
                                "Not provided"}
                            </p>
                          </div>

                          <div className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">
                              Expenses
                            </p>

                            <p className="mt-2 break-words text-sm text-[#4B3439]">
                              {safeString(
                                selectedApplication.expenses,
                              ) ||
                                "Not provided"}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                        <div className="flex items-center gap-2">
                          <FiCreditCard className="text-[#B51F35]" />

                          <h4 className="font-bold">
                            Selected payout details
                          </h4>
                        </div>

                        <div className="mt-5 grid gap-4 sm:grid-cols-2">
                          <div className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">
                              Payment method
                            </p>

                            <p className="mt-2 text-sm font-bold">
                              {selectedApplication.payment_method ||
                                "Not provided"}
                            </p>
                          </div>

                          <div className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">
                              Destination
                            </p>

                            <p className="mt-2 break-all text-sm text-[#4B3439]">
                              {selectedApplication.payment_destination ||
                                "Not provided"}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                        <div className="flex items-center gap-2">
                          <FiPaperclipFallback />

                          <h4 className="font-bold">
                            Supporting documents
                          </h4>
                        </div>

                        <div className="mt-4 rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                          {selectedApplication.documents ? (
                            <pre className="max-h-64 overflow-auto whitespace-pre-wrap break-words text-xs leading-5 text-[#6B4A50]">
                              {safeString(
                                selectedApplication.documents,
                              )}
                            </pre>
                          ) : (
                            <p className="text-sm text-gray-600">
                              No supporting documents were recorded with this application.
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-5">
                      <div className="rounded-2xl border border-[#B51F35]/20 bg-[#B51F35]/5 p-5">
                        <div className="flex items-center gap-2 text-[#B51F35]">
                          <FiShield />

                          <h4 className="font-bold text-[#1F2937]">
                            Review controls
                          </h4>
                        </div>

                        <p className="mt-2 text-xs leading-5 text-[#5C4147]">
                          Review the application before making a decision. Approval does not automatically send an external payment.
                        </p>

                        <div className="mt-5 grid gap-2">
                          <button
                            type="button"
                            disabled={
                              !!applicationBusy
                            }
                            onClick={
                              handleApplicationApprove
                            }
                            className="flex items-center justify-center gap-2 rounded-xl bg-green-500 px-4 py-3 text-sm font-bold text-black hover:bg-green-400 disabled:opacity-50"
                          >
                            <FiCheck />
                            Approve Application
                          </button>

                          <button
                            type="button"
                            disabled={
                              !!applicationBusy
                            }
                            onClick={
                              handleRequestInformation
                            }
                            className="flex items-center justify-center gap-2 rounded-xl border border-blue-500/30 bg-blue-500/10 px-4 py-3 text-sm font-bold text-blue-400 hover:bg-blue-500/20 disabled:opacity-50"
                          >
                            <FiInfo />
                            Request More Information
                          </button>

                          <button
                            type="button"
                            disabled={
                              !!applicationBusy
                            }
                            onClick={
                              openApplicationFeeRequest
                            }
                            className="flex items-center justify-center gap-2 rounded-xl border border-[#B51F35]/30 bg-[#B51F35]/10 px-4 py-3 text-sm font-bold text-[#B51F35] hover:bg-[#B51F35]/20 disabled:opacity-50"
                          >
                            <FiDollarSign />
                            Request Processing Fee
                          </button>

                          <button
                            type="button"
                            disabled={
                              !!applicationBusy
                            }
                            onClick={
                              handleApplicationReject
                            }
                            className="flex items-center justify-center gap-2 rounded-xl bg-red-500 px-4 py-3 text-sm font-bold text-[#1F2937] hover:bg-red-400 disabled:opacity-50"
                          >
                            <FiX />
                            Reject Application
                          </button>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                        <h4 className="font-bold">
                          Approved amount
                        </h4>

                        <p className="mt-1 text-xs text-gray-600">
                          Set the amount that will be used for the disbursement workflow.
                        </p>

                        <input
                          type="number"
                          step="0.01"
                          defaultValue={
                            selectedApplication.approved_amount ??
                            selectedApplication.amount ??
                            ""
                          }
                          key={`${selectedApplication.id}-${selectedApplication.approved_amount}`}
                          onBlur={async (
                            event,
                          ) => {
                            const value =
                              Number(
                                event.target
                                  .value,
                              );

                            if (
                              value > 0 &&
                              value !==
                                selectedApplication.approved_amount
                            ) {
                              await updateApplicationStatus(
                                selectedApplication,
                                selectedApplication.status,
                                value,
                              );
                            }
                          }}
                          className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                        />
                      </div>

                      <div className="rounded-2xl border border-green-500/20 bg-green-500/5 p-5">
                        <div className="flex items-center gap-2 text-green-400">
                          <FiSend />

                          <h4 className="font-bold text-[#1F2937]">
                            Disbursement
                          </h4>
                        </div>

                        <p className="mt-2 text-xs leading-5 text-[#5C4147]">
                          Choose any supported payment method and enter the destination before creating the payout request.
                        </p>

                        <label className="mt-4 block text-xs font-semibold text-[#5C4147]">
                          Payment method
                        </label>

                        <select
                          value={applicationPaymentMethod}
                          onChange={(event) =>
                            setApplicationPaymentMethod(
                              event.target.value,
                            )
                          }
                          disabled={!!applicationBusy}
                          className="mt-2 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                        >
                          {Object.entries(paymentMethods).map(
                            ([key, method]) => (
                              <option key={key} value={key}>
                                {method.name}
                              </option>
                            ),
                          )}
                        </select>

                        <label className="mt-4 block text-xs font-semibold text-[#5C4147]">
                          Payment destination
                        </label>

                        <input
                          value={applicationPaymentDestination}
                          onChange={(event) =>
                            setApplicationPaymentDestination(
                              event.target.value,
                            )
                          }
                          disabled={!!applicationBusy}
                          placeholder="Account, email, tag, wallet address, or other destination"
                          className="mt-2 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                        />

                        <button
                          type="button"
                          disabled={
                            !!applicationBusy ||
                            ![
                              "approved",
                              "disbursed",
                              "paid",
                            ].includes(
                              selectedApplication.status,
                            )
                          }
                          onClick={
                            handleCreateDisbursement
                          }
                          className="mt-4 w-full rounded-xl bg-[#B51F35] px-4 py-3 text-sm font-bold text-black hover:bg-[#B51F35] disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          Create Payout Request
                        </button>

                        <button
                          type="button"
                          disabled={
                            !!applicationBusy ||
                            ![
                              "approved",
                              "disbursed",
                              "paid",
                            ].includes(
                              selectedApplication.status,
                            )
                          }
                          onClick={
                            handleCreditApprovedAmount
                          }
                          className="mt-2 w-full rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm font-bold text-green-400 hover:bg-green-500/20 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          Credit Internal Account
                        </button>
                      </div>

                      {selectedApplication.user_id && (
                        <button
                          type="button"
                          onClick={() =>
                            openCustomer(
                              selectedApplication.user_id!,
                            )
                          }
                          className="flex w-full items-center justify-between rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4 text-left transition hover:border-[#B51F35]/30"
                        >
                          <span>
                            <span className="block text-xs text-gray-600">
                              Customer
                            </span>

                            <span className="mt-1 block font-bold">
                              Open Customer Control Center
                            </span>
                          </span>

                          <FiChevronRight className="text-gray-600" />
                        </button>
                      )}
                    </div>
                  </div>
                </section>
              )}
            </div>
          )}

          {activeSection ===
            "kyc" && (
            <section className="overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]">
              <div className="border-b border-[#E3E7ED] p-5">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div>
                    <h2 className="text-xl font-black">KYC Verification Queue</h2>
                    <p className="mt-1 text-sm text-gray-600">Review customer identity submissions and securely inspect their verification documents.</p>
                  </div>

                  <div className="rounded-xl border border-[#B51F35]/20 bg-[#B51F35]/5 px-4 py-3">
                    <p className="text-[10px] uppercase tracking-wider text-[#B51F35]">Under review</p>
                    <p className="mt-1 text-2xl font-black text-[#1F2937]">
                      {kycSubmissions.filter((item) => item.status === "under_review").length}
                    </p>
                  </div>
                </div>
              </div>

              {kycSubmissions.length === 0 ? (
                <div className="p-16 text-center">
                  <FiShield className="mx-auto text-4xl text-gray-700" />
                  <p className="mt-4 text-sm text-[#5C4147]">No KYC submissions have been received yet.</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {kycSubmissions.map((submission) => {
                    const isBusy = kycBusyId === submission.id;

                    const statusLabel =
                      submission.status === "under_review"
                        ? "Under Review"
                        : submission.status === "changes_requested"
                          ? "Changes Requested"
                          : submission.status.charAt(0).toUpperCase() + submission.status.slice(1);

                    const statusClass =
                      submission.status === "approved"
                        ? "border-green-500/20 bg-green-500/10 text-green-400"
                        : submission.status === "rejected"
                          ? "border-red-500/20 bg-red-500/10 text-red-400"
                          : submission.status === "changes_requested"
                            ? "border-orange-500/20 bg-orange-500/10 text-orange-400"
                            : "border-[#B51F35]/20 bg-[#B51F35]/10 text-[#B51F35]";

                    return (
                      <div key={submission.id} className="p-5 sm:p-6">
                        <div className="flex flex-col gap-5">
                          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <h3 className="text-lg font-bold text-[#1F2937]">
                                  {submission.user_name}
                                </h3>
                                <span className={`rounded-full border px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${statusClass}`}>
                                  {statusLabel}
                                </span>
                              </div>
                              <p className="mt-2 text-xs text-gray-600">
                                Submitted {formatDate(submission.created_at)} · ID {submission.id}
                              </p>
                            </div>

                            <div className="flex flex-wrap gap-2">
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => handleOpenKycFile(submission.id_document_path)}
                                className="inline-flex items-center gap-2 rounded-xl border border-[#E3E7ED] bg-white/5 px-4 py-2.5 text-xs font-semibold text-[#4B3439] transition hover:border-[#B51F35]/30 hover:text-[#1F2937] disabled:opacity-50"
                              >
                                <FiEye size={14} />
                                View ID
                              </button>

                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => handleOpenKycFile(submission.selfie_path)}
                                className="inline-flex items-center gap-2 rounded-xl border border-[#E3E7ED] bg-white/5 px-4 py-2.5 text-xs font-semibold text-[#4B3439] transition hover:border-[#B51F35]/30 hover:text-[#1F2937] disabled:opacity-50"
                              >
                                <FiEye size={14} />
                                View Selfie
                              </button>
                            </div>
                          </div>

                          <div className="grid gap-4 lg:grid-cols-4">
                            <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                              <p className="text-[10px] uppercase tracking-wider text-gray-600">Legal name</p>
                              <p className="mt-2 text-sm font-semibold text-[#1F2937]">{submission.first_name} {submission.last_name}</p>
                            </div>

                            <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                              <p className="text-[10px] uppercase tracking-wider text-gray-600">Date of birth</p>
                              <p className="mt-2 text-sm font-semibold text-[#1F2937]">{submission.date_of_birth || "—"}</p>
                            </div>

                            <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                              <p className="text-[10px] uppercase tracking-wider text-gray-600">Identification</p>
                              <p className="mt-2 text-sm font-semibold text-[#1F2937]">{submission.id_type.replaceAll("_", " ")}</p>
                            </div>

                            <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                              <p className="text-[10px] uppercase tracking-wider text-gray-600">Address</p>
                              <p className="mt-2 text-sm font-semibold text-[#1F2937]">
                                {submission.city}, {submission.state} {submission.zip_code || ""}
                              </p>
                            </div>
                          </div>

                          <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                            <p className="text-[10px] uppercase tracking-wider text-gray-600">Street address</p>
                            <p className="mt-2 text-sm text-[#4B3439]">{submission.address}</p>
                          </div>

                          {submission.admin_note && (
                            <div className="rounded-2xl border border-orange-500/20 bg-orange-500/5 p-4">
                              <p className="text-[10px] uppercase tracking-wider text-orange-400">Current admin note</p>
                              <p className="mt-2 text-sm leading-6 text-[#4B3439]">{submission.admin_note}</p>
                            </div>
                          )}

                          {submission.status === "under_review" && (
                            <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
                              <div>
                                <label className="mb-2 block text-[10px] uppercase tracking-wider text-gray-600">Review note</label>
                                <textarea
                                  rows={3}
                                  value={kycNote[submission.id] || ""}
                                  onChange={(event) =>
                                    setKycNote((current) => ({
                                      ...current,
                                      [submission.id]: event.target.value,
                                    }))
                                  }
                                  placeholder="Optional note for this KYC decision..."
                                  className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                                />
                              </div>

                              <div className="flex flex-wrap gap-2 lg:justify-end">
                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => handleKycStatus(submission, "approved")}
                                  className="rounded-xl bg-green-500 px-4 py-3 text-xs font-bold text-black hover:bg-green-400 disabled:opacity-50"
                                >
                                  {isBusy ? "Processing..." : "Approve"}
                                </button>

                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => handleKycStatus(submission, "changes_requested")}
                                  className="rounded-xl bg-orange-400 px-4 py-3 text-xs font-bold text-black hover:bg-orange-300 disabled:opacity-50"
                                >
                                  Request Changes
                                </button>

                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => handleKycStatus(submission, "rejected")}
                                  className="rounded-xl bg-red-500 px-4 py-3 text-xs font-bold text-[#1F2937] hover:bg-red-400 disabled:opacity-50"
                                >
                                  Reject
                                </button>

                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => handleRemoveKycRequest(submission)}
                                  className="rounded-xl border border-[#E3E7ED] px-4 py-3 text-xs font-semibold text-[#6B4A50] hover:border-red-500/30 hover:text-red-400 disabled:opacity-50"
                                >
                                  Remove Dashboard Request
                                </button>
                              </div>
                            </div>
                          )}

                          {submission.status !== "under_review" && (
                            <div className="flex flex-wrap gap-2">
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => handleRemoveKycRequest(submission)}
                                className="rounded-xl border border-[#E3E7ED] px-4 py-3 text-xs font-semibold text-[#6B4A50] hover:border-red-500/30 hover:text-red-400 disabled:opacity-50"
                              >
                                Remove Dashboard Request
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          )}

          {activeSection ===
            "customers" && (
            <>
              <section
                id="customer-directory"
                className="overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]"
              >
                <div className="border-b border-[#E3E7ED] p-5">
                  <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div>
                      <h2 className="text-xl font-black">
                        Customer Directory
                      </h2>

                      <p className="mt-1 text-sm text-gray-600">
                        Search and manage customer accounts.
                      </p>
                    </div>

                    <div className="relative w-full md:max-w-sm">
                      <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />

                      <input
                        value={
                          customerSearch
                        }
                        onChange={(event) =>
                          setCustomerSearch(
                            event.target
                              .value,
                          )
                        }
                        placeholder="Search customers..."
                        className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] py-3 pl-10 pr-4 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />
                    </div>
                  </div>
                </div>

                {filteredCustomers.length ===
                0 ? (
                  <div className="p-12 text-center text-sm text-gray-600">
                    No customers found.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[900px]">
                      <thead className="border-b border-[#E3E7ED] bg-[#F8F9FB]/40">
                        <tr>
                          <th className="px-5 py-4 text-left text-[10px] uppercase tracking-wider text-gray-600">
                            Customer
                          </th>

                          <th className="px-5 py-4 text-left text-[10px] uppercase tracking-wider text-gray-600">
                            Contact
                          </th>

                          <th className="px-5 py-4 text-left text-[10px] uppercase tracking-wider text-gray-600">
                            Balance
                          </th>

                          <th className="px-5 py-4 text-left text-[10px] uppercase tracking-wider text-gray-600">
                            Account
                          </th>

                          <th className="px-5 py-4 text-left text-[10px] uppercase tracking-wider text-gray-600">
                            Status
                          </th>

                          <th className="px-5 py-4 text-right text-[10px] uppercase tracking-wider text-gray-600">
                            Action
                          </th>
                        </tr>
                      </thead>

                      <tbody className="divide-y divide-white/5">
                        {filteredCustomers.map(
                          (user) => (
                            <tr
                              key={user.id}
                              className="transition hover:bg-white/[0.02]"
                            >
                              <td className="px-5 py-4">
                                <p className="font-semibold text-[#1F2937]">
                                  {user.full_name ||
                                    "Unnamed Customer"}
                                </p>

                                <p className="mt-1 text-[10px] text-gray-700">
                                  {user.id}
                                </p>
                              </td>

                              <td className="px-5 py-4">
                                <p className="text-sm text-[#6B4A50]">
                                  {user.phone ||
                                    "No phone"}
                                </p>

                                {user.email && (
                                  <p className="mt-1 text-xs text-gray-600">
                                    {user.email}
                                  </p>
                                )}
                              </td>

                              <td className="px-5 py-4 text-sm font-bold">
                                {money(
                                  user.balance,
                                )}
                              </td>

                              <td className="px-5 py-4 text-xs capitalize text-[#5C4147]">
                                {user.account_type ||
                                  "personal"}
                              </td>

                              <td className="px-5 py-4">
                                <span
                                  className={`rounded-full border px-2 py-1 text-[9px] uppercase ${statusClass(
                                    user.account_status,
                                  )}`}
                                >
                                  {user.account_status ||
                                    "active"}
                                </span>
                              </td>

                              <td className="px-5 py-4 text-right">
                                <button
                                  type="button"
                                  onClick={() =>
                                    openCustomer(
                                      user.id,
                                    )
                                  }
                                  className="rounded-xl bg-[#B51F35] px-4 py-2 text-xs font-bold text-black hover:bg-[#B51F35]"
                                >
                                  Manage
                                </button>
                              </td>
                            </tr>
                          ),
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              {selectedUserData && (
                <div
                  ref={
                    customerControlRef
                  }
                  className="mt-6 scroll-mt-28 rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB]"
                >
                  <div className="border-b border-[#E3E7ED] p-5">
                    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                      <div>
                        <p className="text-[10px] uppercase tracking-[0.2em] text-[#B51F35]">
                          Customer Control Center
                        </p>

                        <h2 className="mt-1 text-2xl font-black">
                          {selectedUserData.full_name ||
                            "Unnamed Customer"}
                        </h2>

                        <p className="mt-1 text-sm text-gray-600">
                          {selectedUserData.phone ||
                            "No phone number"}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setSelectedUser(
                            "",
                          );

                          document
                            .getElementById(
                              "customer-directory",
                            )
                            ?.scrollIntoView({
                              behavior:
                                "smooth",
                              block:
                                "start",
                            });
                        }}
                        className="rounded-xl border border-[#E3E7ED] px-4 py-2 text-sm text-[#5C4147] hover:bg-white/5 hover:text-[#1F2937]"
                      >
                        Back to Directory
                      </button>
                    </div>
                  </div>

                  <div className="grid gap-4 p-5 md:grid-cols-3">
                    <div className="rounded-2xl border border-[#B51F35]/20 bg-[#B51F35]/5 p-5">
                      <p className="text-xs text-gray-600">
                        Current Balance
                      </p>

                      <p className="mt-2 text-2xl font-black">
                        {money(
                          selectedUserData.balance,
                        )}
                      </p>
                    </div>

                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <p className="text-xs text-gray-600">
                        Account Type
                      </p>

                      <p className="mt-2 font-bold capitalize">
                        {selectedUserData.account_type ||
                          "personal"}
                      </p>
                    </div>

                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <p className="text-xs text-gray-600">
                        Customer Since
                      </p>

                      <p className="mt-2 text-sm font-bold">
                        {formatDate(
                          selectedUserData.created_at,
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="grid gap-4 px-5 pb-5 md:grid-cols-3">
                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                      <p className="text-xs text-gray-600">
                        Applications
                      </p>

                      <p className="mt-2 text-2xl font-black">
                        {
                          allApplications.filter(
                            (item) =>
                              item.user_id ===
                              selectedUser,
                          ).length
                        }
                      </p>
                    </div>

                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                      <p className="text-xs text-gray-600">
                        Deposits
                      </p>

                      <p className="mt-2 text-2xl font-black">
                        {
                          selectedUserDeposits.length
                        }
                      </p>
                    </div>

                    <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                      <p className="text-xs text-gray-600">
                        Withdrawals
                      </p>

                      <p className="mt-2 text-2xl font-black">
                        {
                          selectedUserWithdrawals.length
                        }
                      </p>
                    </div>
                  </div>

                  <div className="grid gap-5 border-t border-[#E3E7ED] p-5 xl:grid-cols-2">
                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <h3 className="font-bold">
                        Account Controls
                      </h3>

                      <div className="mt-5">
                        <label className="mb-2 block text-xs text-gray-600">
                          Account Status / Service Access
                        </label>

                        <select
                          value={
                            selectedStatus
                          }
                          disabled={busy}
                          onChange={(
                            event,
                          ) =>
                            handleStatusChange(
                              event.target
                                .value,
                            )
                          }
                          className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                        >
                          <option value="active">
                            Active
                          </option>

                          <option value="suspended">
                            Suspended
                          </option>

                          <option value="restricted">
                            Restricted
                          </option>

                          <option value="pending">
                            Pending
                          </option>
                        </select>
                      </div>

                      <div className="mt-5">
                        <label className="mb-2 block text-xs text-gray-600">
                          User Role
                        </label>

                        <select
                          value={
                            selectedRole
                          }
                          disabled={busy}
                          onChange={(
                            event,
                          ) =>
                            handleRoleChange(
                              event.target
                                .value,
                            )
                          }
                          className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                        >
                          <option value="user">
                            User
                          </option>

                          <option value="admin">
                            Staff
                          </option>
                        </select>
                      </div>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <h3 className="font-bold">
                        Balance Management
                      </h3>

                      <p className="mt-1 text-xs text-gray-600">
                        Adjust the application's internal customer ledger.
                      </p>

                      <input
                        type="number"
                        step="0.01"
                        value={
                          balanceAmount
                        }
                        onChange={(
                          event,
                        ) =>
                          setBalanceAmount(
                            event.target
                              .value,
                          )
                        }
                        placeholder="Use negative amount to deduct"
                        className="mt-5 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <input
                        value={
                          balanceReason
                        }
                        onChange={(
                          event,
                        ) =>
                          setBalanceReason(
                            event.target
                              .value,
                          )
                        }
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <button
                        type="button"
                        disabled={
                          busy
                        }
                        onClick={
                          handleAdjustBalance
                        }
                        className="mt-4 w-full rounded-xl bg-[#B51F35] px-4 py-3 text-sm font-bold text-black hover:bg-[#B51F35] disabled:opacity-50"
                      >
                        {busy
                          ? "Processing..."
                          : "Adjust Balance"}
                      </button>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <h3 className="font-bold">Balance History</h3>
                          <p className="mt-1 text-xs text-gray-600">FlashFinance activity recorded against this customer.</p>
                        </div>
                        <span className="text-xs text-gray-600">{selectedUserActivity.length}</span>
                      </div>
                      <div className="mt-4 max-h-72 space-y-2 overflow-y-auto">
                        {selectedUserActivity.length === 0 ? (
                          <p className="rounded-xl border border-white/5 bg-[#F8F9FB] p-4 text-sm text-gray-600">No customer balance activity recorded yet.</p>
                        ) : selectedUserActivity.slice(0, 20).map((log) => (
                          <div key={log.id} className="rounded-xl border border-white/5 bg-[#F8F9FB] p-3">
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <p className="text-xs font-semibold text-[#4B3439]">{log.action}</p>
                                <p className="mt-1 text-xs leading-5 text-[#5C4147]">{log.description || "FlashFinance account activity"}</p>
                              </div>
                              <span className="shrink-0 text-[9px] text-gray-700">{formatDate(log.created_at)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <h3 className="font-bold">
                        Identity / KYC
                      </h3>

                      <input
                        value={
                          kycTitle
                        }
                        onChange={(
                          event,
                        ) =>
                          setKycTitle(
                            event.target
                              .value,
                          )
                        }
                        className="mt-5 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <textarea
                        rows={5}
                        value={
                          kycMessage
                        }
                        onChange={(
                          event,
                        ) =>
                          setKycMessage(
                            event.target
                              .value,
                          )
                        }
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <button
                        type="button"
                        disabled={
                          busy
                        }
                        onClick={
                          handleSendKyc
                        }
                        className="mt-4 w-full rounded-xl bg-[#B51F35] px-4 py-3 text-sm font-bold text-black hover:bg-[#B51F35] disabled:opacity-50"
                      >
                        Send KYC Request
                      </button>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <h3 className="font-bold">
                        Message Customer
                      </h3>

                      <input
                        value={
                          userMessageTitle
                        }
                        onChange={(
                          event,
                        ) =>
                          setUserMessageTitle(
                            event.target
                              .value,
                          )
                        }
                        className="mt-5 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <textarea
                        rows={5}
                        value={
                          userMessage
                        }
                        onChange={(
                          event,
                        ) =>
                          setUserMessage(
                            event.target
                              .value,
                          )
                        }
                        placeholder="Write a message to this customer..."
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <button
                        type="button"
                        disabled={
                          busy
                        }
                        onClick={
                          handleSendMessage
                        }
                        className="mt-4 w-full rounded-xl bg-[#B51F35] px-4 py-3 text-sm font-bold text-black hover:bg-[#B51F35] disabled:opacity-50"
                      >
                        Send Message
                      </button>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <h3 className="font-bold">
                        Fee Request
                      </h3>

                      <div className="mt-5 grid gap-4 sm:grid-cols-2">
                        <input
                          type="number"
                          step="0.01"
                          value={
                            feeAmount
                          }
                          onChange={(
                            event,
                          ) =>
                            setFeeAmount(
                              event.target
                                .value,
                            )
                          }
                          placeholder="Amount"
                          className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                        />

                        <select
                          value={
                            feeType
                          }
                          onChange={(
                            event,
                          ) =>
                            setFeeType(
                              event.target
                                .value,
                            )
                          }
                          className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                        >
                          <option value="service_fee">
                            Service Fee
                          </option>

                          <option value="processing_fee">
                            Processing Fee
                          </option>

                          <option value="verification_fee">
                            Verification Fee
                          </option>

                          <option value="withdrawal_fee">
                            Withdrawal Fee
                          </option>

                          <option value="other">
                            Other
                          </option>
                        </select>
                      </div>

                      <input
                        value={
                          feeTitle
                        }
                        onChange={(
                          event,
                        ) =>
                          setFeeTitle(
                            event.target
                              .value,
                          )
                        }
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <textarea
                        rows={4}
                        value={
                          feeMessage
                        }
                        onChange={(
                          event,
                        ) =>
                          setFeeMessage(
                            event.target
                              .value,
                          )
                        }
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <button
                        type="button"
                        disabled={
                          busy
                        }
                        onClick={
                          handleCreateFee
                        }
                        className="mt-4 w-full rounded-xl bg-[#B51F35] px-4 py-3 text-sm font-bold text-black hover:bg-[#B51F35] disabled:opacity-50"
                      >
                        Create Fee Request
                      </button>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5 xl:col-span-2">
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <h3 className="font-bold">Fee Requests Sent</h3>
                          <p className="mt-1 text-xs text-gray-600">View and control fee requests sent to this customer.</p>
                        </div>
                        <span className="text-xs text-gray-600">{selectedUserFees.length} request(s)</span>
                      </div>
                      <div className="mt-4 space-y-3">
                        {selectedUserFees.length === 0 ? (
                          <p className="rounded-xl border border-white/5 bg-[#F8F9FB] p-4 text-sm text-gray-600">No fee requests found.</p>
                        ) : selectedUserFees.map((fee) => (
                          <div key={fee.id} className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4">
                            <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                              <div>
                                <p className="font-semibold">{fee.title || "Fee Request"}</p>
                                <p className="mt-1 text-sm text-[#6B4A50]">{money(fee.amount)} · {fee.status || "pending"}</p>
                                <p className="mt-1 text-xs text-gray-600">{fee.message || "No message"}</p>
                                <p className="mt-2 text-[10px] text-gray-700">{formatDate(fee.created_at)}</p>
                              </div>
                              <button type="button" onClick={() => openFeeEditor(fee)} className="rounded-xl border border-[#B51F35]/30 px-4 py-2 text-xs font-bold text-[#B51F35] hover:bg-[#B51F35]/10">Edit</button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5 xl:col-span-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-bold">Customer Support Inbox</h3>
                          <p className="mt-1 text-xs text-gray-600">Every support conversation opened by this customer.</p>
                        </div>
                        <button type="button" onClick={() => setActiveSection("support")} className="rounded-xl border border-[#E3E7ED] px-3 py-2 text-[10px] font-bold uppercase text-[#5C4147] hover:text-[#1F2937]">Open Support</button>
                      </div>
                      <div className="mt-4 space-y-3">
                        {selectedUserInbox.length === 0 ? (
                          <p className="rounded-xl border border-white/5 bg-[#F8F9FB] p-4 text-sm text-gray-600">No support conversations found for this customer.</p>
                        ) : selectedUserInbox.map((ticket) => {
                          const needsAttention = ticket.inboxState === "Needs attention";
                          return (
                            <button key={ticket.id} type="button" onClick={() => { setSelectedTicket(ticket); setTicketReply(ticket.admin_reply || ""); setActiveSection("support"); }} className="block w-full rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4 text-left hover:bg-white/[0.03]">
                              <div className="flex items-center justify-between gap-3">
                                <p className="font-semibold">{ticket.subject || "Support Request"}</p>
                                <span className={`rounded-full border px-2 py-1 text-[9px] uppercase ${needsAttention ? "border-blue-500/20 bg-blue-500/10 text-blue-400" : "border-[#E3E7ED] text-[#5C4147]"}`}>{ticket.inboxState}</span>
                              </div>
                              <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-[#6B4A50]">{ticket.message || "No message provided."}</p>
                              <div className="mt-2 flex flex-wrap gap-2">
                                <span className="rounded-full border border-[#E3E7ED] px-2 py-1 text-[9px] uppercase text-[#5C4147]">{ticket.status || "open"}</span>
                                <span className="rounded-full border border-[#E3E7ED] px-2 py-1 text-[9px] uppercase text-[#5C4147]">{ticket.priority || "normal"}</span>
                                <span className="text-[10px] text-gray-700">{formatDate(ticket.created_at)}</span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </section>

                    <section className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                      <h3 className="font-bold">
                        Payment Instruction
                      </h3>

                      <select
                        value={
                          paymentMethod
                        }
                        onChange={(
                          event,
                        ) =>
                          setPaymentMethod(
                            event.target
                              .value,
                          )
                        }
                        className="mt-5 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      >
                        {Object.entries(
                          paymentMethods,
                        ).map(
                          ([
                            key,
                            method,
                          ]) => (
                            <option
                              key={key}
                              value={key}
                            >
                              {
                                method.name
                              }
                            </option>
                          ),
                        )}
                      </select>

                      <input
                        type="number"
                        step="0.01"
                        value={
                          paymentAmount
                        }
                        onChange={(
                          event,
                        ) =>
                          setPaymentAmount(
                            event.target
                              .value,
                          )
                        }
                        placeholder="Amount"
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <input
                        value={
                          paymentDestination
                        }
                        onChange={(
                          event,
                        ) =>
                          setPaymentDestination(
                            event.target
                              .value,
                          )
                        }
                        placeholder="Destination"
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <textarea
                        rows={3}
                        value={
                          paymentNote
                        }
                        onChange={(
                          event,
                        ) =>
                          setPaymentNote(
                            event.target
                              .value,
                          )
                        }
                        className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                      />

                      <button
                        type="button"
                        disabled={
                          busy
                        }
                        onClick={
                          handleCreatePayment
                        }
                        className="mt-4 w-full rounded-xl bg-[#B51F35] px-4 py-3 text-sm font-bold text-black hover:bg-[#B51F35] disabled:opacity-50"
                      >
                        Create Payment Instruction
                      </button>
                    </section>
                  </div>
                </div>
              )}
            </>
          )}

          {activeSection ===
            "transactions" && (
            <>
              <div className="grid gap-4 md:grid-cols-4">
                <button
                  type="button"
                  onClick={() =>
                    scrollTo(
                      depositsRef,
                    )
                  }
                  className="rounded-2xl border border-[#B51F35]/20 bg-[#F8F9FB] p-5 text-left"
                >
                  <p className="text-xs text-gray-600">
                    Pending Deposits
                  </p>

                  <p className="mt-2 text-3xl font-black text-[#B51F35]">
                    {pendingDeposits.length}
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    scrollTo(
                      withdrawalsRef,
                    )
                  }
                  className="rounded-2xl border border-[#B51F35]/20 bg-[#F8F9FB] p-5 text-left"
                >
                  <p className="text-xs text-gray-600">
                    Pending Withdrawals
                  </p>

                  <p className="mt-2 text-3xl font-black text-[#B51F35]">
                    {pendingWithdrawals.length}
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    document.getElementById("fee-payments-management")?.scrollIntoView({ behavior: "smooth", block: "start" })
                  }
                  className="rounded-2xl border border-[#B51F35]/20 bg-[#F8F9FB] p-5 text-left"
                >
                  <p className="text-xs text-gray-600">Pending Fee Payments</p>
                  <p className="mt-2 text-3xl font-black text-[#B51F35]">
                    {feePayments.filter((item) => (item.status || "pending").toLowerCase() === "pending").length}
                  </p>
                </button>

                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    Total Transactions
                  </p>

                  <p className="mt-2 text-3xl font-black">
                    {deposits.length +
                      withdrawals.length +
                      feePayments.length}
                  </p>
                </div>
              </div>

              <div
                ref={depositsRef}
                className="mt-6 scroll-mt-28 overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]"
              >
                <div className="border-b border-[#E3E7ED] p-5">
                  <h2 className="text-xl font-black">
                    Deposit Management
                  </h2>

                  <p className="mt-1 text-sm text-gray-600">
                    Review pending customer deposits.
                  </p>
                </div>

                {pendingDeposits.length ===
                0 ? (
                  <div className="p-12 text-center text-sm text-gray-600">
                    No pending deposits.
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {pendingDeposits.map(
                      (deposit) => (
                        <div
                          key={
                            deposit.id
                          }
                          className="p-5"
                        >
                          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                            <div>
                              <p className="font-bold">
                                {
                                  deposit.user_name
                                }
                              </p>

                              <p className="mt-1 text-sm text-[#5C4147]">
                                {money(
                                  deposit.amount,
                                )}{" "}
                                via{" "}
                                {paymentMethods[
                                  deposit.payment_method as keyof typeof paymentMethods
                                ]?.name ||
                                  deposit.payment_method ||
                                  "Unknown method"}
                              </p>

                              <p className="mt-1 text-xs text-gray-700">
                                Reference:{" "}
                                {deposit.reference ||
                                  "—"}
                              </p>

                              <p className="mt-1 text-xs text-gray-700">
                                {formatDate(
                                  deposit.created_at,
                                )}
                              </p>
                            </div>

                            <div className="flex gap-2">
                              <button
                                type="button"
                                disabled={
                                  reviewingDeposit ===
                                  deposit.id
                                }
                                onClick={() =>
                                  handleReviewDeposit(
                                    deposit,
                                    "approved",
                                  )
                                }
                                className="rounded-xl bg-green-500 px-4 py-2 text-xs font-bold text-black hover:bg-green-400 disabled:opacity-50"
                              >
                                Approve
                              </button>

                              <button
                                type="button"
                                disabled={
                                  reviewingDeposit ===
                                  deposit.id
                                }
                                onClick={() =>
                                  handleReviewDeposit(
                                    deposit,
                                    "rejected",
                                  )
                                }
                                className="rounded-xl bg-red-500 px-4 py-2 text-xs font-bold text-[#1F2937] hover:bg-red-400 disabled:opacity-50"
                              >
                                Reject
                              </button>
                            </div>
                          </div>
                        </div>
                      ),
                    )}
                  </div>
                )}
              </div>

              <div
                ref={
                  withdrawalsRef
                }
                className="mt-6 scroll-mt-28 overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]"
              >
                <div className="border-b border-[#E3E7ED] p-5">
                  <h2 className="text-xl font-black">
                    Withdrawal Management
                  </h2>

                  <p className="mt-1 text-sm text-gray-600">
                    Review pending withdrawal requests.
                  </p>
                </div>

                {pendingWithdrawals.length ===
                0 ? (
                  <div className="p-12 text-center text-sm text-gray-600">
                    No pending withdrawals.
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {pendingWithdrawals.map(
                      (
                        withdrawal,
                      ) => (
                        <div
                          key={
                            withdrawal.id
                          }
                          className="p-5"
                        >
                          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                            <div>
                              <p className="font-bold">
                                {
                                  withdrawal.user_name
                                }
                              </p>

                              <p className="mt-1 text-sm text-[#5C4147]">
                                {money(
                                  withdrawal.amount,
                                )}{" "}
                                via{" "}
                                {withdrawalMethods[
                                  withdrawal.withdrawal_method as keyof typeof withdrawalMethods
                                ]?.name ||
                                  withdrawal.withdrawal_method ||
                                  "Unknown method"}
                              </p>

                              <p className="mt-1 text-xs text-gray-700">
                                Destination:{" "}
                                {withdrawal.destination ||
                                  "—"}
                              </p>

                              {withdrawal.note && (
                                <p className="mt-1 text-xs text-gray-700">
                                  Note:{" "}
                                  {
                                    withdrawal.note
                                  }
                                </p>
                              )}

                              <p className="mt-1 text-xs text-gray-700">
                                {formatDate(
                                  withdrawal.created_at,
                                )}
                              </p>
                            </div>

                            <div className="flex gap-2">
                              <button
                                type="button"
                                disabled={
                                  reviewingWithdrawal ===
                                  withdrawal.id
                                }
                                onClick={() =>
                                  handleReviewWithdrawal(
                                    withdrawal,
                                    "approved",
                                  )
                                }
                                className="rounded-xl bg-green-500 px-4 py-2 text-xs font-bold text-black hover:bg-green-400 disabled:opacity-50"
                              >
                                Approve
                              </button>

                              <button
                                type="button"
                                disabled={
                                  reviewingWithdrawal ===
                                  withdrawal.id
                                }
                                onClick={() =>
                                  handleReviewWithdrawal(
                                    withdrawal,
                                    "rejected",
                                  )
                                }
                                className="rounded-xl bg-red-500 px-4 py-2 text-xs font-bold text-[#1F2937] hover:bg-red-400 disabled:opacity-50"
                              >
                                Reject
                              </button>
                            </div>
                          </div>
                        </div>
                      ),
                    )}
                  </div>
                )}
              </div>
            </>
          )}

          {activeSection === "transactions" && (
            <div id="fee-payments-management" className="mt-6 scroll-mt-28 overflow-hidden rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB]">
              <div className="border-b border-[#E3E7ED] p-5">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div>
                    <h2 className="text-xl font-black">Fee Payment Management</h2>
                    <p className="mt-1 text-sm text-gray-600">Approve or reject customer fee payments. Pending and rejected payments do not reduce the outstanding fee. Only approved payments count.</p>
                  </div>
                  <span className="rounded-full border border-[#B51F35]/20 bg-[#B51F35]/10 px-3 py-1 text-xs font-bold text-[#B51F35]">
                    {feePayments.filter((item) => (item.status || "pending").toLowerCase() === "pending").length} pending
                  </span>
                </div>
              </div>

              {feePayments.length === 0 ? (
                <div className="p-12 text-center text-sm text-gray-600">No fee payments found.</div>
              ) : (
                <div className="divide-y divide-white/5">
                  {feePayments.map((payment) => {
                    const status = (payment.status || "pending").toLowerCase();
                    const fee = feeRequests.find((item) => item.id === payment.reference);
                    const approvedBefore = feePayments
                      .filter((item) => item.reference === payment.reference && item.id !== payment.id && ["completed", "approved", "paid"].includes((item.status || "").toLowerCase()))
                      .reduce((sum, item) => sum + Number(item.amount || 0), 0);
                    const remainingBefore = fee ? Math.max(Number(fee.amount || 0) - approvedBefore, 0) : null;

                    return (
                      <div key={payment.id} className="p-5">
                        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <p className="font-bold text-[#1F2937]">{payment.customer_name}</p>
                              <span className={`rounded-full border px-2 py-1 text-[9px] uppercase ${status === "rejected" ? "border-red-500/20 bg-red-500/10 text-red-400" : ["completed", "approved", "paid"].includes(status) ? "border-green-500/20 bg-green-500/10 text-green-400" : "border-[#B51F35]/20 bg-[#B51F35]/10 text-[#B51F35]"}`}>{status}</span>
                            </div>
                            <p className="mt-1 text-sm text-[#5C4147]">{payment.customer_email || "No email"}</p>
                            <p className="mt-2 text-sm text-[#4B3439]">Payment amount: <strong>{money(payment.amount)}</strong>{fee ? ` · Requested fee: ${money(fee.amount)}` : ""}</p>
                            {remainingBefore !== null && <p className="mt-1 text-xs text-[#5C4147]">Approved before this payment: {money(approvedBefore)} · Remaining before review: {money(remainingBefore)}</p>}
                            <p className="mt-1 text-xs text-gray-600">Payment reference / fee ID: {payment.reference || "—"}</p>
                            <p className="mt-1 text-xs text-gray-600">{payment.description || "Fee payment"} · {formatDate(payment.created_at)}</p>
                          </div>

                          {status === "pending" && (
                            <div className="flex shrink-0 gap-2">
                              <button type="button" disabled={feePaymentReviewing === payment.id} onClick={() => handleReviewFeePayment(payment, "approved")} className="rounded-xl bg-green-500 px-4 py-2 text-xs font-bold text-black hover:bg-green-400 disabled:opacity-50">{feePaymentReviewing === payment.id ? "Processing..." : "Approve"}</button>
                              <button type="button" disabled={feePaymentReviewing === payment.id} onClick={() => handleReviewFeePayment(payment, "rejected")} className="rounded-xl bg-red-500 px-4 py-2 text-xs font-bold text-[#1F2937] hover:bg-red-400 disabled:opacity-50">Reject</button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeSection === "payment-settings" && (
            <section className="space-y-6">
              <div className="relative overflow-hidden rounded-[34px] border border-[#E3E7ED] bg-[#07090E] shadow-[0_35px_120px_rgba(0,0,0,0.42)]">
                <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-red-600/10 blur-3xl" />
                <div className="absolute -bottom-28 right-0 h-80 w-80 rounded-full bg-red-900/10 blur-3xl" />

                <div className="relative border-b border-[#E3E7ED] px-6 py-7 sm:px-8 lg:px-10">
                  <div className="flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
                    <div className="max-w-3xl">
                      <div className="mb-4 flex flex-wrap items-center gap-2">
                        <span className="inline-flex items-center gap-2 rounded-full border border-red-500/20 bg-red-500/[0.07] px-3 py-1.5 text-[9px] font-black uppercase tracking-[0.2em] text-red-300">
                          <FiSettings /> Payment Control Center
                        </span>
                        <span className="rounded-full border border-[#E3E7ED] bg-white/[0.03] px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-[#5C4147]">
                          09 Channels
                        </span>
                      </div>
                      <h2 className="text-3xl font-black tracking-tight text-[#1F2937] sm:text-4xl">
                        Payment Settings
                      </h2>
                      <p className="mt-3 max-w-2xl text-sm leading-7 text-[#5C4147]">
                        Control the exact payment destination customers receive. Every payment method has two isolated configurations so deposit information can never be used for fees and fee information can never be used for deposits.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:min-w-[390px]">
                      <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB]/30 p-4">
                        <p className="text-[9px] font-black uppercase tracking-[0.18em] text-gray-600">Channels</p>
                        <p className="mt-2 text-2xl font-black text-[#1F2937]">09</p>
                      </div>
                      <div className="rounded-2xl border border-blue-500/15 bg-blue-500/[0.035] p-4">
                        <p className="text-[9px] font-black uppercase tracking-[0.18em] text-blue-400/70">Deposit</p>
                        <p className="mt-2 text-2xl font-black text-blue-300">09</p>
                      </div>
                      <div className="rounded-2xl border border-red-500/15 bg-red-500/[0.035] p-4 col-span-2 sm:col-span-1">
                        <p className="text-[9px] font-black uppercase tracking-[0.18em] text-red-400/70">Fee</p>
                        <p className="mt-2 text-2xl font-black text-red-300">09</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="relative p-5 sm:p-7 lg:p-8">
                  <div className="mb-6 rounded-3xl border border-red-500/10 bg-red-500/[0.025] p-5 sm:p-6">
                    <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex items-start gap-4">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-red-500/15 bg-red-500/[0.07] text-red-400">
                          <FiShield size={20} />
                        </div>
                        <div>
                          <p className="text-sm font-black text-[#1F2937]">Payment information isolation is enabled</p>
                          <p className="mt-1 max-w-2xl text-xs leading-6 text-[#5C4147]">
                            Deposit and fee destinations are saved under separate keys for every channel. Editing one side does not overwrite the other side.
                          </p>
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-2 rounded-full border border-green-500/20 bg-green-500/[0.05] px-3 py-2 text-[9px] font-black uppercase tracking-[0.16em] text-green-400">
                        <span className="h-1.5 w-1.5 rounded-full bg-green-400" /> Separate storage
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-4 lg:grid-cols-3">
                    {[
                      ["deposit_fee", "Deposit Fee"],
                      ["withdrawal_fee", "Withdrawal Fee"],
                      ["network_fee", "Network Fee"],
                      ["minimum_deposit", "Minimum Deposit"],
                      ["minimum_withdrawal", "Minimum Withdrawal"],
                    ].map(([key, label]) => (
                      <label key={key} className="group rounded-3xl border border-[#E3E7ED] bg-white p-4 transition hover:border-red-500/20">
                        <span className="mb-2 block text-[9px] font-black uppercase tracking-[0.17em] text-gray-600">{label}</span>
                        <div className="flex items-center rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB]/50 px-3 transition group-focus-within:border-red-500/40">
                          <span className="text-sm font-black text-red-400">$</span>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={paymentSettingsForm[key as keyof typeof paymentSettingsForm]}
                            onChange={(event) => setPaymentSettingsForm((current) => ({ ...current, [key]: event.target.value }))}
                            className="w-full bg-transparent px-2 py-3 text-sm font-bold text-[#1F2937] outline-none"
                          />
                        </div>
                      </label>
                    ))}
                  </div>

                  <div className="mt-5 grid gap-4 lg:grid-cols-3">
                    {[
                      ["deposit_instructions", "Deposit Instructions", "General instructions shown during deposits."],
                      ["fee_payment_instructions", "Fee Payment Instructions", "General instructions shown during fee payments."],
                      ["withdrawal_instructions", "Withdrawal Instructions", "General withdrawal instructions."],
                    ].map(([key, label, placeholder]) => (
                      <label key={key} className="rounded-3xl border border-[#E3E7ED] bg-white p-5">
                        <span className="mb-2 block text-[9px] font-black uppercase tracking-[0.17em] text-gray-600">{label}</span>
                        <textarea
                          rows={4}
                          value={paymentSettingsForm[key as keyof typeof paymentSettingsForm]}
                          onChange={(event) => setPaymentSettingsForm((current) => ({ ...current, [key]: event.target.value }))}
                          className="w-full resize-none rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB]/50 px-4 py-3 text-sm leading-6 text-[#1F2937] outline-none transition placeholder:text-gray-700 focus:border-red-500/40"
                          placeholder={placeholder}
                        />
                      </label>
                    ))}
                  </div>

                  <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                      <p className="text-xl font-black text-[#1F2937]">Payment Methods</p>
                      <p className="mt-1 text-xs leading-5 text-gray-600">
                        Deposit and fee destinations are separate entries. Open only the entry you want to edit.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 text-[9px] font-bold uppercase tracking-[0.16em] text-gray-600">
                      <span className="h-2 w-2 rounded-full bg-blue-400" /> Deposit
                      <span className="ml-2 h-2 w-2 rounded-full bg-red-400" /> Fees
                    </div>
                  </div>

                  {paymentSettingsLoading ? (
                    <div className="mt-5 rounded-[28px] border border-[#E3E7ED] bg-[#F8F9FB] p-12 text-center">
                      <FiRefreshCw className="mx-auto animate-spin text-xl text-red-400" />
                      <p className="mt-4 text-sm font-bold text-[#1F2937]">Loading payment methods...</p>
                    </div>
                  ) : (
                    <div className="mt-5 grid gap-4 xl:grid-cols-2">
                      {uniquePaymentMethodsData.flatMap((method, methodIndex) =>
                        (["deposit", "fee"] as const).map((side) => {
                          const fields = paymentFieldDefinitions[method.type] || [];
                          const icon =
                            paymentMethods[method.type as keyof typeof paymentMethods]?.icon ||
                            method.name.slice(0, 1);
                          const isDeposit = side === "deposit";
                          const accordionKey = `${method.id}:${side}`;
                          const isExpanded = expandedPaymentMethod === accordionKey;
                          const isSaving = paymentMethodSaving === accordionKey;
                          const configured = fields.every((field) =>
                            paymentDetailValue(method.details, side, method.type, field.key).trim(),
                          );

                          return (
                            <article
                              key={accordionKey}
                              className={`overflow-hidden rounded-[26px] border bg-[#F8F9FB] transition duration-300 ${
                                isExpanded
                                  ? isDeposit
                                    ? "border-blue-500/30 shadow-[0_24px_70px_rgba(0,0,0,0.28)]"
                                    : "border-red-500/30 shadow-[0_24px_70px_rgba(0,0,0,0.28)]"
                                  : "border-[#E3E7ED] hover:border-[#DDE2E8]"
                              }`}
                            >
                              <button
                                type="button"
                                onClick={() => setExpandedPaymentMethod(isExpanded ? null : accordionKey)}
                                className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-6"
                              >
                                <div className="flex min-w-0 items-center gap-4">
                                  <div
                                    className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border text-lg font-black ${
                                      isDeposit
                                        ? "border-blue-500/20 bg-blue-500/[0.07] text-blue-300"
                                        : "border-red-500/20 bg-red-500/[0.07] text-red-300"
                                    }`}
                                  >
                                    {icon}
                                  </div>

                                  <div className="min-w-0">
                                    <div className="flex flex-wrap items-center gap-2">
                                      <h4 className="truncate text-base font-black text-[#1F2937]">
                                        {method.name} {isDeposit ? "Deposit" : "Fees"}
                                      </h4>
                                      <span
                                        className={`rounded-full border px-2 py-1 text-[8px] font-black uppercase tracking-[0.14em] ${
                                          configured
                                            ? "border-green-500/20 bg-green-500/[0.05] text-green-400"
                                            : "border-[#B51F35]/20 bg-[#B51F35]/[0.05] text-[#B51F35]"
                                        }`}
                                      >
                                        {configured ? "Configured" : "Not configured"}
                                      </span>
                                    </div>
                                    <p className="mt-1 text-[10px] text-gray-600">
                                      {isDeposit
                                        ? "Shown only on the customer deposit screen"
                                        : "Shown only on the customer fee payment screen"}
                                    </p>
                                  </div>
                                </div>

                                <div className="flex shrink-0 items-center gap-2">
                                  <span className="hidden text-[9px] font-bold uppercase tracking-[0.15em] text-gray-700 sm:block">
                                    {String(methodIndex + 1).padStart(2, "0")}
                                  </span>
                                  <span
                                    className={`flex h-9 w-9 items-center justify-center rounded-xl border ${
                                      isExpanded
                                        ? isDeposit
                                          ? "border-blue-500/30 bg-blue-500/10 text-blue-300"
                                          : "border-red-500/30 bg-red-500/10 text-red-300"
                                        : "border-[#E3E7ED] bg-white/[0.03] text-[#5C4147]"
                                    }`}
                                  >
                                    <FiChevronDown
                                      className={`transition-transform duration-300 ${isExpanded ? "rotate-180" : ""}`}
                                    />
                                  </span>
                                </div>
                              </button>

                              {isExpanded && (
                                <div className="border-t border-[#E3E7ED] p-5 sm:p-6">
                                  <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                    <div>
                                      <p
                                        className={`text-[9px] font-black uppercase tracking-[0.18em] ${
                                          isDeposit ? "text-blue-400" : "text-red-400"
                                        }`}
                                      >
                                        {isDeposit ? "Deposit destination" : "Fee payment destination"}
                                      </p>
                                      <p className="mt-1 text-xs text-gray-600">
                                        Editing this entry does not overwrite {isDeposit ? "fee" : "deposit"} information.
                                      </p>
                                    </div>

                                    <label className="flex items-center gap-2 text-[9px] font-black uppercase tracking-[0.12em] text-gray-600">
                                      Method status
                                      <select
                                        value={method.is_active ? "active" : "disabled"}
                                        onChange={(event) =>
                                          updatePaymentMethodLocal(method.id, {
                                            is_active: event.target.value === "active",
                                          })
                                        }
                                        className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB]/50 px-3 py-2 text-xs font-bold text-[#1F2937] outline-none"
                                      >
                                        <option value="active">Active</option>
                                        <option value="disabled">Disabled</option>
                                      </select>
                                    </label>
                                  </div>

                                  <div className="grid gap-4 sm:grid-cols-2">
                                    {fields.map((field) => {
                                      const storageKey = `${side}_${method.type}_${field.key}`;
                                      return (
                                        <label key={storageKey} className="block">
                                          <span className="mb-2 block text-[9px] font-black uppercase tracking-[0.14em] text-gray-600">
                                            {field.label}
                                          </span>
                                          <input
                                            value={paymentDetailValue(
                                              method.details,
                                              side,
                                              method.type,
                                              field.key,
                                            )}
                                            onChange={(event) =>
                                              updatePaymentMethodDetail(
                                                method.id,
                                                storageKey,
                                                event.target.value,
                                              )
                                            }
                                            className={`w-full rounded-2xl border bg-[#F8F9FB]/50 px-4 py-3.5 text-sm font-medium text-[#1F2937] outline-none transition placeholder:text-gray-800 ${
                                              isDeposit
                                                ? "border-[#E3E7ED] focus:border-blue-500/40"
                                                : "border-[#E3E7ED] focus:border-red-500/40"
                                            }`}
                                            placeholder={field.placeholder}
                                          />
                                        </label>
                                      );
                                    })}
                                  </div>

                                  <label className="mt-4 block">
                                    <span className="mb-2 block text-[9px] font-black uppercase tracking-[0.14em] text-gray-600">
                                      Additional {isDeposit ? "Deposit" : "Fee Payment"} Instructions
                                    </span>
                                    <textarea
                                      rows={3}
                                      value={paymentInstructionValue(method.details, side, method.type)}
                                      onChange={(event) =>
                                        updatePaymentMethodDetail(
                                          method.id,
                                          `${side}_${method.type}_instructions`,
                                          event.target.value,
                                        )
                                      }
                                      className={`w-full resize-none rounded-2xl border bg-[#F8F9FB]/50 px-4 py-3.5 text-sm leading-6 text-[#1F2937] outline-none transition placeholder:text-gray-800 ${
                                        isDeposit
                                          ? "border-[#E3E7ED] focus:border-blue-500/40"
                                          : "border-[#E3E7ED] focus:border-red-500/40"
                                      }`}
                                      placeholder={`Optional ${isDeposit ? "deposit" : "fee payment"} instructions`}
                                    />
                                  </label>

                                  <div className="mt-5 flex flex-col gap-3 border-t border-[#E3E7ED] pt-5 sm:flex-row sm:items-center sm:justify-between">
                                    <div className="flex items-center gap-2 text-[10px] text-gray-600">
                                      <FiLock className={isDeposit ? "text-blue-400" : "text-red-400"} />
                                      {isDeposit
                                        ? "Saves to deposit fields and legacy customer-deposit fields"
                                        : "Saves only to fee-payment fields"}
                                    </div>
                                    <button
                                      type="button"
                                      disabled={isSaving || paymentSettingsLoading}
                                      onClick={() => savePaymentMethodSide(method, side)}
                                      className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-5 py-3 text-xs font-black uppercase tracking-[0.1em] text-[#1F2937] transition disabled:cursor-not-allowed disabled:opacity-50 ${
                                        isDeposit
                                          ? "bg-blue-600 hover:bg-blue-500"
                                          : "bg-red-600 hover:bg-red-500"
                                      }`}
                                    >
                                      <FiCheckCircle />
                                      {isSaving
                                        ? "Saving..."
                                        : `Save ${method.name} ${isDeposit ? "Deposit" : "Fees"}`}
                                    </button>
                                  </div>
                                </div>
                              )}
                            </article>
                          );
                        }),
                      )}
                    </div>
                  )}

                  <div className="mt-6 rounded-[30px] border border-[#E3E7ED] bg-white p-5 sm:p-6">
                    <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
                      <div className="flex items-start gap-4">
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-[#E3E7ED] bg-white text-[#6B4A50]">
                          <FiCheckCircle size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-black text-[#1F2937]">Ready to publish payment changes</p>
                          <p className="mt-1 text-xs leading-5 text-gray-600">Saving writes each deposit and fee destination separately for every payment method.</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        disabled={paymentSettingsSaving || paymentSettingsLoading}
                        onClick={savePaymentSettings}
                        className="inline-flex min-h-12 items-center justify-center gap-3 rounded-2xl bg-red-600 px-7 py-3 text-sm font-black uppercase tracking-[0.12em] text-[#1F2937] shadow-[0_18px_50px_rgba(220,38,38,0.2)] transition hover:bg-red-500 hover:shadow-[0_20px_60px_rgba(220,38,38,0.26)] disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <FiCheckCircle />
                        {paymentSettingsSaving ? "Saving Payment Configuration..." : "Save All Payment Settings"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {activeSection ===
            "support" && (
            <>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    Open Tickets
                  </p>

                  <p className="mt-2 text-3xl font-black">
                    {openSupportTickets.length}
                  </p>
                </div>

                <div className="rounded-2xl border border-red-500/20 bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    Urgent
                  </p>

                  <p className="mt-2 text-3xl font-black text-red-400">
                    {urgentSupportTickets.length}
                  </p>
                </div>

                <div className="rounded-2xl border border-[#E3E7ED] bg-[#F8F9FB] p-5">
                  <p className="text-xs text-gray-600">
                    Total Tickets
                  </p>

                  <p className="mt-2 text-3xl font-black">
                    {supportTickets.length}
                  </p>
                </div>
              </div>

              <div
                ref={supportRef}
                className="mt-6 grid scroll-mt-28 gap-5 xl:grid-cols-[.9fr_1.1fr]"
              >
                <section className="overflow-hidden rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB]">
                  <div className="border-b border-[#E3E7ED] p-5">
                    <h2 className="text-xl font-black">
                      Support Queue
                    </h2>

                    <input
                      value={
                        supportSearch
                      }
                      onChange={(
                        event,
                      ) =>
                        setSupportSearch(
                          event.target
                            .value,
                        )
                      }
                      placeholder="Search tickets..."
                      className="mt-4 w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                    />

                    <div className="mt-3 flex flex-wrap gap-2">
                      {[
                        [
                          "all",
                          "All",
                        ],
                        [
                          "open",
                          "Open",
                        ],
                        [
                          "urgent",
                          "Urgent",
                        ],
                        [
                          "pending",
                          "Pending",
                        ],
                        [
                          "answered",
                          "Answered",
                        ],
                        [
                          "resolved",
                          "Resolved",
                        ],
                        [
                          "closed",
                          "Closed",
                        ],
                      ].map(
                        ([
                          value,
                          label,
                        ]) => (
                          <button
                            key={
                              value
                            }
                            type="button"
                            onClick={() =>
                              setSupportFilter(
                                value,
                              )
                            }
                            className={`rounded-lg px-3 py-2 text-[10px] font-semibold uppercase ${
                              supportFilter ===
                              value
                                ? "bg-[#B51F35] text-black"
                                : "border border-[#E3E7ED] text-[#5C4147] hover:text-[#1F2937]"
                            }`}
                          >
                            {
                              label
                            }
                          </button>
                        ),
                      )}
                    </div>
                  </div>

                  {filteredSupportTickets.length ===
                  0 ? (
                    <div className="p-12 text-center text-sm text-gray-600">
                      No support tickets found.
                    </div>
                  ) : (
                    <div className="divide-y divide-white/5">
                      {filteredSupportTickets.map(
                        (
                          ticket,
                        ) => (
                          <button
                            key={
                              ticket.id
                            }
                            type="button"
                            onClick={() => {
                              setSelectedTicket(
                                ticket,
                              );
                              setTicketReply(
                                ticket.admin_reply ||
                                  "",
                              );
                            }}
                            className={`block w-full p-5 text-left transition ${
                              selectedTicket?.id ===
                              ticket.id
                                ? "bg-[#B51F35]/[0.05]"
                                : "hover:bg-white/[0.03]"
                            }`}
                          >
                            <div className="flex flex-col gap-3">
                              <div className="flex flex-wrap items-center gap-2">
                                <h3 className="truncate font-semibold">
                                  {ticket.subject ||
                                    "Support Request"}
                                </h3>

                                <span
                                  className={`rounded-full border px-2 py-0.5 text-[9px] ${statusClass(
                                    ticket.status,
                                  )}`}
                                >
                                  {(
                                    ticket.status ||
                                    "open"
                                  ).toUpperCase()}
                                </span>

                                <span
                                  className={`rounded-full border px-2 py-0.5 text-[9px] ${priorityClass(
                                    ticket.priority,
                                  )}`}
                                >
                                  {(
                                    ticket.priority ||
                                    "normal"
                                  ).toUpperCase()}
                                </span>
                              </div>

                              <p className="text-sm text-[#6B4A50]">
                                {
                                  ticket.user_name
                                }
                              </p>

                              <p className="line-clamp-2 text-xs text-gray-600">
                                {ticket.message ||
                                  "No message provided."}
                              </p>

                              <p className="text-[10px] text-gray-700">
                                {formatDate(
                                  ticket.created_at,
                                )}
                              </p>
                            </div>
                          </button>
                        ),
                      )}
                    </div>
                  )}
                </section>

                <section className="rounded-3xl border border-[#B51F35]/20 bg-[#F8F9FB]">
                  {!selectedTicket ? (
                    <div className="flex min-h-[500px] items-center justify-center p-8 text-center">
                      <div>
                        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#B51F35]/10 text-[#B51F35]">
                          <FiMessageSquare />
                        </div>

                        <h3 className="mt-4 font-bold">
                          Select a support ticket
                        </h3>

                        <p className="mt-2 text-sm text-gray-600">
                          Choose a ticket from the queue to manage it.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="border-b border-[#E3E7ED] p-5">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <p className="text-[10px] uppercase tracking-widest text-[#B51F35]">
                              Support Ticket
                            </p>

                            <h3 className="mt-1 text-xl font-black">
                              {selectedTicket.subject ||
                                "Support Request"}
                            </h3>

                            <p className="mt-1 text-xs text-gray-600">
                              {
                                selectedTicket.user_name
                              }
                            </p>
                          </div>

                          <button
                            type="button"
                            onClick={() =>
                              setSelectedTicket(
                                null,
                              )
                            }
                            className="text-gray-600 hover:text-[#1F2937]"
                          >
                            <FiX />
                          </button>
                        </div>
                      </div>

                      <div className="space-y-5 p-5">
                        <div>
                          <p className="mb-2 text-xs uppercase tracking-wider text-gray-600">
                            Customer message
                          </p>

                          <div className="rounded-xl border border-[#E3E7ED] bg-[#F8F9FB] p-4 text-sm leading-6 text-[#4B3439]">
                            {selectedTicket.message ||
                              "No message provided."}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="mb-2 block text-xs text-gray-600">
                              Status
                            </label>

                            <select
                              value={
                                selectedTicket.status ||
                                "open"
                              }
                              disabled={
                                supportBusy
                              }
                              onChange={(
                                event,
                              ) =>
                                handleTicketStatus(
                                  selectedTicket,
                                  event.target
                                    .value,
                                )
                              }
                              className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-3 py-2.5 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                            >
                              <option value="open">
                                Open
                              </option>

                              <option value="pending">
                                Pending
                              </option>

                              <option value="answered">
                                Answered
                              </option>

                              <option value="resolved">
                                Resolved
                              </option>

                              <option value="closed">
                                Closed
                              </option>
                            </select>
                          </div>

                          <div>
                            <label className="mb-2 block text-xs text-gray-600">
                              Priority
                            </label>

                            <select
                              value={
                                selectedTicket.priority ||
                                "normal"
                              }
                              disabled={
                                supportBusy
                              }
                              onChange={(
                                event,
                              ) =>
                                handleTicketPriority(
                                  selectedTicket,
                                  event.target
                                    .value,
                                )
                              }
                              className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-3 py-2.5 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                            >
                              <option value="low">
                                Low
                              </option>

                              <option value="normal">
                                Normal
                              </option>

                              <option value="high">
                                High
                              </option>

                              <option value="urgent">
                                Urgent
                              </option>
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="mb-2 block text-xs text-gray-600">
                            Category
                          </label>

                          <select
                            value={
                              selectedTicket.category ||
                              "general"
                            }
                            disabled={
                              supportBusy
                            }
                            onChange={(
                              event,
                            ) =>
                              handleTicketCategory(
                                selectedTicket,
                                event.target
                                  .value,
                              )
                            }
                            className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                          >
                            <option value="general">
                              General
                            </option>

                            <option value="account">
                              Account
                            </option>

                            <option value="deposit">
                              Deposit
                            </option>

                            <option value="withdrawal">
                              Withdrawal
                            </option>

                            <option value="payment">
                              Payment
                            </option>

                            <option value="kyc">
                              KYC
                            </option>

                            <option value="technical">
                              Technical
                            </option>

                            <option value="security">
                              Security
                            </option>
                          </select>
                        </div>

                        <div>
                          <p className="mb-2 text-xs uppercase tracking-wider text-gray-600">
                            FlashFinance reply
                          </p>

                          <textarea
                            value={
                              ticketReply
                            }
                            onChange={(
                              event,
                            ) =>
                              setTicketReply(
                                event.target
                                  .value,
                              )
                            }
                            rows={7}
                            placeholder="Write your response..."
                            className="w-full rounded-xl border border-[#DDE2E8] bg-[#F8F9FB] px-4 py-3 text-sm text-[#1F2937] outline-none focus:border-[#B51F35]"
                          />

                          <button
                            type="button"
                            onClick={
                              handleReplyTicket
                            }
                            disabled={
                              supportBusy
                            }
                            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-5 py-3 font-semibold text-black hover:bg-[#B51F35] disabled:opacity-50"
                          >
                            <FiSend />

                            {supportBusy
                              ? "Processing..."
                              : "Send Reply"}
                          </button>
                        </div>

                        {selectedTicket.admin_reply && (
                          <div>
                            <p className="mb-2 text-xs uppercase tracking-wider text-gray-600">
                              Previous reply
                            </p>

                            <div className="rounded-xl border border-green-500/20 bg-green-500/5 p-4 text-sm leading-6 text-[#4B3439]">
                              {
                                selectedTicket.admin_reply
                              }

                              {selectedTicket.replied_at && (
                                <p className="mt-3 text-xs text-gray-600">
                                  Replied{" "}
                                  {formatDate(
                                    selectedTicket.replied_at,
                                  )}
                                </p>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </section>
              </div>
            </>
          )}

          {activeSection ===
            "activity" && (
            <section className="overflow-hidden rounded-3xl border border-[#E3E7ED] bg-[#F8F9FB]">
              <div className="border-b border-[#E3E7ED] p-5">
                <h2 className="text-xl font-black">
                  FlashFinance Activity Log
                </h2>

                <p className="mt-1 text-sm text-[#5C4147]">
                  FlashFinance actions recorded for accountability.
                </p>
              </div>

              {auditLogs.length ===
              0 ? (
                <div className="p-16 text-center text-gray-600">
                  No FlashFinance activity recorded yet.
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {auditLogs.map(
                    (log) => (
                      <div
                        key={log.id}
                        className="p-5 hover:bg-white/[0.02]"
                      >
                        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="rounded-lg bg-[#B51F35]/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-[#B51F35]">
                                {
                                  log.action
                                }
                              </span>

                              {log.target_user_id && (
                                <span className="text-[10px] text-gray-600">
                                  Customer action
                                </span>
                              )}
                            </div>

                            <p className="mt-2 text-sm text-[#4B3439]">
                              {
                                log.description
                              }
                            </p>

                            {log.metadata &&
                              Object.keys(
                                log.metadata,
                              ).length >
                                0 && (
                                <pre className="mt-3 max-w-full overflow-x-auto rounded-xl border border-white/5 bg-[#F8F9FB] p-3 text-[10px] text-gray-600">
                                  {JSON.stringify(
                                    log.metadata,
                                    null,
                                    2,
                                  )}
                                </pre>
                              )}
                          </div>

                          <p className="shrink-0 text-xs text-gray-600">
                            {formatDate(
                              log.created_at,
                            )}
                          </p>
                        </div>
                      </div>
                    ),
                  )}
                </div>
              )}
            </section>
          )}

          <footer className="mt-8 flex flex-col gap-3 border-t border-[#E3E7ED] py-6 text-xs text-gray-700 sm:flex-row sm:items-center sm:justify-between">
            <p>
              FlashFinance Control Center
            </p>

            <p>
              Last refreshed{" "}
              {lastRefreshed || "—"}
            </p>
          </footer>
        </section>
      </div>
    </main>
  );
}

function FiPaperclipFallback() {
  return (
    <FiFileText className="text-[#B51F35]" />
  );
}










