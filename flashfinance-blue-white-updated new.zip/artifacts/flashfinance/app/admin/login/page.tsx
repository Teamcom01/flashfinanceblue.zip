﻿"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase";

export default function AdminLoginPage() {
  const router = useRouter();
  const supabase = createClient();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setLoading(true);
    setMessage("");

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error || !data.user) {
      setMessage("Invalid admin email or password.");
      setLoading(false);
      return;
    }

    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", data.user.id)
      .single();

    if (profileError || profile?.role !== "admin") {
      await supabase.auth.signOut();
      setMessage("This account does not have admin access.");
      setLoading(false);
      return;
    }

    router.push("/admin/dashboard");
  }

  return (
    <main className="ff-auth-page ff-admin-auth relative flex min-h-screen items-center justify-center overflow-hidden bg-[#F1F3F6] px-6 py-12 text-[#111318]">
      {/* Background */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-32 -top-32 h-[420px] w-[420px] rounded-full bg-[#B51F35]/10 blur-3xl" />

        <div className="absolute -right-40 top-20 h-[520px] w-[520px] rounded-full bg-[#0B0E17]/[0.06] blur-3xl" />

        <div className="absolute bottom-[-220px] left-[30%] h-[500px] w-[500px] rounded-full bg-white/80 blur-3xl" />

        <div className="absolute inset-0 bg-[linear-gradient(120deg,rgba(255,255,255,0.45)_0%,transparent_38%,rgba(255,255,255,0.3)_100%)]" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Branding */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center rounded-2xl bg-white px-6 py-3 shadow-[0_12px_35px_rgba(17,19,24,0.08)] ring-1 ring-[#E2E5E9]">
            <div className="text-3xl font-bold tracking-wide">
              <span className="text-[#0B0E17]">FLASH</span>
              <span className="text-[#B51F35]">FINANCE</span>
            </div>
          </div>

          <p className="mt-4 text-sm font-medium text-[#69707D]">
            Administrator Control Center
          </p>
        </div>

        {/* Login Card */}
        <div className="rounded-[28px] border border-[#E2E5E9] bg-white p-8 shadow-[0_24px_70px_rgba(17,19,24,0.10)]">
          <div className="mb-7">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#0B0E17] text-lg font-bold text-white shadow-sm">
              FF
            </div>

            <h1 className="text-2xl font-bold text-[#111318]">
              Welcome, Admin
            </h1>

            <p className="mt-2 text-sm leading-6 text-[#69707D]">
              Sign in to manage the FlashFinance system, customers,
              applications, transactions and support.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="mb-2 block text-sm font-semibold text-[#252932]">
                Admin Email
              </label>

              <input
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                required
                autoComplete="email"
                className="w-full rounded-xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-3.5 text-[#111318] outline-none transition placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white focus:ring-4 focus:ring-[#B51F35]/10"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-[#252932]">
                Password
              </label>

              <input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                required
                autoComplete="current-password"
                className="w-full rounded-xl border border-[#E2E5E9] bg-[#F8F9FB] px-4 py-3.5 text-[#111318] outline-none transition placeholder:text-[#9298A3] focus:border-[#B51F35] focus:bg-white focus:ring-4 focus:ring-[#B51F35]/10"
              />
            </div>

            {message && (
              <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium leading-5 text-red-700">
                {message}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-[#B51F35] py-3.5 font-semibold text-white shadow-[0_10px_25px_rgba(181,31,53,0.20)] transition hover:bg-[#991B30] hover:shadow-[0_12px_30px_rgba(181,31,53,0.25)] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? "Signing in..." : "Admin Login"}
            </button>
          </form>

          <div className="mt-7 border-t border-[#E2E5E9] pt-6 text-center">
            <Link
              href="/"
              className="text-sm font-medium text-[#69707D] transition hover:text-[#B51F35]"
            >
              ← Back to FlashFinance
            </Link>
          </div>
        </div>

        {/* Admin Notice */}
        <div className="mt-6 flex items-center justify-center gap-2 text-xs text-[#9298A3]">
          <span className="h-2 w-2 rounded-full bg-[#B51F35]" />
          <span>FlashFinance Administrator Access</span>
        </div>
      </div>
    </main>
  );
}