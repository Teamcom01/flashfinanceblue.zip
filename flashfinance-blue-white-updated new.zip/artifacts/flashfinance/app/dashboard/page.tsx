"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FiActivity,
  FiAlertCircle,
  FiAlertTriangle,
  FiArrowDownLeft,
  FiArrowUpRight,
  FiBell,
  FiBriefcase,
  FiChevronDown,
  FiChevronRight,
  FiClock,
  FiCreditCard,
  FiDollarSign,
  FiEye,
  FiEyeOff,
  FiExternalLink,
  FiGift,
  FiGrid,
  FiHome,
  FiLogOut,
  FiMenu,
  FiMessageCircle,
  FiMoon,
  FiPlus,
  FiSearch,
  FiSend,
  FiShield,
  FiSmartphone,
  FiTrendingUp,
  FiUser,
  FiX,
  FiZap,
} from "react-icons/fi";
import { createClient } from "@/lib/supabase";

type Profile = {
  full_name: string | null;
  phone: string | null;
  account_status: string | null;
  account_type: string | null;
  role: string | null;
  avatar_url: string | null;
};

type Account = {
  balance: number | null;
  currency: string | null;
};

type Transaction = {
  id: string;
  type: string;
  amount: number;
  description: string | null;
  created_at: string;
};

type Deposit = {
  id: string;
  amount: number;
  payment_method: string;
  status: string;
  reference: string | null;
  created_at: string;
};

type WithdrawalRequest = {
  id: string;
  amount: number;
  withdrawal_method: string;
  destination: string;
  status: string;
  created_at: string;
};

type UserInboxItem = {
  id: string;
  source: string | null;
  type: string;
  sender_name: string | null;
  title: string;
  message: string;
  amount: number | null;
  currency: string | null;
  action_required: boolean;
  action_url: string | null;
  reference: string | null;
  request_status: string | null;
  is_read: boolean;
  read_at: string | null;
  resolved_at: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
};

type Activity = {
  id: string;
  amount: number;
  description: string;
  created_at: string;
  status?: string;
  payment_method?: string;
  reference?: string | null;
  isDeposit?: boolean;
  isWithdrawal?: boolean;
  withdrawalId?: string;
  type: "credit" | "debit";
};

type InvestmentPlan = {
  id: string;
  name: string;
  description: string | null;
  roi_percent: number;
  duration_value: number;
  duration_unit:
    | "minutes"
    | "hours"
    | "days"
    | "weeks"
    | "months";
  min_amount: number;
  max_amount: number;
  active: boolean;
  featured: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
};

function formatMoney(amount: number, currency = "USD") {
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `$${amount.toFixed(2)}`;
  }
}

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function formatDateTime(dateString: string) {
  return new Date(dateString).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatDuration(
  value: number,
  unit: InvestmentPlan["duration_unit"],
) {
  const safeValue = Number(value || 0);

  if (safeValue === 1) {
    if (unit === "minutes") return "1 minute";
    if (unit === "hours") return "1 hour";
    if (unit === "days") return "1 day";
    if (unit === "weeks") return "1 week";
    if (unit === "months") return "1 month";
  }

  return `${safeValue} ${unit}`;
}

function getActivityStyle(activity: Activity) {
  const status = activity.status?.toLowerCase();

  if (activity.isWithdrawal && status === "pending") {
    return {
      text: "text-[#B51F35]",
      background: "bg-[#B51F35]/10",
      icon: "pending",
    };
  }

  if (activity.isWithdrawal && status === "approved") {
    return {
      text: "text-[#B51F35]",
      background: "bg-[#B51F35]/10",
      icon: "debit",
    };
  }

  if (activity.type === "debit") {
    return {
      text: "text-[#B51F35]",
      background: "bg-[#B51F35]/10",
      icon: "debit",
    };
  }

  if (activity.isDeposit && status === "pending") {
    return {
      text: "text-[#B51F35]",
      background: "bg-[#B51F35]/10",
      icon: "pending",
    };
  }

  if (status === "rejected") {
    return {
      text: "text-orange-600",
      background: "bg-orange-50",
      icon: "rejected",
    };
  }

  return {
    text: "text-[#2EAD5B]",
    background: "bg-[#2EAD5B]/10",
    icon: "approved",
  };
}

function getInboxIcon(type: string) {
  const normalized = type.toLowerCase();

  if (normalized.includes("kyc")) return <FiShield size={19} />;
  if (normalized.includes("fee")) return <FiDollarSign size={19} />;
  if (normalized.includes("payment")) return <FiCreditCard size={19} />;
  if (normalized.includes("support")) return <FiMessageCircle size={19} />;
  if (normalized.includes("announcement")) return <FiAlertCircle size={19} />;

  return <FiBell size={19} />;
}

function getInboxTypeLabel(type: string) {
  const normalized = type.toLowerCase();

  if (normalized.includes("kyc")) return "KYC Request";
  if (normalized.includes("fee")) return "Fee Request";
  if (normalized.includes("payment")) return "Payment Request";
  if (normalized.includes("support")) return "Support";
  if (normalized.includes("announcement")) return "Announcement";

  return "Message";
}

function getInboxStyle(type: string) {
  const normalized = type.toLowerCase();

  if (normalized.includes("kyc")) {
    return {
      iconBackground: "bg-[#B51F35]/10",
      iconColor: "text-[#B51F35]",
      badge:
        "border-[#B51F35]/15 bg-[#B51F35]/10 text-[#B51F35]",
    };
  }

  if (normalized.includes("fee")) {
    return {
      iconBackground: "bg-[#B51F35]/10",
      iconColor: "text-[#B51F35]",
      badge:
        "border-[#B51F35]/15 bg-[#B51F35]/10 text-[#B51F35]",
    };
  }

  if (normalized.includes("payment")) {
    return {
      iconBackground: "bg-[#171B26]/10",
      iconColor: "text-[#171B26]",
      badge:
        "border-[#171B26]/15 bg-[#171B26]/5 text-[#171B26]",
    };
  }

  if (normalized.includes("support")) {
    return {
      iconBackground: "bg-[#2EAD5B]/10",
      iconColor: "text-[#2EAD5B]",
      badge:
        "border-[#2EAD5B]/15 bg-[#2EAD5B]/10 text-[#2EAD5B]",
    };
  }

  return {
    iconBackground: "bg-[#171B26]/10",
    iconColor: "text-[#171B26]",
    badge:
      "border-[#171B26]/15 bg-[#171B26]/5 text-[#171B26]",
  };
}

function isKycInboxItem(item: UserInboxItem) {
  const type = item.type?.toLowerCase().trim() || "";
  const title = item.title?.toLowerCase().trim() || "";
  const message = item.message?.toLowerCase() || "";

  // Fee notifications must never be treated as KYC.
  const isFee =
    type === "fee_request" ||
    type === "fee-request" ||
    type === "fee" ||
    type.includes("fee") ||
    title.includes("verification fee") ||
    title.includes("processing fee") ||
    title.includes("service fee") ||
    title.includes("application processing fee") ||
    title.includes("administrative fee") ||
    title.includes("fee request") ||
    message.includes("processing fee") ||
    message.includes("service fee") ||
    message.includes("application processing fee") ||
    message.includes("administrative fee") ||
    message.includes("fee has been requested") ||
    message.includes("fee has been created") ||
    message.includes("fee payment");

  if (isFee) {
    return false;
  }

  return (
    type.includes("kyc") ||
    title.includes("kyc") ||
    title === "verification" ||
    title.includes("identity") ||
    message.includes("government id") ||
    message.includes("selfie verification") ||
    message.includes("verify your identity") ||
    message.includes("identity verification")
  );
}

/*
 * IMPORTANT:
 *
 * A notification is treated as a fee notification only when
 * the notification itself clearly identifies a fee.
 *
 * This prevents ordinary support messages from accidentally
 * displaying the Make payment button.
 */
function isFeeInboxItem(item: UserInboxItem) {
  const type = item.type?.toLowerCase().trim() || "";
  const title = item.title?.toLowerCase().trim() || "";
  const message = item.message?.toLowerCase() || "";

  return (
    type === "fee_request" ||
    type === "fee-request" ||
    type === "fee" ||
    type.includes("fee") ||
    title.includes("verification fee") ||
    title.includes("fee request") ||
    title.includes("processing fee") ||
    title.includes("service fee") ||
    title.includes("application processing fee") ||
    title.includes("administrative fee") ||
    message.includes("verification fee") ||
    message.includes("processing fee") ||
    message.includes("service fee") ||
    message.includes("application processing fee") ||
    message.includes("administrative fee") ||
    message.includes("fee has been requested") ||
    message.includes("fee has been created") ||
    message.includes("fee payment")
  );
}

function isApplicationInformationRequest(item: UserInboxItem) {
  const type = item.type?.toLowerCase().trim() || "";
  const title = item.title?.toLowerCase() || "";
  const message = item.message?.toLowerCase() || "";

  const isFee = isFeeInboxItem(item);
  const isKyc = isKycInboxItem(item);

  if (isFee || isKyc) {
    return false;
  }

  return (
    type.includes("application") ||
    type.includes("grant") ||
    type.includes("loan") ||
    type.includes("review") ||
    title.includes("grant application") ||
    title.includes("loan application") ||
    title.includes("application") ||
    message.includes("information requested") ||
    message.includes("supporting documents") ||
    message.includes("provide the requested information") ||
    message.includes("proof of financial hardship")
  );
}

function isUuid(value: unknown): value is string {
  return (
    typeof value === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      value.trim(),
    )
  );
}

/*
 * Extract the exact fee UUID from structured notification
 * metadata, reference, or an already-created payment URL.
 */
function getFeeIdFromInboxItem(item: UserInboxItem) {
  const metadata = item.metadata;

  if (metadata && typeof metadata === "object") {
    const possibleIdKeys = [
      "fee_id",
      "feeId",
      "admin_fee_id",
      "adminFeeId",
      "fee_request_id",
      "feeRequestId",
      "request_id",
      "requestId",
    ];

    for (const key of possibleIdKeys) {
      const value = metadata[key];

      if (isUuid(value)) {
        return value.trim();
      }
    }

    const possibleUrlKeys = [
      "payment_url",
      "paymentUrl",
      "fee_payment_url",
      "feePaymentUrl",
      "action_url",
      "actionUrl",
    ];

    for (const key of possibleUrlKeys) {
      const value = metadata[key];

      if (typeof value === "string") {
        const urlText: string = value;

        const match = urlText.match(
          /\/fees\/pay\/([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})/i,
        );

        if (match?.[1]) {
          return match[1];
        }
      }
    }
  }

  const referenceValue = item.reference;

  if (typeof referenceValue === "string") {
    const referenceText: string = referenceValue;

    const directReference = referenceText.match(
      /([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})/i,
    );

    if (directReference?.[1]) {
      return directReference[1];
    }
  }

  const actionUrlValue = item.action_url;

  if (typeof actionUrlValue === "string") {
    const actionUrlText: string = actionUrlValue;

    const actionMatch = actionUrlText.match(
      /\/fees\/pay\/([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})/i,
    );

    if (actionMatch?.[1]) {
      return actionMatch[1];
    }
  }

  return null;
}
function isActiveKycRequest(item: UserInboxItem) {
  if (!isKycInboxItem(item)) {
    return false;
  }

  if (!item.action_required) {
    return false;
  }

  if (item.resolved_at) {
    return false;
  }

  const status = item.request_status?.trim().toLowerCase();

  if (
    status === "resolved" ||
    status === "completed" ||
    status === "complete" ||
    status === "removed" ||
    status === "cancelled" ||
    status === "canceled" ||
    status === "rejected" ||
    status === "closed"
  ) {
    return false;
  }

  return true;
}

export default function DashboardPage() {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);

  const [profile, setProfile] = useState<Profile | null>(null);
  const [account, setAccount] = useState<Account | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] =
    useState<WithdrawalRequest[]>([]);
  const [inboxItems, setInboxItems] =
    useState<UserInboxItem[]>([]);
  const [investmentPlans, setInvestmentPlans] =
    useState<InvestmentPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [investmentPlansLoading, setInvestmentPlansLoading] =
    useState(true);
  const [investmentPlansError, setInvestmentPlansError] =
    useState<string | null>(null);

  const [showBalance, setShowBalance] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] =
    useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [investmentOpen, setInvestmentOpen] =
    useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [inboxOpen, setInboxOpen] = useState(false);

  const [selectedInboxItem, setSelectedInboxItem] =
    useState<UserInboxItem | null>(null);

  const [searchText, setSearchText] = useState("");

  const [selectedPlan, setSelectedPlan] =
    useState<InvestmentPlan | null>(null);

  const [investmentAmount, setInvestmentAmount] =
    useState("");
  const [refreshingInbox, setRefreshingInbox] =
    useState(false);
  const [inboxError, setInboxError] =
    useState<string | null>(null);
  const [lightTheme, setLightTheme] = useState(true);
  const [lastUpdated, setLastUpdated] =
    useState<Date | null>(null);

  const inboxSelect =
    "id, source, type, sender_name, title, message, amount, currency, action_required, action_url, reference, request_status, is_read, read_at, resolved_at, metadata, created_at";

  useEffect(() => {
    let active = true;
    let interval: ReturnType<typeof setInterval> | null =
      null;
    let channel: ReturnType<typeof supabase.channel> | null =
      null;

    async function loadInvestmentPlans(
      showPlanLoader = false,
    ) {
      if (showPlanLoader) {
        setInvestmentPlansLoading(true);
      }

      const { data, error } = await supabase
        .from("investment_plans")
        .select(
          "id, name, description, roi_percent, duration_value, duration_unit, min_amount, max_amount, active, featured, display_order, created_at, updated_at",
        )
        .eq("active", true)
        .order("display_order", {
          ascending: true,
        })
        .order("created_at", {
          ascending: true,
        });

      if (!active) return;

      if (error) {
        setInvestmentPlansError(error.message);
        setInvestmentPlansLoading(false);
        return;
      }

      const plans = (data ?? []) as InvestmentPlan[];

      setInvestmentPlans(plans);
      setInvestmentPlansError(null);
      setInvestmentPlansLoading(false);

      setSelectedPlan((current) => {
        if (!plans.length) return null;

        if (
          current &&
          plans.some((plan) => plan.id === current.id)
        ) {
          return (
            plans.find(
              (plan) => plan.id === current.id,
            ) || plans[0]
          );
        }

        return plans[0];
      });
    }

    async function loadDashboard(showLoader = true) {
      if (showLoader) setLoading(true);

      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const authAvatarUrl =
        typeof user.user_metadata?.avatar_url ===
        "string"
          ? user.user_metadata.avatar_url
          : null;

      const [
        { data: profileData },
        { data: accountData },
        { data: transactionData },
        { data: depositData },
        { data: withdrawalData },
        { data: inboxData, error: inboxQueryError },
      ] = await Promise.all([
        supabase
          .from("profiles")
          .select(
            "full_name, phone, account_status, account_type, role, avatar_url",
          )
          .eq("id", user.id)
          .maybeSingle(),

        supabase
          .from("accounts")
          .select("balance, currency")
          .eq("user_id", user.id)
          .maybeSingle(),

        supabase
          .from("transactions")
          .select(
            "id, type, amount, description, created_at",
          )
          .eq("user_id", user.id)
          .order("created_at", {
            ascending: false,
          }),

        supabase
          .from("deposits")
          .select(
            "id, amount, payment_method, status, reference, created_at",
          )
          .eq("user_id", user.id)
          .order("created_at", {
            ascending: false,
          }),

        supabase
          .from("withdrawal_requests")
          .select(
            "id, amount, withdrawal_method, destination, status, created_at",
          )
          .eq("user_id", user.id)
          .neq("status", "rejected")
          .order("created_at", {
            ascending: false,
          }),

        supabase
          .from("user_inbox")
          .select(inboxSelect)
          .eq("user_id", user.id)
          .order("created_at", {
            ascending: false,
          })
          .limit(100),
      ]);

      if (!active) return;

      if (inboxQueryError) {
        setInboxError(inboxQueryError.message);
      } else {
        setInboxError(null);
      }

      const avatarUrl =
        authAvatarUrl ||
        profileData?.avatar_url ||
        null;

      setProfile(
        profileData
          ? {
              ...profileData,
              avatar_url: avatarUrl,
            }
          : {
              full_name:
                user.user_metadata?.full_name ||
                user.user_metadata?.name ||
                null,
              phone: null,
              account_status: null,
              account_type: null,
              role: null,
              avatar_url: avatarUrl,
            },
      );

      setAccount(accountData ?? null);
      setTransactions(transactionData ?? []);
      setDeposits(depositData ?? []);
      setWithdrawalRequests(withdrawalData ?? []);

      setInboxItems(
        ((inboxData ?? []) as UserInboxItem[]).map(
          (item) => ({
            ...item,
            sender_name:
              item.sender_name ||
              "FlashFinance Support Team",
          }),
        ),
      );

      setLastUpdated(new Date());
      setLoading(false);
    }

    async function setup() {
      await Promise.all([
        loadDashboard(true),
        loadInvestmentPlans(true),
      ]);

      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user || !active) return;

      channel = supabase
        .channel(`user-dashboard-${user.id}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "accounts",
            filter: `user_id=eq.${user.id}`,
          },
          async () => loadDashboard(false),
        )
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "transactions",
            filter: `user_id=eq.${user.id}`,
          },
          async () => loadDashboard(false),
        )
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "deposits",
            filter: `user_id=eq.${user.id}`,
          },
          async () => loadDashboard(false),
        )
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "withdrawal_requests",
            filter: `user_id=eq.${user.id}`,
          },
          async () => loadDashboard(false),
        )
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "user_inbox",
            filter: `user_id=eq.${user.id}`,
          },
          async () => loadDashboard(false),
        )
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "investment_plans",
          },
          async () =>
            loadInvestmentPlans(false),
        )
        .subscribe();

      interval = setInterval(() => {
        void loadDashboard(false);
        void loadInvestmentPlans(false);
      }, 15000);
    }

    void setup();

    return () => {
      active = false;

      if (interval) {
        clearInterval(interval);
      }

      if (channel) {
        void supabase.removeChannel(channel);
      }
    };
  }, [router, supabase, inboxSelect]);

  const activities = useMemo<Activity[]>(() => {
    const normalTransactions: Activity[] =
      transactions
        .filter((transaction) => {
          const description =
            transaction.description
              ?.trim()
              .toLowerCase() || "";

          return (
            !description.startsWith(
              "deposit approved",
            ) &&
            !description.startsWith("withdrawal")
          );
        })
        .map(
          (transaction): Activity => ({
            id: `transaction-${transaction.id}`,
            amount: Number(transaction.amount || 0),
            description:
              transaction.description ||
              "Transaction",
            created_at:
              transaction.created_at,
            type:
              transaction.type?.toLowerCase() ===
              "credit"
                ? "credit"
                : "debit",
          }),
        );

    const depositActivities: Activity[] =
      deposits
        .filter(
          (deposit) =>
            deposit.status?.toLowerCase() !==
            "rejected",
        )
        .map(
          (deposit): Activity => ({
            id: `deposit-${deposit.id}`,
            amount: Number(deposit.amount || 0),
            description: `${
              deposit.payment_method ||
              "Deposit"
            } deposit`,
            created_at:
              deposit.created_at,
            status: deposit.status,
            payment_method:
              deposit.payment_method,
            reference:
              deposit.reference,
            isDeposit: true,
            type: "credit",
          }),
        );

    const withdrawalActivities: Activity[] =
      withdrawalRequests.map(
        (
          withdrawal,
        ): Activity => ({
          id: `withdrawal-${withdrawal.id}`,
          amount: Number(
            withdrawal.amount || 0,
          ),
          description: `${withdrawal.withdrawal_method} withdrawal`,
          created_at:
            withdrawal.created_at,
          status: withdrawal.status,
          payment_method:
            withdrawal.withdrawal_method,
          isWithdrawal: true,
          type: "debit",
          withdrawalId: withdrawal.id,
        }),
      );

    return [
      ...depositActivities,
      ...withdrawalActivities,
      ...normalTransactions,
    ].sort(
      (a, b) =>
        new Date(b.created_at).getTime() -
        new Date(a.created_at).getTime(),
    );
  }, [
    transactions,
    deposits,
    withdrawalRequests,
  ]);

  const filteredActivities = useMemo(() => {
    const search = searchText
      .trim()
      .toLowerCase();

    if (!search) return activities;

    return activities.filter((activity) =>
      [
        activity.description,
        activity.status,
        activity.payment_method,
        activity.reference,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase()
        .includes(search),
    );
  }, [activities, searchText]);

  const unreadInboxCount = useMemo(
    () =>
      inboxItems.filter(
        (item) => !item.is_read,
      ).length,
    [inboxItems],
  );

  const activeKycRequests = useMemo(
    () =>
      inboxItems
        .filter((item) =>
          isActiveKycRequest(item),
        )
        .sort(
          (a, b) =>
            new Date(b.created_at).getTime() -
            new Date(a.created_at).getTime(),
        ),
    [inboxItems],
  );

  const latestKycRequest =
    activeKycRequests[0] || null;

  const balance = Number(
    account?.balance || 0,
  );

  const currency =
    account?.currency || "USD";

  const numericInvestmentAmount =
    Number(investmentAmount || 0);

  const estimatedProfit =
    selectedPlan &&
    numericInvestmentAmount > 0
      ? numericInvestmentAmount *
        (Number(
          selectedPlan.roi_percent || 0,
        ) / 100)
      : 0;

  const estimatedTotal =
    numericInvestmentAmount +
    estimatedProfit;

  const avatarUrl =
    profile?.avatar_url || null;

  const profileInitial = (
    profile?.full_name?.charAt(0) || "U"
  ).toUpperCase();

  const greeting = (() => {
    const hour = new Date().getHours();

    if (hour < 12) return "Good Morning";
    if (hour < 18) return "Good Afternoon";

    return "Good Evening";
  })();

  function openPage(path: string) {
    setMoreOpen(false);
    setMobileMenuOpen(false);
    router.push(path);
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
  }

  function openKycVerification(
    _item?: UserInboxItem | null,
  ) {
    setInboxOpen(false);
    setSelectedInboxItem(null);
    router.push("/kyc");
  }

  async function refreshInbox() {
    setRefreshingInbox(true);
    setInboxError(null);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setRefreshingInbox(false);
      router.push("/login");
      return;
    }

    const { data, error } =
      await supabase
        .from("user_inbox")
        .select(inboxSelect)
        .eq("user_id", user.id)
        .order("created_at", {
          ascending: false,
        })
        .limit(100);

    if (error) {
      setInboxError(error.message);
    } else {
      setInboxItems(
        ((data ?? []) as UserInboxItem[]).map(
          (item) => ({
            ...item,
            sender_name:
              item.sender_name ||
              "FlashFinance Support Team",
          }),
        ),
      );
    }

    setRefreshingInbox(false);
  }

  async function markInboxRead(id: string) {
    const previousItems = inboxItems;

    setInboxItems((current) =>
      current.map((item) =>
        item.id === id
          ? {
              ...item,
              is_read: true,
              read_at:
                item.read_at ||
                new Date().toISOString(),
            }
          : item,
      ),
    );

    const { error } =
      await supabase.rpc(
        "user_mark_inbox_read",
        {
          p_inbox_id: id,
        },
      );

    if (error) {
      setInboxItems(previousItems);
      setInboxError(error.message);
    }
  }

  async function markAllInboxRead() {
    const previousItems = inboxItems;

    setInboxItems((current) =>
      current.map((item) => ({
        ...item,
        is_read: true,
        read_at:
          item.read_at ||
          new Date().toISOString(),
      })),
    );

    const { error } =
      await supabase.rpc(
        "user_mark_all_inbox_read",
      );

    if (error) {
      setInboxItems(previousItems);
      setInboxError(error.message);
    }
  }

  async function openInboxItem(
    item: UserInboxItem,
  ) {
    setSelectedInboxItem(item);

    if (!item.is_read) {
      await markInboxRead(item.id);
    }
  }

  /*
   * FEE PAYMENT
   *
   * This function NEVER marks a fee as paid.
   *
   * It only finds the exact fee request and sends the
   * customer to:
   *
   * /fees/pay/{fee-id}
   *
   * The actual payment page is responsible for recording
   * the payment and updating the fee's paid/remaining amount.
   */
  async function openFeePayment(
    item: UserInboxItem,
  ) {
    setInboxError(null);

    let feeId = getFeeIdFromInboxItem(item);

    /*
     * If the notification already contains the exact
     * payment URL, use it directly.
     *
     * This avoids sending the customer to /dashboard
     * or the generic payments page.
     */
    const metadata = item.metadata;

    if (!feeId && metadata) {
      const possibleUrls = [
        metadata.payment_url,
        metadata.paymentUrl,
        metadata.fee_payment_url,
        metadata.feePaymentUrl,
        metadata.action_url,
        metadata.actionUrl,
      ];

      for (const value of possibleUrls) {
        if (
          typeof value === "string" &&
          value.includes("/fees/pay/")
        ) {
          const match = value.match(
            /\/fees\/pay\/([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})/i,
          );

          if (match?.[1]) {
            feeId = match[1];
            break;
          }
        }
      }
    }

    /*
     * Older notifications may not have stored fee_id.
     *
     * In that case we try to resolve the exact fee from
     * the customer's own fee requests.
     */
    if (!feeId) {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        setInboxOpen(false);
        setSelectedInboxItem(null);
        router.push("/login");
        return;
      }

      const {
        data: feeRows,
        error: feeQueryError,
      } = await supabase
        .from("admin_fee_requests")
        .select(
          "id, user_id, amount, fee_type, title, message, status, created_at, updated_at",
        )
        .eq("user_id", user.id)
        .order("created_at", {
          ascending: false,
        })
        .limit(50);

      if (feeQueryError) {
        setInboxError(
          "This fee request could not be linked to its payment page. Please refresh your notifications or contact FlashFinance Support.",
        );
        return;
      }

      if (feeRows && feeRows.length > 0) {
        const notificationAmount =
          item.amount === null
            ? null
            : Number(item.amount);

        const notificationTitle =
          item.title?.trim().toLowerCase() || "";

        const notificationMessage =
          item.message?.trim().toLowerCase() || "";

        const usableRows = feeRows.filter(
          (fee) => {
            const status =
              String(
                fee.status || "",
              ).toLowerCase();

            return ![
              "paid",
              "cancelled",
              "canceled",
              "rejected",
              "closed",
            ].includes(status);
          },
        );

        /*
         * First try the strongest possible match:
         * amount + title + message.
         */
        const exactMatch =
          usableRows.find((fee) => {
            const sameAmount =
              notificationAmount === null ||
              Number(fee.amount) ===
                notificationAmount;

            const sameTitle =
              !notificationTitle ||
              String(
                fee.title || "",
              )
                .trim()
                .toLowerCase() ===
                notificationTitle;

            const sameMessage =
              !notificationMessage ||
              String(
                fee.message || "",
              )
                .trim()
                .toLowerCase() ===
                notificationMessage;

            return (
              sameAmount &&
              sameTitle &&
              sameMessage
            );
          });

        /*
         * Then amount-only match.
         */
        const amountMatch =
          usableRows.find((fee) => {
            if (
              notificationAmount === null
            ) {
              return false;
            }

            return (
              Number(fee.amount) ===
              notificationAmount
            );
          });

        /*
         * Final legacy fallback is the newest
         * unpaid fee belonging to this user.
         */
        const selectedFee =
          exactMatch ||
          amountMatch ||
          usableRows[0] ||
          null;

        if (selectedFee?.id) {
          feeId = String(selectedFee.id);
        }
      }
    }

    if (!feeId) {
      setInboxError(
        "This fee request could not be linked to its payment page. Please refresh your notifications or contact FlashFinance Support.",
      );
      return;
    }

    setInboxOpen(false);
    setSelectedInboxItem(null);

    /*
     * Only navigation happens here.
     * Nothing is marked paid by clicking this button.
     */
    router.push(
      `/fees/pay/${encodeURIComponent(feeId)}`,
    );
  }

  function handleInboxAction(
    item: UserInboxItem,
  ) {
    /*
     * KYC notifications always go to the KYC page.
     */
    if (isActiveKycRequest(item)) {
      openKycVerification(item);
      return;
    }

    /*
     * Fee notifications always use Make payment.
     */
    if (isFeeInboxItem(item)) {
      void openFeePayment(item);
      return;
    }

    /*
     * All other notifications use their own
     * action_url.
     */
    if (!item.action_url) return;

    setInboxOpen(false);
    setSelectedInboxItem(null);
    router.push(item.action_url);
  }

  function openSupportTicket() {
    setInboxOpen(false);
    setSelectedInboxItem(null);
    router.push("/support");
  }

  function renderActivityIcon(
    activity: Activity,
  ) {
    const style =
      getActivityStyle(activity);

    if (style.icon === "pending") {
      return (
        <FiClock
          size={18}
          className="text-[#B51F35]"
        />
      );
    }

    if (style.icon === "debit") {
      return (
        <FiArrowUpRight
          size={18}
          className="text-[#B51F35]"
        />
      );
    }

    if (style.icon === "rejected") {
      return (
        <FiAlertTriangle
          size={18}
          className="text-orange-500"
        />
      );
    }

    return (
      <FiArrowDownLeft
        size={18}
        className="text-[#2EAD5B]"
      />
    );
  }

  if (loading) {
    return (
      <main className="min-h-screen !bg-[#F1F3F6] font-sans !text-[#111318]">
        <div className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="h-9 w-40 animate-pulse rounded-xl bg-white/80" />
            <div className="h-11 w-11 animate-pulse rounded-full bg-white/80" />
          </div>
          <div className="mt-10 max-w-2xl">
            <div className="h-4 w-28 animate-pulse rounded bg-white/80" />
            <div className="mt-4 h-10 w-72 animate-pulse rounded-xl bg-white/80 sm:w-96" />
            <div className="mt-3 h-4 w-full max-w-md animate-pulse rounded bg-white/70" />
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-[1.4fr_1fr]">
            <div className="h-52 animate-pulse rounded-[1.75rem] bg-[#294b6d]/15" />
            <div className="h-52 animate-pulse rounded-[1.75rem] bg-white/80" />
          </div>
        </div>
      </main>
    );
  }

  const dark = !lightTheme;

  const shell = dark
    ? "!bg-[#0D101A] text-white"
    : "!bg-[#F8F9FB] !text-[#111318]";

  const mutedText = dark
    ? "text-white/35"
    : "!text-[#9298A3]";

  return (
    <main
      className={`min-h-screen font-sans ${shell}`}
    >
      <div className="min-h-screen">

        {/* Desktop sidebar */}
        <aside
          className={`fixed inset-y-0 left-0 z-50 hidden w-64 flex-col border-r lg:flex ${
            dark
              ? "border-white/10 bg-[#0A0D15]"
              : "border-[#E2E5E9] bg-white"
          }`}
        >
          <div
            className={`border-b p-6 ${
              dark
                ? "border-white/10"
                : "border-[#E2E5E9]"
            }`}
          >
            <button
              type="button"
              onClick={() =>
                openPage("/dashboard")
              }
              className="flex w-full items-center gap-3 text-left"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#B51F35] text-white shadow-lg shadow-[#B51F35]/20">
                <FiZap size={21} />
              </div>

              <div>
                <div className="text-lg font-extrabold tracking-tight">
                  <span>FLASH</span>
                  <span className="text-[#B51F35]">
                    FINANCE
                  </span>
                </div>

                <div
                  className={`mt-0.5 text-[9px] uppercase tracking-[0.18em] ${mutedText}`}
                >
                  Premium banking
                </div>
              </div>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-6">
            <p
              className={`mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.18em] ${mutedText}`}
            >
              Main
            </p>

            <div className="space-y-1.5">
              <SidebarItem
                active
                icon={<FiHome size={18} />}
                label="Home"
                onClick={() =>
                  openPage("/dashboard")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiSend size={18} />}
                label="Transfer"
                onClick={() =>
                  openPage("/transfer")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiCreditCard size={18} />}
                label="Cards"
                onClick={() =>
                  openPage("/cards")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiActivity size={18} />}
                label="Activity"
                onClick={() =>
                  setHistoryOpen(true)
                }
                dark={dark}
              />
            </div>

            <p
              className={`mb-3 mt-8 px-3 text-[10px] font-bold uppercase tracking-[0.18em] ${mutedText}`}
            >
              Manage
            </p>

            <div className="space-y-1.5">
              <SidebarItem
                icon={<FiPlus size={18} />}
                label="Deposit"
                onClick={() =>
                  openPage("/deposit")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiTrendingUp size={18} />}
                label="Investments"
                onClick={() =>
                  openPage("/investments")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiDollarSign size={18} />}
                label="Savings"
                onClick={() =>
                  openPage("/savings")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiBriefcase size={18} />}
                label="Loans"
                onClick={() =>
                  openPage("/loans")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiGift size={18} />}
                label="Grants"
                onClick={() =>
                  openPage("/grants")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiZap size={18} />}
                label="Payments"
                onClick={() =>
                  openPage("/payments")
                }
                dark={dark}
              />

              <SidebarItem
                icon={<FiUser size={18} />}
                label="Profile"
                onClick={() =>
                  openPage("/profile")
                }
                dark={dark}
              />
            </div>
          </div>

          <div
            className={`border-t p-4 ${
              dark
                ? "border-white/10"
                : "border-[#E2E5E9]"
            }`}
          >
            <button
              type="button"
              onClick={handleLogout}
              className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition ${
                dark
                  ? "text-white/55 hover:bg-white/5 hover:text-white"
                  : "text-[#69707D] hover:bg-[#F1F3F6] hover:text-[#111318]"
              }`}
            >
              <FiLogOut size={18} />
              Logout
            </button>
          </div>
        </aside>

        {/* Main */}
        <div className="lg:pl-64">

          {/* Header */}
          <header
            className={`sticky top-0 z-40 border-b backdrop-blur-xl ${
              dark
                ? "border-white/10 bg-[#0D101A]/90"
                : "border-[#E2E5E9] bg-[#F8F9FB]/95"
            }`}
          >
            <div className="flex items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
              <div className="flex min-w-0 items-center gap-3">

                <button
                  type="button"
                  onClick={() =>
                    setMobileMenuOpen(
                      (value) => !value,
                    )
                  }
                  className={`flex h-11 w-11 items-center justify-center rounded-full border lg:hidden ${
                    dark
                      ? "border-white/10 bg-[#242936]"
                      : "border-[#E2E5E9] bg-white !text-[#111318]"
                  }`}
                >
                  {mobileMenuOpen ? (
                    <FiX size={19} />
                  ) : (
                    <FiMenu size={19} />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() =>
                    openPage("/profile")
                  }
                  className="flex items-center gap-3 text-left"
                >
                  <div
                    className={`flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full ring-1 ${
                      dark
                        ? "bg-[#F1F5FF] text-[#6D89B5] ring-white/10"
                        : "bg-[#F1F5FF] text-[#6D89B5] ring-[#E2E5E9]"
                    }`}
                  >
                    {avatarUrl ? (
                      <img
                        src={avatarUrl}
                        alt={
                          profile?.full_name ||
                          "Profile"
                        }
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <span className="font-semibold">
                        {profileInitial}
                      </span>
                    )}
                  </div>

                  <div className="hidden min-w-0 sm:block">
                    <p
                      className={`text-sm ${
                        dark
                          ? "text-white/60"
                          : "!text-[#69707D]"
                      }`}
                    >
                      {greeting}
                    </p>

                    <p className="truncate text-[18px] font-semibold">
                      {profile?.full_name ||
                        "User"}
                    </p>
                  </div>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setLightTheme(
                      (value) => !value,
                    )
                  }
                  aria-label="Toggle theme"
                  className={`flex h-11 w-11 items-center justify-center rounded-full transition ${
                    dark
                      ? "bg-[#242936] text-white/75 hover:bg-[#292D38]"
                      : "bg-white !text-[#69707D] shadow-sm ring-1 ring-[#E2E5E9]"
                  }`}
                >
                  <FiMoon size={19} />
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setInboxOpen(true)
                  }
                  aria-label="Open notifications"
                  className={`relative flex h-11 w-11 items-center justify-center rounded-full transition ${
                    dark
                      ? "bg-[#242936] text-white/75 hover:bg-[#292D38]"
                      : "bg-white !text-[#69707D] shadow-sm ring-1 ring-[#E2E5E9]"
                  }`}
                >
                  <FiBell size={19} />

                  {unreadInboxCount > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-[#B51F35] px-1 text-[8px] font-black text-white">
                      {unreadInboxCount > 9
                        ? "9+"
                        : unreadInboxCount}
                    </span>
                  )}
                </button>
              </div>
            </div>

            {mobileMenuOpen && (
              <div
                className={`border-t p-4 lg:hidden ${
                  dark
                    ? "border-white/10 bg-[#0A0D15]"
                    : "border-[#E2E5E9] bg-white"
                }`}
              >
                <div className="grid grid-cols-2 gap-2">
                  <MobileMenuItem
                    label="Home"
                    icon={<FiHome />}
                    onClick={() =>
                      openPage("/dashboard")
                    }
                  />

                  <MobileMenuItem
                    label="Transfer"
                    icon={<FiSend />}
                    onClick={() =>
                      openPage("/transfer")
                    }
                  />

                  <MobileMenuItem
                    label="Deposit"
                    icon={<FiPlus />}
                    onClick={() =>
                      openPage("/deposit")
                    }
                  />

                  <MobileMenuItem
                    label="Invest"
                    icon={<FiTrendingUp />}
                    onClick={() =>
                      openPage("/investments")
                    }
                  />

                  <MobileMenuItem
                    label="Cards"
                    icon={<FiCreditCard />}
                    onClick={() =>
                      openPage("/cards")
                    }
                  />

                  <MobileMenuItem
                    label="Grants"
                    icon={<FiGift />}
                    onClick={() =>
                      openPage("/grants")
                    }
                  />

                  <MobileMenuItem
                    label="Payments"
                    icon={<FiZap />}
                    onClick={() =>
                      openPage("/payments")
                    }
                  />

                  <MobileMenuItem
                    label="Profile"
                    icon={<FiUser />}
                    onClick={() =>
                      openPage("/profile")
                    }
                  />
                </div>
              </div>
            )}
          </header>

          {/* Hero + balance + primary actions */}
          <section
            className={`${
              dark
                ? "bg-[#0D101A]"
                : "bg-[#F8F9FB]"
            } px-4 pb-8 pt-6 sm:px-6 lg:px-8 lg:pb-10 lg:pt-8`}
          >
            <div className="mx-auto max-w-6xl">

              {/* KYC */}
              {latestKycRequest && (
                <section
                  className={`mb-6 overflow-hidden rounded-3xl border p-5 ${
                    dark
                      ? "border-[#B51F35]/25 bg-[#171B26]"
                      : "border-[#B51F35]/15 bg-white"
                  }`}
                >
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start gap-4">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#B51F35]/10 text-[#B51F35]">
                        <FiShield size={22} />
                      </div>

                      <div>
                        <span className="inline-flex rounded-full border border-[#B51F35]/15 bg-[#B51F35]/10 px-2.5 py-1 text-[9px] font-black uppercase tracking-wider text-[#B51F35]">
                          Identity Verification
                        </span>

                        <h2 className="mt-2 text-lg font-bold">
                          {latestKycRequest.title ||
                            "Complete your identity verification"}
                        </h2>

                        <p
                          className={`mt-1 max-w-2xl text-sm leading-6 ${
                            dark
                              ? "text-white/55"
                              : "!text-[#69707D]"
                          }`}
                        >
                          {latestKycRequest.message ||
                            "Please complete your identity verification."}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        openKycVerification(
                          latestKycRequest,
                        )
                      }
                      className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-[#B51F35] px-5 py-3 text-sm font-semibold text-white transition active:scale-[0.98] hover:bg-[#991B30]"
                    >
                      Complete KYC
                      <FiChevronRight size={16} />
                    </button>
                  </div>
                </section>
              )}

              {/* Account card */}
              <section className="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-[#B51F35] via-[#C9213A] to-[#991B30] p-6 shadow-2xl shadow-[#B51F35]/20 sm:p-8 lg:min-h-[250px]">
                <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-white/10" />

                <div className="pointer-events-none absolute -bottom-36 left-10 h-64 w-64 rounded-full bg-black/10" />

                <div className="pointer-events-none absolute bottom-6 right-10 h-24 w-24 rounded-full bg-black/5" />

                <div className="relative flex h-full flex-col justify-between gap-10">

                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-sm font-semibold tracking-[0.08em] text-white/90">
                        FLASHFINANCE
                      </p>

                      <p className="mt-1 text-sm text-white/70">
                        {profile?.full_name ||
                          "Account holder"}
                      </p>
                    </div>

                    <div className="text-right">
                      <p className="text-sm text-white/70">
                        {profile?.account_type ||
                          "Checking Account"}
                      </p>

                      <p className="mt-1 text-sm font-medium text-white">
                        â€¢â€¢â€¢â€¢ 9863
                      </p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-white/75">
                      Available Balance
                    </p>

                    <div className="mt-2 flex items-center gap-3">
                      <h1 className="text-[40px] font-bold leading-none tracking-tight text-white sm:text-[44px]">
                        {showBalance
                          ? formatMoney(
                              balance,
                              currency,
                            )
                          : "â€¢â€¢â€¢â€¢â€¢â€¢â€¢â€¢"}
                      </h1>

                      <button
                        type="button"
                        onClick={() =>
                          setShowBalance(
                            (value) => !value,
                          )
                        }
                        aria-label={
                          showBalance
                            ? "Hide balance"
                            : "Show balance"
                        }
                        className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white/80 transition hover:bg-white/15 active:scale-[0.97]"
                      >
                        {showBalance ? (
                          <FiEyeOff size={19} />
                        ) : (
                          <FiEye size={19} />
                        )}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-4 text-sm">
                    <span className="inline-flex items-center gap-2 text-white/90">
                      <span className="h-2 w-2 rounded-full bg-[#3ED66B]" />

                      {profile?.account_status
                        ? profile.account_status
                            .charAt(0)
                            .toUpperCase() +
                          profile.account_status.slice(1)
                        : "Active"}
                    </span>

                    <span className="text-right text-white/60">
                      Last updated:{" "}
                      {lastUpdated
                        ? lastUpdated.toLocaleString(
                            "en-US",
                            {
                              month: "short",
                              day: "numeric",
                              year: "numeric",
                              hour: "numeric",
                              minute: "2-digit",
                            },
                          )
                        : "Just now"}
                    </span>
                  </div>
                </div>
              </section>

              {/* MAIN ACTIONS */}
              <section className="mt-7 grid grid-cols-4 gap-3 sm:gap-5">

                <QuickAction
                  icon={<FiPlus size={23} />}
                  label="Deposit"
                  primary
                  onClick={() =>
                    openPage("/deposit")
                  }
                  dark={dark}
                />

                <QuickAction
                  icon={<FiSend size={23} />}
                  label="Send"
                  onClick={() =>
                    openPage("/transfer")
                  }
                  dark={dark}
                />

                <QuickAction
                  icon={<FiTrendingUp size={23} />}
                  label="Invest"
                  onClick={() =>
                    openPage("/investments")
                  }
                  dark={dark}
                />

                <div className="relative">
                  <QuickAction
                    icon={<FiGrid size={22} />}
                    label="More"
                    onClick={() =>
                      setMoreOpen(
                        (value) => !value,
                      )
                    }
                    dark={dark}
                  />

                  {moreOpen && (
                    <div
                      className={`absolute right-0 top-full z-30 mt-3 w-60 overflow-hidden rounded-2xl border p-2 shadow-2xl ${
                        dark
                          ? "border-white/10 bg-[#171B26]"
                          : "border-[#E2E5E9] bg-white"
                      }`}
                    >
                      <MoreItem
                        icon={<FiArrowUpRight />}
                        label="Withdraw"
                        onClick={() =>
                          openPage("/withdraw")
                        }
                        dark={dark}
                      />

                      <MoreItem
                        icon={<FiSmartphone />}
                        label="Bills & Airtime"
                        onClick={() =>
                          openPage("/payments")
                        }
                        dark={dark}
                      />

                      <MoreItem
                        icon={<FiGift />}
                        label="Grants"
                        onClick={() =>
                          openPage("/grants")
                        }
                        dark={dark}
                      />

                      <MoreItem
                        icon={<FiBriefcase />}
                        label="Loans"
                        onClick={() =>
                          openPage("/loans")
                        }
                        dark={dark}
                      />

                      <MoreItem
                        icon={<FiDollarSign />}
                        label="Savings"
                        onClick={() =>
                          openPage("/savings")
                        }
                        dark={dark}
                      />

                      <MoreItem
                        icon={<FiShield />}
                        label="KYC"
                        onClick={() =>
                          openPage("/kyc")
                        }
                        dark={dark}
                      />

                      <MoreItem
                        icon={<FiUser />}
                        label="Profile"
                        onClick={() =>
                          openPage("/profile")
                        }
                        dark={dark}
                      />
                    </div>
                  )}
                </div>
              </section>
            </div>
          </section>

          {/* SECONDARY DASHBOARD CONTENT */}
          <section className="!bg-[#F8F9FB] px-4 pb-32 pt-8 !text-[#111318] sm:px-6 lg:px-8">
            <div className="mx-auto max-w-6xl">

              {/* SERVICES */}
              <section>
                <div className="mb-4">
                  <p className="text-[11px] font-bold uppercase tracking-[0.16em] !text-[#9298A3]">
                    Services
                  </p>

                  <h2 className="mt-1 text-xl font-bold !text-[#111318]">
                    Everyday money tools
                  </h2>
                </div>

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <ServiceCard
                    icon={<FiSend size={21} />}
                    title="Send"
                    description="Send money"
                    onClick={() =>
                      openPage("/transfer")
                    }
                  />

                  <ServiceCard
                    icon={<FiArrowUpRight size={21} />}
                    title="Withdraw"
                    description="Withdraw money"
                    onClick={() =>
                      openPage("/withdraw")
                    }
                  />

                  <ServiceCard
                    icon={<FiZap size={21} />}
                    title="Electricity"
                    description="Pay bills"
                    onClick={() =>
                      openPage("/payments/bills")
                    }
                  />

                  <ServiceCard
                    icon={<FiSmartphone size={21} />}
                    title="Airtime & Data"
                    description="Recharge and data"
                    onClick={() =>
                      openPage("/payments")
                    }
                  />
                </div>
              </section>

              {/* GRANTS */}
              <section className="relative mt-6 overflow-hidden rounded-[28px] bg-gradient-to-br from-[#B51F35] to-[#991B30] p-6 text-white shadow-[0_12px_40px_rgba(181,31,53,0.18)] sm:p-7">
                <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full bg-white/10" />

                <div className="pointer-events-none absolute -bottom-28 -left-10 h-48 w-48 rounded-full bg-black/10" />

                <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
                  <div className="max-w-2xl">
                    <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10">
                      <FiGift size={23} />
                    </div>

                    <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/55">
                      Financial assistance
                    </p>

                    <h2 className="mt-2 text-2xl font-bold tracking-tight">
                      Financial help when life becomes difficult.
                    </h2>

                    <p className="mt-3 text-sm leading-6 text-white/70">
                      Explore the FlashFinance Financial Assistance Grant Program and learn about eligibility, applications, and available support.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      openPage("/grants")
                    }
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-white px-6 py-3.5 text-sm font-bold text-[#B51F35] transition hover:bg-white/90 active:scale-[0.98]"
                  >
                    <FiGift size={17} />
                    Explore Grants
                    <FiChevronRight size={16} />
                  </button>
                </div>
              </section>

              {/* INVESTMENT CENTER */}
              <section className="mt-6 overflow-hidden rounded-[28px] bg-white shadow-[0_4px_20px_rgba(0,0,0,0.06)] ring-1 ring-[#E2E5E9]">
                <button
                  type="button"
                  onClick={() =>
                    setInvestmentOpen(
                      (value) => !value,
                    )
                  }
                  className="flex w-full items-center justify-between gap-4 p-6 text-left sm:p-7"
                >
                  <div>
                    <p className="text-[11px] font-bold uppercase tracking-[0.16em] !text-[#9298A3]">
                      Investment Center
                    </p>

                    <h2 className="mt-1 text-xl font-bold !text-[#111318]">
                      Choose an investment plan
                    </h2>

                    <p className="mt-1 text-sm !text-[#69707D]">
                      Choose a plan and calculate your potential return.
                    </p>
                  </div>

                  <FiChevronDown
                    size={19}
                    className={`!text-[#69707D] transition-transform ${
                      investmentOpen
                        ? "rotate-180"
                        : ""
                    }`}
                  />
                </button>

                {investmentOpen && (
                  <div className="border-t border-[#E2E5E9] p-6 sm:p-7">

                    {investmentPlansLoading ? (
                      <div className="rounded-2xl bg-[#F8F9FB] p-8 text-center ring-1 ring-[#E2E5E9]">
                        <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-[#B51F35] border-t-transparent" />

                        <p className="mt-3 text-sm !text-[#69707D]">
                          Loading investment plans...
                        </p>
                      </div>
                    ) : investmentPlansError ? (
                      <div className="rounded-2xl border border-[#B51F35]/15 bg-[#B51F35]/5 p-5">
                        <div className="flex items-start gap-3">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                            <FiAlertCircle size={19} />
                          </div>

                          <div>
                            <p className="font-bold !text-[#111318]">
                              Investment plans could not be loaded
                            </p>

                            <p className="mt-1 text-xs leading-5 !text-[#69707D]">
                              Please try again in a moment. The investment plans are controlled by FlashFinance administration.
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : investmentPlans.length === 0 ? (
                      <div className="rounded-2xl bg-[#F8F9FB] p-8 text-center ring-1 ring-[#E2E5E9]">
                        <FiTrendingUp
                          size={27}
                          className="mx-auto text-[#9298A3]"
                        />

                        <p className="mt-3 text-sm font-semibold !text-[#111318]">
                          No investment plans are currently available
                        </p>

                        <p className="mt-1 text-xs !text-[#9298A3]">
                          Please check again later.
                        </p>
                      </div>
                    ) : (
                      <>
                        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                          {investmentPlans.map(
                            (plan) => {
                              const selected =
                                selectedPlan?.id ===
                                plan.id;

                              return (
                                <button
                                  key={plan.id}
                                  type="button"
                                  onClick={() => {
                                    setSelectedPlan(
                                      plan,
                                    );
                                    setInvestmentAmount(
                                      "",
                                    );
                                  }}
                                  className={`rounded-2xl border p-5 text-left transition active:scale-[0.99] ${
                                    selected
                                      ? "border-[#B51F35] bg-[#B51F35]/5"
                                      : "border-[#E2E5E9] bg-[#F8F9FB] hover:border-[#B51F35]/30"
                                  }`}
                                >
                                  <div className="flex items-start justify-between gap-2">
                                    <div className="min-w-0">
                                      <p className="truncate text-base font-bold !text-[#111318]">
                                        {plan.name}
                                      </p>

                                      <p className="mt-1 text-xs !text-[#9298A3]">
                                        {formatDuration(
                                          plan.duration_value,
                                          plan.duration_unit,
                                        )}
                                      </p>
                                    </div>

                                    {plan.featured && (
                                      <span className="shrink-0 rounded-full bg-[#B51F35] px-2 py-1 text-[9px] font-black text-white">
                                        FEATURED
                                      </span>
                                    )}
                                  </div>

                                  {plan.description && (
                                    <p className="mt-3 line-clamp-2 text-xs leading-5 !text-[#69707D]">
                                      {
                                        plan.description
                                      }
                                    </p>
                                  )}

                                  <p className="mt-5 text-2xl font-bold text-[#B51F35]">
                                    {Number(
                                      plan.roi_percent ||
                                        0,
                                    ).toLocaleString(
                                      "en-US",
                                      {
                                        maximumFractionDigits: 4,
                                      },
                                    )}
                                    %
                                  </p>

                                  <p className="mt-1 text-xs !text-[#9298A3]">
                                    ROI
                                  </p>

                                  <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                                    <div className="rounded-xl bg-white p-3 ring-1 ring-[#E2E5E9]">
                                      <p className="!text-[#9298A3]">
                                        Minimum
                                      </p>

                                      <p className="mt-1 font-semibold !text-[#111318]">
                                        {formatMoney(
                                          Number(
                                            plan.min_amount ||
                                              0,
                                          ),
                                          currency,
                                        )}
                                      </p>
                                    </div>

                                    <div className="rounded-xl bg-white p-3 ring-1 ring-[#E2E5E9]">
                                      <p className="!text-[#9298A3]">
                                        Maximum
                                      </p>

                                      <p className="mt-1 font-semibold !text-[#111318]">
                                        {formatMoney(
                                          Number(
                                            plan.max_amount ||
                                              0,
                                          ),
                                          currency,
                                        )}
                                      </p>
                                    </div>
                                  </div>
                                </button>
                              );
                            },
                          )}
                        </div>

                        {selectedPlan && (
                          <div className="mt-5 rounded-2xl bg-[#F8F9FB] p-5 ring-1 ring-[#E2E5E9]">
                            <div className="flex items-center gap-3">
                              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                                <FiDollarSign size={18} />
                              </div>

                              <div>
                                <p className="font-bold !text-[#111318]">
                                  Investment Calculator
                                </p>

                                <p className="text-xs !text-[#9298A3]">
                                  Selected plan:{" "}
                                  {
                                    selectedPlan.name
                                  }
                                </p>
                              </div>
                            </div>

                            <div className="mt-5 grid gap-4 md:grid-cols-3">
                              <div>
                                <label
                                  htmlFor="investmentAmount"
                                  className="mb-2 block text-xs font-semibold !text-[#69707D]"
                                >
                                  Investment amount
                                </label>

                                <div className="flex items-center rounded-xl bg-white px-4 ring-1 ring-[#E2E5E9]">
                                  <span className="mr-2 !text-[#9298A3]">
                                    $
                                  </span>

                                  <input
                                    id="investmentAmount"
                                    type="number"
                                    min={
                                      selectedPlan.min_amount
                                    }
                                    max={
                                      selectedPlan.max_amount
                                    }
                                    step="0.01"
                                    value={
                                      investmentAmount
                                    }
                                    onChange={(
                                      event,
                                    ) =>
                                      setInvestmentAmount(
                                        event.target
                                          .value,
                                      )
                                    }
                                    placeholder={`${selectedPlan.min_amount}`}
                                    className="w-full bg-transparent py-3 text-sm font-semibold !text-[#111318] outline-none placeholder:!text-[#C4C8D0]"
                                  />
                                </div>

                                <p className="mt-2 text-[10px] !text-[#9298A3]">
                                  Range:{" "}
                                  {formatMoney(
                                    Number(
                                      selectedPlan.min_amount ||
                                        0,
                                    ),
                                    currency,
                                  )}{" "}
                                  to{" "}
                                  {formatMoney(
                                    Number(
                                      selectedPlan.max_amount ||
                                        0,
                                    ),
                                    currency,
                                  )}
                                </p>
                              </div>

                              <div className="rounded-xl bg-white p-4 ring-1 ring-[#E2E5E9]">
                                <p className="text-xs !text-[#9298A3]">
                                  Estimated Profit
                                </p>

                                <p className="mt-2 text-xl font-bold text-[#B51F35]">
                                  {formatMoney(
                                    estimatedProfit,
                                    currency,
                                  )}
                                </p>

                                <p className="mt-1 text-[10px] !text-[#9298A3]">
                                  Based on{" "}
                                  {Number(
                                    selectedPlan.roi_percent ||
                                      0,
                                  ).toLocaleString(
                                    "en-US",
                                    {
                                      maximumFractionDigits: 4,
                                    },
                                  )}{" "}
                                  % ROI
                                </p>
                              </div>

                              <div className="rounded-xl bg-[#B51F35]/5 p-4 ring-1 ring-[#B51F35]/10">
                                <p className="text-xs !text-[#9298A3]">
                                  Estimated Total
                                </p>

                                <p className="mt-2 text-xl font-bold text-[#B51F35]">
                                  {formatMoney(
                                    estimatedTotal,
                                    currency,
                                  )}
                                </p>

                                <p className="mt-1 text-[10px] !text-[#9298A3]">
                                  After{" "}
                                  {formatDuration(
                                    selectedPlan.duration_value,
                                    selectedPlan.duration_unit,
                                  )}
                                </p>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() =>
                                openPage(
                                  "/investments",
                                )
                              }
                              className="mt-5 inline-flex items-center gap-2 rounded-full bg-[#B51F35] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#991B30] active:scale-[0.98]"
                            >
                              Open Investments
                              <FiChevronRight
                                size={16}
                              />
                            </button>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </section>

              {/* ACTIVITY */}
              <section className="mt-6">
                <div className="mb-4 flex items-end justify-between gap-4">
                  <div>
                    <p className="text-[11px] font-bold uppercase tracking-[0.16em] !text-[#9298A3]">
                      Activity
                    </p>

                    <h2 className="mt-1 text-xl font-bold !text-[#111318]">
                      Recent transactions
                    </h2>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      setHistoryOpen(true)
                    }
                    className="inline-flex items-center gap-1 text-sm font-semibold text-[#B51F35]"
                  >
                    View all
                    <FiChevronRight size={16} />
                  </button>
                </div>

                <div className="overflow-hidden rounded-[28px] bg-white shadow-[0_4px_20px_rgba(0,0,0,0.06)] ring-1 ring-[#E2E5E9]">
                  {activities.length === 0 ? (
                    <div className="p-10 text-center">
                      <FiClock
                        size={24}
                        className="mx-auto !text-[#9298A3]"
                      />

                      <p className="mt-3 text-sm !text-[#69707D]">
                        No transactions yet
                      </p>
                    </div>
                  ) : (
                    activities
                      .slice(0, 5)
                      .map((activity) => {
                        const style =
                          getActivityStyle(
                            activity,
                          );

                        const pending =
                          activity.isWithdrawal &&
                          activity.status?.toLowerCase() ===
                            "pending";

                        return (
                          <button
                            type="button"
                            key={activity.id}
                            onClick={() => setHistoryOpen(true)}
                            className="flex w-full items-center justify-between gap-4 border-b border-[#E2E5E9] px-5 py-4 text-left transition hover:bg-[#F8F9FB] active:bg-[#F1F3F6] focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#B51F35]/20 last:border-b-0 sm:px-6"
                          >
                            <div className="flex min-w-0 items-center gap-3">
                              <div
                                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${style.background}`}
                              >
                                {renderActivityIcon(
                                  activity,
                                )}
                              </div>

                              <div className="min-w-0">
                                <p className="truncate text-sm font-semibold !text-[#111318]">
                                  {
                                    activity.description
                                  }
                                </p>

                                <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] !text-[#9298A3]">
                                  <span>
                                    {formatDate(
                                      activity.created_at,
                                    )}
                                  </span>

                                  {activity.status && (
                                    <>
                                      <span>
                                        ·
                                      </span>

                                      <span
                                        className={
                                          style.text
                                        }
                                      >
                                        {
                                          activity.status
                                        }
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="shrink-0 text-right">
                              <p
                                className={`text-sm font-bold ${style.text}`}
                              >
                                {pending
                                  ? ""
                                  : activity.type ===
                                        "credit" &&
                                      !activity.isWithdrawal
                                    ? "+"
                                    : "-"}
                                {formatMoney(
                                  Math.abs(
                                    activity.amount,
                                  ),
                                  currency,
                                )}
                              </p>

                              {pending && (
                                <p className="mt-1 text-[9px] font-bold uppercase tracking-wider text-[#B51F35]">
                                  Pending
                                </p>
                              )}
                            </div></button>
                        );
                      })
                  )}
                </div>
              </section>

              {/* SECURITY */}
              <section className="mt-6 rounded-[28px] bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.06)] ring-1 ring-[#E2E5E9] sm:p-7">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#171B26]/5 text-[#171B26]">
                    <FiShield size={20} />
                  </div>

                  <div>
                    <h3 className="font-bold !text-[#111318]">
                      Secure account
                    </h3>

                    <p className="mt-1 text-xs !text-[#9298A3]">
                      Your account is connected to Supabase.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    openPage("/profile")
                  }
                  className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-[#B51F35]"
                >
                  Open profile
                  <FiChevronRight size={15} />
                </button>
              </section>
            </div>
          </section>
        </div>
      </div>

      {/* MOBILE FLOATING NAVIGATION */}
      <div className="fixed bottom-4 left-1/2 z-40 w-[calc(100%-24px)] max-w-[430px] -translate-x-1/2 lg:hidden">
        <div className="grid grid-cols-5 items-center gap-1 rounded-[34px] bg-white p-2 shadow-[0_18px_50px_rgba(17,19,24,0.16)] ring-1 ring-[#E2E5E9]">

          <FloatingNavItem
            icon={<FiTrendingUp size={21} />}
            label="Invest"
            onClick={() =>
              router.push("/investments")
            }
          />

          <FloatingNavItem
            icon={<FiGift size={21} />}
            label="Grant"
            onClick={() =>
              router.push("/grants")
            }
          />

          <FloatingNavItem
            icon={<FiHome size={21} />}
            label="Home"
            onClick={() =>
              router.push("/dashboard")
            }
            active
          />

          <FloatingNavItem
            icon={<FiBriefcase size={21} />}
            label="Loan"
            onClick={() =>
              router.push("/loans")
            }
          />

          <FloatingNavItem
            icon={<FiArrowUpRight size={21} />}
            label="Withdraw"
            onClick={() =>
              router.push("/withdraw")
            }
          />

        </div>
      </div>

      {/* SUPPORT / NOTIFICATIONS */}
      {inboxOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl bg-[#F8F9FB] shadow-2xl">

            <div className="flex items-center justify-between border-b border-[#E2E5E9] bg-white p-5 sm:p-6">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold text-[#111318]">
                    Notifications
                  </h2>

                  {unreadInboxCount > 0 && (
                    <span className="rounded-full bg-[#B51F35] px-2 py-1 text-[9px] font-black text-white">
                      {unreadInboxCount} new
                    </span>
                  )}
                </div>

                <p className="mt-1 text-xs text-[#9298A3]">
                  Messages and account requests from FlashFinance Support Team.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={refreshInbox}
                  disabled={refreshingInbox}
                  className="rounded-full border border-[#E2E5E9] bg-white px-3 py-2 text-xs font-semibold text-[#69707D]"
                >
                  {refreshingInbox
                    ? "Refreshing..."
                    : "Refresh"}
                </button>

                {unreadInboxCount > 0 && (
                  <button
                    type="button"
                    onClick={
                      markAllInboxRead
                    }
                    className="hidden rounded-full bg-[#B51F35] px-3 py-2 text-xs font-semibold text-white sm:block"
                  >
                    Mark all read
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setInboxOpen(false);
                    setSelectedInboxItem(
                      null,
                    );
                  }}
                  className="rounded-full bg-[#F0F1F5] p-2 text-[#69707D]"
                >
                  <FiX size={18} />
                </button>
              </div>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto">
              {inboxError && (
                <div className="m-5 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">
                  {inboxError}
                </div>
              )}

              {latestKycRequest && (
                <div className="border-b border-[#E2E5E9] bg-[#B51F35]/5 p-4 sm:p-5">
                  <button
                    type="button"
                    onClick={() =>
                      openKycVerification(
                        latestKycRequest,
                      )
                    }
                    className="flex w-full items-center justify-between gap-4 rounded-2xl bg-white p-4 text-left shadow-sm ring-1 ring-[#B51F35]/10"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#B51F35]/10 text-[#B51F35]">
                        <FiShield size={20} />
                      </div>

                      <div>
                        <p className="font-bold text-[#B51F35]">
                          KYC verification required
                        </p>

                        <p className="mt-1 text-xs text-[#69707D]">
                          Submit your Government ID and selfie verification.
                        </p>
                      </div>
                    </div>

                    <span className="rounded-full bg-[#B51F35] px-3 py-2 text-[10px] font-bold text-white">
                      Complete KYC
                    </span>
                  </button>
                </div>
              )}

              {inboxItems.length === 0 ? (
                <div className="p-12 text-center">
                  <FiMessageCircle
                    size={28}
                    className="mx-auto text-[#9298A3]"
                  />

                  <h3 className="mt-4 font-bold text-[#111318]">
                    No notifications yet
                  </h3>

                  <p className="mx-auto mt-2 max-w-sm text-xs leading-5 text-[#9298A3]">
                    Messages from FlashFinance Support Team will appear here.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-[#E2E5E9]">
                  {inboxItems.map((item) => {
                    const style =
                      getInboxStyle(
                        item.type,
                      );

                    const kyc =
                      isKycInboxItem(item);

                    const activeKyc =
                      isActiveKycRequest(item);

                    const fee =
                      isFeeInboxItem(item);

                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() =>
                          openInboxItem(item)
                        }
                        className={`flex w-full items-start gap-4 p-5 text-left transition hover:bg-[#F8F9FB] ${
                          !item.is_read
                            ? "bg-[#B51F35]/[0.025]"
                            : "bg-white"
                        }`}
                      >
                        <div
                          className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${style.iconBackground} ${style.iconColor}`}
                        >
                          {getInboxIcon(
                            item.type,
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span
                              className={`rounded-full border px-2 py-1 text-[9px] font-bold uppercase tracking-wider ${style.badge}`}
                            >
                              {getInboxTypeLabel(
                                item.type,
                              )}
                            </span>

                            {!item.is_read && (
                              <span className="rounded-full bg-[#B51F35] px-2 py-1 text-[9px] font-black text-white">
                                New
                              </span>
                            )}
                          </div>

                          <h3 className="mt-3 truncate text-sm font-bold text-[#111318]">
                            {item.title}
                          </h3>

                          <p className="mt-1 text-xs font-semibold text-[#B51F35]">
                            {item.sender_name ||
                              "FlashFinance Support Team"}
                          </p>

                          <p className="mt-2 line-clamp-2 text-xs leading-5 text-[#69707D]">
                            {item.message}
                          </p>

                          {activeKyc && (
                            <p className="mt-2 text-[10px] font-bold text-[#B51F35]">
                              Government ID + selfie verification
                            </p>
                          )}

                          {kyc && !activeKyc && (
                            <p className="mt-2 text-[10px] font-semibold text-[#9298A3]">
                              KYC request no longer requires action
                            </p>
                          )}

                          {fee &&
                            item.action_required &&
                            !item.resolved_at && (
                              <p className="mt-2 text-[10px] font-bold text-[#B51F35]">
                                Payment required
                              </p>
                            )}

                          <p className="mt-3 text-[10px] text-[#9298A3]">
                            {formatDateTime(
                              item.created_at,
                            )}
                          </p>
                        </div>

                        <FiChevronRight
                          size={18}
                          className="mt-5 shrink-0 text-[#9298A3]"
                        />
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* INBOX DETAIL */}
      {selectedInboxItem && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white shadow-2xl">

            <div className="flex items-start justify-between gap-4 border-b border-[#E2E5E9] p-5 sm:p-6">
              <div className="flex min-w-0 items-start gap-3">
                <div
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${
                    getInboxStyle(
                      selectedInboxItem.type,
                    ).iconBackground
                  } ${
                    getInboxStyle(
                      selectedInboxItem.type,
                    ).iconColor
                  }`}
                >
                  {getInboxIcon(
                    selectedInboxItem.type,
                  )}
                </div>

                <div>
                  <span
                    className={`inline-flex rounded-full border px-2 py-1 text-[9px] font-bold uppercase ${
                      getInboxStyle(
                        selectedInboxItem.type,
                      ).badge
                    }`}
                  >
                    {getInboxTypeLabel(
                      selectedInboxItem.type,
                    )}
                  </span>

                  <h2 className="mt-2 text-xl font-bold text-[#111318]">
                    {selectedInboxItem.title}
                  </h2>

                  <p className="mt-1 text-xs font-bold text-[#B51F35]">
                    {selectedInboxItem.sender_name ||
                      "FlashFinance Support Team"}
                  </p>

                  <p className="mt-1 text-[10px] text-[#9298A3]">
                    {formatDateTime(
                      selectedInboxItem.created_at,
                    )}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  setSelectedInboxItem(
                    null,
                  )
                }
                className="rounded-full bg-[#F0F1F5] p-2 text-[#69707D]"
              >
                <FiX size={18} />
              </button>
            </div>

            <div className="p-5 sm:p-6">
              {selectedInboxItem.action_required &&
                !selectedInboxItem.resolved_at && (
                  <div className="mb-5 rounded-2xl border border-[#B51F35]/15 bg-[#B51F35]/5 p-4 text-sm text-[#B51F35]">
                    <div className="flex items-start gap-3">
                      <FiAlertTriangle size={19} />

                      <div>
                        <p className="font-bold">
                          Action required
                        </p>

                        <p className="mt-1 text-xs leading-5">
                          Please review this request and follow the instructions provided.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

              <div className="rounded-2xl bg-[#F8F9FB] p-5">
                <p className="whitespace-pre-wrap text-sm leading-7 text-[#111318]">
                  {selectedInboxItem.message}
                </p>
              </div>

              {selectedInboxItem.amount !==
                null &&
                selectedInboxItem.amount !==
                  undefined && (
                  <div className="mt-4 rounded-2xl bg-[#B51F35]/5 p-5">
                    <p className="text-xs uppercase tracking-wider text-[#9298A3]">
                      Amount
                    </p>

                    <p className="mt-2 text-2xl font-bold text-[#B51F35]">
                      {formatMoney(
                        Number(
                          selectedInboxItem.amount,
                        ),
                        selectedInboxItem.currency ||
                          currency,
                      )}
                    </p>
                  </div>
                )}

              {isFeeInboxItem(
                selectedInboxItem,
              ) && (
                <div className="mt-4 rounded-2xl border border-[#B51F35]/15 bg-[#B51F35]/5 p-4">
                  <p className="text-xs font-semibold leading-5 text-[#69707D]">
                    You can pay all of this fee at once or make a partial payment. The payment page will show the exact remaining amount.
                  </p>
                </div>
              )}

              {isApplicationInformationRequest(
                selectedInboxItem,
              ) && (
                <div className="mt-4 rounded-2xl border border-[#B51F35]/15 bg-[#B51F35]/5 p-4">
                  <p className="text-xs font-semibold leading-5 text-[#69707D]">
                    Use Review request to open the exact application request and provide the information or supporting documents requested by FlashFinance Support Team.
                  </p>
                </div>
              )}

              <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">

                {/* KYC */}
                {isActiveKycRequest(
                  selectedInboxItem,
                ) && (
                  <button
                    type="button"
                    onClick={() =>
                      openKycVerification(
                        selectedInboxItem,
                      )
                    }
                    className="flex items-center justify-center gap-2 rounded-full bg-[#B51F35] px-5 py-3 text-sm font-semibold text-white"
                  >
                    Complete KYC
                    <FiShield size={16} />
                  </button>
                )}

                {/* FEE REQUEST */}
                {isFeeInboxItem(
                  selectedInboxItem,
                ) &&
                  selectedInboxItem.action_required &&
                  !selectedInboxItem.resolved_at && (
                    <button
                      type="button"
                      onClick={() =>
                        void openFeePayment(
                          selectedInboxItem,
                        )
                      }
                      className="flex items-center justify-center gap-2 rounded-full bg-[#B51F35] px-5 py-3 text-sm font-semibold text-white"
                    >
                      Make payment
                      <FiDollarSign
                        size={16}
                      />
                    </button>
                  )}

                {/* GRANT / LOAN / APPLICATION INFORMATION REQUEST */}
                {!isKycInboxItem(
                  selectedInboxItem,
                ) &&
                  !isFeeInboxItem(
                    selectedInboxItem,
                  ) &&
                  selectedInboxItem.action_url && (
                    <button
                      type="button"
                      onClick={() =>
                        handleInboxAction(
                          selectedInboxItem,
                        )
                      }
                      className="flex items-center justify-center gap-2 rounded-full bg-[#B51F35] px-5 py-3 text-sm font-semibold text-white"
                    >
                      Review request
                      <FiExternalLink
                        size={16}
                      />
                    </button>
                  )}

                <button
                  type="button"
                  onClick={openSupportTicket}
                  className="rounded-full border border-[#B51F35]/20 px-5 py-3 text-sm font-semibold text-[#B51F35]"
                >
                  Contact Support
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setSelectedInboxItem(
                      null,
                    )
                  }
                  className="rounded-full border border-[#E2E5E9] px-5 py-3 text-sm font-semibold text-[#69707D]"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TRANSACTION HISTORY */}
      {historyOpen && (
        <div className="fixed inset-0 z-[65] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-3xl bg-white shadow-2xl">

            <div className="flex items-center justify-between border-b border-[#E2E5E9] p-5 sm:p-6">
              <div>
                <h2 className="text-xl font-bold text-[#111318]">
                  Transaction history
                </h2>

                <p className="mt-1 text-xs text-[#9298A3]">
                  Activity is sorted by original transaction time.
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  setHistoryOpen(false)
                }
                className="rounded-full bg-[#F0F1F5] p-2 text-[#69707D]"
              >
                <FiX size={18} />
              </button>
            </div>

            <div className="border-b border-[#E2E5E9] p-4">
              <div className="flex items-center gap-2 rounded-xl bg-[#F8F9FB] px-3 ring-1 ring-[#E2E5E9]">
                <FiSearch
                  size={17}
                  className="text-[#9298A3]"
                />

                <input
                  value={searchText}
                  onChange={(event) =>
                    setSearchText(
                      event.target.value,
                    )
                  }
                  placeholder="Search transactions..."
                  className="w-full bg-transparent py-3 text-sm text-[#111318] outline-none placeholder:text-[#9298A3]"
                />
              </div>
            </div>

            <div className="max-h-[65vh] overflow-y-auto">
              {filteredActivities.length ===
              0 ? (
                <div className="p-10 text-center text-sm text-[#69707D]">
                  No matching transactions found.
                </div>
              ) : (
                filteredActivities.map(
                  (activity) => {
                    const style =
                      getActivityStyle(
                        activity,
                      );

                    const pending =
                      activity.isWithdrawal &&
                      activity.status?.toLowerCase() ===
                        "pending";

                    return (
                      <div
                        key={activity.id}
                        className="flex w-full items-center justify-between gap-4 border-b border-[#E2E5E9] px-5 py-4 text-left transition hover:bg-[#F8F9FB] active:bg-[#F1F3F6] focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#B51F35]/20 last:border-b-0 sm:px-6"
                      >
                        <div className="flex min-w-0 items-center gap-3">
                          <div
                            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${style.background}`}
                          >
                            {renderActivityIcon(
                              activity,
                            )}
                          </div>

                          <div className="min-w-0">
                            <p className="truncate text-sm font-semibold text-[#111318]">
                              {
                                activity.description
                              }
                            </p>

                            <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-[#9298A3]">
                              <span>
                                {formatDate(
                                  activity.created_at,
                                )}
                              </span>

                              {activity.status && (
                                <>
                                  <span>
                                    â€¢
                                  </span>

                                  <span
                                    className={
                                      style.text
                                    }
                                  >
                                    {
                                      activity.status
                                    }
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="text-right">
                          <p
                            className={`text-sm font-bold ${style.text}`}
                          >
                            {pending
                              ? ""
                              : activity.type ===
                                    "credit" &&
                                  !activity.isWithdrawal
                                ? "+"
                                : "-"}
                            {formatMoney(
                              Math.abs(
                                activity.amount,
                              ),
                              currency,
                            )}
                          </p>

                          {pending && (
                            <p className="mt-1 text-[10px] font-bold uppercase text-[#B51F35]">
                              Pending
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  },
                )
              )}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

/* SIDEBAR */

function SidebarItem({
  active = false,
  icon,
  label,
  onClick,
  dark,
}: {
  active?: boolean;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  dark: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition active:scale-[0.99] ${
        active
          ? "bg-[#B51F35] text-white shadow-lg shadow-[#B51F35]/20"
          : dark
            ? "text-white/55 hover:bg-white/5 hover:text-white"
            : "text-[#69707D] hover:bg-[#F1F3F6] hover:text-[#111318]"
      }`}
    >
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
        {icon}
      </span>

      <span>{label}</span>
    </button>
  );
}

/* MOBILE MENU */

function MobileMenuItem({
  label,
  icon,
  onClick,
}: {
  label: string;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-3 rounded-2xl bg-[#F8F9FB] p-3 text-left text-sm font-semibold text-[#111318] ring-1 ring-[#E2E5E9] transition active:scale-[0.98]"
    >
      <span className="text-[#B51F35]">
        {icon}
      </span>

      <span>{label}</span>
    </button>
  );
}

/* QUICK ACTION */

function QuickAction({
  icon,
  label,
  primary = false,
  onClick,
  dark,
}: {
  icon: React.ReactNode;
  label: string;
  primary?: boolean;
  onClick: () => void;
  dark: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex flex-col items-center gap-2 text-center transition active:scale-[0.97]"
    >
      <span
        className={`flex h-14 w-14 items-center justify-center rounded-full shadow-lg transition sm:h-16 sm:w-16 ${
          primary
            ? "bg-[#B51F35] text-white shadow-[#B51F35]/15"
            : dark
              ? "bg-[#292D38] text-white hover:bg-[#343946]"
              : "bg-[#292D38] text-white hover:bg-[#343946]"
        }`}
      >
        {icon}
      </span>

      <span
        className={`text-xs font-medium sm:text-sm ${
          dark
            ? "text-white/75"
            : "text-[#69707D]"
        }`}
      >
        {label}
      </span>
    </button>
  );
}

/* MORE MENU */

function MoreItem({
  icon,
  label,
  onClick,
  dark,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  dark: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold transition ${
        dark
          ? "text-white/75 hover:bg-white/5 hover:text-white"
          : "text-[#69707D] hover:bg-[#F8F9FB] hover:text-[#111318]"
      }`}
    >
      <span
        className={`flex h-9 w-9 items-center justify-center rounded-full ${
          dark
            ? "bg-white/5 text-white"
            : "bg-[#F0F1F5] text-[#69707D]"
        }`}
      >
        {icon}
      </span>

      <span>{label}</span>
    </button>
  );
}

/* SERVICE CARD */

function ServiceCard({
  icon,
  title,
  description,
  onClick,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-2xl bg-white p-4 text-left shadow-[0_4px_18px_rgba(0,0,0,0.04)] ring-1 ring-[#E2E5E9] transition hover:-translate-y-0.5 hover:ring-[#B51F35]/20 active:scale-[0.98]"
    >
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#B51F35]/10 text-[#B51F35]">
        {icon}
      </span>

      <p className="mt-4 text-sm font-bold text-[#111318]">
        {title}
      </p>

      <p className="mt-1 text-xs text-[#9298A3]">
        {description}
      </p>
    </button>
  );
}

/* FLOATING BOTTOM NAV */

function FloatingNavItem({
  icon,
  label,
  onClick,
  active = false,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex min-w-0 flex-col items-center justify-center gap-1 rounded-[24px] px-1 py-2 text-[10px] font-semibold transition duration-200 active:scale-[0.96] ${
        active
          ? "bg-[#B51F35] text-white shadow-md shadow-[#B51F35]/15"
          : "text-[#69707D] hover:bg-[#F0F1F5]"
      }`}
    >
      <span className="flex h-8 items-center justify-center">
        {icon}
      </span>

      <span className="truncate">
        {label}
      </span>
    </button>
  );
}




