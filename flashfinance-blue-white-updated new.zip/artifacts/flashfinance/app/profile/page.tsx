"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase";
import Link from "next/link";
import {
  FiArrowLeft,
  FiUser,
  FiMail,
  FiPhone,
  FiShield,
  FiCreditCard,
  FiCalendar,
  FiEdit3,
  FiCheck,
  FiLogOut,
  FiChevronRight,
  FiBell,
  FiLock,
  FiHelpCircle,
  FiFileText,
  FiSettings,
  FiCopy,
  FiCheckCircle,
  FiActivity,
  FiX,
  FiCamera,
  FiTrash2,
  FiEye,
  FiEyeOff,
  FiDownload,
  FiSearch,
  FiMessageCircle,
  FiChevronDown,
  FiRefreshCw,
} from "react-icons/fi";

const supabase = createClient();

type Profile = {
  id: string;
  full_name: string | null;
  phone: string | null;
  account_status: string | null;
  account_type: string | null;
  created_at: string | null;
  avatar_url?: string | null;
};

type Transaction = {
  id: string;
  created_at: string | null;
  type?: string | null;
  description?: string | null;
  amount?: number | null;
  status?: string | null;
  reference?: string | null;
};

type NotificationSettings = {
  transactions: boolean;
  security: boolean;
  payments: boolean;
  marketing: boolean;
};

type Preferences = {
  currency: string;
  language: string;
  transactionConfirmation: boolean;
};

type SupportMessage = {
  id: string;
  subject: string;
  message: string;
  created_at: string;
};

const defaultNotifications: NotificationSettings = {
  transactions: true,
  security: true,
  payments: true,
  marketing: false,
};

const defaultPreferences: Preferences = {
  currency: "NGN",
  language: "English",
  transactionConfirmation: true,
};

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [email, setEmail] = useState("");

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");

  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [copied, setCopied] = useState(false);

  const [activePanel, setActivePanel] = useState<string | null>(null);

  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [avatarError, setAvatarError] = useState("");
  const [avatarMessage, setAvatarMessage] = useState("");

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [changingPassword, setChangingPassword] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const [notifications, setNotifications] =
    useState<NotificationSettings>(defaultNotifications);

  const [preferences, setPreferences] =
    useState<Preferences>(defaultPreferences);

  const [settingsSaved, setSettingsSaved] = useState(false);

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loadingTransactions, setLoadingTransactions] = useState(false);
  const [transactionSearch, setTransactionSearch] = useState("");

  const [supportSubject, setSupportSubject] = useState("");
  const [supportMessage, setSupportMessage] = useState("");
  const [sendingSupport, setSendingSupport] = useState(false);
  const [supportSuccess, setSupportSuccess] = useState("");
  const [supportError, setSupportError] = useState("");

  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    loadProfile();
  }, []);

  async function loadProfile() {
    setLoading(true);
    setErrorMessage("");

    try {
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();

      if (authError || !user) {
        window.location.href = "/login";
        return;
      }

      setEmail(user.email || "");

      const authAvatar =
        typeof user.user_metadata?.avatar_url === "string"
          ? user.user_metadata.avatar_url
          : "";

      const authNotifications =
        user.user_metadata?.notification_preferences;

      const authPreferences =
        user.user_metadata?.account_preferences;

      if (authNotifications) {
        setNotifications({
          ...defaultNotifications,
          ...authNotifications,
        });
      }

      if (authPreferences) {
        setPreferences({
          ...defaultPreferences,
          ...authPreferences,
        });
      }

      const { data, error } = await supabase
        .from("profiles")
        .select(
          "id, full_name, phone, account_status, account_type, created_at, avatar_url"
        )
        .eq("id", user.id)
        .single();

      if (error) {
        console.error("Profile query error:", error);

        const fallback = await supabase
          .from("profiles")
          .select(
            "id, full_name, phone, account_status, account_type, created_at"
          )
          .eq("id", user.id)
          .single();

        if (fallback.error || !fallback.data) {
          console.error("Fallback profile error:", fallback.error);

          setErrorMessage(
            "We could not load your profile information."
          );

          setLoading(false);
          return;
        }

        setProfile({
          ...fallback.data,
          avatar_url: authAvatar || null,
        });

        setFullName(fallback.data.full_name || "");
        setPhone(fallback.data.phone || "");

        setLoading(false);
        return;
      }

      const databaseAvatar =
        typeof data.avatar_url === "string"
          ? data.avatar_url
          : "";

      setProfile({
        ...data,
        avatar_url: authAvatar || databaseAvatar || null,
      });

      setFullName(data.full_name || "");
      setPhone(data.phone || "");

      setLoading(false);
    } catch (error) {
      console.error("Profile loading error:", error);

      setErrorMessage(
        "Something went wrong while loading your profile."
      );

      setLoading(false);
    }
  }

  function saveLocalSettings(
    nextNotifications: NotificationSettings,
    nextPreferences: Preferences
  ) {
    try {
      localStorage.setItem(
        "flashfinance_notifications",
        JSON.stringify(nextNotifications)
      );

      localStorage.setItem(
        "flashfinance_preferences",
        JSON.stringify(nextPreferences)
      );
    } catch (error) {
      console.error("Could not save local settings:", error);
    }
  }

  function showSettingsSaved() {
    setSettingsSaved(true);

    setTimeout(() => {
      setSettingsSaved(false);
    }, 2500);
  }

  async function saveNotificationSettings(
    next: NotificationSettings
  ) {
    const previous = notifications;

    setNotifications(next);

    try {
      const { error } = await supabase.auth.updateUser({
        data: {
          notification_preferences: next,
        },
      });

      if (error) {
        console.error(error);
        setNotifications(previous);

        setErrorMessage(
          "We could not save your notification preferences."
        );

        return;
      }

      saveLocalSettings(next, preferences);
      showSettingsSaved();
    } catch (error) {
      console.error(error);
      setNotifications(previous);

      setErrorMessage(
        "We could not save your notification preferences."
      );
    }
  }

  async function savePreferences(next: Preferences) {
    const previous = preferences;

    setPreferences(next);

    try {
      const { error } = await supabase.auth.updateUser({
        data: {
          account_preferences: next,
        },
      });

      if (error) {
        console.error(error);
        setPreferences(previous);

        setErrorMessage(
          "We could not save your account preferences."
        );

        return;
      }

      saveLocalSettings(notifications, next);
      showSettingsSaved();
    } catch (error) {
      console.error(error);
      setPreferences(previous);

      setErrorMessage(
        "We could not save your account preferences."
      );
    }
  }

  function isValidEmail(value: string) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  async function saveProfile() {
    if (!profile) return;

    setSaving(true);
    setMessage("");
    setErrorMessage("");

    const updatedName = fullName.trim();
    const updatedPhone = phone.trim();
    const updatedEmail = email.trim().toLowerCase();

    if (!updatedName) {
      setErrorMessage("Please enter your full name.");
      setSaving(false);
      return;
    }

    if (!updatedEmail) {
      setErrorMessage("Please enter your email address.");
      setSaving(false);
      return;
    }

    if (!isValidEmail(updatedEmail)) {
      setErrorMessage("Please enter a valid email address.");
      setSaving(false);
      return;
    }

    const emailChanged =
      updatedEmail.toLowerCase() !== email.toLowerCase();

    if (emailChanged) {
      const { error: emailError } =
        await supabase.auth.updateUser({
          email: updatedEmail,
        });

      if (emailError) {
        console.error(emailError);

        setErrorMessage(
          "We could not update your email address. Please try again."
        );

        setSaving(false);
        return;
      }
    }

    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: updatedName,
        phone: updatedPhone,
      })
      .eq("id", profile.id);

    if (error) {
      console.error(error);

      setErrorMessage(
        "We could not update your profile. Please try again."
      );

      setSaving(false);
      return;
    }

    const { error: authUpdateError } =
      await supabase.auth.updateUser({
        data: {
          full_name: updatedName,
        },
      });

    if (authUpdateError) {
      console.error(authUpdateError);
    }

    setProfile({
      ...profile,
      full_name: updatedName,
      phone: updatedPhone,
    });

    setFullName(updatedName);
    setPhone(updatedPhone);
    setEmail(updatedEmail);
    setEditing(false);

    if (emailChanged) {
      setMessage(
        "Profile updated successfully. A confirmation email has been sent to your new email address."
      );
    } else {
      setMessage("Profile updated successfully.");
    }

    setSaving(false);
  }

  async function signOut() {
    await supabase.auth.signOut();
    window.location.href = "/login";
  }

  async function copyAccountId() {
    if (!profile?.id) return;

    try {
      await navigator.clipboard.writeText(profile.id);
      setCopied(true);

      setTimeout(() => {
        setCopied(false);
      }, 2000);
    } catch (error) {
      console.error(error);
    }
  }

  function formatDate(date: string | null) {
    if (!date) return "Not available";

    return new Date(date).toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  }

  function formatDateTime(date: string | null) {
    if (!date) return "Not available";

    return new Date(date).toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  }

  function getInitials(name: string | null) {
    if (!name) return "FF";

    const parts = name.trim().split(/\s+/);

    if (parts.length === 1) {
      return parts[0].slice(0, 2).toUpperCase();
    }

    return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
  }

  function getStatus(status: string | null) {
    if (!status) return "Active";

    return status.charAt(0).toUpperCase() + status.slice(1);
  }

  function openPanel(panel: string) {
    setActivePanel(panel);

    setPasswordMessage("");
    setPasswordError("");
    setAvatarMessage("");
    setAvatarError("");
    setSupportSuccess("");
    setSupportError("");
    setTransactionSearch("");
    setErrorMessage("");

    if (panel === "statements" || panel === "activity") {
      loadTransactions();
    }
  }

  function closePanel() {
    setActivePanel(null);

    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");

    setPasswordMessage("");
    setPasswordError("");

    setAvatarMessage("");
    setAvatarError("");

    setSupportSuccess("");
    setSupportError("");
  }

  function passwordIsValid(password: string) {
    return (
      password.length >= 8 &&
      /[A-Z]/.test(password) &&
      /[a-z]/.test(password) &&
      /[0-9]/.test(password)
    );
  }

  async function changePassword() {
    setPasswordMessage("");
    setPasswordError("");

    if (!currentPassword) {
      setPasswordError("Please enter your current password.");
      return;
    }

    if (!newPassword) {
      setPasswordError("Please enter your new password.");
      return;
    }

    if (!passwordIsValid(newPassword)) {
      setPasswordError(
        "Your new password must be at least 8 characters and include an uppercase letter, lowercase letter, and number."
      );
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError("Your new passwords do not match.");
      return;
    }

    if (currentPassword === newPassword) {
      setPasswordError(
        "Your new password must be different from your current password."
      );
      return;
    }

    setChangingPassword(true);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user?.email) {
      setPasswordError(
        "We could not verify your account. Please log in again."
      );

      setChangingPassword(false);
      return;
    }

    const { error: verifyError } =
      await supabase.auth.signInWithPassword({
        email: user.email,
        password: currentPassword,
      });

    if (verifyError) {
      setPasswordError("Your current password is incorrect.");
      setChangingPassword(false);
      return;
    }

    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    });

    if (error) {
      console.error(error);

      setPasswordError(
        "We could not change your password. Please try again."
      );

      setChangingPassword(false);
      return;
    }

    setPasswordMessage(
      "Your password has been changed successfully."
    );

    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");

    setChangingPassword(false);
  }

  async function uploadAvatar(
    event: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0];

    event.target.value = "";

    if (!file || !profile) return;

    setAvatarError("");
    setAvatarMessage("");

    if (!file.type.startsWith("image/")) {
      setAvatarError("Please select an image file.");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setAvatarError("Your profile picture must be smaller than 5MB.");
      return;
    }

    setUploadingAvatar(true);

    try {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError || !user) {
        setAvatarError(
          "Your session has expired. Please log in again."
        );

        setUploadingAvatar(false);
        return;
      }

      let extension = "jpg";

      if (file.type === "image/png") extension = "png";
      else if (file.type === "image/webp") extension = "webp";
      else if (file.type === "image/gif") extension = "gif";

      const filePath = `${user.id}/avatar.${extension}`;

      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(filePath, file, {
          cacheControl: "3600",
          upsert: true,
          contentType: file.type,
        });

      if (uploadError) {
        console.error("Avatar upload error:", uploadError);

        setAvatarError(
          "We could not upload your picture. Make sure the Supabase Storage bucket named avatars exists and allows authenticated uploads."
        );

        setUploadingAvatar(false);
        return;
      }

      const { data: publicData } = supabase.storage
        .from("avatars")
        .getPublicUrl(filePath);

      if (!publicData?.publicUrl) {
        setAvatarError(
          "The picture uploaded, but we could not create its public URL."
        );

        setUploadingAvatar(false);
        return;
      }

      const publicUrl = `${publicData.publicUrl}?v=${Date.now()}`;

      const { error: authUpdateError } =
        await supabase.auth.updateUser({
          data: {
            avatar_url: publicUrl,
          },
        });

      if (authUpdateError) {
        console.error(authUpdateError);

        setAvatarError(
          "The picture uploaded, but we could not save it to your account."
        );

        setUploadingAvatar(false);
        return;
      }

      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          avatar_url: publicUrl,
        })
        .eq("id", profile.id);

      if (profileError) {
        console.warn(profileError);
      }

      setProfile({
        ...profile,
        avatar_url: publicUrl,
      });

      setAvatarMessage(
        "Profile picture updated successfully."
      );
    } catch (error) {
      console.error(error);

      setAvatarError(
        "Something went wrong while uploading your profile picture."
      );
    }

    setUploadingAvatar(false);
  }

  async function removeAvatar() {
    if (!profile?.avatar_url) return;

    setAvatarError("");
    setAvatarMessage("");
    setUploadingAvatar(true);

    try {
      const { error: authError } =
        await supabase.auth.updateUser({
          data: {
            avatar_url: null,
          },
        });

      if (authError) {
        console.error(authError);

        setAvatarError(
          "We could not remove your profile picture."
        );

        setUploadingAvatar(false);
        return;
      }

      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          avatar_url: null,
        })
        .eq("id", profile.id);

      if (profileError) {
        console.warn(profileError);
      }

      await supabase.storage
        .from("avatars")
        .remove([
          `${profile.id}/avatar.jpg`,
          `${profile.id}/avatar.png`,
          `${profile.id}/avatar.webp`,
          `${profile.id}/avatar.gif`,
        ]);

      setProfile({
        ...profile,
        avatar_url: null,
      });

      setAvatarMessage("Profile picture removed.");
    } catch (error) {
      console.error(error);

      setAvatarError(
        "Something went wrong while removing your profile picture."
      );
    }

    setUploadingAvatar(false);
  }

  async function loadTransactions() {
    if (!profile) return;

    setLoadingTransactions(true);

    try {
      const result = await supabase
        .from("transactions")
        .select(
          "id, created_at, type, description, amount, status, reference"
        )
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(100);

      if (result.error) {
        console.error(result.error);
        setTransactions([]);
      } else {
        setTransactions((result.data || []) as Transaction[]);
      }
    } catch (error) {
      console.error(error);
      setTransactions([]);
    }

    setLoadingTransactions(false);
  }

  function filteredTransactions() {
    const search = transactionSearch.trim().toLowerCase();

    if (!search) return transactions;

    return transactions.filter((transaction) => {
      return (
        transaction.description
          ?.toLowerCase()
          .includes(search) ||
        transaction.type?.toLowerCase().includes(search) ||
        transaction.status?.toLowerCase().includes(search) ||
        transaction.reference?.toLowerCase().includes(search)
      );
    });
  }

  function downloadStatement() {
    const rows = filteredTransactions();

    if (rows.length === 0) {
      alert("There are no transactions available for this statement.");
      return;
    }

    const headers = [
      "Date",
      "Type",
      "Description",
      "Amount",
      "Status",
      "Reference",
    ];

    const csvRows = rows.map((transaction) => [
      formatDateTime(transaction.created_at),
      transaction.type || "",
      transaction.description || "",
      String(transaction.amount ?? ""),
      transaction.status || "",
      transaction.reference || "",
    ]);

    const csv = [headers, ...csvRows]
      .map((row) =>
        row
          .map((value) =>
            `"${String(value).replace(/"/g, '""')}"`
          )
          .join(",")
      )
      .join("\n");

    const blob = new Blob([csv], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = `FlashFinance-Statement-${new Date()
      .toISOString()
      .slice(0, 10)}.csv`;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
  }

  async function sendSupportRequest() {
    setSupportSuccess("");
    setSupportError("");

    const subject = supportSubject.trim();
    const body = supportMessage.trim();

    if (!subject) {
      setSupportError("Please enter a subject.");
      return;
    }

    if (!body) {
      setSupportError("Please describe your issue.");
      return;
    }

    setSendingSupport(true);

    const request: SupportMessage = {
      id: crypto.randomUUID(),
      subject,
      message: body,
      created_at: new Date().toISOString(),
    };

    try {
      const existing = localStorage.getItem(
        "flashfinance_support_requests"
      );

      const requests: SupportMessage[] = existing
        ? JSON.parse(existing)
        : [];

      requests.unshift(request);

      localStorage.setItem(
        "flashfinance_support_requests",
        JSON.stringify(requests)
      );

      setSupportSubject("");
      setSupportMessage("");

      setSupportSuccess(
        "Your support request has been submitted successfully."
      );
    } catch (error) {
      console.error(error);

      setSupportError(
        "We could not submit your request. Please try again."
      );
    }

    setSendingSupport(false);
  }

  if (loading) {
    return (
      <main className="profile-page flex min-h-screen items-center justify-center !bg-[#F1F3F6] !text-[#111318]">
        <div className="flex flex-col items-center">
          <div className="h-10 w-10 animate-spin rounded-full !border-2 !border-[#E2E5E9] !border-t-[#B51F35]" />

          <p className="mt-4 text-sm !text-[#69707D]">
            Loading your profile...
          </p>
        </div>
      </main>
    );
  }

  if (!profile) {
    return (
      <main className="profile-page flex min-h-screen items-center justify-center !bg-[#F1F3F6] px-5 !text-[#111318]">
        <div className="w-full max-w-md rounded-3xl !border !border-[#E2E5E9] !bg-white p-8 text-center shadow-[0_8px_30px_rgba(0,0,0,0.06)]">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full !bg-[#F1F3F6]">
            <FiUser size={26} className="!text-[#69707D]" />
          </div>

          <h1 className="mt-5 text-xl font-bold !text-[#111318]">
            Profile unavailable
          </h1>

          <p className="mt-2 text-sm leading-6 !text-[#69707D]">
            We were unable to load your account information.
          </p>

          <Link
            href="/dashboard"
            className="mt-6 inline-flex rounded-xl !bg-[#B51F35] px-6 py-3 text-sm font-semibold text-white transition hover:!bg-[#C9213A]"
          >
            Return to Dashboard
          </Link>
        </div>
      </main>
    );
  }

  const status = getStatus(profile.account_status);
  const visibleTransactions = filteredTransactions();

  return (
    <main className="profile-page min-h-screen !bg-[#F1F3F6] pb-12 !text-[#111318]">
      <header className="sticky top-0 z-40 !border-b !border-[#E2E5E9] !bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Link
            href="/dashboard"
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold !text-[#69707D] transition hover:!bg-[#F1F3F6] hover:!text-[#B51F35]"
          >
            <FiArrowLeft size={18} />
            Dashboard
          </Link>

          <div className="text-center">
            <p className="text-sm font-bold !text-[#111318]">
              Flash<span className="!text-[#B51F35]">Finance</span>
            </p>

            <p className="hidden text-[10px] uppercase tracking-widest !text-[#9298A3] sm:block">
              Profile & Settings
            </p>
          </div>

          <button
            onClick={signOut}
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold !text-[#B51F35] transition hover:!bg-[#B51F35]/5"
          >
            <FiLogOut size={17} />
            <span className="hidden sm:block">Sign out</span>
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
        <section className="profile-hero overflow-hidden rounded-3xl !bg-gradient-to-br !from-[#0B0E17] !to-[#111827] text-white shadow-[0_12px_40px_rgba(0,0,0,0.12)]">
          <div className="relative overflow-hidden px-6 py-8 sm:px-8 sm:py-10 lg:px-10">
            <div className="absolute -right-32 -top-32 h-80 w-80 rounded-full bg-[#B51F35]/10" />
            <div className="absolute -bottom-40 right-20 h-96 w-96 rounded-full bg-white/[0.025]" />

            <div className="relative">
              <div className="flex flex-col gap-7 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex items-center gap-5">
                  <div className="relative shrink-0">
                    {profile.avatar_url ? (
                      <img
                        key={profile.avatar_url}
                        src={profile.avatar_url}
                        alt="Profile"
                        className="h-24 w-24 rounded-full object-cover shadow-2xl ring-2 ring-[#B51F35]/40"
                      />
                    ) : (
                      <div className="flex h-24 w-24 items-center justify-center rounded-full !bg-white text-3xl font-bold !text-[#111318] shadow-2xl">
                        {getInitials(profile.full_name)}
                      </div>
                    )}

                    <label className="absolute bottom-0 right-0 flex h-9 w-9 cursor-pointer items-center justify-center rounded-full border-2 border-[#0B0E17] !bg-[#B51F35] text-white shadow-lg transition hover:!bg-[#C9213A]">
                      {uploadingAvatar ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                      ) : (
                        <FiCamera size={16} />
                      )}

                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp,image/gif"
                        onChange={uploadAvatar}
                        disabled={uploadingAvatar}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-3">
                      <h1 className="truncate text-2xl font-bold sm:text-3xl">
                        {profile.full_name || "Account Holder"}
                      </h1>

                      <span className="flex items-center gap-1.5 rounded-full bg-green-500/15 px-3 py-1 text-xs font-semibold text-green-300">
                        <span className="h-2 w-2 rounded-full bg-green-400" />
                        {status}
                      </span>
                    </div>

                    <p className="mt-2 break-all text-sm text-gray-300">
                      {email}
                    </p>

                    <p className="mt-1 text-xs text-gray-400">
                      {profile.account_type || "Personal Account"}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setMessage("");
                    setErrorMessage("");
                    setEditing(true);
                  }}
                  className="flex w-fit items-center gap-2 rounded-xl !bg-white px-5 py-3 text-sm font-bold !text-[#111318] transition hover:!bg-[#F1F3F6]"
                >
                  <FiEdit3 size={17} />
                  Edit profile
                </button>
              </div>

              <div className="mt-5 flex flex-wrap gap-3">
                {profile.avatar_url && (
                  <button
                    onClick={removeAvatar}
                    disabled={uploadingAvatar}
                    className="flex items-center gap-2 rounded-xl border border-red-400/20 bg-red-500/10 px-4 py-2.5 text-xs font-bold text-red-300 transition hover:bg-red-500/15 disabled:opacity-50"
                  >
                    <FiTrash2 size={15} />
                    Remove picture
                  </button>
                )}

                <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-bold text-gray-300 transition hover:bg-white/10 hover:text-white">
                  <FiCamera size={15} />
                  {profile.avatar_url
                    ? "Change picture"
                    : "Upload picture"}

                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif"
                    onChange={uploadAvatar}
                    disabled={uploadingAvatar}
                    className="hidden"
                  />
                </label>
              </div>

              {avatarMessage && (
                <div className="mt-5 rounded-xl border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm font-semibold text-green-300">
                  {avatarMessage}
                </div>
              )}

              {avatarError && (
                <div className="mt-5 rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-300">
                  {avatarError}
                </div>
              )}
            </div>
          </div>

          <div className="grid border-t border-white/10 sm:grid-cols-3">
            <div className="border-b border-white/10 px-6 py-5 sm:border-b-0 sm:border-r sm:px-8">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400">
                Account type
              </p>

              <p className="mt-2 text-sm font-semibold text-white">
                {profile.account_type || "Personal Account"}
              </p>
            </div>

            <div className="border-b border-white/10 px-6 py-5 sm:border-b-0 sm:border-r sm:px-8">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400">
                Member since
              </p>

              <p className="mt-2 text-sm font-semibold text-white">
                {formatDate(profile.created_at)}
              </p>
            </div>

            <div className="px-6 py-5 sm:px-8">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400">
                Account status
              </p>

              <div className="mt-2 flex items-center gap-2">
                <FiCheckCircle size={16} className="text-green-400" />

                <p className="text-sm font-semibold text-white">
                  {status}
                </p>
              </div>
            </div>
          </div>
        </section>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <section className="rounded-3xl !border !border-[#E2E5E9] !bg-white shadow-[0_4px_20px_rgba(0,0,0,0.04)] lg:col-span-2">
            <div className="flex items-center justify-between border-b !border-[#E2E5E9] px-6 py-5">
              <div>
                <h2 className="text-lg font-bold !text-[#111318]">
                  Personal information
                </h2>

                <p className="mt-1 text-sm !text-[#69707D]">
                  Information connected to your FlashFinance account.
                </p>
              </div>

              {!editing && (
                <button
                  onClick={() => {
                    setMessage("");
                    setErrorMessage("");
                    setEditing(true);
                  }}
                  className="flex items-center gap-2 rounded-xl !border !border-[#E2E5E9] px-4 py-2.5 text-sm font-semibold !text-[#252932] transition hover:!bg-[#F1F3F6]"
                >
                  <FiEdit3 size={16} />
                  Edit
                </button>
              )}
            </div>

            <div className="grid gap-5 p-6 sm:grid-cols-2">
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wide !text-[#69707D]">
                  Full name
                </p>

                {editing ? (
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 text-sm !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                  />
                ) : (
                  <div className="flex min-h-[54px] items-center gap-3 rounded-2xl !bg-[#F1F3F6] px-4">
                    <FiUser size={18} className="!text-[#69707D]" />

                    <span className="text-sm font-semibold !text-[#111318]">
                      {profile.full_name || "Not provided"}
                    </span>
                  </div>
                )}
              </div>

              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wide !text-[#69707D]">
                  Email address
                </p>

                {editing ? (
                  <>
                    <div className="relative">
                      <FiMail
                        size={18}
                        className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#69707D]"
                      />

                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email address"
                        className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3.5 pl-11 pr-4 text-sm !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                      />
                    </div>

                    <p className="mt-2 text-xs !text-[#9298A3]">
                      You may need to confirm your new email address before it becomes active.
                    </p>
                  </>
                ) : (
                  <>
                    <div className="flex min-h-[54px] items-center gap-3 rounded-2xl !bg-[#F1F3F6] px-4">
                      <FiMail size={18} className="!text-[#69707D]" />

                      <span className="break-all text-sm font-semibold !text-[#111318]">
                        {email || "Not provided"}
                      </span>
                    </div>

                    <p className="mt-2 text-xs !text-[#9298A3]">
                      Your login email is managed through account security.
                    </p>
                  </>
                )}
              </div>

              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wide !text-[#69707D]">
                  Phone number
                </p>

                {editing ? (
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Enter your phone number"
                    className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 text-sm !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                  />
                ) : (
                  <div className="flex min-h-[54px] items-center gap-3 rounded-2xl !bg-[#F1F3F6] px-4">
                    <FiPhone size={18} className="!text-[#69707D]" />

                    <span className="text-sm font-semibold !text-[#111318]">
                      {profile.phone || "Not provided"}
                    </span>
                  </div>
                )}
              </div>

              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wide !text-[#69707D]">
                  Account type
                </p>

                <div className="flex min-h-[54px] items-center gap-3 rounded-2xl !bg-[#F1F3F6] px-4">
                  <FiCreditCard size={18} className="!text-[#69707D]" />

                  <span className="text-sm font-semibold capitalize !text-[#111318]">
                    {profile.account_type || "Personal Account"}
                  </span>
                </div>
              </div>

              {editing && (
                <div className="flex flex-wrap gap-3 sm:col-span-2">
                  <button
                    onClick={saveProfile}
                    disabled={saving}
                    className="flex items-center gap-2 rounded-xl !bg-[#B51F35] px-5 py-3 text-sm font-bold text-white transition hover:!bg-[#C9213A] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <FiCheck size={17} />
                    {saving ? "Saving..." : "Save changes"}
                  </button>

                  <button
                    onClick={() => {
                      setFullName(profile.full_name || "");
                      setPhone(profile.phone || "");
                      setEmail(email);
                      setEditing(false);
                      setMessage("");
                      setErrorMessage("");
                    }}
                    className="flex items-center gap-2 rounded-xl !border !border-[#E2E5E9] px-5 py-3 text-sm font-bold !text-[#252932] transition hover:!bg-[#F1F3F6]"
                  >
                    <FiX size={17} />
                    Cancel
                  </button>
                </div>
              )}

              {message && (
                <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-semibold text-green-700 sm:col-span-2">
                  {message}
                </div>
              )}

              {errorMessage && (
                <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold !text-[#B51F35] sm:col-span-2">
                  {errorMessage}
                </div>
              )}
            </div>
          </section>

          <section className="rounded-3xl !border !border-[#E2E5E9] !bg-white shadow-[0_4px_20px_rgba(0,0,0,0.04)]">
            <div className="border-b !border-[#E2E5E9] px-6 py-5">
              <h2 className="text-lg font-bold !text-[#111318]">
                Account details
              </h2>

              <p className="mt-1 text-sm !text-[#69707D]">
                Your FlashFinance account information.
              </p>
            </div>

            <div className="divide-y divide-[#E2E5E9]">
              <div className="flex items-center gap-4 px-6 py-5">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl !bg-[#F1F3F6]">
                  <FiShield size={19} className="!text-[#B51F35]" />
                </div>

                <div>
                  <p className="text-xs !text-[#69707D]">
                    Account status
                  </p>

                  <p className="mt-1 text-sm font-bold !text-[#111318]">
                    {status}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 px-6 py-5">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl !bg-[#F1F3F6]">
                  <FiCalendar size={19} className="!text-[#B51F35]" />
                </div>

                <div>
                  <p className="text-xs !text-[#69707D]">
                    Date opened
                  </p>

                  <p className="mt-1 text-sm font-bold !text-[#111318]">
                    {formatDate(profile.created_at)}
                  </p>
                </div>
              </div>

              <div className="px-6 py-5">
                <div className="flex items-center gap-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl !bg-[#F1F3F6]">
                    <FiCreditCard size={19} className="!text-[#B51F35]" />
                  </div>

                  <div className="min-w-0">
                    <p className="text-xs !text-[#69707D]">
                      Account ID
                    </p>

                    <p className="mt-1 truncate font-mono text-xs font-semibold !text-[#252932]">
                      {profile.id}
                    </p>
                  </div>
                </div>

                <button
                  onClick={copyAccountId}
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl !border !border-[#E2E5E9] py-2.5 text-xs font-bold !text-[#252932] transition hover:!bg-[#F1F3F6]"
                >
                  {copied ? (
                    <>
                      <FiCheck size={15} />
                      Account ID copied
                    </>
                  ) : (
                    <>
                      <FiCopy size={15} />
                      Copy account ID
                    </>
                  )}
                </button>
              </div>
            </div>
          </section>
        </div>

        <section className="mt-6 overflow-hidden rounded-3xl !border !border-[#E2E5E9] !bg-white shadow-[0_4px_20px_rgba(0,0,0,0.04)]">
          <div className="border-b !border-[#E2E5E9] px-6 py-5">
            <h2 className="text-lg font-bold !text-[#111318]">
              Account management
            </h2>

            <p className="mt-1 text-sm !text-[#69707D]">
              Manage security, notifications, preferences and support.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                key: "security",
                icon: FiLock,
                title: "Login & security",
                description: "Password and account security",
              },
              {
                key: "notifications",
                icon: FiBell,
                title: "Notifications",
                description: "Transaction and account alerts",
              },
              {
                key: "preferences",
                icon: FiSettings,
                title: "Preferences",
                description: "Customize your account experience",
              },
              {
                key: "statements",
                icon: FiFileText,
                title: "Statements & documents",
                description: "Account records and documents",
              },
              {
                key: "activity",
                icon: FiActivity,
                title: "Account activity",
                description: "Recent account activity",
              },
              {
                key: "support",
                icon: FiHelpCircle,
                title: "Help & support",
                description: "Get help with your account",
              },
            ].map((item) => {
              const Icon = item.icon;

              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => openPanel(item.key)}
                  className="flex items-center justify-between border-b !border-[#E2E5E9] px-6 py-5 text-left transition hover:!bg-[#F8F9FB] lg:border-r lg:!border-[#E2E5E9] lg:[&:nth-child(3n)]:border-r-0"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl !bg-[#F1F3F6]">
                      <Icon size={19} className="!text-[#B51F35]" />
                    </div>

                    <div>
                      <p className="text-sm font-bold !text-[#111318]">
                        {item.title}
                      </p>

                      <p className="mt-1 text-xs !text-[#69707D]">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  <FiChevronRight
                    size={19}
                    className="!text-[#9298A3]"
                  />
                </button>
              );
            })}
          </div>
        </section>

        <button
          onClick={signOut}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl !border !border-red-200 !bg-white py-4 text-sm font-bold !text-[#B51F35] shadow-sm transition hover:!bg-red-50"
        >
          <FiLogOut size={18} />
          Sign out of FlashFinance
        </button>
      </div>

      {activePanel && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#0B0E17]/75 p-0 backdrop-blur-sm sm:items-center sm:p-6">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-t-3xl !border !border-[#E2E5E9] !bg-white shadow-2xl sm:rounded-3xl">
            <div className="sticky top-0 z-10 flex items-center justify-between !border-b !border-[#E2E5E9] !bg-white/95 px-6 py-5 backdrop-blur">
              <div>
                <h2 className="text-lg font-bold !text-[#111318]">
                  {activePanel === "security" && "Login & security"}
                  {activePanel === "notifications" && "Notifications"}
                  {activePanel === "preferences" && "Preferences"}
                  {activePanel === "statements" &&
                    "Statements & documents"}
                  {activePanel === "activity" && "Account activity"}
                  {activePanel === "support" && "Help & support"}
                </h2>

                <p className="mt-1 text-xs !text-[#69707D]">
                  FlashFinance account management
                </p>
              </div>

              <button
                onClick={closePanel}
                className="flex h-9 w-9 items-center justify-center rounded-full !bg-[#F1F3F6] !text-[#69707D] transition hover:!bg-[#E2E5E9] hover:!text-[#111318]"
              >
                <FiX size={18} />
              </button>
            </div>

            <div className="p-6">
              {activePanel === "security" && (
                <div className="space-y-5">
                  <div className="rounded-2xl !bg-[#F1F3F6] p-5">
                    <div className="flex items-start gap-4">
                      <FiLock
                        size={21}
                        className="mt-0.5 !text-[#B51F35]"
                      />

                      <div>
                        <p className="text-sm font-bold !text-[#111318]">
                          Change your password
                        </p>

                        <p className="mt-1 text-sm leading-6 !text-[#69707D]">
                          Keep your FlashFinance account secure by
                          regularly updating your password.
                        </p>
                      </div>
                    </div>
                  </div>

                  {[
                    {
                      label: "Current password",
                      value: currentPassword,
                      setValue: setCurrentPassword,
                      show: showCurrentPassword,
                      setShow: setShowCurrentPassword,
                      placeholder: "Enter current password",
                    },
                    {
                      label: "New password",
                      value: newPassword,
                      setValue: setNewPassword,
                      show: showNewPassword,
                      setShow: setShowNewPassword,
                      placeholder: "Enter new password",
                    },
                    {
                      label: "Confirm new password",
                      value: confirmPassword,
                      setValue: setConfirmPassword,
                      show: showConfirmPassword,
                      setShow: setShowConfirmPassword,
                      placeholder: "Confirm new password",
                    },
                  ].map((field) => (
                    <div key={field.label}>
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wide !text-[#69707D]">
                        {field.label}
                      </label>

                      <div className="relative">
                        <input
                          type={field.show ? "text" : "password"}
                          value={field.value}
                          onChange={(e) =>
                            field.setValue(e.target.value)
                          }
                          className="w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 pr-12 text-sm !text-[#111318] outline-none focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                          placeholder={field.placeholder}
                        />

                        <button
                          type="button"
                          onClick={() =>
                            field.setShow(!field.show)
                          }
                          className="absolute right-3 top-1/2 -translate-y-1/2 !text-[#69707D] hover:!text-[#B51F35]"
                        >
                          {field.show ? (
                            <FiEyeOff size={18} />
                          ) : (
                            <FiEye size={18} />
                          )}
                        </button>
                      </div>

                      {field.label === "New password" && (
                        <p className="mt-2 text-xs leading-5 !text-[#9298A3]">
                          At least 8 characters with uppercase, lowercase
                          and a number.
                        </p>
                      )}
                    </div>
                  ))}

                  {passwordError && (
                    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold !text-[#B51F35]">
                      {passwordError}
                    </div>
                  )}

                  {passwordMessage && (
                    <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-semibold text-green-700">
                      {passwordMessage}
                    </div>
                  )}

                  <button
                    onClick={changePassword}
                    disabled={changingPassword}
                    className="flex w-full items-center justify-center gap-2 rounded-xl !bg-[#B51F35] py-3.5 text-sm font-bold text-white transition hover:!bg-[#C9213A] disabled:opacity-50"
                  >
                    <FiCheck size={17} />

                    {changingPassword
                      ? "Updating password..."
                      : "Update password"}
                  </button>
                </div>
              )}

              {activePanel === "notifications" && (
                <div className="space-y-3">
                  <div className="rounded-2xl !bg-[#F1F3F6] p-5">
                    <div className="flex items-start gap-4">
                      <FiBell
                        size={21}
                        className="mt-0.5 !text-[#B51F35]"
                      />

                      <div>
                        <p className="text-sm font-bold !text-[#111318]">
                          Notification preferences
                        </p>

                        <p className="mt-1 text-sm leading-6 !text-[#69707D]">
                          Choose which account alerts you want to
                          receive.
                        </p>
                      </div>
                    </div>
                  </div>

                  {[
                    {
                      key: "transactions" as const,
                      title: "Transaction alerts",
                      description:
                        "Get notified when money moves in or out of your account.",
                    },
                    {
                      key: "security" as const,
                      title: "Security alerts",
                      description:
                        "Receive alerts about sign-ins, password changes and security events.",
                    },
                    {
                      key: "payments" as const,
                      title: "Payment alerts",
                      description:
                        "Receive notifications when bills and other payments are processed.",
                    },
                    {
                      key: "marketing" as const,
                      title: "Offers and updates",
                      description:
                        "Receive FlashFinance product updates and special offers.",
                    },
                  ].map((item) => (
                    <div
                      key={item.key}
                      className="flex items-center justify-between gap-4 rounded-2xl !border !border-[#E2E5E9] !bg-white p-4"
                    >
                      <div>
                        <p className="text-sm font-bold !text-[#111318]">
                          {item.title}
                        </p>

                        <p className="mt-1 text-xs leading-5 !text-[#69707D]">
                          {item.description}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          saveNotificationSettings({
                            ...notifications,
                            [item.key]:
                              !notifications[item.key],
                          })
                        }
                        className={`relative h-7 w-12 shrink-0 rounded-full transition ${
                          notifications[item.key]
                            ? "bg-[#B51F35]"
                            : "bg-[#E2E5E9]"
                        }`}
                      >
                        <span
                          className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${
                            notifications[item.key]
                              ? "left-6"
                              : "left-1"
                          }`}
                        />
                      </button>
                    </div>
                  ))}

                  {settingsSaved && (
                    <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-semibold text-green-700">
                      Notification preferences saved.
                    </div>
                  )}
                </div>
              )}

              {activePanel === "preferences" && (
                <div className="space-y-4">
                  <div className="rounded-2xl !bg-[#F1F3F6] p-5">
                    <p className="text-sm font-bold !text-[#111318]">
                      Account preferences
                    </p>

                    <p className="mt-1 text-sm leading-6 !text-[#69707D]">
                      Customize how FlashFinance displays and handles
                      your account.
                    </p>
                  </div>

                  <div className="rounded-2xl !border !border-[#E2E5E9] !bg-white p-5">
                    <label className="text-sm font-bold !text-[#111318]">
                      Currency
                    </label>

                    <select
                      value={preferences.currency}
                      onChange={(e) =>
                        savePreferences({
                          ...preferences,
                          currency: e.target.value,
                        })
                      }
                      className="mt-4 w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3 text-sm !text-[#111318] outline-none focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    >
                      <option value="NGN">
                        NGN — Nigerian Naira
                      </option>
                      <option value="USD">USD — US Dollar</option>
                      <option value="GBP">
                        GBP — British Pound
                      </option>
                      <option value="EUR">EUR — Euro</option>
                    </select>
                  </div>

                  <div className="rounded-2xl !border !border-[#E2E5E9] !bg-white p-5">
                    <label className="text-sm font-bold !text-[#111318]">
                      Language
                    </label>

                    <select
                      value={preferences.language}
                      onChange={(e) =>
                        savePreferences({
                          ...preferences,
                          language: e.target.value,
                        })
                      }
                      className="mt-4 w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3 text-sm !text-[#111318] outline-none focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    >
                      <option value="English">English</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between rounded-2xl !border !border-[#E2E5E9] !bg-white p-5">
                    <div>
                      <p className="text-sm font-bold !text-[#111318]">
                        Transaction confirmation
                      </p>

                      <p className="mt-1 text-xs leading-5 !text-[#69707D]">
                        Ask for confirmation before completing
                        transactions.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        savePreferences({
                          ...preferences,
                          transactionConfirmation:
                            !preferences.transactionConfirmation,
                        })
                      }
                      className={`relative h-7 w-12 shrink-0 rounded-full transition ${
                        preferences.transactionConfirmation
                          ? "bg-[#B51F35]"
                          : "bg-[#E2E5E9]"
                      }`}
                    >
                      <span
                        className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${
                          preferences.transactionConfirmation
                            ? "left-6"
                            : "left-1"
                        }`}
                      />
                    </button>
                  </div>

                  {settingsSaved && (
                    <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-semibold text-green-700">
                      Preferences saved.
                    </div>
                  )}
                </div>
              )}

              {activePanel === "statements" && (
                <div className="space-y-4">
                  <div className="flex flex-col gap-3 rounded-2xl !bg-[#F1F3F6] p-5 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="text-sm font-bold !text-[#111318]">
                        Account statement
                      </p>

                      <p className="mt-1 text-xs !text-[#69707D]">
                        View and download your transactions.
                      </p>
                    </div>

                    <button
                      onClick={downloadStatement}
                      disabled={visibleTransactions.length === 0}
                      className="flex items-center justify-center gap-2 rounded-xl !bg-[#B51F35] px-4 py-3 text-xs font-bold text-white transition hover:!bg-[#C9213A] disabled:opacity-40"
                    >
                      <FiDownload size={15} />
                      Download
                    </button>
                  </div>

                  <div className="relative">
                    <FiSearch
                      size={17}
                      className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#9298A3]"
                    />

                    <input
                      value={transactionSearch}
                      onChange={(e) =>
                        setTransactionSearch(e.target.value)
                      }
                      placeholder="Search transactions..."
                      className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] py-3 pl-11 pr-4 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                    />
                  </div>

                  {loadingTransactions ? (
                    <div className="flex justify-center rounded-2xl !bg-[#F1F3F6] py-10">
                      <div className="h-7 w-7 animate-spin rounded-full !border-2 !border-[#E2E5E9] !border-t-[#B51F35]" />
                    </div>
                  ) : visibleTransactions.length === 0 ? (
                    <div className="rounded-2xl !bg-[#F1F3F6] p-8 text-center">
                      <FiFileText
                        size={28}
                        className="mx-auto !text-[#9298A3]"
                      />

                      <p className="mt-4 text-sm font-bold !text-[#111318]">
                        No statements available
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-hidden rounded-2xl !border !border-[#E2E5E9]">
                      <div className="max-h-[420px] overflow-y-auto">
                        {visibleTransactions.map((transaction) => (
                          <div
                            key={transaction.id}
                            className="border-b !border-[#E2E5E9] !bg-white p-4 last:border-b-0"
                          >
                            <div className="flex items-start justify-between gap-4">
                              <div className="min-w-0">
                                <p className="truncate text-sm font-bold !text-[#111318]">
                                  {transaction.description ||
                                    transaction.type ||
                                    "Transaction"}
                                </p>

                                <p className="mt-1 text-xs !text-[#9298A3]">
                                  {formatDateTime(
                                    transaction.created_at
                                  )}
                                </p>
                              </div>

                              <div className="text-right">
                                <p className="text-sm font-bold !text-[#111318]">
                                  {transaction.amount !== null &&
                                  transaction.amount !== undefined
                                    ? `${preferences.currency} ${Number(
                                        transaction.amount
                                      ).toLocaleString()}`
                                    : "—"}
                                </p>

                                <span className="mt-1 inline-flex rounded-full bg-green-50 px-2 py-1 text-[10px] font-bold text-green-700">
                                  {transaction.status || "Completed"}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activePanel === "activity" && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between rounded-2xl !bg-[#F1F3F6] p-5">
                    <div>
                      <p className="text-sm font-bold !text-[#111318]">
                        Recent account activity
                      </p>

                      <p className="mt-1 text-xs !text-[#69707D]">
                        Your latest account transactions.
                      </p>
                    </div>

                    <button
                      onClick={loadTransactions}
                      className="flex h-9 w-9 items-center justify-center rounded-xl !bg-white !text-[#69707D] hover:!bg-[#E2E5E9]"
                    >
                      <FiRefreshCw size={16} />
                    </button>
                  </div>

                  {loadingTransactions ? (
                    <div className="flex justify-center rounded-2xl !bg-[#F1F3F6] py-10">
                      <div className="h-7 w-7 animate-spin rounded-full !border-2 !border-[#E2E5E9] !border-t-[#B51F35]" />
                    </div>
                  ) : transactions.length === 0 ? (
                    <div className="rounded-2xl !bg-[#F1F3F6] p-8 text-center">
                      <FiActivity
                        size={28}
                        className="mx-auto !text-[#9298A3]"
                      />

                      <p className="mt-4 text-sm font-bold !text-[#111318]">
                        No recent activity
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {transactions.slice(0, 20).map((transaction) => (
                        <div
                          key={transaction.id}
                          className="flex items-center gap-4 rounded-2xl !border !border-[#E2E5E9] !bg-white p-4"
                        >
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full !bg-[#F1F3F6]">
                            <FiActivity
                              size={17}
                              className="!text-[#B51F35]"
                            />
                          </div>

                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-bold !text-[#111318]">
                              {transaction.description ||
                                transaction.type ||
                                "Account transaction"}
                            </p>

                            <p className="mt-1 text-xs !text-[#9298A3]">
                              {formatDateTime(
                                transaction.created_at
                              )}
                            </p>
                          </div>

                          <span className="rounded-full bg-green-50 px-2.5 py-1 text-[10px] font-bold text-green-700">
                            {transaction.status || "Completed"}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activePanel === "support" && (
                <div className="space-y-5">
                  <div className="rounded-2xl !bg-[#F1F3F6] p-5">
                    <div className="flex items-start gap-4">
                      <FiHelpCircle
                        size={21}
                        className="mt-0.5 !text-[#B51F35]"
                      />

                      <div>
                        <p className="text-sm font-bold !text-[#111318]">
                          FlashFinance support
                        </p>

                        <p className="mt-1 text-sm leading-6 !text-[#69707D]">
                          Need help? Check the common questions or
                          send us a support request.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <p className="mb-3 text-sm font-bold !text-[#111318]">
                      Frequently asked questions
                    </p>

                    <div className="space-y-2">
                      {[
                        {
                          question:
                            "How do I change my password?",
                          answer:
                            "Open Login & security from your Profile page, enter your current password and create a new password.",
                        },
                        {
                          question:
                            "How do I update my personal information?",
                          answer:
                            "Use the Edit profile button to update your name, email and phone number.",
                        },
                        {
                          question:
                            "Where can I see my transactions?",
                          answer:
                            "Open Statements & documents or Account activity from Account management.",
                        },
                        {
                          question:
                            "How do I change my notification settings?",
                          answer:
                            "Open Notifications and use the switches to enable or disable individual alerts.",
                        },
                        {
                          question:
                            "How do I upload a profile picture?",
                          answer:
                            "Use the camera button on your profile picture and select an image from your device.",
                        },
                      ].map((faq, index) => (
                        <div
                          key={faq.question}
                          className="overflow-hidden rounded-2xl !border !border-[#E2E5E9] !bg-white"
                        >
                          <button
                            onClick={() =>
                              setOpenFaq(
                                openFaq === index ? null : index
                              )
                            }
                            className="flex w-full items-center justify-between gap-4 px-4 py-4 text-left"
                          >
                            <span className="text-sm font-semibold !text-[#111318]">
                              {faq.question}
                            </span>

                            <FiChevronDown
                              size={17}
                              className={`shrink-0 !text-[#9298A3] transition ${
                                openFaq === index
                                  ? "rotate-180"
                                  : ""
                              }`}
                            />
                          </button>

                          {openFaq === index && (
                            <div className="border-t !border-[#E2E5E9] px-4 py-4">
                              <p className="text-xs leading-6 !text-[#69707D]">
                                {faq.answer}
                              </p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border-t !border-[#E2E5E9] pt-5">
                    <div className="mb-4 flex items-center gap-3">
                      <FiMessageCircle
                        size={19}
                        className="!text-[#B51F35]"
                      />

                      <div>
                        <p className="text-sm font-bold !text-[#111318]">
                          Contact support
                        </p>

                        <p className="mt-1 text-xs !text-[#69707D]">
                          Tell us what you need help with.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <input
                        value={supportSubject}
                        onChange={(e) =>
                          setSupportSubject(e.target.value)
                        }
                        placeholder="Subject"
                        className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                      />

                      <textarea
                        value={supportMessage}
                        onChange={(e) =>
                          setSupportMessage(e.target.value)
                        }
                        placeholder="Describe your issue..."
                        rows={5}
                        className="w-full resize-none rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-3.5 text-sm !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                      />

                      {supportError && (
                        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold !text-[#B51F35]">
                          {supportError}
                        </div>
                      )}

                      {supportSuccess && (
                        <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-semibold text-green-700">
                          {supportSuccess}
                        </div>
                      )}

                      <button
                        onClick={sendSupportRequest}
                        disabled={sendingSupport}
                        className="flex w-full items-center justify-center gap-2 rounded-xl !bg-[#B51F35] py-3.5 text-sm font-bold text-white transition hover:!bg-[#C9213A] disabled:opacity-50"
                      >
                        <FiMessageCircle size={17} />

                        {sendingSupport
                          ? "Sending..."
                          : "Submit support request"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}