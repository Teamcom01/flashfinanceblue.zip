"use client";

import {
  Suspense,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase";
import {
  SiPaypal,
  SiCashapp,
  SiZelle,
  SiVenmo,
  SiBitcoin,
} from "react-icons/si";

type PaymentMethod =
  | "PayPal"
  | "Cash App"
  | "Bitcoin"
  | "Bank Transfer"
  | "Zelle"
  | "Venmo"
  | "Chime"
  | "USDT"
  | "Ethereum";

type PaymentMethodKey =
  | "paypal"
  | "cashapp"
  | "bitcoin"
  | "bank"
  | "zelle"
  | "venmo"
  | "chime"
  | "usdt"
  | "ethereum";

type PaymentMethodRow = {
  id: string;
  name: string;
  type: string;
  details: Record<string, unknown> | null;
  is_active: boolean | null;
  sort_order: number | null;
  created_at?: string | null;
  updated_at?: string | null;
};

type PaymentInformationField = {
  label: string;
  value: string;
};

type PaymentInstructions = {
  title: string;
  description: string;
  fields: PaymentInformationField[];
  instructions: string;
};

const paymentMethods: {
  name: PaymentMethod;
  key: PaymentMethodKey;
  Icon: React.ComponentType<{ size?: number; className?: string }> | null;
}[] = [
  {
    name: "PayPal",
    key: "paypal",
    Icon: SiPaypal,
  },
  {
    name: "Cash App",
    key: "cashapp",
    Icon: SiCashapp,
  },
  {
    name: "Bitcoin",
    key: "bitcoin",
    Icon: SiBitcoin,
  },
  {
    name: "Bank Transfer",
    key: "bank",
    Icon: null,
  },
  {
    name: "Zelle",
    key: "zelle",
    Icon: SiZelle,
  },
  {
    name: "Venmo",
    key: "venmo",
    Icon: SiVenmo,
  },
  {
    name: "Chime",
    key: "chime",
    Icon: null,
  },
  {
    name: "USDT",
    key: "usdt",
    Icon: null,
  },
  {
    name: "Ethereum",
    key: "ethereum",
    Icon: null,
  },
];

function normalizePaymentMethod(value: unknown): PaymentMethodKey | null {
  const normalized = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ");

  if (normalized.includes("paypal")) {
    return "paypal";
  }

  if (
    normalized === "cashapp" ||
    normalized === "cash app" ||
    normalized.includes("cash app") ||
    normalized.includes("cashapp")
  ) {
    return "cashapp";
  }

  if (
    normalized === "bitcoin" ||
    normalized === "btc" ||
    normalized.includes("bitcoin")
  ) {
    return "bitcoin";
  }

  if (
    normalized === "bank" ||
    normalized === "bank transfer" ||
    normalized.includes("bank transfer")
  ) {
    return "bank";
  }

  if (normalized.includes("zelle")) {
    return "zelle";
  }

  if (normalized.includes("venmo")) {
    return "venmo";
  }

  if (normalized.includes("chime")) {
    return "chime";
  }

  if (
    normalized === "usdt" ||
    normalized === "tether" ||
    normalized.includes("usdt") ||
    normalized.includes("tether")
  ) {
    return "usdt";
  }

  if (
    normalized === "ethereum" ||
    normalized === "eth" ||
    normalized.includes("ethereum")
  ) {
    return "ethereum";
  }

  return null;
}

function parsePaymentDetails(value: unknown): Record<string, unknown> {
  if (!value) {
    return {};
  }

  if (
    typeof value === "object" &&
    !Array.isArray(value)
  ) {
    return value as Record<string, unknown>;
  }

  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);

      if (
        parsed &&
        typeof parsed === "object" &&
        !Array.isArray(parsed)
      ) {
        return parsed as Record<string, unknown>;
      }
    } catch {
      return {};
    }
  }

  return {};
}

function textValue(value: unknown): string {
  if (
    value === null ||
    value === undefined
  ) {
    return "";
  }

  if (
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean"
  ) {
    return String(value).trim();
  }

  return "";
}

function normalizeKey(value: string): string {
  return value
    .toLowerCase()
    .replace(/[_\-\s]+/g, "");
}

function getValueFromObject(
  object: Record<string, unknown>,
  keys: string[],
): string {
  const wanted = new Set(
    keys.map((key) => normalizeKey(key)),
  );

  for (const [key, value] of Object.entries(object)) {
    if (!wanted.has(normalizeKey(key))) {
      continue;
    }

    const text = textValue(value);

    if (text) {
      return text;
    }
  }

  return "";
}

function getDepositDetails(
  details: Record<string, unknown>,
): Record<string, unknown> {
  const deposit = parsePaymentDetails(details.deposit);

  if (Object.keys(deposit).length > 0) {
    return deposit;
  }

  return {};
}

function getAllPaymentObjects(
  details: Record<string, unknown>,
): Record<string, unknown>[] {
  const result: Record<string, unknown>[] = [];

  const visit = (value: unknown) => {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value)
    ) {
      return;
    }

    const object = value as Record<string, unknown>;

    result.push(object);

    for (const child of Object.values(object)) {
      visit(child);
    }
  };

  visit(details);

  return result;
}

function findAnywhere(
  details: Record<string, unknown>,
  keys: string[],
): string {
  const objects = getAllPaymentObjects(details);

  for (const object of objects) {
    const value = getValueFromObject(
      object,
      keys,
    );

    if (value) {
      return value;
    }
  }

  return "";
}

function getField(
  deposit: Record<string, unknown>,
  details: Record<string, unknown>,
  keys: string[],
): string {
  return (
    getValueFromObject(deposit, keys) ||
    findAnywhere(details, keys)
  );
}

function addField(
  fields: PaymentInformationField[],
  label: string,
  value: string,
) {
  if (!value) {
    return;
  }

  fields.push({
    label,
    value,
  });
}

function getDepositFields(
  details: Record<string, unknown>,
  methodKey: PaymentMethodKey,
): PaymentInformationField[] {
  const deposit = getDepositDetails(details);
  const fields: PaymentInformationField[] = [];

  if (methodKey === "paypal") {
    addField(
      fields,
      "Account Name",
      getField(
        deposit,
        details,
        [
          "account_name",
          "paypal_account_name",
          "account",
          "name",
        ],
      ),
    );

    addField(
      fields,
      "Email",
      getField(
        deposit,
        details,
        [
          "email",
          "paypal_email",
          "email_address",
          "account_email",
        ],
      ),
    );

    return fields;
  }

  if (methodKey === "cashapp") {
    let cashtag = getField(
      deposit,
      details,
      [
        "cashtag",
        "cash_tag",
        "cashapp_tag",
        "cash_app_tag",
        "tag",
        "username",
      ],
    );

    if (
      cashtag &&
      !cashtag.startsWith("$")
    ) {
      cashtag = `$${cashtag}`;
    }

    addField(
      fields,
      "Account Name",
      getField(
        deposit,
        details,
        [
          "account_name",
          "cashapp_account_name",
          "cash_app_account_name",
          "account",
          "name",
        ],
      ),
    );

    addField(
      fields,
      "Cashtag",
      cashtag,
    );

    return fields;
  }

  if (methodKey === "zelle") {
    addField(
      fields,
      "Account Name",
      getField(
        deposit,
        details,
        [
          "account_name",
          "zelle_account_name",
          "account",
          "name",
        ],
      ),
    );

    addField(
      fields,
      "Email or Phone",
      getField(
        deposit,
        details,
        [
          "email_or_phone",
          "email",
          "phone",
          "zelle_email",
          "zelle_phone",
          "contact",
        ],
      ),
    );

    return fields;
  }

  if (methodKey === "venmo") {
    addField(
      fields,
      "Account Name",
      getField(
        deposit,
        details,
        [
          "account_name",
          "venmo_account_name",
          "account",
          "name",
        ],
      ),
    );

    addField(
      fields,
      "Username",
      getField(
        deposit,
        details,
        [
          "username",
          "venmo_username",
          "handle",
          "tag",
          "venmo",
        ],
      ),
    );

    return fields;
  }

  if (methodKey === "chime") {
    addField(
      fields,
      "Account Name",
      getField(
        deposit,
        details,
        [
          "account_name",
          "chime_account_name",
          "account",
          "name",
        ],
      ),
    );

    addField(
      fields,
      "Email",
      getField(
        deposit,
        details,
        [
          "email",
          "chime_email",
          "email_address",
          "account_email",
        ],
      ),
    );

    addField(
      fields,
      "Tag",
      getField(
        deposit,
        details,
        [
          "tag",
          "chime_tag",
          "username",
          "cashtag",
          "chime_username",
        ],
      ),
    );

    return fields;
  }

  if (
    methodKey === "bitcoin" ||
    methodKey === "ethereum" ||
    methodKey === "usdt"
  ) {
    const prefix = methodKey;

    addField(
      fields,
      "Network",
      getField(
        deposit,
        details,
        [
          "network",
          `${prefix}_network`,
          "blockchain",
          "chain",
          "network_name",
        ],
      ),
    );

    addField(
      fields,
      "Wallet Address",
      getField(
        deposit,
        details,
        [
          "wallet_address",
          "walletAddress",
          "address",
          `${prefix}_address`,
          `${prefix}_wallet_address`,
          "wallet",
        ],
      ),
    );

    return fields;
  }

  if (methodKey === "bank") {
    addField(
      fields,
      "Bank Name",
      getField(
        deposit,
        details,
        [
          "bank_name",
          "bank",
          "name_of_bank",
        ],
      ),
    );

    addField(
      fields,
      "Account Name",
      getField(
        deposit,
        details,
        [
          "account_name",
          "bank_account_name",
          "account_holder_name",
        ],
      ),
    );

    addField(
      fields,
      "Account Number",
      getField(
        deposit,
        details,
        [
          "account_number",
          "bank_account_number",
        ],
      ),
    );

    addField(
      fields,
      "Routing Number",
      getField(
        deposit,
        details,
        [
          "routing_number",
          "routing",
          "aba",
          "aba_routing",
        ],
      ),
    );

    addField(
      fields,
      "Account Type",
      getField(
        deposit,
        details,
        [
          "account_type",
          "bank_account_type",
        ],
      ),
    );

    addField(
      fields,
      "Swift Code",
      getField(
        deposit,
        details,
        [
          "swift_code",
          "swift_bic",
          "swift",
          "bic",
          "bic_code",
          "swift_bic_code",
        ],
      ),
    );

    addField(
      fields,
      "Bank Address",
      getField(
        deposit,
        details,
        [
          "bank_address",
          "address",
          "bank_location",
        ],
      ),
    );

    return fields;
  }

  for (const [key, value] of Object.entries(
    deposit,
  )) {
    if (
      key === "instructions" ||
      key === "instruction"
    ) {
      continue;
    }

    const text = textValue(value);

    if (!text) {
      continue;
    }

    fields.push({
      label: key
        .replace(/[_-]+/g, " ")
        .replace(/\b\w/g, (letter) =>
          letter.toUpperCase(),
        ),
      value: text,
    });
  }

  return fields;
}

function getDepositInstruction(
  details: Record<string, unknown>,
): string {
  const deposit = getDepositDetails(details);

  return getField(
    deposit,
    details,
    [
      "instructions",
      "instruction",
      "payment_instructions",
      "deposit_instructions",
    ],
  );
}

function getMethodTitle(
  method: PaymentMethod,
): string {
  return `${method} Payment`;
}

function getMethodDescription(
  method: PaymentMethod,
): string {
  switch (method) {
    case "PayPal":
      return "Send your payment using the PayPal information provided below.";

    case "Cash App":
      return "Send your payment using the Cash App information provided below.";

    case "Bitcoin":
      return "Send your Bitcoin payment using the Bitcoin information provided below.";

    case "Bank Transfer":
      return "Complete your bank transfer using the banking information provided below.";

    case "Zelle":
      return "Send your payment using the Zelle information provided below.";

    case "Venmo":
      return "Send your payment using the Venmo information provided below.";

    case "Chime":
      return "Complete your payment using the Chime information provided below.";

    case "USDT":
      return "Send your USDT payment using the wallet information provided below.";

    case "Ethereum":
      return "Send your Ethereum payment using the wallet information provided below.";

    default:
      return "Complete your payment using the payment information provided below.";
  }
}

function buildDepositPaymentInformation(
  details: Record<string, unknown>,
  method: PaymentMethod,
  methodKey: PaymentMethodKey,
): PaymentInstructions {
  return {
    title: getMethodTitle(method),
    description: getMethodDescription(method),
    fields: getDepositFields(
      details,
      methodKey,
    ),
    instructions:
      getDepositInstruction(details),
  };
}

function selectBestPaymentMethodRow(
  rows: PaymentMethodRow[],
  methodKey: PaymentMethodKey,
): PaymentMethodRow | null {
  const matchingRows = rows.filter(
    (row) => {
      const rowType =
        normalizePaymentMethod(row.type);

      const rowName =
        normalizePaymentMethod(row.name);

      return (
        rowType === methodKey ||
        rowName === methodKey
      );
    },
  );

  if (matchingRows.length === 0) {
    return null;
  }

  const activeRows =
    matchingRows.filter(
      (row) =>
        row.is_active !== false,
    );

  const candidates =
    activeRows.length > 0
      ? activeRows
      : matchingRows;

  return [...candidates].sort(
    (a, b) => {
      const sortA = Number(
        a.sort_order ?? 999999,
      );

      const sortB = Number(
        b.sort_order ?? 999999,
      );

      if (sortA !== sortB) {
        return sortA - sortB;
      }

      const updatedA =
        a.updated_at
          ? new Date(
              a.updated_at,
            ).getTime()
          : 0;

      const updatedB =
        b.updated_at
          ? new Date(
              b.updated_at,
            ).getTime()
          : 0;

      if (updatedA !== updatedB) {
        return updatedB - updatedA;
      }

      const createdA =
        a.created_at
          ? new Date(
              a.created_at,
            ).getTime()
          : 0;

      const createdB =
        b.created_at
          ? new Date(
              b.created_at,
            ).getTime()
          : 0;

      return createdB - createdA;
    },
  )[0];
}

function DepositPaymentContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const methodFromUrl =
    searchParams.get("method") as
      | PaymentMethod
      | null;

  const initialMethod =
    useMemo<PaymentMethod>(() => {
      if (
        methodFromUrl &&
        paymentMethods.some(
          (item) =>
            item.name === methodFromUrl,
        )
      ) {
        return methodFromUrl;
      }

      return "Zelle";
    }, [methodFromUrl]);

  const [paymentMethod, setPaymentMethod] =
    useState<PaymentMethod>(
      initialMethod,
    );

  const [amount, setAmount] =
    useState("");

  const [reference, setReference] =
    useState("");

  const [receiptFile, setReceiptFile] =
    useState<File | null>(null);

  const [
    paymentInformation,
    setPaymentInformation,
  ] =
    useState<PaymentInstructions | null>(
      null,
    );

  const [
    paymentInformationLoading,
    setPaymentInformationLoading,
  ] = useState(true);

  const [submitting, setSubmitting] =
    useState(false);

  const [submitted, setSubmitted] =
    useState(false);

  const [error, setError] =
    useState("");

  const refreshTimerRef =
    useRef<ReturnType<
      typeof setInterval
    > | null>(null);

  const selectedPaymentMethodConfig =
    paymentMethods.find(
      (method) =>
        method.name === paymentMethod,
    ) || paymentMethods[0];

  useEffect(() => {
    setPaymentMethod(initialMethod);
  }, [initialMethod]);

  const loadPaymentInformation =
    useCallback(
      async (showLoader = true) => {
        const methodKey =
          selectedPaymentMethodConfig.key;

        if (showLoader) {
          setPaymentInformationLoading(
            true,
          );
        }

        const supabase =
          createClient();

        try {
          const {
            data,
            error: paymentError,
          } = await supabase
            .from("payment_methods")
            .select(
              "id, name, type, details, is_active, sort_order, created_at, updated_at",
            )
            .order("sort_order", {
              ascending: true,
            })
            .order("updated_at", {
              ascending: false,
            });

          if (paymentError) {
            console.error(
              "Payment methods query failed:",
              paymentError,
            );

            if (showLoader) {
              setError(
                "Unable to load payment information. Please try again.",
              );
            }

            return;
          }

          const rows =
            (data || []) as PaymentMethodRow[];

          const selectedRow =
            selectBestPaymentMethodRow(
              rows,
              methodKey,
            );

          if (!selectedRow) {
            setPaymentInformation({
              title:
                getMethodTitle(
                  paymentMethod,
                ),
              description:
                getMethodDescription(
                  paymentMethod,
                ),
              fields: [],
              instructions: "",
            });

            return;
          }

          const details =
            parsePaymentDetails(
              selectedRow.details,
            );

          const information =
            buildDepositPaymentInformation(
              details,
              paymentMethod,
              methodKey,
            );

          setPaymentInformation(
            information,
          );

          setError("");
        } catch (loadError) {
          console.error(
            "Payment information loading error:",
            loadError,
          );

          if (showLoader) {
            setError(
              "Unable to load payment information. Please try again.",
            );
          }
        } finally {
          if (showLoader) {
            setPaymentInformationLoading(
              false,
            );
          }
        }
      },
      [
        paymentMethod,
        selectedPaymentMethodConfig.key,
      ],
    );

  useEffect(() => {
    loadPaymentInformation(true);
  }, [loadPaymentInformation]);

  useEffect(() => {
    const supabase = createClient();

    let mounted = true;

    const refresh = async () => {
      if (!mounted) {
        return;
      }

      await loadPaymentInformation(
        false,
      );
    };

    const channel = supabase
      .channel(
        `payment-methods-live-${selectedPaymentMethodConfig.key}`,
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "payment_methods",
        },
        () => {
          refresh();
        },
      )
      .subscribe((status) => {
        console.log(
          "Payment methods realtime status:",
          status,
        );
      });

    refreshTimerRef.current =
      setInterval(() => {
        refresh();
      }, 2000);

    const handleVisibilityChange =
      () => {
        if (
          document.visibilityState ===
          "visible"
        ) {
          refresh();
        }
      };

    document.addEventListener(
      "visibilitychange",
      handleVisibilityChange,
    );

    const handleFocus = () => {
      refresh();
    };

    window.addEventListener(
      "focus",
      handleFocus,
    );

    return () => {
      mounted = false;

      if (refreshTimerRef.current) {
        clearInterval(
          refreshTimerRef.current,
        );

        refreshTimerRef.current = null;
      }

      document.removeEventListener(
        "visibilitychange",
        handleVisibilityChange,
      );

      window.removeEventListener(
        "focus",
        handleFocus,
      );

      supabase.removeChannel(channel);
    };
  }, [
    loadPaymentInformation,
    selectedPaymentMethodConfig.key,
  ]);

  const formattedAmount = Number(
    amount || 0,
  ).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  async function handleSubmit(
    event: React.FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    setError("");

    const numericAmount =
      Number(amount);

    if (
      !numericAmount ||
      numericAmount <= 0
    ) {
      setError(
        "Please enter a valid deposit amount.",
      );

      return;
    }

    if (!receiptFile) {
      setError(
        "Please upload your payment receipt before submitting.",
      );

      return;
    }

    setSubmitting(true);

    try {
      const supabase =
        createClient();

      const {
        data: { user },
        error: userError,
      } =
        await supabase.auth.getUser();

      if (userError || !user) {
        setError(
          "Your session has expired. Please log in again.",
        );

        setSubmitting(false);

        return;
      }

      const fileExtension =
        receiptFile.name
          .split(".")
          .pop()
          ?.toLowerCase() ||
        "jpg";

      const filePath =
        `${user.id}/${crypto.randomUUID()}.${fileExtension}`;

      const {
        error: uploadError,
      } =
        await supabase.storage
          .from("payment-receipts")
          .upload(
            filePath,
            receiptFile,
            {
              cacheControl: "3600",
              upsert: false,
            },
          );

      if (uploadError) {
        console.error(uploadError);

        setError(
          "Unable to upload your receipt. Please try again.",
        );

        setSubmitting(false);

        return;
      }

      const {
        data: deposit,
        error: depositError,
      } =
        await supabase
          .from("deposits")
          .insert({
            user_id: user.id,
            amount: numericAmount,
            payment_method:
              paymentMethod,
            status: "pending",
            reference:
              reference.trim() || null,
            receipt_path:
              filePath,
          })
          .select()
          .single();

      if (
        depositError ||
        !deposit
      ) {
        console.error(
          depositError,
        );

        setError(
          "Unable to submit your deposit. Please try again.",
        );

        setSubmitting(false);

        return;
      }

      setSubmitted(true);
      setSubmitting(false);
    } catch (err) {
      console.error(err);

      setError(
        "Something went wrong. Please try again.",
      );

      setSubmitting(false);
    }
  }

  const hasConfiguredPaymentInformation =
    Boolean(
      paymentInformation &&
        paymentInformation.fields
          .length > 0,
    );

  return (
    <main className="min-h-screen !bg-[#F1F3F6] !text-[#111318]">
      <header className="border-b !border-[#E2E5E9] !bg-white">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          <button
            type="button"
            onClick={() =>
              router.push("/deposit")
            }
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold !text-[#69707D] transition hover:!bg-[#F1F3F6] hover:!text-[#B51F35]"
          >
            ← Back to Deposit
          </button>

          <div className="text-sm font-bold !text-[#0B0E17]">
            Flash
            <span className="!text-[#B51F35]">
              Finance
            </span>
          </div>

          <div className="w-24" />
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-10 sm:px-8">
        <div className="mb-8">
          <p className="mb-2 text-sm font-bold uppercase tracking-[0.2em] !text-[#B51F35]">
            FlashFinance
          </p>

          <h1 className="text-3xl font-bold !text-[#111318] md:text-4xl">
            Complete Your Deposit
          </h1>

          <p className="mt-3 max-w-2xl !text-[#69707D]">
            Review your payment details,
            complete your payment, upload
            your receipt, then submit the
            deposit for confirmation.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
            <h2 className="mb-5 text-xl font-semibold !text-[#111318]">
              Payment Method
            </h2>

            <div className="grid gap-3 sm:grid-cols-2">
              {paymentMethods.map(
                ({
                  name,
                  Icon,
                }) => {
                  const selected =
                    paymentMethod ===
                    name;

                  return (
                    <button
                      key={name}
                      type="button"
                      onClick={() => {
                        setPaymentMethod(
                          name,
                        );
                        setError("");
                      }}
                      className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
                        selected
                          ? "!border-[#B51F35] !bg-[#B51F35] text-white shadow-[0_6px_18px_rgba(181,31,53,0.16)]"
                          : "!border-[#E2E5E9] !bg-[#F8F9FB] !text-[#111318] hover:!border-[#B51F35]/40 hover:!bg-white"
                      }`}
                    >
                      {Icon ? (
                        <Icon
                          size={24}
                          className={
                            selected
                              ? "text-white"
                              : ""
                          }
                        />
                      ) : (
                        <div
                          className={`flex h-6 w-6 items-center justify-center rounded-full border text-xs ${
                            selected
                              ? "border-white text-white"
                              : "border-[#69707D] text-[#69707D]"
                          }`}
                        >
                          $
                        </div>
                      )}

                      <span className="font-medium">
                        {name}
                      </span>
                    </button>
                  );
                },
              )}
            </div>

            <div className="mt-8 rounded-2xl !border !border-[#B51F35]/20 !bg-[#B51F35]/5 p-5">
              <div className="mb-5">
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] !text-[#B51F35]">
                  Payment Information
                </p>

                <h3 className="text-xl font-bold !text-[#111318]">
                  {paymentInformation?.title ||
                    `${paymentMethod} Payment`}
                </h3>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  {paymentInformation?.description ||
                    getMethodDescription(
                      paymentMethod,
                    )}
                </p>
              </div>

              {paymentInformationLoading ? (
                <div className="rounded-xl !border !border-[#E2E5E9] !bg-white px-4 py-6 text-center">
                  <div className="mx-auto h-6 w-6 animate-spin rounded-full border-2 !border-[#E2E5E9] border-t-[#B51F35]" />

                  <p className="mt-3 text-sm !text-[#69707D]">
                    Loading payment
                    information...
                  </p>
                </div>
              ) : hasConfiguredPaymentInformation ? (
                <>
                  <div className="space-y-4">
                    {paymentInformation?.fields.map(
                      (
                        field,
                        index,
                      ) => (
                        <div
                          key={`${field.label}-${index}`}
                        >
                          <p className="mb-2 text-xs font-medium uppercase tracking-wider !text-[#69707D]">
                            {field.label}
                          </p>

                          <div className="break-all rounded-xl !border !border-[#E2E5E9] !bg-white px-4 py-4 font-semibold !text-[#B51F35]">
                            {
                              field.value
                            }
                          </div>
                        </div>
                      ),
                    )}
                  </div>

                  {paymentInformation?.instructions && (
                    <div className="mt-5 rounded-xl !border !border-[#E2E5E9] !bg-white p-4">
                      <p className="mb-2 text-xs font-bold uppercase tracking-wider !text-[#69707D]">
                        Payment
                        Instructions
                      </p>

                      <p className="whitespace-pre-wrap text-sm leading-6 !text-[#69707D]">
                        {
                          paymentInformation.instructions
                        }
                      </p>
                    </div>
                  )}
                </>
              ) : (
                <div className="rounded-xl !border !border-[#E2E5E9] !bg-white px-4 py-5">
                  <p className="font-semibold !text-[#111318]">
                    Payment information
                    is not configured
                    yet.
                  </p>

                  <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                    The administrator has
                    not configured the
                    deposit information
                    for{" "}
                    {paymentMethod}{" "}
                    yet. Please choose
                    another payment method
                    or try again later.
                  </p>
                </div>
              )}
            </div>

            <div className="mt-8">
              <label className="mb-2 block text-sm font-medium !text-[#252932]">
                Deposit Amount
              </label>

              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#B51F35]">
                  $
                </span>

                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={amount}
                  onChange={(e) =>
                    setAmount(
                      e.target.value,
                    )
                  }
                  placeholder="0.00"
                  className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-10 py-4 text-lg !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                />
              </div>
            </div>

            <div className="mt-6">
              <label className="mb-2 block text-sm font-medium !text-[#252932]">
                Payment Reference
                <span className="ml-2 !text-[#9298A3]">
                  (optional)
                </span>
              </label>

              <input
                type="text"
                value={reference}
                onChange={(e) =>
                  setReference(
                    e.target.value,
                  )
                }
                placeholder="Enter your payment reference"
                className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-4 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
              />
            </div>

            <div className="mt-6">
              <label className="mb-2 block text-sm font-medium !text-[#252932]">
                Payment Receipt
              </label>

              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(e) =>
                  setReceiptFile(
                    e.target.files?.[0] ||
                      null,
                  )
                }
                className="w-full rounded-xl border border-dashed !border-[#D7DBE1] !bg-[#F8F9FB] p-4 text-sm !text-[#69707D] file:mr-4 file:rounded-lg file:border-0 file:!bg-[#B51F35] file:px-4 file:py-2 file:font-semibold file:text-white"
              />

              {receiptFile && (
                <p className="mt-2 text-sm !text-[#69707D]">
                  Selected:{" "}
                  {receiptFile.name}
                </p>
              )}
            </div>
          </div>

          <div className="h-fit rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
            <h2 className="mb-5 text-xl font-semibold !text-[#111318]">
              Deposit Summary
            </h2>

            <div className="space-y-4">
              <div className="flex items-center justify-between border-b !border-[#E2E5E9] pb-4">
                <span className="!text-[#69707D]">
                  Payment Method
                </span>

                <span className="font-semibold !text-[#111318]">
                  {paymentMethod}
                </span>
              </div>

              <div className="flex items-center justify-between border-b !border-[#E2E5E9] pb-4">
                <span className="!text-[#69707D]">
                  Deposit Amount
                </span>

                <span className="font-semibold !text-[#111318]">
                  ${formattedAmount}
                </span>
              </div>

              <div className="flex items-center justify-between border-b !border-[#E2E5E9] pb-4">
                <span className="!text-[#69707D]">
                  Status
                </span>

                <span
                  className={
                    submitted
                      ? "font-semibold !text-[#B51F35]"
                      : "font-semibold !text-[#69707D]"
                  }
                >
                  {submitted
                    ? "Pending"
                    : "Ready to Submit"}
                </span>
              </div>
            </div>

            <div className="mt-6 rounded-xl !border !border-[#B51F35]/20 !bg-[#B51F35]/5 p-4">
              <h3 className="font-semibold !text-[#B51F35]">
                Payment Instructions
              </h3>

              <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                Complete your payment
                using the payment
                information shown above.
                Once your payment is
                confirmed, your balance
                will be updated and your
                deposit will be reflected
                in your account.
              </p>
            </div>

            {error && (
              <div className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">
                {error}
              </div>
            )}

            {submitted ? (
              <div className="mt-6 rounded-xl !border !border-[#B51F35]/20 !bg-[#B51F35]/5 p-5">
                <p className="font-semibold !text-[#B51F35]">
                  Deposit Submitted
                </p>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  Your deposit has been
                  submitted successfully.
                  Your balance will be
                  updated once your payment
                  has been confirmed.
                </p>

                <button
                  type="button"
                  onClick={() =>
                    router.push(
                      "/dashboard",
                    )
                  }
                  className="mt-5 w-full rounded-xl !bg-[#B51F35] px-5 py-3 font-semibold text-white transition hover:!bg-[#991B30]"
                >
                  Return to Dashboard
                </button>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
              >
                <button
                  type="submit"
                  disabled={submitting}
                  className="mt-6 w-full rounded-xl !bg-[#B51F35] px-5 py-4 font-bold text-white transition hover:!bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {submitting
                    ? "Submitting Deposit..."
                    : "Submit Deposit"}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

export default function DepositPaymentPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center !bg-[#F1F3F6] !text-[#111318]">
          <div className="text-center">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-2 !border-[#E2E5E9] border-t-[#B51F35]" />

            <p className="mt-4 text-sm !text-[#69707D]">
              Loading payment
              instructions...
            </p>
          </div>
        </main>
      }
    >
      <DepositPaymentContent />
    </Suspense>
  );
}