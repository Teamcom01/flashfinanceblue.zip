"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase";
import {
  SiPaypal,
  SiCashapp,
  SiZelle,
  SiVenmo,
  SiBitcoin,
} from "react-icons/si";

type PaymentMethod =
  | "PayPal"
  | "Cash App"
  | "Bitcoin"
  | "Bank Transfer"
  | "Zelle"
  | "Venmo"
  | "Chime";

const paymentMethods: {
  name: PaymentMethod;
  Icon: React.ComponentType<{ size?: number; className?: string }> | null;
}[] = [
  { name: "PayPal", Icon: SiPaypal },
  { name: "Cash App", Icon: SiCashapp },
  { name: "Bitcoin", Icon: SiBitcoin },
  { name: "Bank Transfer", Icon: null },
  { name: "Zelle", Icon: SiZelle },
  { name: "Venmo", Icon: SiVenmo },
  { name: "Chime", Icon: null },
];

function DepositPaymentContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();

  const methodFromUrl = searchParams.get("method") as PaymentMethod | null;

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(
    methodFromUrl &&
      paymentMethods.some((item) => item.name === methodFromUrl)
      ? methodFromUrl
      : "Zelle"
  );

  const [amount, setAmount] = useState("");
  const [reference, setReference] = useState("");
  const [receiptFile, setReceiptFile] = useState<File | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const formattedAmount = Number(amount || 0).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  function getPaymentInstructions() {
    switch (paymentMethod) {
      case "Bitcoin":
        return {
          title: "Bitcoin Payment",
          description:
            "Send your Bitcoin payment to your verified business Bitcoin address.",
          fields: [
            {
              label: "Bitcoin Address",
              value: "1zq2xVz3TwRNMyAFeKXAt5AKFr7QAEs9V",
            },
            {
              label: "Network",
              value: "Bitcoin (BTC)",
            },
          ],
        };

      case "Cash App":
        return {
          title: "Cash App Payment",
          description:
            "Send your payment to your verified business Cash App account.",
          fields: [
            {
              label: "Cash App Tag",
              value: "$FlashFinance",
            },
          ],
        };

      case "Zelle":
        return {
          title: "Zelle Payment",
          description:
            "Send your payment using your verified Zelle recipient information.",
          fields: [
            {
              label: "Zelle Email or Phone",
              value: "Zelleinvestpay@FlashFinance.com",
            },
            {
              label: "Recipient Name",
              value: "FlashFinance Invest",
            },
          ],
        };

      case "PayPal":
        return {
          title: "PayPal Payment",
          description:
            "Send your payment to your verified PayPal business account.",
          fields: [
            {
              label: "PayPal Email",
              value: "Paypalinvestpay@FlashFinance.com",
            },
          ],
        };

      case "Venmo":
        return {
          title: "Venmo Payment",
          description:
            "Send your payment to your verified Venmo business account.",
          fields: [
            {
              label: "Venmo Username",
              value: "Pay@FlashFinance",
            },
          ],
        };

      case "Bank Transfer":
        return {
          title: "Bank Transfer",
          description:
            "Use your verified business bank information to complete the transfer.",
          fields: [
            {
              label: "Bank Name",
              value: "Bank of America",
            },
            {
              label: "Account Name",
              value: "FlashFinance Invest",
            },
            {
              label: "Account Number",
              value: "6000535341",
            },
            {
              label: "Routing Number",
              value: "322271627",
            },
          ],
        };

      case "Chime":
        return {
          title: "Chime Payment",
          description:
            "Use your verified Chime payment information.",
          fields: [
            {
              label: "Chime Payment Information",
              value: "Chimeinvestpay@FlashFinance.com",
            },
          ],
        };
    }
  }

  const instructions = getPaymentInstructions();

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");

    const numericAmount = Number(amount);

    if (!numericAmount || numericAmount <= 0) {
      setError("Please enter a valid deposit amount.");
      return;
    }

    if (!receiptFile) {
      setError("Please upload your payment receipt before submitting.");
      return;
    }

    setSubmitting(true);

    try {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError || !user) {
        setError("Your session has expired. Please log in again.");
        setSubmitting(false);
        return;
      }

      const fileExtension =
        receiptFile.name.split(".").pop()?.toLowerCase() || "jpg";

      const filePath = `${user.id}/${crypto.randomUUID()}.${fileExtension}`;

      const { error: uploadError } = await supabase.storage
        .from("payment-receipts")
        .upload(filePath, receiptFile, {
          cacheControl: "3600",
          upsert: false,
        });

      if (uploadError) {
        console.error(uploadError);
        setError("Unable to upload your receipt. Please try again.");
        setSubmitting(false);
        return;
      }

      const { data: deposit, error: depositError } = await supabase
        .from("deposits")
        .insert({
          user_id: user.id,
          amount: numericAmount,
          payment_method: paymentMethod,
          status: "pending",
          reference: reference.trim() || null,
          receipt_path: filePath,
        })
        .select()
        .single();

      if (depositError || !deposit) {
        console.error(depositError);
        setError("Unable to submit your deposit. Please try again.");
        setSubmitting(false);
        return;
      }

      setSubmitted(true);
      setSubmitting(false);
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Please try again.");
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen !bg-[#F1F3F6] !text-[#111318]">
      <header className="border-b !border-[#E2E5E9] !bg-white">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          <button
            type="button"
            onClick={() => router.push("/deposit")}
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold !text-[#69707D] transition hover:!bg-[#F1F3F6] hover:!text-[#B51F35]"
          >
            ← Back to Deposit
          </button>

          <div className="text-sm font-bold !text-[#0B0E17]">
            Flash<span className="!text-[#B51F35]">Finance</span>
          </div>

          <div className="w-24" />
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-10 sm:px-8">
        <div className="mb-8">
          <p className="mb-2 text-sm font-bold uppercase tracking-[0.2em] !text-[#B51F35]">
            FlashFinance
          </p>

          <h1 className="text-3xl font-bold !text-[#111318] md:text-4xl">
            Complete Your Deposit
          </h1>

          <p className="mt-3 max-w-2xl !text-[#69707D]">
            Review your payment details, complete your payment, upload your
            receipt, then submit the deposit for confirmation.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
            <h2 className="mb-5 text-xl font-semibold !text-[#111318]">
              Payment Method
            </h2>

            <div className="grid gap-3 sm:grid-cols-2">
              {paymentMethods.map(({ name, Icon }) => {
                const selected = paymentMethod === name;

                return (
                  <button
                    key={name}
                    type="button"
                    onClick={() => {
                      setPaymentMethod(name);
                      setError("");
                    }}
                    className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
                      selected
                        ? "!border-[#B51F35] !bg-[#B51F35] text-white shadow-[0_6px_18px_rgba(181,31,53,0.16)]"
                        : "!border-[#E2E5E9] !bg-[#F8F9FB] !text-[#111318] hover:!border-[#B51F35]/40 hover:!bg-white"
                    }`}
                  >
                    {Icon ? (
                      <Icon
                        size={24}
                        className={selected ? "text-white" : ""}
                      />
                    ) : (
                      <div
                        className={`flex h-6 w-6 items-center justify-center rounded-full border text-xs ${
                          selected
                            ? "border-white text-white"
                            : "border-[#69707D] text-[#69707D]"
                        }`}
                      >
                        $
                      </div>
                    )}

                    <span className="font-medium">{name}</span>
                  </button>
                );
              })}
            </div>

            {/* PAYMENT DETAILS */}
            <div className="mt-8 rounded-2xl !border !border-[#B51F35]/20 !bg-[#B51F35]/5 p-5">
              <div className="mb-5">
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] !text-[#B51F35]">
                  Payment Information
                </p>

                <h3 className="text-xl font-bold !text-[#111318]">
                  {instructions.title}
                </h3>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  {instructions.description}
                </p>
              </div>

              <div className="space-y-4">
                {instructions.fields.map((field) => (
                  <div key={field.label}>
                    <p className="mb-2 text-xs font-medium uppercase tracking-wider !text-[#69707D]">
                      {field.label}
                    </p>

                    <div className="break-all rounded-xl !border !border-[#E2E5E9] !bg-white px-4 py-4 font-semibold !text-[#B51F35]">
                      {field.value}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* DEPOSIT AMOUNT */}
            <div className="mt-8">
              <label className="mb-2 block text-sm font-medium !text-[#252932]">
                Deposit Amount
              </label>

              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 !text-[#B51F35]">
                  $
                </span>

                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-10 py-4 text-lg !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
                />
              </div>
            </div>

            {/* PAYMENT REFERENCE */}
            <div className="mt-6">
              <label className="mb-2 block text-sm font-medium !text-[#252932]">
                Payment Reference
                <span className="ml-2 !text-[#9298A3]">(optional)</span>
              </label>

              <input
                type="text"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="Enter your payment reference"
                className="w-full rounded-xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-4 !text-[#111318] outline-none transition placeholder:!text-[#9298A3] focus:!border-[#B51F35] focus:ring-2 focus:ring-[#B51F35]/10"
              />
            </div>

            {/* RECEIPT */}
            <div className="mt-6">
              <label className="mb-2 block text-sm font-medium !text-[#252932]">
                Payment Receipt
              </label>

              <input
                type="file"
                accept="image/*,.pdf"
                onChange={(e) =>
                  setReceiptFile(e.target.files?.[0] || null)
                }
                className="w-full rounded-xl border border-dashed !border-[#D7DBE1] !bg-[#F8F9FB] p-4 text-sm !text-[#69707D] file:mr-4 file:rounded-lg file:border-0 file:!bg-[#B51F35] file:px-4 file:py-2 file:font-semibold file:text-white"
              />

              {receiptFile && (
                <p className="mt-2 text-sm !text-[#69707D]">
                  Selected: {receiptFile.name}
                </p>
              )}
            </div>
          </div>

          {/* SUMMARY */}
          <div className="h-fit rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)]">
            <h2 className="mb-5 text-xl font-semibold !text-[#111318]">
              Deposit Summary
            </h2>

            <div className="space-y-4">
              <div className="flex items-center justify-between border-b !border-[#E2E5E9] pb-4">
                <span className="!text-[#69707D]">
                  Payment Method
                </span>

                <span className="font-semibold !text-[#111318]">
                  {paymentMethod}
                </span>
              </div>

              <div className="flex items-center justify-between border-b !border-[#E2E5E9] pb-4">
                <span className="!text-[#69707D]">
                  Deposit Amount
                </span>

                <span className="font-semibold !text-[#111318]">
                  ${formattedAmount}
                </span>
              </div>

              <div className="flex items-center justify-between border-b !border-[#E2E5E9] pb-4">
                <span className="!text-[#69707D]">
                  Status
                </span>

                <span
                  className={
                    submitted
                      ? "font-semibold !text-[#B51F35]"
                      : "font-semibold !text-[#69707D]"
                  }
                >
                  {submitted ? "Pending" : "Ready to Submit"}
                </span>
              </div>
            </div>

            <div className="mt-6 rounded-xl !border !border-[#B51F35]/20 !bg-[#B51F35]/5 p-4">
              <h3 className="font-semibold !text-[#B51F35]">
                Payment Instructions
              </h3>

              <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                Complete your payment using the payment information shown
                above. Once your payment is confirmed, your balance will be
                updated promptly and your deposit will be reflected in your
                account.
              </p>
            </div>

            {error && (
              <div className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-600">
                {error}
              </div>
            )}

            {submitted ? (
              <div className="mt-6 rounded-xl !border !border-[#B51F35]/20 !bg-[#B51F35]/5 p-5">
                <p className="font-semibold !text-[#B51F35]">
                  Deposit Submitted
                </p>

                <p className="mt-2 text-sm leading-6 !text-[#69707D]">
                  Your deposit has been submitted successfully. Your balance
                  will be updated once your payment has been confirmed.
                </p>

                <button
                  type="button"
                  onClick={() => router.push("/dashboard")}
                  className="mt-5 w-full rounded-xl !bg-[#B51F35] px-5 py-3 font-semibold text-white transition hover:!bg-[#991B30]"
                >
                  Return to Dashboard
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <button
                  type="submit"
                  disabled={submitting}
                  className="mt-6 w-full rounded-xl !bg-[#B51F35] px-5 py-4 font-bold text-white transition hover:!bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {submitting
                    ? "Submitting Deposit..."
                    : "Submit Deposit"}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

export default function DepositPaymentPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center !bg-[#F1F3F6] !text-[#111318]">
          <div className="text-center">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-2 !border-[#E2E5E9] border-t-[#B51F35]" />

            <p className="mt-4 text-sm !text-[#69707D]">
              Loading payment instructions...
            </p>
          </div>
        </main>
      }
    >
      <DepositPaymentContent />
    </Suspense>
  );
}