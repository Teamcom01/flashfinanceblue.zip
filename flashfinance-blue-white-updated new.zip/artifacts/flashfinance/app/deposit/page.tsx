"use client";

import {
  Suspense,
  useEffect,
  useMemo,
  useState,
  type ChangeEvent,
  type FormEvent,
} from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase";
import {
  FiAlertCircle,
  FiArrowLeft,
  FiArrowRight,
  FiCheck,
  FiCheckCircle,
  FiChevronRight,
  FiCopy,
  FiInfo,
  FiLock,
  FiShield,
  FiUploadCloud,
  FiX,
} from "react-icons/fi";
import {
  SiBitcoin,
  SiCashapp,
  SiPaypal,
  SiVenmo,
  SiZelle,
} from "react-icons/si";

type PaymentMethod =
  | "PayPal"
  | "Cash App"
  | "Bitcoin"
  | "Bank Transfer"
  | "Zelle"
  | "Venmo"
  | "Chime"
  | "USDT"
  | "Ethereum";

type PaymentDetails = Record<string, unknown>;

type PaymentMethodRecord = {
  name: string;
  details: PaymentDetails | null;
  is_active: boolean | null;
};

type PaymentFieldDefinition = {
  key: string;
  label: string;
  type?: "text" | "multiline";
};

type FieldValue = {
  key: string;
  label: string;
  value: string;
};

const paymentMethods: { name: PaymentMethod }[] = [
  { name: "PayPal" },
  { name: "Cash App" },
  { name: "Bitcoin" },
  { name: "Bank Transfer" },
  { name: "Zelle" },
  { name: "Venmo" },
  { name: "Chime" },
  { name: "USDT" },
  { name: "Ethereum" },
];

const methodFieldDefinitions: Record<
  PaymentMethod,
  PaymentFieldDefinition[]
> = {
  PayPal: [
    { key: "accountName", label: "Account Name" },
    { key: "email", label: "Email" },
  ],

  "Cash App": [
    { key: "accountName", label: "Account Name" },
    { key: "cashtag", label: "Cashtag" },
  ],

  Bitcoin: [
    { key: "network", label: "Network" },
    {
      key: "walletAddress",
      label: "Wallet Address",
      type: "multiline",
    },
  ],

  "Bank Transfer": [
    { key: "bankName", label: "Bank Name" },
    { key: "accountName", label: "Account Name" },
    { key: "accountNumber", label: "Account Number" },
    { key: "routingNumber", label: "Routing Number" },
    { key: "accountType", label: "Account Type" },
    { key: "swiftCode", label: "Swift Code" },
  ],

  Zelle: [
    { key: "accountName", label: "Account Name" },
    { key: "emailOrPhone", label: "Email Or Phone" },
  ],

  Venmo: [
    { key: "accountName", label: "Account Name" },
    { key: "username", label: "Username" },
  ],

  Chime: [
    { key: "accountName", label: "Account Name" },
    { key: "email", label: "Email" },
  ],

  USDT: [
    { key: "network", label: "Network" },
    {
      key: "walletAddress",
      label: "Wallet Address",
      type: "multiline",
    },
  ],

  Ethereum: [
    { key: "network", label: "Network" },
    {
      key: "walletAddress",
      label: "Wallet Address",
      type: "multiline",
    },
  ],
};

const paymentDescriptions: Record<PaymentMethod, string> = {
  PayPal: "Secure digital payment channel",
  "Cash App": "Fast peer to peer transfer",
  Bitcoin: "Blockchain network transfer",
  "Bank Transfer": "Direct banking settlement",
  Zelle: "Instant bank linked transfer",
  Venmo: "Digital wallet transfer",
  Chime: "Digital banking transfer",
  USDT: "Stablecoin blockchain transfer",
  Ethereum: "Ethereum network transfer",
};

function normalizeKey(value: string) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function isForbiddenKey(key: string) {
  const normalized = normalizeKey(key);

  return (
    normalized.includes("fee") ||
    normalized.includes("destination") ||
    normalized.includes("walletlabel") ||
    normalized.includes("accounttype") ||
    normalized.includes("bankaddress")
  );
}

function stringValueObject(value: unknown): string {
  if (typeof value === "string") {
    return value.trim();
  }

  if (typeof value === "number" || typeof value === "boolean") {
    return String(value).trim();
  }

  return "";
}

function getDepositFields(method: PaymentMethod) {
  return methodFieldDefinitions[method];
}

function getMethodAliases(method: PaymentMethod): string[] {
  switch (method) {
    case "PayPal":
      return ["paypal", "paypals"];

    case "Cash App":
      return ["cashapp", "cash", "cashapptransfer"];

    case "Bitcoin":
      return ["bitcoin", "btc"];

    case "Bank Transfer":
      return ["banktransfer", "bank", "wiretransfer", "bankwire"];

    case "Zelle":
      return ["zelle"];

    case "Venmo":
      return ["venmo"];

    case "Chime":
      return ["chime"];

    case "USDT":
      return ["usdt", "tether"];

    case "Ethereum":
      return ["ethereum", "eth"];

    default:
      return [];
  }
}

function getNestedMethodObjects(
  details: PaymentDetails,
  method: PaymentMethod,
): PaymentDetails[] {
  const aliases = getMethodAliases(method);
  const output: PaymentDetails[] = [];

  for (const key of Object.keys(details)) {
    const normalized = normalizeKey(key);

    if (!aliases.includes(normalized)) {
      continue;
    }

    const value = details[key];

    if (
      value &&
      typeof value === "object" &&
      !Array.isArray(value)
    ) {
      output.push(value as PaymentDetails);
    }
  }

  return output;
}

function candidateKeysForField(
  method: PaymentMethod,
  field: PaymentFieldDefinition,
): string[] {
  const methodAliasMap: Record<PaymentMethod, string[]> = {
    PayPal: ["paypal", "paypalaccount", "paypalpayment"],
    "Cash App": [
      "cashapp",
      "cashappaccount",
      "cashappaccountdetails",
    ],
    Bitcoin: ["bitcoin", "btc"],
    "Bank Transfer": [
      "banktransfer",
      "bank",
      "wiretransfer",
    ],
    Zelle: ["zelle"],
    Venmo: ["venmo"],
    Chime: ["chime"],
    USDT: ["usdt", "tether"],
    Ethereum: ["ethereum", "eth"],
  };

  const aliases = methodAliasMap[method];

  const fieldAliases: Record<string, string[]> = {
    accountName: ["accountname", "name", "account"],
    email: ["email", "emailaddress"],
    cashtag: [
      "cashtag",
      "cashtagname",
      "cashtagid",
      "cashtagvalue",
      "cashtagaccount",
      "cashtagusername",
      "cashapptag",
    ],
    network: [
      "network",
      "networkname",
      "chain",
      "blockchain",
    ],
    walletAddress: [
      "walletaddress",
      "address",
      "wallet",
      "walletid",
    ],
    bankName: [
      "bankname",
      "bank",
      "financialinstitution",
    ],
    accountNumber: [
      "accountnumber",
      "acctnumber",
      "accountno",
    ],
    routingNumber: [
      "routingnumber",
      "routing",
      "routingno",
    ],
    swiftCode: ["swiftcode", "swift", "bic"],
    emailOrPhone: [
      "emailorphone",
      "emailphone",
      "emailorphonenumber",
      "phone",
      "phonenumber",
      "zelleemailphone",
    ],
    username: ["username", "user", "venmousername"],
  };

  const fieldAliasesForCurrentField =
    fieldAliases[field.key] || [normalizeKey(field.key)];

  const keys: string[] = [];

  for (const alias of aliases) {
    for (const fieldAlias of fieldAliasesForCurrentField) {
      keys.push(`${alias}${fieldAlias}`);
      keys.push(`deposit${alias}${fieldAlias}`);
      keys.push(`${alias}deposit${fieldAlias}`);
      keys.push(`deposit${fieldAlias}${alias}`);
    }
  }

  for (const fieldAlias of fieldAliasesForCurrentField) {
    keys.push(fieldAlias);
    keys.push(`deposit${fieldAlias}`);
  }

  return keys;
}

function getFieldValue(
  details: PaymentDetails,
  method: PaymentMethod,
  field: PaymentFieldDefinition,
): string {
  const nestedObjects = getNestedMethodObjects(details, method);
  const directEntries = Object.entries(details);

  const candidateKeys = candidateKeysForField(
    method,
    field,
  ).map(normalizeKey);

  for (const candidate of candidateKeys) {
    for (const [key, value] of directEntries) {
      if (
        normalizeKey(key) === candidate &&
        !isForbiddenKey(key)
      ) {
        const result = stringValueObject(value);

        if (result) {
          return result;
        }
      }
    }
  }

  for (const nested of nestedObjects) {
    const nestedEntries = Object.entries(nested);

    for (const candidate of candidateKeys) {
      for (const [key, value] of nestedEntries) {
        if (
          normalizeKey(key) === candidate ||
          normalizeKey(key) ===
            normalizeKey(
              candidate.replace(
                getMethodAliases(method)[0] || "",
                "",
              ),
            )
        ) {
          if (isForbiddenKey(key)) {
            continue;
          }

          const result = stringValueObject(value);

          if (result) {
            return result;
          }
        }
      }
    }

    for (const [key, value] of nestedEntries) {
      if (isForbiddenKey(key)) {
        continue;
      }

      const normalizedKey = normalizeKey(key);

      if (
        field.key === "accountName" &&
        (normalizedKey === "accountname" ||
          normalizedKey === "name")
      ) {
        const result = stringValueObject(value);

        if (result) {
          return result;
        }
      }

      if (
        field.key === "email" &&
        normalizedKey === "email"
      ) {
        const result = stringValueObject(value);

        if (result) {
          return result;
        }
      }

      if (
        field.key === "walletAddress" &&
        (normalizedKey === "walletaddress" ||
          normalizedKey === "address" ||
          normalizedKey === "wallet")
      ) {
        const result = stringValueObject(value);

        if (result) {
          return result;
        }
      }

      if (
        field.key === "network" &&
        (normalizedKey === "network" ||
          normalizedKey === "chain" ||
          normalizedKey === "blockchain")
      ) {
        const result = stringValueObject(value);

        if (result) {
          return result;
        }
      }
    }
  }

  return "";
}

function parsePaymentDetails(
  details: unknown,
): PaymentDetails {
  if (
    details &&
    typeof details === "object" &&
    !Array.isArray(details)
  ) {
    return details as PaymentDetails;
  }

  return {};
}

function getPaymentShortLabel(method: PaymentMethod): string {
  switch (method) {
    case "PayPal":
      return "PP";
    case "Cash App":
      return "$";
    case "Bitcoin":
      return "₿";
    case "Bank Transfer":
      return "BT";
    case "Zelle":
      return "Z";
    case "Venmo":
      return "V";
    case "Chime":
      return "C";
    case "USDT":
      return "₮";
    case "Ethereum":
      return "Ξ";
    default:
      return "?";
  }
}

function getPaymentAccent(method: PaymentMethod) {
  switch (method) {
    case "PayPal":
      return "#38A8EA";
    case "Cash App":
      return "#27D17F";
    case "Bitcoin":
      return "#F7931A";
    case "Bank Transfer":
      return "#8B5CF6";
    case "Zelle":
      return "#6D35D8";
    case "Venmo":
      return "#3D95CE";
    case "Chime":
      return "#45D6B0";
    case "USDT":
      return "#26A17B";
    case "Ethereum":
      return "#8A8DFF";
    default:
      return "#B51F35";
  }
}

function PaymentLogo({
  method,
  size = "md",
}: {
  method: PaymentMethod;
  size?: "sm" | "md" | "lg";
}) {
  const accent = getPaymentAccent(method);

  const sizeClass =
    size === "lg"
      ? "h-16 w-16"
      : size === "sm"
        ? "h-9 w-9"
        : "h-12 w-12";

  const iconSize =
    size === "lg"
      ? 28
      : size === "sm"
        ? 17
        : 22;

  const common =
    "relative flex shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-white/10 bg-black/50 shadow-[0_0_30px_rgba(255,255,255,0.03)]";

  if (method === "PayPal") {
    return (
      <div
        className={`${common} ${sizeClass}`}
        style={{
          boxShadow: `0 0 30px ${accent}20`,
        }}
      >
        <SiPaypal size={iconSize} color={accent} />
      </div>
    );
  }

  if (method === "Cash App") {
    return (
      <div
        className={`${common} ${sizeClass}`}
        style={{
          boxShadow: `0 0 30px ${accent}20`,
        }}
      >
        <SiCashapp size={iconSize} color={accent} />
      </div>
    );
  }

  if (method === "Bitcoin") {
    return (
      <div
        className={`${common} ${sizeClass}`}
        style={{
          boxShadow: `0 0 30px ${accent}20`,
        }}
      >
        <SiBitcoin size={iconSize} color={accent} />
      </div>
    );
  }

  if (method === "Venmo") {
    return (
      <div
        className={`${common} ${sizeClass}`}
        style={{
          boxShadow: `0 0 30px ${accent}20`,
        }}
      >
        <SiVenmo size={iconSize} color={accent} />
      </div>
    );
  }

  if (method === "Zelle") {
    return (
      <div
        className={`${common} ${sizeClass}`}
        style={{
          boxShadow: `0 0 30px ${accent}20`,
        }}
      >
        <SiZelle size={iconSize} color={accent} />
      </div>
    );
  }

  return (
    <div
      className={`${common} ${sizeClass}`}
      style={{
        boxShadow: `0 0 30px ${accent}20`,
      }}
    >
      <span
        className={`font-black ${
          size === "lg"
            ? "text-2xl"
            : size === "sm"
              ? "text-sm"
              : "text-lg"
        }`}
        style={{ color: accent }}
      >
        {getPaymentShortLabel(method)}
      </span>

      <span
        className="absolute bottom-1 right-1 h-1.5 w-1.5 rounded-full"
        style={{ backgroundColor: accent }}
      />
    </div>
  );
}

function FlashFinanceMark() {
  return (
    <div className="relative flex h-11 w-11 items-center justify-center">
      <div className="absolute inset-0 rotate-45 rounded-xl border border-[#B51F35]/50 bg-[#B51F35]/10 shadow-[0_0_30px_rgba(181,31,53,0.18)]" />

      <div className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-[#B51F35] shadow-[0_0_25px_rgba(181,31,53,0.5)]">
        <span className="text-lg font-black italic text-white">
          F
        </span>
      </div>

      <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-[#FF5A67] shadow-[0_0_12px_#FF5A67]" />
    </div>
  );
}

function BlockchainBackground() {
  return (
    <>
      <div className="pointer-events-none fixed inset-0 overflow-hidden bg-[#030406]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-10%,rgba(181,31,53,0.20),transparent_38%),radial-gradient(circle_at_5%_45%,rgba(124,58,237,0.10),transparent_30%),radial-gradient(circle_at_95%_70%,rgba(181,31,53,0.10),transparent_32%)]" />

        <div className="absolute -left-40 top-[-180px] h-[600px] w-[600px] rounded-full bg-[#B51F35]/10 blur-[160px]" />
        <div className="absolute -right-48 top-[18%] h-[650px] w-[650px] rounded-full bg-[#6D35D8]/10 blur-[170px]" />
        <div className="absolute bottom-[-250px] left-[20%] h-[650px] w-[650px] rounded-full bg-[#B51F35]/[0.07] blur-[170px]" />

        <div
          className="absolute inset-0 opacity-[0.20]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px)",
            backgroundSize: "42px 42px",
            maskImage:
              "linear-gradient(to bottom, black, transparent 90%)",
            WebkitMaskImage:
              "linear-gradient(to bottom, black, transparent 90%)",
          }}
        />

        <div
          className="absolute inset-0 opacity-[0.045]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(135deg, transparent 0, transparent 80px, rgba(255,255,255,0.12) 81px, transparent 82px)",
          }}
        />

        <svg
          className="absolute left-1/2 top-0 h-full w-[1500px] -translate-x-1/2 opacity-[0.42]"
          viewBox="0 0 1500 1000"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient
              id="redNetwork"
              x1="0"
              y1="0"
              x2="1"
              y2="1"
            >
              <stop offset="0%" stopColor="#B51F35" stopOpacity="0" />
              <stop offset="40%" stopColor="#B51F35" stopOpacity="0.7" />
              <stop offset="100%" stopColor="#FF6875" stopOpacity="0" />
            </linearGradient>

            <linearGradient
              id="purpleNetwork"
              x1="1"
              y1="0"
              x2="0"
              y2="1"
            >
              <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0" />
              <stop offset="50%" stopColor="#8B5CF6" stopOpacity="0.55" />
              <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
            </linearGradient>

            <filter id="softGlow">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <path
            d="M30 180 L240 75 L430 210 L670 95 L910 245 L1160 105 L1470 205"
            fill="none"
            stroke="url(#redNetwork)"
            strokeWidth="1"
          />

          <path
            d="M80 430 L280 330 L510 475 L750 345 L990 470 L1230 330 L1480 430"
            fill="none"
            stroke="url(#purpleNetwork)"
            strokeWidth="1"
          />

          <path
            d="M20 790 L220 660 L470 815 L720 650 L980 790 L1220 640 L1490 760"
            fill="none"
            stroke="url(#redNetwork)"
            strokeWidth="1"
          />

          <path
            d="M240 75 L280 330 M430 210 L510 475 M670 95 L750 345 M910 245 L990 470 M1160 105 L1230 330 M280 330 L220 660 M510 475 L470 815 M750 345 L720 650 M990 470 L980 790 M1230 330 L1220 640"
            fill="none"
            stroke="#FFFFFF"
            strokeOpacity="0.07"
            strokeWidth="1"
          />

          {[
            [30, 180, "#B51F35"],
            [240, 75, "#FF6875"],
            [430, 210, "#B51F35"],
            [670, 95, "#FF6875"],
            [910, 245, "#B51F35"],
            [1160, 105, "#FF6875"],
            [1470, 205, "#B51F35"],
            [80, 430, "#8B5CF6"],
            [280, 330, "#8B5CF6"],
            [510, 475, "#B51F35"],
            [750, 345, "#8B5CF6"],
            [990, 470, "#B51F35"],
            [1230, 330, "#8B5CF6"],
            [1480, 430, "#B51F35"],
            [20, 790, "#B51F35"],
            [220, 660, "#FF6875"],
            [470, 815, "#B51F35"],
            [720, 650, "#FF6875"],
            [980, 790, "#B51F35"],
            [1220, 640, "#FF6875"],
            [1490, 760, "#B51F35"],
          ].map(([cx, cy, color], index) => (
            <g key={index} filter="url(#softGlow)">
              <circle
                cx={cx}
                cy={cy}
                r="2.5"
                fill={color as string}
              />
              <circle
                cx={cx}
                cy={cy}
                r="8"
                fill="none"
                stroke={color as string}
                strokeOpacity="0.18"
              />
            </g>
          ))}
        </svg>

        <div className="absolute left-[12%] top-[24%] h-2 w-2 rounded-full bg-[#FF6875] shadow-[0_0_25px_8px_rgba(255,90,103,0.08)]" />
        <div className="absolute right-[18%] top-[16%] h-1.5 w-1.5 rounded-full bg-[#8B5CF6] shadow-[0_0_25px_8px_rgba(139,92,246,0.08)]" />
        <div className="absolute left-[35%] bottom-[18%] h-1.5 w-1.5 rounded-full bg-[#B51F35] shadow-[0_0_25px_8px_rgba(181,31,53,0.08)]" />
        <div className="absolute right-[8%] bottom-[28%] h-2 w-2 rounded-full bg-[#FF6875] shadow-[0_0_25px_8px_rgba(255,90,103,0.08)]" />

        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(0,0,0,0.42)_100%)]" />

        <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-[#030406] via-[#030406]/70 to-transparent" />
      </div>
    </>
  );
}

function NetworkBadge({
  method,
}: {
  method: PaymentMethod;
}) {
  const accent = getPaymentAccent(method);

  return (
    <div className="flex items-center gap-2">
      <span
        className="h-1.5 w-1.5 rounded-full"
        style={{
          backgroundColor: accent,
          boxShadow: `0 0 10px ${accent}`,
        }}
      />

      <span className="font-mono text-[9px] font-bold uppercase tracking-[0.2em] text-white/40">
        {method === "Bitcoin" ||
        method === "USDT" ||
        method === "Ethereum"
          ? "ON CHAIN"
          : "NETWORK"}
      </span>
    </div>
  );
}

function DetailRow({
  field,
  value,
  onCopy,
}: {
  field: PaymentFieldDefinition;
  value: string;
  onCopy: () => void;
}) {
  const displayValue = value || "Not configured";
  const isConfigured = Boolean(value);

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.025] p-4 transition hover:border-white/[0.13] hover:bg-white/[0.04]">
      <div className="absolute left-0 top-0 h-full w-px bg-gradient-to-b from-[#B51F35] via-transparent to-transparent opacity-70" />

      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0 flex-1">
          <p className="font-mono text-[9px] font-bold uppercase tracking-[0.2em] text-white/35">
            {field.label}
          </p>

          <p
            className={`mt-2 break-all text-sm leading-6 ${
              isConfigured
                ? "text-white/90"
                : "text-white/25"
            } ${
              field.type === "multiline"
                ? "font-mono text-xs"
                : "font-medium"
            }`}
          >
            {displayValue}
          </p>
        </div>

        {isConfigured && (
          <button
            type="button"
            onClick={onCopy}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/[0.08] bg-black/30 text-white/35 transition hover:border-[#B51F35]/40 hover:bg-[#B51F35]/10 hover:text-[#FF6875]"
            aria-label={`Copy ${field.label}`}
          >
            <FiCopy size={14} />
          </button>
        )}
      </div>
    </div>
  );
}

function DepositPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const supabase = useMemo(
    () => createClient(),
    [],
  );

  const requestedMethod =
    searchParams.get("method") as PaymentMethod | null;

  const [paymentMethod, setPaymentMethod] =
    useState<PaymentMethod>(
      paymentMethods.some(
        (item) => item.name === requestedMethod,
      )
        ? (requestedMethod as PaymentMethod)
        : "Zelle",
    );

  const [amount, setAmount] = useState("");
  const [reference, setReference] = useState("");
  const [receiptFile, setReceiptFile] =
    useState<File | null>(null);
  const [receiptFileName, setReceiptFileName] =
    useState("");

  const [paymentRecord, setPaymentRecord] =
    useState<PaymentMethodRecord | null>(null);

  const [loadingPaymentDetails, setLoadingPaymentDetails] =
    useState(true);

  const [submitting, setSubmitting] = useState(false);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [submitted, setSubmitted] = useState(false);

  const [copiedField, setCopiedField] =
    useState("");

  const [currentStep, setCurrentStep] = useState(1);

  const numericAmount = useMemo(() => {
    const parsed = Number(
      amount.replace(/,/g, "").trim(),
    );

    return Number.isFinite(parsed) ? parsed : 0;
  }, [amount]);

  const methodActive =
    paymentRecord?.is_active !== false;

  const selectedFields = useMemo(
    () => getDepositFields(paymentMethod),
    [paymentMethod],
  );

  const resolvedFields = useMemo<FieldValue[]>(() => {
    const details = parsePaymentDetails(
      paymentRecord?.details,
    );

    return selectedFields.map((field) => ({
      key: field.key,
      label: field.label,
      value: getFieldValue(
        details,
        paymentMethod,
        field,
      ),
    }));
  }, [
    paymentRecord,
    paymentMethod,
    selectedFields,
  ]);

  async function loadPaymentDetails(
    method: PaymentMethod,
  ) {
    setLoadingPaymentDetails(true);
    setError("");

    try {
      const {
        data,
        error: paymentError,
      } = await supabase
        .from("payment_methods")
        .select("name, details, is_active")
        .ilike("name", method)
        .order("created_at", {
          ascending: true,
        })
        .limit(1)
        .maybeSingle();

      if (paymentError) {
        throw paymentError;
      }

      setPaymentRecord(
        data
          ? {
              name: String(data.name || method),
              details: parsePaymentDetails(
                data.details,
              ),
              is_active:
                data.is_active === null ||
                data.is_active === undefined
                  ? true
                  : Boolean(data.is_active),
            }
          : null,
      );
    } catch (loadError) {
      console.error(
        "Payment method load error:",
        loadError,
      );

      setPaymentRecord(null);

      setError(
        loadError instanceof Error
          ? loadError.message
          : "Unable to load payment information.",
      );
    } finally {
      setLoadingPaymentDetails(false);
    }
  }

  useEffect(() => {
    void loadPaymentDetails(paymentMethod);
  }, [paymentMethod]);

  function selectPaymentMethod(
    method: PaymentMethod,
  ) {
    setPaymentMethod(method);
    setError("");
    setSuccess("");
    setCopiedField("");

    const params = new URLSearchParams(
      searchParams.toString(),
    );

    params.set("method", method);

    router.replace(
      `/deposit?${params.toString()}`,
      { scroll: false },
    );
  }

  function handleAmountChange(value: string) {
    let nextValue = value.replace(
      /[^0-9.]/g,
      "",
    );

    const firstDecimalIndex =
      nextValue.indexOf(".");

    if (firstDecimalIndex !== -1) {
      const beforeDecimal = nextValue.slice(
        0,
        firstDecimalIndex,
      );

      const afterDecimal = nextValue
        .slice(firstDecimalIndex + 1)
        .replace(/\./g, "")
        .slice(0, 2);

      nextValue =
        `${beforeDecimal}.${afterDecimal}`;
    }

    setAmount(nextValue);
    setError("");
    setSuccess("");
  }

  function handleReceiptChange(
    event: ChangeEvent<HTMLInputElement>,
  ) {
    const file =
      event.target.files?.[0] || null;

    if (!file) {
      setReceiptFile(null);
      setReceiptFileName("");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError(
        "Payment receipt must be 10 MB or smaller.",
      );
      setReceiptFile(null);
      setReceiptFileName("");
      return;
    }

    setError("");
    setSuccess("");
    setReceiptFile(file);
    setReceiptFileName(file.name);
  }

  async function copyValue(
    field: FieldValue,
  ) {
    if (!field.value) {
      return;
    }

    try {
      await navigator.clipboard.writeText(
        field.value,
      );

      setCopiedField(field.key);

      window.setTimeout(() => {
        setCopiedField("");
      }, 1600);
    } catch {
      setError(
        "Unable to copy this payment detail.",
      );
    }
  }

  function continueToReceipt() {
    setError("");
    setSuccess("");

    if (!numericAmount || numericAmount <= 0) {
      setError(
        "Enter a valid deposit amount.",
      );
      return;
    }

    if (!methodActive) {
      setError(
        "This payment method is currently unavailable.",
      );
      return;
    }

    setCurrentStep(2);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  function goBackToPayment() {
    setCurrentStep(1);
    setError("");
    setSuccess("");

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  async function handleSubmit(
    event: FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    setError("");
    setSuccess("");

    if (!numericAmount || numericAmount <= 0) {
      setError(
        "Enter a valid deposit amount.",
      );
      setCurrentStep(1);
      return;
    }

    if (!receiptFile) {
      setError(
        "Please upload your payment receipt.",
      );
      return;
    }

    if (!methodActive) {
      setError(
        "This payment method is currently unavailable.",
      );
      return;
    }

    setSubmitting(true);

    try {
      const {
        data: authData,
        error: authError,
      } =
        await supabase.auth.getUser();

      if (authError) {
        throw authError;
      }

      const user = authData.user;

      if (!user) {
        router.replace("/login");
        return;
      }

      const fileExtension =
        receiptFile.name
          .split(".")
          .pop()
          ?.toLowerCase() || "bin";

      const filePath =
        `${user.id}/${crypto.randomUUID()}.${fileExtension}`;

      const {
        error: uploadError,
      } = await supabase.storage
        .from("payment-receipts")
        .upload(
          filePath,
          receiptFile,
          {
            upsert: false,
          },
        );

      if (uploadError) {
        throw uploadError;
      }

      const {
        error: insertError,
      } = await supabase
        .from("deposits")
        .insert({
          user_id: user.id,
          amount: numericAmount,
          payment_method: paymentMethod,
          status: "pending",
          reference:
            reference.trim() || null,
          receipt_path: filePath,
        });

      if (insertError) {
        throw insertError;
      }

      setSubmitted(true);
      setSuccess(
        "Your deposit has been submitted successfully. Your balance will be updated once your payment has been confirmed.",
      );
    } catch (submitError) {
      console.error(
        "Deposit submission error:",
        submitError,
      );

      setError(
        submitError instanceof Error
          ? submitError.message
          : "Unable to submit your deposit. Please try again.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (submitted) {
    return (
      <main className="relative min-h-screen overflow-hidden bg-[#030406] text-white">
        <BlockchainBackground />

        <div className="relative z-10 mx-auto flex min-h-screen max-w-3xl items-center justify-center px-5 py-10">
          <div className="w-full overflow-hidden rounded-[32px] border border-white/[0.08] bg-[#0A0C10]/90 shadow-[0_30px_100px_rgba(0,0,0,0.6)] backdrop-blur-2xl">
            <div className="h-1 bg-gradient-to-r from-transparent via-[#B51F35] to-transparent" />

            <div className="px-6 py-14 text-center sm:px-12 sm:py-20">
              <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-[28px] border border-[#2BDB8A]/20 bg-[#2BDB8A]/10 shadow-[0_0_60px_rgba(43,219,138,0.14)]">
                <FiCheckCircle
                  size={46}
                  className="text-[#2BDB8A]"
                />
              </div>

              <div className="mt-8">
                <p className="font-mono text-[10px] font-bold uppercase tracking-[0.3em] text-[#2BDB8A]">
                  TRANSACTION BROADCAST
                </p>

                <h1 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">
                  Deposit submitted
                </h1>

                <p className="mx-auto mt-4 max-w-lg text-sm leading-7 text-white/45">
                  Your deposit has been submitted
                  successfully. Your balance will be
                  updated once your payment has been
                  confirmed.
                </p>
              </div>

              <div className="mx-auto mt-8 max-w-md rounded-2xl border border-white/[0.07] bg-black/30 p-5 text-left">
                <div className="flex items-center justify-between gap-4">
                  <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-white/30">
                    Amount
                  </span>

                  <span className="font-mono text-sm font-bold text-white">
                    {numericAmount.toLocaleString(
                      "en-US",
                      {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      },
                    )}
                  </span>
                </div>

                <div className="my-4 h-px bg-white/[0.06]" />

                <div className="flex items-center justify-between gap-4">
                  <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-white/30">
                    Method
                  </span>

                  <span className="text-sm font-semibold text-white/80">
                    {paymentMethod}
                  </span>
                </div>

                <div className="my-4 h-px bg-white/[0.06]" />

                <div className="flex items-center justify-between gap-4">
                  <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-white/30">
                    Status
                  </span>

                  <span className="flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-wider text-[#2BDB8A]">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#2BDB8A] shadow-[0_0_10px_#2BDB8A]" />
                    Pending Review
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  router.push("/dashboard")
                }
                className="mt-8 inline-flex items-center gap-3 rounded-xl bg-[#B51F35] px-7 py-3.5 text-sm font-bold text-white shadow-[0_0_35px_rgba(181,31,53,0.25)] transition hover:bg-[#C52840]"
              >
                Return to dashboard
                <FiArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#030406] text-white">
      <BlockchainBackground />

      <div className="relative z-10 mx-auto max-w-[1500px] px-4 py-5 sm:px-6 lg:px-8">
        <header className="mb-5 flex items-center justify-between rounded-2xl border border-white/[0.07] bg-[#080A0D]/80 px-4 py-3 backdrop-blur-xl sm:px-5">
          <button
            type="button"
            onClick={() =>
              router.push("/dashboard")
            }
            className="flex items-center gap-3 text-white/55 transition hover:text-white"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/[0.08] bg-white/[0.03]">
              <FiArrowLeft size={16} />
            </div>

            <span className="hidden text-xs font-semibold sm:block">
              Dashboard
            </span>
          </button>

          <div className="flex items-center gap-3">
            <FlashFinanceMark />

            <div className="hidden sm:block">
              <p className="text-sm font-black tracking-tight">
                FlashFinance
              </p>

              <p className="font-mono text-[8px] uppercase tracking-[0.25em] text-white/30">
                Financial Network
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-full border border-[#2BDB8A]/15 bg-[#2BDB8A]/5 px-3 py-2">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#2BDB8A] shadow-[0_0_10px_#2BDB8A]" />

            <span className="font-mono text-[8px] font-bold uppercase tracking-[0.18em] text-[#2BDB8A]">
              Network Online
            </span>
          </div>
        </header>

        <section className="relative mb-5 overflow-hidden rounded-[28px] border border-white/[0.07] bg-[#080A0E]/90 px-6 py-7 shadow-[0_30px_90px_rgba(0,0,0,0.35)] backdrop-blur-2xl sm:px-8 lg:px-10">
          <div className="absolute right-[-80px] top-[-100px] h-72 w-72 rounded-full bg-[#B51F35]/10 blur-[100px]" />

          <div className="relative flex flex-col justify-between gap-7 lg:flex-row lg:items-end">
            <div>
              <div className="mb-4 flex items-center gap-3">
                <div className="flex items-center gap-2 rounded-full border border-[#B51F35]/20 bg-[#B51F35]/5 px-3 py-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#B51F35] shadow-[0_0_10px_#B51F35]" />

                  <span className="font-mono text-[8px] font-bold uppercase tracking-[0.25em] text-[#FF6976]">
                    Deposit Protocol
                  </span>
                </div>

                <span className="font-mono text-[9px] text-white/20">
                  / SECURE CHANNEL
                </span>
              </div>

              <h1 className="max-w-3xl text-3xl font-black tracking-[-0.04em] text-white sm:text-4xl lg:text-5xl">
                Fund your
                <span className="text-[#B51F35]">
                  {" "}
                  FlashFinance
                </span>{" "}
                account
              </h1>

              <p className="mt-4 max-w-2xl text-sm leading-7 text-white/40">
                Select a settlement network, enter your
                deposit amount, complete the transfer,
                and submit your transaction proof for
                verification.
              </p>
            </div>

            <div className="shrink-0">
              <div className="rounded-2xl border border-white/[0.07] bg-black/30 px-5 py-4">
                <p className="font-mono text-[8px] uppercase tracking-[0.22em] text-white/25">
                  Protocol status
                </p>

                <div className="mt-2 flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-[#2BDB8A] shadow-[0_0_12px_#2BDB8A]" />

                  <span className="font-mono text-xs font-bold text-[#2BDB8A]">
                    OPERATIONAL
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="mb-5 grid grid-cols-2 gap-2">
          {[
            {
              number: 1,
              title: "Settlement",
              subtitle: "Choose network",
            },
            {
              number: 2,
              title: "Broadcast",
              subtitle: "Submit proof",
            },
          ].map((step) => {
            const active =
              currentStep === step.number;
            const complete =
              currentStep > step.number;

            return (
              <div
                key={step.number}
                className={`relative overflow-hidden rounded-2xl border px-4 py-4 transition ${
                  active
                    ? "border-[#B51F35]/40 bg-[#B51F35]/[0.07]"
                    : complete
                      ? "border-[#2BDB8A]/20 bg-[#2BDB8A]/[0.04]"
                      : "border-white/[0.06] bg-[#080A0D]/70"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-lg border font-mono text-xs font-black ${
                      active
                        ? "border-[#B51F35]/40 bg-[#B51F35]/15 text-[#FF6875]"
                        : complete
                          ? "border-[#2BDB8A]/30 bg-[#2BDB8A]/10 text-[#2BDB8A]"
                          : "border-white/[0.08] bg-white/[0.025] text-white/30"
                    }`}
                  >
                    {complete ? (
                      <FiCheck size={15} />
                    ) : (
                      String(step.number).padStart(2, "0")
                    )}
                  </div>

                  <div>
                    <p className="text-xs font-bold text-white/80">
                      {step.title}
                    </p>

                    <p className="mt-0.5 font-mono text-[8px] uppercase tracking-[0.16em] text-white/25">
                      {step.subtitle}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {error && (
          <div className="mb-5 flex items-start gap-3 rounded-2xl border border-[#FF4D5D]/20 bg-[#FF4D5D]/[0.06] px-4 py-4 text-sm text-[#FF8A94]">
            <FiAlertCircle
              className="mt-0.5 shrink-0"
              size={18}
            />

            <p className="leading-6">
              {error}
            </p>

            <button
              type="button"
              onClick={() => setError("")}
              className="ml-auto shrink-0 text-white/25 transition hover:text-white"
            >
              <FiX size={16} />
            </button>
          </div>
        )}

        {success && (
          <div className="mb-5 flex items-start gap-3 rounded-2xl border border-[#2BDB8A]/20 bg-[#2BDB8A]/[0.05] px-4 py-4 text-sm text-[#64E8AB]">
            <FiCheckCircle
              className="mt-0.5 shrink-0"
              size={18}
            />

            <p className="leading-6">
              {success}
            </p>
          </div>
        )}

        {currentStep === 1 ? (
          <div className="grid gap-5 xl:grid-cols-[320px_minmax(0,1fr)_330px]">
            <section className="overflow-hidden rounded-[28px] border border-white/[0.07] bg-[#080A0D]/90 shadow-[0_25px_70px_rgba(0,0,0,0.3)] backdrop-blur-xl">
              <div className="border-b border-white/[0.06] px-5 py-5">
                <p className="font-mono text-[8px] font-bold uppercase tracking-[0.25em] text-white/25">
                  Available networks
                </p>

                <h2 className="mt-2 text-lg font-black">
                  Choose settlement
                </h2>
              </div>

              <div className="space-y-1 p-3">
                {paymentMethods.map(
                  (methodItem) => {
                    const method =
                      methodItem.name;

                    const active =
                      paymentMethod === method;

                    const accent =
                      getPaymentAccent(method);

                    return (
                      <button
                        key={method}
                        type="button"
                        onClick={() =>
                          selectPaymentMethod(
                            method,
                          )
                        }
                        className={`group relative flex w-full items-center gap-3 overflow-hidden rounded-2xl border p-3 text-left transition ${
                          active
                            ? "border-white/[0.12] bg-white/[0.055]"
                            : "border-transparent hover:border-white/[0.06] hover:bg-white/[0.025]"
                        }`}
                      >
                        {active && (
                          <span
                            className="absolute bottom-2 left-0 top-2 w-0.5 rounded-full"
                            style={{
                              backgroundColor:
                                accent,
                              boxShadow: `0 0 12px ${accent}`,
                            }}
                          />
                        )}

                        <PaymentLogo
                          method={method}
                          size="sm"
                        />

                        <div className="min-w-0 flex-1">
                          <p
                            className={`truncate text-xs font-bold ${
                              active
                                ? "text-white"
                                : "text-white/55 group-hover:text-white/80"
                            }`}
                          >
                            {method}
                          </p>

                          <p className="mt-1 truncate font-mono text-[8px] text-white/25">
                            {
                              paymentDescriptions[
                                method
                              ]
                            }
                          </p>
                        </div>

                        <FiChevronRight
                          size={15}
                          className={
                            active
                              ? "text-white/60"
                              : "text-white/15"
                          }
                        />
                      </button>
                    );
                  },
                )}
              </div>
            </section>

            <section className="overflow-hidden rounded-[28px] border border-white/[0.07] bg-[#080A0D]/90 shadow-[0_25px_70px_rgba(0,0,0,0.3)] backdrop-blur-xl">
              <div className="relative overflow-hidden border-b border-white/[0.06] px-6 py-6 sm:px-8">
                <div
                  className="absolute right-0 top-0 h-40 w-40 rounded-full opacity-10 blur-[70px]"
                  style={{
                    backgroundColor:
                      getPaymentAccent(
                        paymentMethod,
                      ),
                  }}
                />

                <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-4">
                    <PaymentLogo
                      method={paymentMethod}
                      size="lg"
                    />

                    <div>
                      <NetworkBadge
                        method={paymentMethod}
                      />

                      <h2 className="mt-2 text-xl font-black tracking-tight">
                        {paymentMethod}
                      </h2>

                      <p className="mt-1 text-xs text-white/35">
                        {
                          paymentDescriptions[
                            paymentMethod
                          ]
                        }
                      </p>
                    </div>
                  </div>

                  <div
                    className={`self-start rounded-full border px-3 py-1.5 font-mono text-[8px] font-bold uppercase tracking-[0.18em] ${
                      methodActive
                        ? "border-[#2BDB8A]/20 bg-[#2BDB8A]/5 text-[#4DE39B]"
                        : "border-[#FF4D5D]/20 bg-[#FF4D5D]/5 text-[#FF7C87]"
                    }`}
                  >
                    {methodActive
                      ? "ACTIVE"
                      : "DISABLED"}
                  </div>
                </div>
              </div>

              <div className="p-5 sm:p-7">
                <div className="mb-5 flex items-center justify-between">
                  <div>
                    <p className="font-mono text-[8px] font-bold uppercase tracking-[0.22em] text-white/25">
                      Payment coordinates
                    </p>

                    <p className="mt-1 text-xs text-white/35">
                      Send the deposit using the
                      exact information below.
                    </p>
                  </div>

                  <div className="hidden items-center gap-2 rounded-lg border border-white/[0.06] bg-black/30 px-3 py-2 sm:flex">
                    <FiLock
                      size={12}
                      className="text-[#B51F35]"
                    />

                    <span className="font-mono text-[8px] text-white/25">
                      ENCRYPTED VIEW
                    </span>
                  </div>
                </div>

                {loadingPaymentDetails ? (
                  <div className="space-y-3">
                    {selectedFields.map(
                      (field) => (
                        <div
                          key={field.key}
                          className="h-[86px] animate-pulse rounded-2xl border border-white/[0.05] bg-white/[0.025]"
                        />
                      ),
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {resolvedFields.map(
                      (field) => (
                        <DetailRow
                          key={field.key}
                          field={
                            selectedFields.find(
                              (item) =>
                                item.key ===
                                field.key,
                            ) || {
                              key: field.key,
                              label: field.label,
                            }
                          }
                          value={field.value}
                          onCopy={() =>
                            copyValue(field)
                          }
                        />
                      ),
                    )}
                  </div>
                )}

                {copiedField && (
                  <div className="mt-3 flex items-center gap-2 rounded-xl border border-[#2BDB8A]/15 bg-[#2BDB8A]/[0.04] px-3 py-2 text-[10px] text-[#4DE39B]">
                    <FiCheck size={13} />
                    Payment detail copied
                  </div>
                )}
              </div>
            </section>

            <section className="overflow-hidden rounded-[28px] border border-white/[0.07] bg-[#080A0D]/90 shadow-[0_25px_70px_rgba(0,0,0,0.3)] backdrop-blur-xl">
              <div className="border-b border-white/[0.06] px-5 py-5">
                <p className="font-mono text-[8px] font-bold uppercase tracking-[0.25em] text-white/25">
                  Transaction
                </p>

                <h2 className="mt-2 text-lg font-black">
                  Deposit amount
                </h2>
              </div>

              <div className="p-5">
                <label
                  htmlFor="deposit-amount"
                  className="font-mono text-[9px] font-bold uppercase tracking-[0.2em] text-white/30"
                >
                  Amount to broadcast
                </label>

                <div className="relative mt-3 overflow-hidden rounded-2xl border border-white/[0.08] bg-[#030406] shadow-[inset_0_0_35px_rgba(0,0,0,0.55)]">
                  <div className="absolute inset-y-0 left-0 flex w-14 items-center justify-center border-r border-white/[0.06] bg-[#07080A]">
                    <span className="font-mono text-sm font-bold text-[#B51F35]">
                      $
                    </span>
                  </div>

                  <input
                    id="deposit-amount"
                    type="text"
                    inputMode="decimal"
                    value={amount}
                    onChange={(event) =>
                      handleAmountChange(
                        event.target.value,
                      )
                    }
                    placeholder="0.00"
                    disabled={submitting}
                    autoComplete="off"
                    className="block w-full appearance-none border-0 bg-[#030406] py-5 pl-16 pr-16 text-2xl font-black tracking-tight text-white outline-none placeholder:text-white/[0.10] focus:border-0 focus:bg-[#030406] focus:outline-none focus:ring-0 disabled:opacity-50"
                    style={{
                      backgroundColor: "#030406",
                      color: "#FFFFFF",
                      colorScheme: "dark",
                      WebkitAppearance: "none",
                      WebkitTextFillColor: "#FFFFFF",
                      caretColor: "#FFFFFF",
                      boxShadow:
                        "inset 0 0 35px rgba(0,0,0,0.55)",
                    }}
                  />

                  <div className="pointer-events-none absolute bottom-2 right-3 font-mono text-[7px] uppercase tracking-[0.15em] text-white/20">
                    USD
                  </div>
                </div>

                <div className="mt-5 rounded-xl border border-white/[0.06] bg-[#030406] p-4 shadow-[inset_0_0_20px_rgba(0,0,0,0.35)]">
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-white/25">
                      Transaction amount
                    </span>

                    <span className="font-mono text-xs font-bold text-white/70">
                      $
                      {numericAmount.toLocaleString(
                        "en-US",
                        {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        },
                      )}
                    </span>
                  </div>
                </div>

                <div className="mt-4 flex items-start gap-3 rounded-xl border border-white/[0.06] bg-black/20 p-4">
                  <FiShield
                    size={15}
                    className="mt-0.5 shrink-0 text-[#B51F35]"
                  />

                  <p className="font-mono text-[9px] leading-5 text-white/30">
                    Your deposit will be recorded as
                    a pending transaction until the
                    submitted proof has been reviewed.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={continueToReceipt}
                  disabled={
                    submitting ||
                    !methodActive ||
                    !numericAmount ||
                    numericAmount <= 0
                  }
                  className="group mt-5 flex w-full items-center justify-center gap-3 rounded-xl bg-[#B51F35] px-5 py-4 text-sm font-black text-white shadow-[0_0_35px_rgba(181,31,53,0.2)] transition hover:bg-[#C72840] hover:shadow-[0_0_45px_rgba(181,31,53,0.3)] disabled:cursor-not-allowed disabled:opacity-30"
                >
                  Continue to proof
                  <FiArrowRight
                    size={16}
                    className="transition group-hover:translate-x-1"
                  />
                </button>
              </div>
            </section>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_380px]"
          >
            <section className="overflow-hidden rounded-[28px] border border-white/[0.07] bg-[#080A0D]/90 shadow-[0_25px_70px_rgba(0,0,0,0.3)] backdrop-blur-xl">
              <div className="border-b border-white/[0.06] px-6 py-6 sm:px-8">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="font-mono text-[8px] font-bold uppercase tracking-[0.25em] text-white/25">
                      Transaction proof
                    </p>

                    <h2 className="mt-2 text-xl font-black">
                      Broadcast your deposit
                    </h2>

                    <p className="mt-2 text-xs leading-6 text-white/35">
                      Upload proof of payment so the
                      FlashFinance verification team can
                      review your transaction.
                    </p>
                  </div>

                  <div className="hidden h-12 w-12 items-center justify-center rounded-xl border border-[#B51F35]/20 bg-[#B51F35]/[0.06] sm:flex">
                    <FiUploadCloud
                      size={21}
                      className="text-[#FF6875]"
                    />
                  </div>
                </div>
              </div>

              <div className="p-5 sm:p-8">
                <label
                  htmlFor="receipt-upload"
                  className="group relative flex min-h-[250px] cursor-pointer flex-col items-center justify-center overflow-hidden rounded-[24px] border border-dashed border-white/[0.12] bg-black/25 px-6 text-center transition hover:border-[#B51F35]/50 hover:bg-[#B51F35]/[0.025]"
                >
                  <div className="absolute inset-0 opacity-30">
                    <div
                      className="h-full w-full"
                      style={{
                        backgroundImage:
                          "linear-gradient(45deg, rgba(255,255,255,.025) 25%, transparent 25%, transparent 75%, rgba(255,255,255,.025) 75%), linear-gradient(45deg, rgba(255,255,255,.025) 25%, transparent 25%, transparent 75%, rgba(255,255,255,.025) 75%)",
                        backgroundPosition:
                          "0 0, 10px 10px",
                        backgroundSize:
                          "20px 20px",
                      }}
                    />
                  </div>

                  <div className="relative z-10">
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-[#B51F35]/20 bg-[#B51F35]/[0.07] shadow-[0_0_35px_rgba(181,31,53,0.12)] transition group-hover:scale-105">
                      {receiptFile ? (
                        <FiCheckCircle
                          size={28}
                          className="text-[#2BDB8A]"
                        />
                      ) : (
                        <FiUploadCloud
                          size={28}
                          className="text-[#FF6875]"
                        />
                      )}
                    </div>

                    <p className="mt-5 text-sm font-bold text-white/80">
                      {receiptFile
                        ? "Receipt attached"
                        : "Upload payment receipt"}
                    </p>

                    <p className="mt-2 max-w-md text-xs leading-5 text-white/30">
                      {receiptFile
                        ? receiptFileName
                        : "PNG, JPG, JPEG or PDF · Maximum 10 MB"}
                    </p>

                    <span className="mt-5 inline-flex rounded-lg border border-white/[0.08] bg-white/[0.035] px-4 py-2 font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-white/40 transition group-hover:border-[#B51F35]/30 group-hover:text-white/70">
                      {receiptFile
                        ? "Replace receipt"
                        : "Select file"}
                    </span>
                  </div>

                  <input
                    id="receipt-upload"
                    type="file"
                    accept="image/*,.pdf"
                    className="hidden"
                    onChange={handleReceiptChange}
                    disabled={submitting}
                  />
                </label>

                <div className="mt-6">
                  <label
                    htmlFor="payment-reference"
                    className="font-mono text-[9px] font-bold uppercase tracking-[0.2em] text-white/30"
                  >
                    Payment reference
                    <span className="ml-2 text-white/15">
                      OPTIONAL
                    </span>
                  </label>

                  <div className="mt-3 overflow-hidden rounded-xl border border-white/[0.07] bg-black/30">
                    <input
                      id="payment-reference"
                      type="text"
                      value={reference}
                      onChange={(event) =>
                        setReference(
                          event.target.value,
                        )
                      }
                      placeholder="Enter transaction reference if available"
                      disabled={submitting}
                      className="w-full bg-transparent px-4 py-3.5 text-sm text-white outline-none placeholder:text-white/15"
                    />
                  </div>
                </div>

                <div className="mt-6 flex items-start gap-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4">
                  <FiInfo
                    size={16}
                    className="mt-0.5 shrink-0 text-white/30"
                  />

                  <p className="text-xs leading-6 text-white/30">
                    Make sure the receipt clearly shows
                    the payment amount and transaction
                    information. Your deposit will remain
                    pending until it has been verified.
                  </p>
                </div>
              </div>
            </section>

            <aside className="h-fit overflow-hidden rounded-[28px] border border-white/[0.07] bg-[#080A0D]/90 shadow-[0_25px_70px_rgba(0,0,0,0.3)] backdrop-blur-xl lg:sticky lg:top-5">
              <div className="border-b border-white/[0.06] px-5 py-5">
                <p className="font-mono text-[8px] font-bold uppercase tracking-[0.25em] text-white/25">
                  Transaction manifest
                </p>

                <h2 className="mt-2 text-lg font-black">
                  Review before broadcast
                </h2>
              </div>

              <div className="p-5">
                <div className="flex items-center gap-3 rounded-2xl border border-white/[0.06] bg-black/25 p-4">
                  <PaymentLogo
                    method={paymentMethod}
                    size="md"
                  />

                  <div className="min-w-0">
                    <p className="text-sm font-bold text-white">
                      {paymentMethod}
                    </p>

                    <p className="mt-1 font-mono text-[8px] uppercase tracking-[0.18em] text-white/25">
                      Settlement network
                    </p>
                  </div>
                </div>

                <div className="mt-4 rounded-2xl border border-white/[0.06] bg-black/25 p-5">
                  <p className="font-mono text-[8px] uppercase tracking-[0.2em] text-white/25">
                    Amount
                  </p>

                  <p className="mt-2 text-3xl font-black tracking-tight text-white">
                    $
                    {numericAmount.toLocaleString(
                      "en-US",
                      {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      },
                    )}
                  </p>
                </div>

                <div className="my-5 h-px bg-white/[0.06]" />

                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-4">
                    <span className="font-mono text-[8px] uppercase tracking-[0.15em] text-white/25">
                      Receipt
                    </span>

                    <span
                      className={`font-mono text-[9px] font-bold uppercase ${
                        receiptFile
                          ? "text-[#2BDB8A]"
                          : "text-[#FF6875]"
                      }`}
                    >
                      {receiptFile
                        ? "Attached"
                        : "Required"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <span className="font-mono text-[8px] uppercase tracking-[0.15em] text-white/25">
                      Reference
                    </span>

                    <span className="max-w-[180px] truncate text-xs text-white/60">
                      {reference.trim() ||
                        "Not provided"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <span className="font-mono text-[8px] uppercase tracking-[0.15em] text-white/25">
                      Status
                    </span>

                    <span className="flex items-center gap-2 font-mono text-[9px] font-bold uppercase text-[#F7A928]">
                      <span className="h-1.5 w-1.5 rounded-full bg-[#F7A928] shadow-[0_0_8px_#F7A928]" />
                      Pending
                    </span>
                  </div>
                </div>

                <div className="mt-6 rounded-2xl border border-[#B51F35]/15 bg-[#B51F35]/[0.035] p-4">
                  <div className="flex items-start gap-3">
                    <FiShield
                      size={15}
                      className="mt-0.5 shrink-0 text-[#B51F35]"
                    />

                    <p className="font-mono text-[8px] leading-5 text-white/30">
                      By submitting, your deposit enters
                      the FlashFinance verification queue.
                    </p>
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={goBackToPayment}
                    disabled={submitting}
                    className="flex items-center justify-center gap-2 rounded-xl border border-white/[0.08] bg-white/[0.025] px-4 py-3.5 text-xs font-bold text-white/50 transition hover:border-white/[0.15] hover:text-white disabled:opacity-30"
                  >
                    <FiArrowLeft size={14} />
                    Back
                  </button>

                  <button
                    type="submit"
                    disabled={
                      submitting ||
                      !receiptFile ||
                      !numericAmount ||
                      numericAmount <= 0
                    }
                    className="flex items-center justify-center gap-2 rounded-xl bg-[#B51F35] px-4 py-3.5 text-xs font-black text-white shadow-[0_0_30px_rgba(181,31,53,0.22)] transition hover:bg-[#C72840] disabled:cursor-not-allowed disabled:opacity-30"
                  >
                    {submitting ? (
                      <>
                        <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                        Sending
                      </>
                    ) : (
                      <>
                        Submit
                        <FiArrowRight size={14} />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </aside>
          </form>
        )}

        <footer className="mt-5 flex flex-col gap-3 rounded-2xl border border-white/[0.06] bg-[#080A0D]/70 px-5 py-4 backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <FiLock
              size={13}
              className="text-[#B51F35]"
            />

            <span className="font-mono text-[8px] uppercase tracking-[0.18em] text-white/25">
              Secure FlashFinance deposit protocol
            </span>
          </div>

          <div className="flex items-center gap-4 font-mono text-[8px] uppercase tracking-[0.15em] text-white/20">
            <span>Encrypted</span>
            <span className="h-1 w-1 rounded-full bg-white/20" />
            <span>Verified</span>
            <span className="h-1 w-1 rounded-full bg-white/20" />
            <span>Protected</span>
          </div>
        </footer>
      </div>

      <style jsx global>{`
        #deposit-amount,
        #deposit-amount:hover,
        #deposit-amount:focus,
        #deposit-amount:active {
          background: #030406 !important;
          background-color: #030406 !important;
          color: #ffffff !important;
          -webkit-text-fill-color: #ffffff !important;
          color-scheme: dark !important;
        }

        #deposit-amount:-webkit-autofill,
        #deposit-amount:-webkit-autofill:hover,
        #deposit-amount:-webkit-autofill:focus,
        #deposit-amount:-webkit-autofill:active {
          background: #030406 !important;
          background-color: #030406 !important;
          -webkit-box-shadow: 0 0 0 1000px #030406 inset !important;
          box-shadow: 0 0 0 1000px #030406 inset !important;
          -webkit-text-fill-color: #ffffff !important;
          color: #ffffff !important;
          caret-color: #ffffff !important;
          color-scheme: dark !important;
        }

        #deposit-amount::placeholder {
          color: rgba(255, 255, 255, 0.1) !important;
          opacity: 1 !important;
        }

        #deposit-amount::-webkit-outer-spin-button,
        #deposit-amount::-webkit-inner-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
      `}</style>
    </main>
  );
}

export default function DepositPage() {
  return (
    <Suspense
      fallback={
        <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#030406] text-white">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(181,31,53,0.18),transparent_35%),radial-gradient(circle_at_80%_70%,rgba(109,53,216,0.12),transparent_35%)]" />

          <div className="relative flex items-center gap-3 font-mono text-xs text-white/40">
            <span className="h-2 w-2 animate-pulse rounded-full bg-[#B51F35] shadow-[0_0_12px_#B51F35]" />
            Initializing deposit protocol...
          </div>
        </main>
      }
    >
      <DepositPageContent />
    </Suspense>
  );
}

