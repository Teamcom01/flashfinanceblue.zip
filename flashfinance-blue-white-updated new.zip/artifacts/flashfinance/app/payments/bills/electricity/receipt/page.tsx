"use client";

import { useEffect, useState } from "react";
import { createClient } from "../../../../../lib/supabase";

type Payment = {
  id: string;
  country: string | null;
  provider: string;
  meter_number: string;
  meter_type: string;
  amount: number;
  status: string;
  reference: string;
  created_at: string;
  completed_at: string | null;
};

export default function ElectricityReceiptPage() {
  const supabase = createClient();

  const [payment, setPayment] = useState<Payment | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadPayment() {
      const params = new URLSearchParams(window.location.search);
      const id = params.get("id");

      if (!id) {
        setError("Payment receipt could not be found.");
        setLoading(false);
        return;
      }

      const { data, error: paymentError } = await supabase
        .from("electricity_payments")
        .select(
          "id, country, provider, meter_number, meter_type, amount, status, reference, created_at, completed_at"
        )
        .eq("id", id)
        .single();

      if (paymentError || !data) {
        setError("Payment receipt could not be found.");
        setLoading(false);
        return;
      }

      setPayment(data);
      setLoading(false);
    }

    loadPayment();
  }, [supabase]);

  if (loading) {
    return (
      <main className="min-h-screen !bg-[#F1F3F6] px-4 py-10 !text-[#111318]">
        <div className="mx-auto max-w-xl">
          <div className="rounded-3xl !border !border-[#E2E5E9] !bg-white p-8 text-center shadow-sm">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-2 border-[#E2E5E9] border-t-[#B51F35]" />

            <p className="mt-4 text-sm !text-[#69707D]">
              Loading receipt...
            </p>
          </div>
        </div>
      </main>
    );
  }

  if (error || !payment) {
    return (
      <main className="min-h-screen !bg-[#F1F3F6] px-4 py-10 !text-[#111318]">
        <div className="mx-auto max-w-xl">
          <div className="rounded-3xl border border-red-200 bg-red-50 p-6">
            <p className="text-sm text-red-700">
              {error || "Receipt not found."}
            </p>

            <a
              href="/payments/bills"
              className="mt-5 inline-flex rounded-xl bg-[#B51F35] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#991B30]"
            >
              Back to Pay Bills
            </a>
          </div>
        </div>
      </main>
    );
  }

  const paymentDate = new Date(payment.created_at).toLocaleString();

  const amount = new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    minimumFractionDigits: 2,
  }).format(Number(payment.amount));

  function maskMeterNumber(meter: string) {
    if (!meter) return "—";

    if (meter.length <= 4) {
      return meter;
    }

    return `${"•".repeat(Math.max(0, meter.length - 4))}${meter.slice(-4)}`;
  }

  const status = payment.status?.toLowerCase();

  const isSuccessful =
    status === "successful" ||
    status === "success" ||
    status === "completed";

  return (
    <main className="min-h-screen !bg-[#F1F3F6] px-4 py-10 !text-[#111318]">
      <div className="mx-auto max-w-xl">

        {/* Header */}
        <div className="mb-6 flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold !text-[#B51F35]">
              FlashFinance
            </p>

            <h1 className="mt-1 text-2xl font-bold !text-[#111318]">
              Electricity Receipt
            </h1>
          </div>

          <a
            href="/payments/bills"
            className="rounded-xl !border !border-[#E2E5E9] !bg-white px-4 py-2 text-sm font-medium !text-[#69707D] transition hover:!border-[#B51F35]/40 hover:!text-[#B51F35]"
          >
            Back
          </a>
        </div>

        {/* Receipt */}
        <section
          id="receipt"
          className="overflow-hidden rounded-3xl !border !border-[#E2E5E9] !bg-white shadow-sm"
        >
          {/* Receipt Header */}
          <div className="border-b border-[#E2E5E9] p-6 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#B51F35] text-3xl text-white shadow-sm">
              ⚡
            </div>

            <h2 className="mt-4 text-xl font-bold !text-[#111318]">
              Electricity Payment
            </h2>

            <p className="mt-2 text-sm !text-[#69707D]">
              Payment receipt
            </p>

            <div
              className={`mt-5 inline-flex rounded-full border px-4 py-2 text-sm font-medium ${
                isSuccessful
                  ? "border-green-200 bg-green-50 text-green-700"
                  : "border-orange-200 bg-orange-50 text-orange-700"
              }`}
            >
              {isSuccessful
                ? "✓ Successful"
                : payment.status || "Processing"}
            </div>
          </div>

          {/* Amount */}
          <div className="border-b border-[#E2E5E9] bg-[#F8F9FB] px-6 py-7 text-center">
            <p className="text-xs font-semibold uppercase tracking-wider !text-[#9298A3]">
              Amount Paid
            </p>

            <p className="mt-2 text-3xl font-bold tracking-tight !text-[#B51F35]">
              {amount}
            </p>
          </div>

          {/* Payment Details */}
          <div className="space-y-1 px-6 py-6">
            {/* Country */}
            <div className="flex items-center justify-between gap-6 border-b border-[#E2E5E9] py-4">
              <span className="text-sm !text-[#69707D]">
                Country
              </span>

              <span className="text-right text-sm font-semibold !text-[#111318]">
                {payment.country || "—"}
              </span>
            </div>

            {/* Provider */}
            <div className="flex items-center justify-between gap-6 border-b border-[#E2E5E9] py-4">
              <span className="text-sm !text-[#69707D]">
                Electricity provider
              </span>

              <span className="text-right text-sm font-semibold !text-[#111318]">
                {payment.provider}
              </span>
            </div>

            {/* Meter Number */}
            <div className="flex items-center justify-between gap-6 border-b border-[#E2E5E9] py-4">
              <span className="text-sm !text-[#69707D]">
                Meter number
              </span>

              <span className="text-right text-sm font-semibold !text-[#111318]">
                {maskMeterNumber(payment.meter_number)}
              </span>
            </div>

            {/* Meter Type */}
            <div className="flex items-center justify-between gap-6 border-b border-[#E2E5E9] py-4">
              <span className="text-sm !text-[#69707D]">
                Meter type
              </span>

              <span className="text-right text-sm font-semibold capitalize !text-[#111318]">
                {payment.meter_type}
              </span>
            </div>

            {/* Reference */}
            <div className="flex items-start justify-between gap-6 border-b border-[#E2E5E9] py-4">
              <span className="shrink-0 text-sm !text-[#69707D]">
                Reference
              </span>

              <span className="max-w-[230px] break-all text-right text-xs font-semibold !text-[#111318]">
                {payment.reference}
              </span>
            </div>

            {/* Date */}
            <div className="flex items-center justify-between gap-6 py-4">
              <span className="text-sm !text-[#69707D]">
                Date
              </span>

              <span className="text-right text-sm font-semibold !text-[#111318]">
                {paymentDate}
              </span>
            </div>
          </div>

          {/* Footer */}
          <div className="border-t border-[#E2E5E9] bg-[#F8F9FB] px-6 py-6 text-center">
            <p className="text-xs !text-[#69707D]">
              Thank you for using FlashFinance.
            </p>

            <p className="mt-1 text-xs !text-[#9298A3]">
              Keep this receipt for your records.
            </p>
          </div>
        </section>

        {/* Actions */}
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => window.print()}
            className="rounded-2xl !border !border-[#E2E5E9] !bg-white px-5 py-4 text-sm font-semibold !text-[#252932] shadow-sm transition hover:!border-[#B51F35]/40 hover:!text-[#B51F35]"
          >
            Print Receipt
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="rounded-2xl bg-[#B51F35] px-5 py-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#991B30]"
          >
            Save Receipt
          </button>
        </div>
      </div>

      {/* Print Styling */}
      <style jsx global>{`
        @media print {
          body {
            background: white !important;
          }

          body * {
            visibility: hidden;
          }

          #receipt,
          #receipt * {
            visibility: visible;
          }

          #receipt {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            border: none !important;
            background: white !important;
            color: black !important;
            box-shadow: none !important;
          }

          #receipt p,
          #receipt span,
          #receipt h2 {
            color: black !important;
          }

          main {
            background: white !important;
          }
        }
      `}</style>
    </main>
  );
}