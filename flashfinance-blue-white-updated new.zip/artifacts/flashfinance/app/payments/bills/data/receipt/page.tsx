"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "../../../../../lib/supabase";

type Payment = {
  id: string;
  country: string;
  network: string;
  phone_number: string;
  data_plan: string;
  amount: number;
  status: string;
  reference: string;
  created_at: string;
  completed_at: string | null;
};

export default function DataReceiptPage() {
  const [payment, setPayment] = useState<Payment | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const loadPayment = async () => {
      const params = new URLSearchParams(window.location.search);
      const id = params.get("id");

      if (!id) {
        setError("Payment receipt not found.");
        setLoading(false);
        return;
      }

      const supabase = createClient();

      const { data, error: paymentError } = await supabase
        .from("data_payments")
        .select(
          "id, country, network, phone_number, data_plan, amount, status, reference, created_at, completed_at"
        )
        .eq("id", id)
        .single();

      if (paymentError) {
        console.error(paymentError);
        setError("Unable to load payment receipt.");
        setLoading(false);
        return;
      }

      setPayment(data as Payment);
      setLoading(false);
    };

    loadPayment();
  }, []);

  const getCountryName = (countryCode: string) => {
    try {
      const displayNames = new Intl.DisplayNames(["en"], {
        type: "region",
      });

      return displayNames.of(countryCode) || countryCode;
    } catch {
      return countryCode;
    }
  };

  const formatDate = (date: string | null) => {
    if (!date) return "—";

    return new Date(date).toLocaleString("en-US", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  const formatAmount = (amount: number) => {
    return Number(amount).toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center !bg-[#F8F9FB] px-6 !text-[#111318]">
        <div className="text-center">
          <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-[#E2E5E9] border-t-[#B51F35]" />
          <p className="text-[#69707D]">Loading receipt...</p>
        </div>
      </main>
    );
  }

  if (error || !payment) {
    return (
      <main className="flex min-h-screen items-center justify-center !bg-[#F8F9FB] px-6 !text-[#111318]">
        <div className="w-full max-w-md rounded-3xl border border-[#E2E5E9] bg-white p-8 text-center shadow-sm">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-red-50 text-3xl text-red-600">
            ✕
          </div>

          <h1 className="text-2xl font-bold text-[#111318]">
            Receipt Not Found
          </h1>

          <p className="mt-3 text-[#69707D]">
            {error || "We could not find this data payment."}
          </p>

          <Link
            href="/payments/bills"
            className="mt-6 inline-flex rounded-xl bg-[#B51F35] px-6 py-3 font-semibold text-white transition hover:bg-[#991B30]"
          >
            Back to Bills
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen !bg-[#F8F9FB] px-4 py-10 !text-[#111318] sm:px-6">
      <div className="mx-auto w-full max-w-2xl">
        {/* SUCCESS HEADER */}
        <div className="mb-6 text-center">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-50 text-4xl text-emerald-600">
            ✓
          </div>

          <h1 className="text-3xl font-black tracking-tight text-[#111318]">
            Data Purchase Successful
          </h1>

          <p className="mt-2 text-[#69707D]">
            Your data purchase has been completed successfully.
          </p>
        </div>

        {/* RECEIPT */}
        <div className="overflow-hidden rounded-3xl border border-[#E2E5E9] bg-white shadow-sm">
          <div className="border-b border-[#E2E5E9] bg-gradient-to-r from-[#B51F35]/5 to-transparent px-6 py-5">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm font-medium text-[#69707D]">
                  Data Purchase
                </p>

                <h2 className="mt-1 text-xl font-bold text-[#111318]">
                  FlashFinance
                </h2>
              </div>

              <div className="rounded-full bg-emerald-50 px-3 py-1 text-sm font-semibold capitalize text-emerald-700">
                {payment.status}
              </div>
            </div>
          </div>

          <div className="p-6">
            {/* AMOUNT */}
            <div className="mb-7 rounded-2xl bg-[#F1F3F6] px-5 py-5 text-center">
              <p className="text-sm font-medium text-[#69707D]">
                Amount Paid
              </p>

              <p className="mt-1 text-4xl font-black tracking-tight text-[#B51F35]">
                ${formatAmount(payment.amount)}
              </p>
            </div>

            {/* DETAILS */}
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-6 border-b border-[#E2E5E9] pb-4">
                <span className="text-[#69707D]">Country</span>

                <span className="text-right font-semibold text-[#111318]">
                  {getCountryName(payment.country)}
                </span>
              </div>

              <div className="flex items-start justify-between gap-6 border-b border-[#E2E5E9] pb-4">
                <span className="text-[#69707D]">Mobile Network</span>

                <span className="text-right font-semibold text-[#111318]">
                  {payment.network}
                </span>
              </div>

              <div className="flex items-start justify-between gap-6 border-b border-[#E2E5E9] pb-4">
                <span className="text-[#69707D]">Phone Number</span>

                <span className="text-right font-semibold text-[#111318]">
                  {payment.phone_number}
                </span>
              </div>

              <div className="flex items-start justify-between gap-6 border-b border-[#E2E5E9] pb-4">
                <span className="text-[#69707D]">Data Plan</span>

                <span className="text-right font-semibold text-[#111318]">
                  {payment.data_plan}
                </span>
              </div>

              <div className="flex items-start justify-between gap-6 border-b border-[#E2E5E9] pb-4">
                <span className="text-[#69707D]">Reference</span>

                <span className="max-w-[220px] break-all text-right font-semibold text-[#B51F35]">
                  {payment.reference}
                </span>
              </div>

              <div className="flex items-start justify-between gap-6 border-b border-[#E2E5E9] pb-4">
                <span className="text-[#69707D]">Transaction Date</span>

                <span className="text-right font-semibold text-[#111318]">
                  {formatDate(payment.created_at)}
                </span>
              </div>

              <div className="flex items-start justify-between gap-6">
                <span className="text-[#69707D]">Completed</span>

                <span className="text-right font-semibold text-[#111318]">
                  {formatDate(payment.completed_at)}
                </span>
              </div>
            </div>

            {/* ACTIONS */}
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="rounded-xl border border-[#E2E5E9] bg-white px-5 py-3 font-semibold text-[#252932] transition hover:border-[#B51F35]/40 hover:bg-[#F8F9FB] hover:text-[#B51F35]"
              >
                Print Receipt
              </button>

              <Link
                href="/payments/bills"
                className="rounded-xl bg-[#B51F35] px-5 py-3 text-center font-semibold text-white transition hover:bg-[#991B30]"
              >
                Buy More Data
              </Link>
            </div>
          </div>

          <div className="border-t border-[#E2E5E9] px-6 py-4 text-center">
            <p className="text-xs text-[#9298A3]">
              Thank you for using FlashFinance.
            </p>
          </div>
        </div>
      </div>

      <style jsx global>{`
        @media print {
          body {
            background: white !important;
          }

          main {
            min-height: auto !important;
            background: white !important;
            color: black !important;
            padding: 0 !important;
          }

          main > div > div:first-child,
          main > div > div:first-child + div > div:first-child,
          main > div > div:first-child + div > div:last-child,
          button,
          a {
            display: none !important;
          }

          main > div {
            max-width: 100% !important;
          }

          main > div > div:first-child + div {
            border: none !important;
            background: white !important;
            box-shadow: none !important;
          }

          .text-[#69707D],
          .text-[#9298A3] {
            color: #555 !important;
          }

          .text-[#111318],
          .text-[#252932] {
            color: black !important;
          }

          .text-[#B51F35] {
            color: #a71930 !important;
          }

          .border-[#E2E5E9] {
            border-color: #ddd !important;
          }

          .bg-[#F1F3F6],
          .bg-[#F8F9FB] {
            background: white !important;
          }
        }
      `}</style>
    </main>
  );
}