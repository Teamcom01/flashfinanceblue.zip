"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "../../../lib/supabase";

const billTypes = [
  {
    name: "Electricity",
    description: "Pay your electricity bill",
    icon: "⚡",
  },
  {
    name: "Airtime",
    description: "Recharge your mobile line",
    icon: "📱",
  },
  {
    name: "Data",
    description: "Buy a mobile data plan",
    icon: "◉",
  },
];

/* Complete country list in the requested order:
   United States first, then Afghanistan, followed alphabetically. */
const countries = [
  "United States",
  "Afghanistan",
  "Albania",
  "Algeria",
  "Andorra",
  "Angola",
  "Antigua and Barbuda",
  "Argentina",
  "Armenia",
  "Australia",
  "Austria",
  "Azerbaijan",
  "Bahamas",
  "Bahrain",
  "Bangladesh",
  "Barbados",
  "Belarus",
  "Belgium",
  "Belize",
  "Benin",
  "Bhutan",
  "Bolivia",
  "Bosnia and Herzegovina",
  "Botswana",
  "Brazil",
  "Brunei",
  "Bulgaria",
  "Burkina Faso",
  "Burundi",
  "Cabo Verde",
  "Cambodia",
  "Cameroon",
  "Canada",
  "Central African Republic",
  "Chad",
  "Chile",
  "China",
  "Colombia",
  "Comoros",
  "Congo",
  "Costa Rica",
  "Croatia",
  "Cuba",
  "Cyprus",
  "Czech Republic",
  "Democratic Republic of the Congo",
  "Denmark",
  "Djibouti",
  "Dominica",
  "Dominican Republic",
  "Ecuador",
  "Egypt",
  "El Salvador",
  "Equatorial Guinea",
  "Eritrea",
  "Estonia",
  "Eswatini",
  "Ethiopia",
  "Fiji",
  "Finland",
  "France",
  "Gabon",
  "Gambia",
  "Georgia",
  "Germany",
  "Ghana",
  "Greece",
  "Grenada",
  "Guatemala",
  "Guinea",
  "Guinea-Bissau",
  "Guyana",
  "Haiti",
  "Honduras",
  "Hungary",
  "Iceland",
  "India",
  "Indonesia",
  "Iran",
  "Iraq",
  "Ireland",
  "Israel",
  "Italy",
  "Ivory Coast",
  "Jamaica",
  "Japan",
  "Jordan",
  "Kazakhstan",
  "Kenya",
  "Kiribati",
  "Kuwait",
  "Kyrgyzstan",
  "Laos",
  "Latvia",
  "Lebanon",
  "Lesotho",
  "Liberia",
  "Libya",
  "Liechtenstein",
  "Lithuania",
  "Luxembourg",
  "Madagascar",
  "Malawi",
  "Malaysia",
  "Maldives",
  "Mali",
  "Malta",
  "Marshall Islands",
  "Mauritania",
  "Mauritius",
  "Mexico",
  "Micronesia",
  "Moldova",
  "Monaco",
  "Mongolia",
  "Montenegro",
  "Morocco",
  "Mozambique",
  "Myanmar",
  "Namibia",
  "Nauru",
  "Nepal",
  "Netherlands",
  "New Zealand",
  "Nicaragua",
  "Niger",
  "Nigeria",
  "North Korea",
  "North Macedonia",
  "Norway",
  "Oman",
  "Pakistan",
  "Palau",
  "Palestine",
  "Panama",
  "Papua New Guinea",
  "Paraguay",
  "Peru",
  "Philippines",
  "Poland",
  "Portugal",
  "Qatar",
  "Romania",
  "Russia",
  "Rwanda",
  "Saint Kitts and Nevis",
  "Saint Lucia",
  "Saint Vincent and the Grenadines",
  "Samoa",
  "San Marino",
  "Sao Tome and Principe",
  "Saudi Arabia",
  "Senegal",
  "Serbia",
  "Seychelles",
  "Sierra Leone",
  "Singapore",
  "Slovakia",
  "Slovenia",
  "Solomon Islands",
  "Somalia",
  "South Africa",
  "South Korea",
  "South Sudan",
  "Spain",
  "Sri Lanka",
  "Sudan",
  "Suriname",
  "Sweden",
  "Switzerland",
  "Syria",
  "Taiwan",
  "Tajikistan",
  "Tanzania",
  "Thailand",
  "Timor-Leste",
  "Togo",
  "Tonga",
  "Trinidad and Tobago",
  "Tunisia",
  "Turkey",
  "Turkmenistan",
  "Tuvalu",
  "Uganda",
  "Ukraine",
  "United Arab Emirates",
  "United Kingdom",
  "Uruguay",
  "Uzbekistan",
  "Vanuatu",
  "Vatican City",
  "Venezuela",
  "Vietnam",
  "Yemen",
  "Zambia",
  "Zimbabwe",
];

const electricityProvidersByCountry: Record<string, string[]> = {
  "United States": [
    "PG&E",
    "Con Edison",
    "Duke Energy",
    "Florida Power & Light",
    "Southern California Edison",
    "Other Provider",
  ],
  Nigeria: [
    "AEDC",
    "EKEDC",
    "IKEDC",
    "IBEDC",
    "EEDC",
    "KAEDCO",
    "KEDCO",
    "PHED",
    "JED",
    "YEDC",
  ],
  Ghana: ["ECG", "NEDCo"],
  Kenya: ["Kenya Power"],
  "South Africa": ["Eskom", "City Power", "Cape Town Electricity"],
  "United Kingdom": [
    "British Gas",
    "Octopus Energy",
    "EDF Energy",
    "E.ON Next",
    "OVO Energy",
  ],
  Canada: ["Hydro One", "Hydro Quebec", "BC Hydro", "EPCOR"],
  Australia: ["AGL", "Origin Energy", "EnergyAustralia", "Red Energy"],
  Germany: ["E.ON", "EnBW", "Vattenfall", "RWE"],
  France: ["EDF", "Engie", "TotalEnergies"],
  Italy: ["Enel Energia", "Edison", "A2A"],
  Spain: ["Endesa", "Iberdrola", "Naturgy"],
  Netherlands: ["Vattenfall", "Eneco", "Essent"],
  Ireland: ["Electric Ireland", "SSE Airtricity", "Energia"],
  India: ["Adani Electricity", "Tata Power", "BSES", "MSEDCL"],
  "United Arab Emirates": ["DEWA", "SEWA", "ADDC", "AADC"],
  "Saudi Arabia": ["Saudi Electricity Company"],
};

const mobileNetworksByCountry: Record<string, string[]> = {
  "United States": ["AT&T", "T-Mobile", "Verizon", "US Cellular"],
  Nigeria: ["MTN", "Airtel", "Glo", "9mobile"],
  Ghana: ["MTN Ghana", "Vodafone Ghana", "AirtelTigo"],
  Kenya: ["Safaricom", "Airtel Kenya", "Telkom Kenya"],
  "South Africa": ["Vodacom", "MTN", "Cell C", "Telkom"],
  "United Kingdom": ["EE", "O2", "Vodafone", "Three"],
  Canada: ["Rogers", "Bell", "Telus", "Freedom Mobile"],
  Australia: ["Telstra", "Optus", "Vodafone"],
  Germany: ["Deutsche Telekom", "Vodafone", "O2"],
  France: ["Orange", "SFR", "Bouygues Telecom", "Free Mobile"],
  Italy: ["TIM", "Vodafone", "Wind Tre", "Iliad"],
  Spain: ["Movistar", "Vodafone", "Orange", "Yoigo"],
  Netherlands: ["KPN", "Vodafone", "Odido"],
  Ireland: ["Vodafone", "Three", "Eir"],
  India: ["Airtel", "Jio", "Vi", "BSNL"],
  "United Arab Emirates": ["Etisalat", "du"],
  "Saudi Arabia": ["STC", "Mobily", "Zain"],
};

const dataPlansByCountry: Record<string, string[]> = {
  "United States": ["1 GB", "5 GB", "10 GB", "20 GB", "50 GB", "Unlimited"],
  Nigeria: [
    "1 GB",
    "2 GB",
    "3 GB",
    "5 GB",
    "10 GB",
    "15 GB",
    "20 GB",
    "30 GB",
    "50 GB",
    "100 GB",
  ],
  Ghana: ["1 GB", "2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  Kenya: ["1 GB", "2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  "South Africa": ["1 GB", "2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  "United Kingdom": ["5 GB", "10 GB", "20 GB", "50 GB", "100 GB", "Unlimited"],
  Canada: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  Australia: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB", "100 GB"],
  Germany: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  France: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  Italy: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  Spain: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  Netherlands: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  Ireland: ["2 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  India: ["1 GB", "2 GB", "3 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  "United Arab Emirates": ["1 GB", "3 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
  "Saudi Arabia": ["1 GB", "3 GB", "5 GB", "10 GB", "20 GB", "50 GB"],
};

const fallbackNetworks = ["Other Network"];
const fallbackElectricityProviders = ["Other Provider"];
const fallbackDataPlans = [
  "1 GB",
  "2 GB",
  "5 GB",
  "10 GB",
  "20 GB",
  "50 GB",
];

export default function BillsPage() {
  const supabase = createClient();

  const [selectedType, setSelectedType] = useState("");

  const [electricityCountry, setElectricityCountry] = useState("");
  const [provider, setProvider] = useState("");
  const [meterNumber, setMeterNumber] = useState("");
  const [meterType, setMeterType] = useState("prepaid");

  const [airtimeCountry, setAirtimeCountry] = useState("");
  const [network, setNetwork] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");

  const [dataCountry, setDataCountry] = useState("");
  const [dataNetwork, setDataNetwork] = useState("");
  const [dataPhoneNumber, setDataPhoneNumber] = useState("");
  const [dataPlan, setDataPlan] = useState("");

  const [amount, setAmount] = useState("");

  const [processing, setProcessing] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [paymentReference, setPaymentReference] = useState("");
  const [paymentId, setPaymentId] = useState("");

  const electricityProviders = useMemo(
    () =>
      electricityCountry
        ? electricityProvidersByCountry[electricityCountry] ||
          fallbackElectricityProviders
        : [],
    [electricityCountry],
  );

  const airtimeNetworks = useMemo(
    () =>
      airtimeCountry
        ? mobileNetworksByCountry[airtimeCountry] || fallbackNetworks
        : [],
    [airtimeCountry],
  );

  const dataNetworks = useMemo(
    () =>
      dataCountry
        ? mobileNetworksByCountry[dataCountry] || fallbackNetworks
        : [],
    [dataCountry],
  );

  const dataPlans = useMemo(
    () =>
      dataCountry
        ? dataPlansByCountry[dataCountry] || fallbackDataPlans
        : [],
    [dataCountry],
  );

  useEffect(() => {
    setProvider("");
    setMeterNumber("");
  }, [electricityCountry]);

  useEffect(() => {
    setNetwork("");
    setPhoneNumber("");
  }, [airtimeCountry]);

  useEffect(() => {
    setDataNetwork("");
    setDataPlan("");
    setDataPhoneNumber("");
  }, [dataCountry]);

  function selectBill(type: string) {
    setSelectedType(type);
    setMessage("");
    setError("");
    setPaymentReference("");
    setPaymentId("");
    setAmount("");
  }

  function resetPaymentState() {
    setMessage("");
    setError("");
    setPaymentReference("");
    setPaymentId("");
  }

  async function payElectricity() {
    resetPaymentState();

    if (!electricityCountry) {
      setError("Please select your country.");
      return;
    }

    if (!provider) {
      setError("Please select your electricity provider.");
      return;
    }

    if (!meterNumber.trim()) {
      setError("Please enter your meter number.");
      return;
    }

    const paymentAmount = Number(amount);

    if (!paymentAmount || paymentAmount <= 0) {
      setError("Please enter a valid amount.");
      return;
    }

    setProcessing(true);

    const { data, error: paymentError } = await supabase.rpc(
      "pay_electricity",
      {
        p_country: electricityCountry,
        p_provider: provider,
        p_meter_number: meterNumber.trim(),
        p_meter_type: meterType,
        p_amount: paymentAmount,
      },
    );

    if (paymentError) {
      setError(paymentError.message);
      setProcessing(false);
      return;
    }

    setMessage("Electricity payment successful.");

    if (data?.reference) {
      setPaymentReference(data.reference);
    }

    if (data?.id) {
      setPaymentId(data.id);
    }

    setAmount("");
    setMeterNumber("");
    setProcessing(false);
  }

  async function payAirtime() {
    resetPaymentState();

    if (!airtimeCountry) {
      setError("Please select your country.");
      return;
    }

    if (!network) {
      setError("Please select your mobile network.");
      return;
    }

    if (!phoneNumber.trim()) {
      setError("Please enter your phone number.");
      return;
    }

    const paymentAmount = Number(amount);

    if (!paymentAmount || paymentAmount <= 0) {
      setError("Please enter a valid amount.");
      return;
    }

    setProcessing(true);

    const { data, error: paymentError } = await supabase.rpc(
      "pay_airtime",
      {
        p_country: airtimeCountry,
        p_carrier: network,
        p_phone_number: phoneNumber.trim(),
        p_amount: paymentAmount,
      },
    );

    if (paymentError) {
      setError(paymentError.message);
      setProcessing(false);
      return;
    }

    setMessage("Airtime purchase successful.");

    if (data?.reference) {
      setPaymentReference(data.reference);
    }

    if (data?.id) {
      setPaymentId(data.id);
    }

    setAmount("");
    setPhoneNumber("");
    setProcessing(false);
  }

  async function payData() {
    resetPaymentState();

    if (!dataCountry) {
      setError("Please select your country.");
      return;
    }

    if (!dataNetwork) {
      setError("Please select your mobile network.");
      return;
    }

    if (!dataPhoneNumber.trim()) {
      setError("Please enter your phone number.");
      return;
    }

    if (!dataPlan) {
      setError("Please select a data plan.");
      return;
    }

    const paymentAmount = Number(amount);

    if (!paymentAmount || paymentAmount <= 0) {
      setError("Please enter a valid amount.");
      return;
    }

    setProcessing(true);

    const { data, error: paymentError } = await supabase.rpc(
      "pay_data",
      {
        p_country: dataCountry,
        p_carrier: dataNetwork,
        p_phone_number: dataPhoneNumber.trim(),
        p_data_plan: dataPlan,
        p_amount: paymentAmount,
      },
    );

    if (paymentError) {
      setError(paymentError.message);
      setProcessing(false);
      return;
    }

    setMessage("Data purchase successful.");

    if (data?.reference) {
      setPaymentReference(data.reference);
    }

    if (data?.id) {
      setPaymentId(data.id);
    }

    setAmount("");
    setDataPhoneNumber("");
    setProcessing(false);
  }

  const inputClass =
    "w-full rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-4 !text-[#111318] outline-none placeholder:!text-[#9298A3] focus:!border-[#B51F35]";

  const selectClass =
    "w-full cursor-pointer appearance-auto rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4 py-4 !text-[#111318] outline-none focus:!border-[#B51F35]";

  const labelClass =
    "mb-2 block text-sm font-medium !text-[#69707D]";

  return (
    <main className="min-h-screen !bg-[#F1F3F6] px-4 py-8 !text-[#111318]">
      <div className="mx-auto max-w-5xl">
        <div className="mb-8 overflow-hidden rounded-3xl !bg-[#0B0E17] px-6 py-7 shadow-sm sm:px-8">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm font-semibold tracking-wide text-[#C9213A]">
                FlashFinance
              </p>

              <h1 className="mt-1 text-3xl font-bold tracking-tight text-white">
                Pay Bills
              </h1>

              <p className="mt-2 text-sm text-[#B8BEC8]">
                Pay your everyday bills from one place.
              </p>
            </div>

            <a
              href="/dashboard"
              className="inline-flex w-fit rounded-xl border border-white/10 bg-white/10 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-white/15"
            >
              Dashboard
            </a>
          </div>
        </div>

        <section className="grid gap-4 md:grid-cols-3">
          {billTypes.map((bill) => {
            const selected = selectedType === bill.name;

            return (
              <button
                key={bill.name}
                type="button"
                onClick={() => selectBill(bill.name)}
                className={`rounded-3xl border p-6 text-left shadow-sm transition ${
                  selected
                    ? "border-[#B51F35] bg-red-50"
                    : "border-[#E2E5E9] bg-white hover:border-[#B51F35]/40 hover:bg-[#F8F9FB]"
                }`}
              >
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-2xl text-2xl ${
                    selected ? "bg-[#B51F35]/10" : "bg-[#F1F3F6]"
                  }`}
                >
                  {bill.icon}
                </div>

                <h2 className="mt-5 text-lg font-bold !text-[#111318]">
                  {bill.name}
                </h2>

                <p className="mt-2 text-sm !text-[#69707D]">
                  {bill.description}
                </p>
              </button>
            );
          })}
        </section>

        {selectedType === "Electricity" ? (
          <section className="mt-6 rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-sm">
            <h2 className="text-lg font-bold !text-[#111318]">
              Electricity
            </h2>

            <p className="mt-2 text-sm !text-[#69707D]">
              Select your country first, then choose your electricity provider.
            </p>

            <div className="mt-6 grid gap-5">
              <div>
                <label className={labelClass}>Country</label>

                <select
                  value={electricityCountry}
                  onChange={(event) =>
                    setElectricityCountry(event.target.value)
                  }
                  className={selectClass}
                >
                  <option value="">Select country</option>

                  {countries.map((country) => (
                    <option key={country} value={country}>
                      {country}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  Electricity provider
                </label>

                <select
                  value={provider}
                  onChange={(event) => setProvider(event.target.value)}
                  disabled={!electricityCountry}
                  className={`${selectClass} disabled:cursor-not-allowed disabled:opacity-60`}
                >
                  <option value="">
                    {electricityCountry
                      ? "Select electricity provider"
                      : "Select country first"}
                  </option>

                  {electricityProviders.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>Meter number</label>

                <input
                  type="text"
                  value={meterNumber}
                  onChange={(event) =>
                    setMeterNumber(event.target.value)
                  }
                  placeholder="Enter meter number"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Meter type</label>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMeterType("prepaid")}
                    className={`rounded-2xl border px-4 py-3 text-sm font-semibold transition ${
                      meterType === "prepaid"
                        ? "border-[#B51F35] bg-red-50 !text-[#B51F35]"
                        : "border-[#E2E5E9] bg-white !text-[#69707D] hover:bg-[#F8F9FB]"
                    }`}
                  >
                    Prepaid
                  </button>

                  <button
                    type="button"
                    onClick={() => setMeterType("postpaid")}
                    className={`rounded-2xl border px-4 py-3 text-sm font-semibold transition ${
                      meterType === "postpaid"
                        ? "border-[#B51F35] bg-red-50 !text-[#B51F35]"
                        : "border-[#E2E5E9] bg-white !text-[#69707D] hover:bg-[#F8F9FB]"
                    }`}
                  >
                    Postpaid
                  </button>
                </div>
              </div>

              <div>
                <label className={labelClass}>Amount</label>

                <div className="flex items-center rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4">
                  <span className="font-semibold !text-[#69707D]">$</span>

                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    value={amount}
                    onChange={(event) =>
                      setAmount(event.target.value)
                    }
                    placeholder="0.00"
                    className="w-full bg-transparent px-3 py-4 !text-[#111318] outline-none placeholder:!text-[#9298A3]"
                  />
                </div>
              </div>

              {message && (
                <div className="rounded-2xl border border-green-200 bg-green-50 px-4 py-4 text-sm text-green-700">
                  <p className="font-semibold">{message}</p>

                  {paymentReference && (
                    <p className="mt-1 text-xs text-green-700/70">
                      Reference: {paymentReference}
                    </p>
                  )}

                  {paymentId && (
                    <a
                      href={`/payments/bills/electricity/receipt?id=${paymentId}`}
                      className="mt-4 inline-flex rounded-xl bg-[#B51F35] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#991B30]"
                    >
                      View Receipt
                    </a>
                  )}
                </div>
              )}

              {error && (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-4 text-sm text-red-700">
                  {error}
                </div>
              )}

              <button
                type="button"
                onClick={payElectricity}
                disabled={processing}
                className="w-full rounded-2xl bg-[#B51F35] px-5 py-4 font-semibold text-white transition hover:bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {processing ? "Processing..." : "Pay Electricity"}
              </button>
            </div>
          </section>
        ) : selectedType === "Airtime" ? (
          <section className="mt-6 rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-sm">
            <h2 className="text-lg font-bold !text-[#111318]">
              Airtime
            </h2>

            <p className="mt-2 text-sm !text-[#69707D]">
              Select your country first, then choose your mobile network.
            </p>

            <div className="mt-6 grid gap-5">
              <div>
                <label className={labelClass}>Country</label>

                <select
                  value={airtimeCountry}
                  onChange={(event) =>
                    setAirtimeCountry(event.target.value)
                  }
                  className={selectClass}
                >
                  <option value="">Select country</option>

                  {countries.map((country) => (
                    <option key={country} value={country}>
                      {country}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  Mobile network
                </label>

                <select
                  value={network}
                  onChange={(event) => setNetwork(event.target.value)}
                  disabled={!airtimeCountry}
                  className={`${selectClass} disabled:cursor-not-allowed disabled:opacity-60`}
                >
                  <option value="">
                    {airtimeCountry
                      ? "Select mobile network"
                      : "Select country first"}
                  </option>

                  {airtimeNetworks.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>Phone number</label>

                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(event) =>
                    setPhoneNumber(event.target.value)
                  }
                  placeholder="Enter phone number"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Amount</label>

                <div className="flex items-center rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4">
                  <span className="font-semibold !text-[#69707D]">$</span>

                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    value={amount}
                    onChange={(event) =>
                      setAmount(event.target.value)
                    }
                    placeholder="0.00"
                    className="w-full bg-transparent px-3 py-4 !text-[#111318] outline-none placeholder:!text-[#9298A3]"
                  />
                </div>
              </div>

              {message && (
                <div className="rounded-2xl border border-green-200 bg-green-50 px-4 py-4 text-sm text-green-700">
                  <p className="font-semibold">{message}</p>

                  {paymentReference && (
                    <p className="mt-1 text-xs text-green-700/70">
                      Reference: {paymentReference}
                    </p>
                  )}

                  {paymentId && (
                    <a
                      href={`/payments/bills/airtime/receipt?id=${paymentId}`}
                      className="mt-4 inline-flex rounded-xl bg-[#B51F35] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#991B30]"
                    >
                      View Receipt
                    </a>
                  )}
                </div>
              )}

              {error && (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-4 text-sm text-red-700">
                  {error}
                </div>
              )}

              <button
                type="button"
                onClick={payAirtime}
                disabled={processing}
                className="w-full rounded-2xl bg-[#B51F35] px-5 py-4 font-semibold text-white transition hover:bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {processing ? "Processing..." : "Buy Airtime"}
              </button>
            </div>
          </section>
        ) : selectedType === "Data" ? (
          <section className="mt-6 rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-sm">
            <h2 className="text-lg font-bold !text-[#111318]">
              Data
            </h2>

            <p className="mt-2 text-sm !text-[#69707D]">
              Select your country first, then choose your mobile network and data plan.
            </p>

            <div className="mt-6 grid gap-5">
              <div>
                <label className={labelClass}>Country</label>

                <select
                  value={dataCountry}
                  onChange={(event) =>
                    setDataCountry(event.target.value)
                  }
                  className={selectClass}
                >
                  <option value="">Select country</option>

                  {countries.map((country) => (
                    <option key={country} value={country}>
                      {country}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  Mobile network
                </label>

                <select
                  value={dataNetwork}
                  onChange={(event) =>
                    setDataNetwork(event.target.value)
                  }
                  disabled={!dataCountry}
                  className={`${selectClass} disabled:cursor-not-allowed disabled:opacity-60`}
                >
                  <option value="">
                    {dataCountry
                      ? "Select mobile network"
                      : "Select country first"}
                  </option>

                  {dataNetworks.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>Phone number</label>

                <input
                  type="tel"
                  value={dataPhoneNumber}
                  onChange={(event) =>
                    setDataPhoneNumber(event.target.value)
                  }
                  placeholder="Enter phone number"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Data plan</label>

                <select
                  value={dataPlan}
                  onChange={(event) =>
                    setDataPlan(event.target.value)
                  }
                  disabled={!dataCountry}
                  className={`${selectClass} disabled:cursor-not-allowed disabled:opacity-60`}
                >
                  <option value="">
                    {dataCountry
                      ? "Select data plan"
                      : "Select country first"}
                  </option>

                  {dataPlans.map((plan) => (
                    <option key={plan} value={plan}>
                      {plan}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClass}>Amount</label>

                <div className="flex items-center rounded-2xl !border !border-[#E2E5E9] !bg-[#F1F3F6] px-4">
                  <span className="font-semibold !text-[#69707D]">$</span>

                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    value={amount}
                    onChange={(event) =>
                      setAmount(event.target.value)
                    }
                    placeholder="0.00"
                    className="w-full bg-transparent px-3 py-4 !text-[#111318] outline-none placeholder:!text-[#9298A3]"
                  />
                </div>
              </div>

              {message && (
                <div className="rounded-2xl border border-green-200 bg-green-50 px-4 py-4 text-sm text-green-700">
                  <p className="font-semibold">{message}</p>

                  {paymentReference && (
                    <p className="mt-1 text-xs text-green-700/70">
                      Reference: {paymentReference}
                    </p>
                  )}

                  {paymentId && (
                    <a
                      href={`/payments/bills/data/receipt?id=${paymentId}`}
                      className="mt-4 inline-flex rounded-xl bg-[#B51F35] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#991B30]"
                    >
                      View Receipt
                    </a>
                  )}
                </div>
              )}

              {error && (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-4 text-sm text-red-700">
                  {error}
                </div>
              )}

              <button
                type="button"
                onClick={payData}
                disabled={processing}
                className="w-full rounded-2xl bg-[#B51F35] px-5 py-4 font-semibold text-white transition hover:bg-[#991B30] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {processing ? "Processing..." : "Buy Data"}
              </button>
            </div>
          </section>
        ) : (
          <section className="mt-6 rounded-3xl !border !border-[#E2E5E9] !bg-white p-6 shadow-sm">
            <h2 className="text-lg font-bold !text-[#111318]">
              Choose a bill
            </h2>

            <p className="mt-2 text-sm !text-[#69707D]">
              Select Electricity, Airtime, or Data to continue.
            </p>
          </section>
        )}
      </div>
    </main>
  );
}