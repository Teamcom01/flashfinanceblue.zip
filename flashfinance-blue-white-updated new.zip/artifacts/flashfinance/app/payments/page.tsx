"use client";

import Link from "next/link";
import { createClient } from "@/lib/supabase";

export default function PaymentsPage() {
  const supabase = createClient();

  return (
    <main className="min-h-screen !bg-[#F1F3F6] !text-[#111318]">
      <div className="mx-auto max-w-5xl px-6 py-10">
        <div className="mb-8">
          <Link
            href="/dashboard"
            className="inline-flex items-center text-sm font-medium !text-[#69707D] transition hover:!text-[#B51F35]"
          >
            ← Back to Dashboard
          </Link>

          <div className="mt-6 rounded-[30px] !bg-[#0B0E17] px-7 py-8 shadow-[0_8px_30px_rgba(0,0,0,0.10)]">
            <p className="text-[11px] font-bold uppercase tracking-[0.16em] !text-[#C9213A]">
              Payments
            </p>

            <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">
              Everyday payments
            </h1>

            <p className="mt-2 max-w-xl text-sm leading-6 !text-[#B8BDC6]">
              Manage your everyday payments, cards, savings and bills from one
              place.
            </p>
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <Link
            href="/payments/bills"
            className="group rounded-[28px] !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)] transition duration-200 hover:-translate-y-1 hover:!border-[#B51F35]/40 hover:shadow-[0_10px_30px_rgba(0,0,0,0.09)]"
          >
            <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl !bg-[#B51F35] text-xl text-white">
              💳
            </div>

            <h2 className="text-xl font-bold !text-[#111318]">
              Pay Bills
            </h2>

            <p className="mt-2 text-sm leading-6 !text-[#69707D]">
              Pay electricity bills, buy airtime and mobile data.
            </p>

            <div className="mt-5 flex items-center text-sm font-semibold !text-[#B51F35]">
              Open
              <span className="ml-2 transition-transform group-hover:translate-x-1">
                →
              </span>
            </div>
          </Link>

          <Link
            href="/cards"
            className="group rounded-[28px] !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)] transition duration-200 hover:-translate-y-1 hover:!border-[#B51F35]/40 hover:shadow-[0_10px_30px_rgba(0,0,0,0.09)]"
          >
            <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl !bg-[#B51F35] text-xl text-white">
              💳
            </div>

            <h2 className="text-xl font-bold !text-[#111318]">
              Cards
            </h2>

            <p className="mt-2 text-sm leading-6 !text-[#69707D]">
              Manage your FlashFinance cards.
            </p>

            <div className="mt-5 flex items-center text-sm font-semibold !text-[#B51F35]">
              Open
              <span className="ml-2 transition-transform group-hover:translate-x-1">
                →
              </span>
            </div>
          </Link>

          <Link
            href="/savings"
            className="group rounded-[28px] !border !border-[#E2E5E9] !bg-white p-6 shadow-[0_4px_20px_rgba(0,0,0,0.05)] transition duration-200 hover:-translate-y-1 hover:!border-[#B51F35]/40 hover:shadow-[0_10px_30px_rgba(0,0,0,0.09)]"
          >
            <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl !bg-[#B51F35] text-xl text-white">
              💰
            </div>

            <h2 className="text-xl font-bold !text-[#111318]">
              Save & Spend
            </h2>

            <p className="mt-2 text-sm leading-6 !text-[#69707D]">
              Manage your savings and everyday spending.
            </p>

            <div className="mt-5 flex items-center text-sm font-semibold !text-[#B51F35]">
              Open
              <span className="ml-2 transition-transform group-hover:translate-x-1">
                →
              </span>
            </div>
          </Link>
        </div>
      </div>
    </main>
  );
}