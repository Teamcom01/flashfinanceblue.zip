"use client";

import { useRouter } from "next/navigation";
import {
  FiArrowLeft,
  FiArrowRight,
  FiCheck,
  FiClock,
  FiHome,
  FiShield,
} from "react-icons/fi";

export default function WithdrawalSuccessPage() {
  const router = useRouter();

  return (
    <main className="min-h-screen bg-[#F7F8FA] font-sans text-[#111318]">
      <header className="border-b border-[#242936] bg-[#0B0E17] text-white">
        <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 sm:px-8">
          <button
            type="button"
            onClick={() => router.push("/dashboard")}
            className="flex items-center gap-3"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-[#0B0E17] shadow-sm">
              <span className="text-xl font-black">F</span>
            </div>

            <div className="text-left">
              <div className="text-[17px] font-extrabold tracking-tight">
                FlashFinance
              </div>
              <div className="text-[11px] font-medium text-white/50">
                Financial Services
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => router.push("/dashboard")}
            className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10 sm:flex"
          >
            <FiHome size={16} />
            Dashboard
          </button>
        </div>
      </header>

      <div className="relative overflow-hidden">
        <div className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-emerald-100/40 blur-3xl" />

        <div className="relative mx-auto flex min-h-[calc(100vh-76px)] max-w-4xl items-center justify-center px-4 py-10 sm:px-6 lg:px-8">
          <section className="w-full max-w-2xl overflow-hidden rounded-[30px] border border-[#E2E5E9] bg-white shadow-[0_24px_80px_rgba(15,23,42,0.10)]">
            <div className="px-6 pb-8 pt-10 text-center sm:px-10 sm:pb-10 sm:pt-12">
              <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-emerald-50 ring-8 ring-emerald-50/60">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/25">
                  <FiCheck size={34} strokeWidth={3} />
                </div>
              </div>

              <div className="mt-7">
                <span className="inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-3.5 py-1.5 text-xs font-bold text-amber-700">
                  <FiClock size={14} />
                  Processing
                </span>
              </div>

              <h1 className="mt-5 text-3xl font-black tracking-tight text-[#111318] sm:text-4xl">
                Withdrawal submitted
              </h1>

              <p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-[#68707D] sm:text-base">
                Your withdrawal request has been submitted and is now being
                processed.
              </p>
            </div>

            <div className="border-y border-[#E9EBEF] bg-[#FAFBFC] px-6 py-7 sm:px-10">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-[#E3E6EA] bg-white p-5">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F1F3F6] text-[#4B5563]">
                      <FiClock size={18} />
                    </div>

                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-[#8A919C]">
                        Status
                      </p>
                      <p className="mt-1 text-sm font-bold text-[#111318]">
                        Processing
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#E3E6EA] bg-white p-5">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#F1F3F6] text-[#4B5563]">
                      <FiShield size={18} />
                    </div>

                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-[#8A919C]">
                        Request
                      </p>
                      <p className="mt-1 text-sm font-bold text-[#111318]">
                        Successfully received
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 rounded-2xl border border-[#E3E6EA] bg-white p-5">
                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#0B0E17] text-white">
                    <FiCheck size={19} />
                  </div>

                  <div>
                    <p className="text-sm font-bold text-[#111318]">
                      What happens next?
                    </p>

                    <p className="mt-1.5 text-sm leading-6 text-[#68707D]">
                      Your withdrawal request has been recorded successfully.
                      Processing will continue based on the withdrawal method
                      you selected.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 py-7 sm:px-10 sm:py-8">
              <button
                type="button"
                onClick={() => router.push("/dashboard")}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#0B0E17] px-5 py-4 text-sm font-bold text-white shadow-lg shadow-[#0B0E17]/10 transition hover:bg-[#171B27] active:scale-[0.99]"
              >
                <FiHome size={18} />
                Back to Dashboard
                <FiArrowRight size={18} />
              </button>

              <button
                type="button"
                onClick={() => router.push("/withdraw")}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-[#DDE1E6] bg-white px-5 py-4 text-sm font-bold text-[#3F4652] transition hover:bg-[#F7F8FA] active:scale-[0.99]"
              >
                <FiArrowLeft size={17} />
                Return to Withdrawals
              </button>

              <p className="mt-6 text-center text-xs leading-5 text-[#9AA1AB]">
                You can return to your dashboard while your withdrawal is
                being processed.
              </p>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}