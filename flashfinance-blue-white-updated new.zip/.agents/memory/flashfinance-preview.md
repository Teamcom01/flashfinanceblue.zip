---
name: FlashFinance preview architecture
description: Why the FlashFinance artifact keeps the uploaded Next.js app instead of converting the route tree to a demo or a second frontend.
---

The FlashFinance preview must run the uploaded Next.js application itself. Keep the App Router, Supabase client/server calls, API routes, authentication, and existing route names as the source of truth; the artifact wrapper exists only to provide the managed Preview and production workflow.

**Why:** The uploaded project contains real business logic and server routes that would be lost or weakened by rebuilding the interface as a separate static dashboard.

**How to apply:** Make visual changes inside the app routes and shared CSS, restart the managed FlashFinance workflow after meaningful edits, and verify phone and desktop Preview views before delivering.